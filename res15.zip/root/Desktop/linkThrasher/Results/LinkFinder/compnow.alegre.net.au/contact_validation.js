﻿<!--
var isSubmitted;
$(document).ready(function() {
    isSubmitted = false;
    addValidationControls();
    addValidationEvents();
    addHelperEvents();

//    $("#ctl00_ctl00_cph_content_contact1_ddlReason").click(function() { validateAll(); });
//    $("#ctl00_ctl00_cph_content_contact1_txtName").keyup(function() { validateAll(); });
//	$("#ctl00_ctl00_cph_content_contact1_txtEmail").keyup(function() { validateAll(); });
//	$("#ctl00_ctl00_cph_content_contact1_txtPhone").keyup(function() { validateAll(); });
//	$("#ctl00_ctl00_cph_content_contact1_txtMessage").keyup(function() { validateAll(); });
//	
    //$("input[id$='imageButtonContactContinue']").css("display", "none");
   // validateAll();
    $("input[id$='imageButtonContactContinue']").click(function() {
        isSubmitted = true;
        contactValidation();
       // $("input[id$='imageButtonContactContinue']").
        return false;
    });

//	$("#cmdSave").click(function() { contactValidation(); } );

//    return false;

    //$("#ctl00_ctl00_cph_content_contact1_txtName").focus();
});

function contactValidation()
{
	    if (validateAll() != true)
        {
            return;
        }
        $("#contact-status").html("Sending request...<img src='" + BasePath + "jq/ajax-loader.gif' height='16' width='16' alt='Loading...' />");
        $.ajax(
        {
            url: BasePath + 'contact_submit.aspx',
            data: 'Reason=' + $("#ctl00_ctl00_cph_content_contact1_hidReason").val()
                  + '&Name=' + $("#ctl00_ctl00_cph_content_contact1_txtName").val()
                  + '&Email=' + $("#ctl00_ctl00_cph_content_contact1_txtEmail").val()
                  + '&Phone=' +$("#ctl00_ctl00_cph_content_contact1_txtPhone").val()
                  + '&Message=' + $("#ctl00_ctl00_cph_content_contact1_txtMessage").val()
                  ,
            type: 'post',
            cache: false,
            success:
                function(html)
                {
                    if (html.indexOf("Thanks for contacting us!" != -1))
                    {
                        $("#ctl00_ctl00_cph_content_contact1_lblInfo").html("");
                        $("#contact-status").html(html);
                        //$("#cmdSave").hide();
                        $("input[id$='imageButtonContactContinue']").css("display", "none");
                    }
                    else {
                        $("#ctl00_ctl00_cph_content_contact1_lblInfo").html(html);
                        isSubmitted = false;
                    }
                    
                }
        });
        return;
}

function DetectEnterContact(buttonId)
{
    if (window.event.keyCode == 13)
    {    
        var obj = document.getElementById(buttonId);    
        return obj.click(contactValidation());
    }
}

function validateAll()
{
   // var save = $("#cmdSave");
    var v = validCount();
    if (v) {
        $("input[id$='imageButtonContactContinue']").css("display", "inherit");
    }
        return v;
//    if (v == 3)
//    {
//        //save.removeAttr("disabled");
//        save.removeClass("contact-button-disabled");
//        save.addClass("contact-button");
//        $("#ctl00_ctl00_cph_content_contact1_lblInfo").html("");
//        return true;
//    }
//    else
//    {
//        //save.attr("disabled", "disabled");
//        save.removeClass("contact-button");
//        save.addClass("contact-button-disabled");        
//        $("#ctl00_ctl00_cph_content_contact1_lblInfo").html("We need your contact information.");
//        return false;
//    }
}

function validCount()
{
    var v = 0;
    //v += validateText($("#ctl00_ctl00_cph_content_contact1_ddlReason").val(), $("#ddlReasonValid"), 1, 300, true);
    v += validateText("#ctl00_ctl00_cph_content_contact1_txtName", 2, 150, true);
    v += validateEmail("#ctl00_ctl00_cph_content_contact1_txtEmail", true);
    v += validateText("#ctl00_ctl00_cph_content_contact1_txtPhone", 0, 30, false);
    v += validateText("#ctl00_ctl00_cph_content_contact1_txtMessage", 5, 3500, true);
    return v == 4;
}

//-->