
//Octopus
window.config = {

  site:{
    apiUrl: 'https://api.shop-model.telekom.assurant.de/',
    apiVersion: '1',
  },
  core:{
    cmsApiUrl:  'https://api.shop-model.telekom.assurant.de/api/v1',
    clientCMS: 'b34b480c-fbdf-43a2-83e3-ce03330c31bf',
    parentCMS: 'af2f760f-e66e-48a8-a7d1-34c0aab2a3b1',
    homeComponents: 'Global,Login,DemandsAndNeedsQuestions,CustomerInformation,EligibilityQuestions,PaymentInformation,CreditCardInformation,IBANInformation,ProductSearchResults,SearchPlans,ReviewPlanDetail,Confirmation,Sales,Signature,FooterLayout',
    language: 'de-De',
    program: 'WeCare',
    systemRole: 'NA',
    production: 'false',
    resourceClient: 'WeCare',
    url_AssurantInternalSite: 'https://api.shop-model.telekom.assurant.de/api/v1/resource/GetResourceVersion'
  },
  aul:{
    aulUrl: 'https://model-maconnexion.assurant.fr/aulv1/',
    aulApiUrl: 'https://model-api.maconnexion.assurant.fr/aulv1/',
    aulClient: 'WECARE',
    aulApplicationName: 'GSP-WECARE',
    bypassLogin: 'false',
  },
  oktaSettings:{
    oktaPrefix: 'AUL__WC',  
    oktaBaseUrl: 'https://assurant.oktapreview.com',
    oktaClientId: '0oaq2qf2i1bgZiCYS0h7',
    oktaInternalEndPoint: 'https://id-model.assurant.com',
    oktaIssuer: 'https://assurant.oktapreview.com/oauth2/v1/',
    oktaAuthIssuer: 'https://assurant.oktapreview.com/oauth2/ausppiuqtmYzAsRY60h7',
    oktaAuthorizeUrl: 'https://assurant.oktapreview.com/oauth2/ausppiuqtmYzAsRY60h7/v1/authorize',
  },
  googleAnalytics:{
    gtmId: 'GTM-M6RJX3C',
  },
  sitefinitySettings:{
    resourceEditMode: 'true',
  },
  misc:{
    version: 'NA',
  }
};