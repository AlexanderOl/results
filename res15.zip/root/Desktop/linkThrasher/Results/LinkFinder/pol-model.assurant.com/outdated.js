outdatedBrowserRework({
    browserSupport: {
        'Chrome': 57, // Includes Chrome for mobile devices
        'Edge': 39,
        'Safari': 10,
        'Mobile Safari': 10,
        'Firefox': 50,
        'Opera': 50,
        'Vivaldi': 1,
        'Yandex': { major: 17, minor: 10 },
        'IE': 11
    },
    requireChromeOnAndroid: false,
    isUnknownBrowserOK: false,
    messages: {
        en: {
            outOfDate: "Upgrade your browser.",
            unsupported: "Your browser is not supported.",
            update: {
                web: "Looks like you're using an unsupported browser. As a result, the site may not work properly. \
                Please upgrade your browser to a newer version for the best experience.",
                googlePlay: "Please install Chrome from Google Play",
                appStore: "Please update iOS from the Settings App"
            },
            url: "http://outdatedbrowser.com/",
            callToAction: "Recommended Browsers",
            close: "Close"
        }
    }
});