/**
 * 
 */
var ForgotPasswordForm = window.ForgotPasswordForm || {};

ForgotPasswordForm = {
		
	previousData: {},
		
	setup : function() {
		
		this.previousData = this.getFormData("#forgot-password-form");
		//setup all event binders
		$("input[name=email]").on('blur', this.validateFieldIfTouched);
		$("#forgot-password-form").on('submit', this.validateForm);
		$("#request-activation-email").on('click', this.requestActivation);
	},
	
	getFormData: function(selector) {
		var data = {};
		$(selector).serializeArray().map(function(formMapElement) {
			data[formMapElement.name] = formMapElement.value;
		});
		return data;
	},
	
	validateForm: function(event) {
		var isValid = true;
		$(".error-block").hide();
		var formEle = $(event.currentTarget);
		formEle.serializeArray().map(function(formFieldMap) {
			var isFieldValid = ForgotPasswordForm.validate($("input[name=" + formFieldMap.name + "]")); 
			isValid = isValid & isFieldValid; 
		});
		if (!isValid) {
			event.preventDefault();
			formEle.find(".has-error :input:visible:enabled:first").focus();
		}
	},
	
	validateFieldIfTouched: function(event) {
		var ele = $(event.currentTarget);
		var currVal = ele.val().trim();
		var eleName = ele.attr('name');
		
		if (currVal != ForgotPasswordForm.previousData[eleName]) {
			ForgotPasswordForm.previousData[eleName] = currVal;
			ForgotPasswordForm.validate(ele);
		}
	},
	validate: function(formEle) {
		if (formEle.prop('required')) {
			return ForgotPasswordForm.validateRequiredField(formEle);
		} else {
			return true;
		}
	},
	
	validateRequiredField: function(formEle) {
		var isValid;
		if (formEle.val().trim().length == 0) {
			ForgotPasswordForm.displayInvalidState(formEle);
			isValid = false;
		} else {
			ForgotPasswordForm.displayValidState(formEle);
			isValid = true;
		}
		return isValid;
	},
	displayInvalidState: function(formEle) {
		formEle.closest(".form-group").addClass("has-error");
	},
	displayValidState: function(formEle) {
		formEle.closest(".form-group").removeClass("has-error");
	},
	
	requestActivation: function(event) {
		var key = $(event.currentTarget).data("accountActivationKey");
		var href = $(event.currentTarget).attr('href');
		event.preventDefault();
		var newForm = jQuery('<form>', {
	        'action': href,
	        'method' :'post'
	    }).append(jQuery('<input>', {
	        'name': 'accountActivationKey',
	        'value': key,
	        'type': 'hidden'
	    }));
		
		$('body').append(newForm);
		newForm.submit();
	}

};
