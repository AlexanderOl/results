window.warehouseMapping = {};

function maskWarehouses() {
	$(".masked-warehouse").each(function(index, dom) {
		var warehouse = ($(dom) && $(dom).text() && $(dom).text().trim()) || "";
		var masked = window.warehouseMapping[warehouse];
		if(masked) {
			$(dom).text(masked);			
		}
		$(dom) && $(dom).css("visibility", "visible");
	});
	return true;
}

function fetchWarehouseMasks() {
	$.ajax({
		type : "GET",
		url : "/api/warehouse/v1/descriptions",
	    contentType: "application/json",
		success: function(response) {
			window.warehouseMapping = response;
			window.maskWarehouses();
		},
		error: function(response) {
			console.log(response);
		}
	});
}

$(document).ready(function() {
	window.fetchWarehouseMasks();
});