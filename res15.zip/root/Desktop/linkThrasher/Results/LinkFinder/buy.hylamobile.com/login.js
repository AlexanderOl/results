/**
 *
 */
var LoginForm = window.LoginForm || {};

LoginForm = {
  previousData: {},

  setup: function () {
    this.previousData = this.getFormData("#login-form");
    //setup all event binders
    $("input[name=j_username]").on("blur", this.validateFieldIfTouched);
    $("input[name=j_password]").on("blur", this.validateFieldIfTouched);
    $("#login-form").on("submit", this.validateForm);
  },

  getFormData: function (selector) {
    var data = {};
    $(selector)
      .serializeArray()
      .map(function (formMapElement) {
        data[formMapElement.name] = formMapElement.value;
      });
    return data;
  },

  validateForm: function (event) {
    var isValid = true;
    $(".error-block").hide();
    var formEle = $(event.currentTarget);
    formEle.serializeArray().map(function (formFieldMap) {
      var isFieldValid = LoginForm.validate(
        $("input[name=" + formFieldMap.name + "]")
      );
      isValid = isValid & isFieldValid;
    });
    if (!isValid) {
      event.preventDefault();
      formEle.find(".has-error :input:visible:enabled:first").focus();
    }
  },

  validateFieldIfTouched: function (event) {
    var ele = $(event.currentTarget);
    var currVal = ele.val().trim();
    var eleName = ele.attr("name");

    if (currVal != LoginForm.previousData[eleName]) {
      LoginForm.previousData[eleName] = currVal;
      LoginForm.validate(ele);
    }
  },
  validate: function (formEle) {
    if (formEle.prop("required")) {
      return LoginForm.validateRequiredField(formEle);
    } else {
      return true;
    }
  },

  validateRequiredField: function (formEle) {
    var isValid;
    if (formEle.val().trim().length == 0) {
      LoginForm.displayInvalidState(formEle);
      isValid = false;
    } else {
      LoginForm.displayValidState(formEle);
      isValid = true;
    }
    return isValid;
  },
  displayInvalidState: function (formEle) {
    formEle.closest(".form-group").addClass("has-error");
  },
  displayValidState: function (formEle) {
    formEle.closest(".form-group").removeClass("has-error");
  },
};

const isNewCustomer = localStorage.getItem("isNewCustomer");
if (!isNewCustomer) localStorage.setItem("isNewCustomer", true);
