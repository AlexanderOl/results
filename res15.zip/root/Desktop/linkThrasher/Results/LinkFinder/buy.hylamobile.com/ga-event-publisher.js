var GaEventPublisher = window.GaEventPublisher || {};

GaEventPublisher = {
	// items - one or more buttons or hyperlinks with data-ga-label (required)
	// OR
	// items - one or more buttons or hyperlinks with data-ga-label (required), data-category (default: Button), data-ga-exclude-location (default: false), data-action (default: Push)
	listenEvents: function(items) {
		if(!items) {
			return;
		}
		if(items.length <= 1) {
			items = [items];
		}
		
		$.each(items, function(index, item) {
			var item = $(item);
			if(item && item.data("ga-label")) {
				item.on("click", function(event) {
					// default
					var excludeLocation = false;
					var category = 'Button';
					var action = 'Push';
					var label = window.location.pathname + " " + item.data("ga-label");
					
					// overwrite if given
					if(item.data("ga-exclude-location")) { 
						excludeLocation = item.data("ga-exclude-location") == true; 
					}
					if(item.data("ga-category")) {
						category = item.data("ga-category");
					}
					if(item.data("ga-action")) {
						action = item.data("ga-action");
					}
					if(excludeLocation) {
						label = item.data("ga-label");
					}
					
					ga('send', 'event', {
						eventLabel: label,
						eventCategory: category,
						eventAction: action
					});
				});
			}
		});
	}
}
		