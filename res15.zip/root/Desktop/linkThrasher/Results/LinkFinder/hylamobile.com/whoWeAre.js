
(function ($, w) {
    w.init = function () {
        bindEvents();
    };

    //Private Helper Functions

    var bindEvents = function () {
        $('#profile-management').on('show.bs.modal', onProfileModalShow);
    };

    var onProfileModalShow = function (e) {
        var parentEl = $(e.relatedTarget);
        var imageEl = $(parentEl).children('#profile-modal-image');
        var imageHtml = $($(imageEl).html());

        $(imageHtml).addClass('img-responsive');

        $('#profile-image-placeholder').html(imageHtml);
        $('#profile-title-placeholder').html($(parentEl).find('#profile-modal-title').html());
        $('#profile-bio-placeholder').html($(parentEl).find('#profile-modal-bio').html());
        $('#profile-name-placeholder').html($(parentEl).find('#profile-modal-name').html());
    };

    var buildCarouselBreadCrumbs = function () {
        var cardsLength = $('.bg-card-cluster').find('.card-block').length;

    };

})($, window.whoWeAreFn = window.whoWeAreFn || {});

(function () {
    $(document).ready(function () {
        whoWeAreFn.init();
        function isElementInViewportLeftRight(elem) {
            var $elem = $(elem);

            // Get the scroll position of the page.
            var scrollElem = ((navigator.userAgent.toLowerCase().indexOf('webkit') != -1) ? 'body' : 'html');
            var viewportLeft = $(scrollElem).scrollLeft();
            var viewportRight = viewportLeft + $(window).width();

            // Get the position of the element on the page.
            var elemLeft = Math.round($elem.offset().left) + 100;
            var elemRight = elemLeft + $elem.width() - ($(window).width() / 2);
            return ((elemLeft < viewportRight) && (elemRight > viewportLeft));
        }

        // Check if we're in each section to highlight it in the navbar 
        function checkSectionInView() {
            var listOfSectionElem = [
                '#overview-blurb',
                '#core-values',
                '#community',
                '#history-matters',
                '#leadership'
            ];

            listOfSectionElem.forEach(function (element) {
                var elem = $(element);

                //check if element is visible
                // if (isElementInViewport(elem)) {
                //     // highlight in main-secondary-nav
                //     $('#main-secondary-nav .nav-tabs .active').removeClass('active');
                //     $('#main-secondary-nav .nav-tabs [href=' + element + ']').closest('li').addClass('active');
                // }
            });
        }

        function carouselBreadcrumbs() {
            
            $('.management .card-carousel').scroll(function (e) {
                $('.management .card-carousel li').each(function (index) {
                    if (isElementInViewportLeftRight('.management .card-carousel li:nth-child(' + (index + 1) + ')')) {
                        if (!$('.management .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').hasClass('active')) {
                            $('.management .card-carousel-breadcrumbs .active').removeClass('active');
                            $('.management .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').addClass('active');
                        }
                        return false;
                    }
                });
            });

            $('.directors .card-carousel').scroll(function (e) {
                $('.directors .card-carousel li').each(function (index) {
                    if (isElementInViewportLeftRight('.directors .card-carousel li:nth-child(' + (index + 1) + ')')) {
                        if (!$('.directors .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').hasClass('active')) {
                            $('.directors .card-carousel-breadcrumbs .active').removeClass('active');
                            $('.directors .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').addClass('active');
                        }
                        return false;
                    }
                });
            });

            $('.regional .card-carousel').scroll(function (e) {
                $('.regional .card-carousel li').each(function (index) {
                    if (isElementInViewportLeftRight('.regional .card-carousel li:nth-child(' + (index + 1) + ')')) {
                        if (!$('.regional .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').hasClass('active')) {
                            $('.regional .card-carousel-breadcrumbs .active').removeClass('active');
                            $('.regional .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').addClass('active');
                        }
                        return false;
                    }
                });
            });
        }

        //timeline callback
        var timeLineCallback = function (obj) {
            $('.timeline .expanded').removeClass('expanded');
            $('.timeline-point-info .start').removeClass('start');

            $(obj).addClass('expanded');

            //show associating point info
            $('.timeline-point-info [point-info]').addClass('hidden');
            var year = $(obj).attr('point');
            var pointInfo = $('.timeline-point-info [point-info=' + year + ']');
            pointInfo.removeClass('hidden');

            pointInfo.find('.layout-lt-content').addClass('start');
            pointInfo.find('.layout-rt-content').addClass('start');

            $('.timeline-point-container').attr('aria-selected', false);
            $(obj).attr('aria-selected', true);
        }

        //timeline event listener
        $('.timeline .timeline-point-container').on('click', function () { timeLineCallback(this); });
        $('.timeline .timeline-point-container').on('keypress', function (ev) {
            var keycode = (ev.keyCode ? ev.keyCode : ev.which);
            if (keycode == '13') timeLineCallback(this);
        });

        //on timeline overflow right clicked
        $('.timeline-arrow-right').on('click', function () {
            var timelineScrollPostion = $('.timeline').scrollLeft();
            $('.timeline').animate({ scrollLeft: timelineScrollPostion + ($(window).width() * 0.5) }, 500);

            //since animation is 500ms long 
            setTimeout(function () {
                timelineOverflow();
            }, 500);
        });

        //on timeline overflow left clicked
        $('.timeline-arrow-left').on('click', function () {
            var timelineScrollPostion = $('.timeline').scrollLeft();
            $('.timeline').animate({ scrollLeft: timelineScrollPostion - ($(window).width() * 0.5) }, 500);

            //since animation is 500ms long 
            setTimeout(function () {
                timelineOverflow();
            }, 500);
        });

        function timelineOverflow() {
            //disabled timeline overflow left arrow when there is nothing left on the left side
            if ($('.timeline').scrollLeft() == 0) {
                $('.timeline-arrow-left').addClass('disabled');
            }
            else if ($('.timeline-arrow-left').hasClass('disabled')) {
                $('.timeline-arrow-left').removeClass('disabled');
            }

            //disables timeline overflow right arrow when there is nothing left on the right side
            if ($('.timeline').scrollLeft() >= ($(window).width() - 1)) {
                $('.timeline-arrow-right').addClass('disabled');
            }
            else if ($('.timeline-arrow-right').hasClass('disabled')) {
                $('.timeline-arrow-right').removeClass('disabled');
            }
        }

        //functionality on mobile versus desktop
        if ($(window).width() < 768) {
            onMobile();
        }
        $(window).resize(function () {
            if ($(window).width() < 768) {
                onMobile();
            }
            else {
                onDesktop();
            }
        });

        function onMobile() {
            //carouselBreadcrumbs();
            timelineOverflow();
            //move in the community title to above the graphic 
            $('#community-title').insertBefore('#community .layout-lt-graphic');
        }

        function onDesktop() {
            //move in the community title to below the graphic
            $('#community-title').insertBefore('#community .layout-rt-content .section-content');
        }

        // Capture scroll events
        $(window).scroll(function () {

            if ($(window).width() > 768) {
                checkSectionInView();
            }
        });
    });
})();