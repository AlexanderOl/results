(function ($, p) {
    p.init = function () {
        bindEvents();

        // For Bug 155661: On keyboard enter click card details will be shown in bootstrap modal popup.
        // For Card.Icons-Modal.cshtml template
        $('.icon-partners-modal').keyup(function (e) {
            var key = e.which;
            if (key == 13)  // the enter key code
            {
                $(this).click();
                return false;     
            }
        });
    };

    //Private Helper Functions

    var bindEvents = function () {
        $('#icons-partners-modal').on('show.bs.modal', onPartnersModalShow);
    };

    var onPartnersModalShow = function (e) {
        var parentEl = $(e.relatedTarget);
        var imageEl = $(parentEl).children('#partners-modal-image');
        var transferClass = $(imageEl).data('transferClass');
        var imageHtml = $($(imageEl).html());
        $(imageHtml).addClass(transferClass);

        $('#partners-image-placeholder').html(imageHtml);
        $('#partners-heading-placeholder').html($(parentEl).children('#partners-modal-heading').html());
        $('#partners-content-placeholder').html($(parentEl).children('#partners-modal-content').html());
        $('#partners-action-placeholder').html($(parentEl).children('#partners-modal-action').html());
    };
})($, window.partnersFn = window.partnersFn || {});

(function () {
    $(document).ready(function () {
        partnersFn.init();

        function isElementInViewportLeftRight(elem) {
            var $elem = $(elem);

            // Get the scroll position of the page.
            var scrollElem = ((navigator.userAgent.toLowerCase().indexOf('webkit') != -1) ? 'body' : 'html');
            var viewportLeft = $(scrollElem).scrollLeft();
            var viewportRight = viewportLeft + $(window).width();

            // Get the position of the element on the page.
            var elemLeft = Math.round($elem.offset().left) + 100;
            var elemRight = elemLeft + $elem.width() - ($(window).width() / 2);
            return ((elemLeft < viewportRight) && (elemRight > viewportLeft));
        }

        // Check if we're in each section to highlight it in the navbar
        function checkSectionInView() {
            var listOfSectionElem = [
                '#overview-blurb',
                '#featured-insights',
                '#partners',
                '#capabilities',
                '.layout-card-row-list'
            ];

            listOfSectionElem.forEach(function (element) {
                var elem = $(element);

                //check if element is visible
                // if (isElementInViewport(elem)) {
                //     // highlight in main-secondary-nav
                //     $('#main-secondary-nav .nav-tabs .active').removeClass('active');
                //     $('#main-secondary-nav .nav-tabs [href=' + element + ']').closest('li').addClass('active');
                // }
            });
        }

        //functionality on mobile versus desktop
        if ($(window).width() < 768) {
            onMobile();
        }
        $(window).resize(function () {
            if ($(window).width() < 768) {
                onMobile();
            }
            else {
                onDesktop();
            }
        });

        function onMobile() {
            carouselBreadcrumbs();
            //convert tabs to accordion for the integrated capabilities section
            $('.layout-tabs-accordion .tab-pane').each(function () {
                $(this).removeClass('tab-pane').addClass('collapse');
                if ($(this).hasClass('active')) {
                    $(this).removeClass('active').addClass("in");
                }
            });

            //move featured insights title to above the graphic
            $('#layout-title-content').insertBefore('#featured-insights .layout-lt-graphic');
        }

        function onDesktop() {
            //convert accordion to tabs for the integrated capabilities section
            $('.layout-tabs-accordion .collapse.in').first().addClass('active');
            $('.layout-tabs-accordion .collapse').each(function () {
                $(this).addClass('tab-pane').removeClass('collapse');
                if ($(this).hasClass('in')) {
                    $(this).removeClass("in");
                }
            });

            //move featured insights title to below the graphic
            $('#layout-title-content').insertBefore('#featured-insights .layout-rt-content .section-content');
        }

        function carouselBreadcrumbs() {
            $('.layout-card-row-list .card-carousel').scroll(function (e) {
                $('.layout-card-row-list .card-carousel .card').each(function (index) {
                    if (isElementInViewportLeftRight($(this))) {
                        if (!$('.layout-card-row-list .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').hasClass('active')) {
                            $('.layout-card-row-list .card-carousel-breadcrumbs .active').removeClass('active');
                            $('.layout-card-row-list .card-carousel-breadcrumbs li:nth-child(' + (index + 1) + ')').addClass('active');
                        }
                        return false;
                    }
                });
            });
        }

        // Capture scroll events
        $(window).scroll(function () {
            if ($(window).width() > 768) {
                checkSectionInView();
            }
        });
    });
})();