﻿$(document).ready(function () {
    /*
    * This logic shows/hides the self-service portal link and description sections for the selected insurance 
    * product on a Help Center SSP page for an insurance type.
    */
    $("#insuranceproduct-dropdown").change(function () {
        var selectedProduct = $("#insuranceproduct-dropdown option:selected").val();
        $(".helpcenter-ssp-productaction-section").hide();
        $(".helpcenter-ssp-productdescription-section").hide();

        if (selectedProduct != "select") {
            selectedProduct = "." + selectedProduct;
            $(selectedProduct).show();
        }
    });
});
