window.appConfig = {
  gl2ServerUrl: '/api/',
  gl2AppPathPrefix: '/',
  rootTimeZone: 'UTC',
  pluginUISettings: {
  "org.graylog.plugins.customization.theme" : { },
  "org.graylog.plugins.customization.notifications" : { }
},
  isCloud: false,
  featureFlags: { },
};
