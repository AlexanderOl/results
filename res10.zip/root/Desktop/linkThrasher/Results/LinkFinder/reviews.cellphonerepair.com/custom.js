/*
 Author: Umair Chaudary @ Pixel Art Inc.
 Author URI: http://www.pixelartinc.com/
 */


function equalHeight(group) {
    tallest = 0;
    group.each(function() {
        thisHeight = $(this).height();
        if(thisHeight > tallest) {
            tallest = thisHeight;
        }
    });
    group.height(tallest);
}

$(window).load(function(){
	//fixSidebarHeight();
});

$(window).resize(function(){
	//fixSidebarHeight(true);
});

function fixSidebarHeight(resize) {
    /*
	var width = $(window).width();
    if(width>960)
	{
		equalHeight($(".equal_colum"));
	}
	else if(resize == true)
	{
		$('.sidebar').css('height', 'auto');
	}
	*/
}

$(document).ready(function(e) {
    

    $('.tooltip').tooltipster({
        position: 'top'
    });

    //$("select").selectBox();

    $(".navigation li ").hover(function(){
        $(this).children('ul').stop(true, true).slideDown(500);
    }, function(){
        $(this).children('ul').stop(true, true).slideUp(500);
    });

    $(".alrt ").hover(function(){
        $('.tips', $(this)).stop(true, true).fadeIn();
    }, function(){
        $('.tips', $(this)).stop(true, true).fadeOut();
    });

    function open_social(){
        $(".title_bar .plus").click(function(e){
            e.preventDefault();
            $(".social_bar").stop(true, true).slideDown(500);
            $(this).addClass('minus');
            close_social();
        });
    }
    open_social();
    function close_social(){
        $(".title_bar .minus").click(function(e){
            e.preventDefault();
            $(".social_bar").stop(true, true).slideUp(500);
            $(this).removeClass('minus');
            open_social();
        });
    }

	/*
    function open_social(){
        $(".title_bar .plus").click(function(e){
            e.preventDefault();
            $(".social_bar").stop(true, true).slideDown(500);
            $(this).addClass('minus');
            close_social();
        });
    }
    open_social();
    function close_social(){
        $(".title_bar .minus").click(function(e){
            e.preventDefault();
            $(".social_bar").stop(true, true).slideUp(500);
            $(this).removeClass('minus');
            open_social();
        });
    }
    */

    function open_faq(){
        $(".faq-button").click(function(e){
            e.preventDefault();
            $(".faq_bar").stop(true, true).slideDown(500);
            $(this).addClass('minus');
            close_faq();
        });
    }
    open_faq();
    function close_faq(){
        $(".faq-button").click(function(e){
            e.preventDefault();
            $(".faq_bar").stop(true, true).slideUp(500);
            $(this).removeClass('minus');
            open_faq();
        });
    }

    function open_list(){
        $(".user .username").click(function(e){
            e.preventDefault();
            $(".login_list").stop(true, true).slideDown(500);
            $(this).addClass('minus');
            close_list();
        });
    }
    open_list();
    function close_list(){
        $(".user .minus").click(function(e){
            e.preventDefault();
            $(".login_list").stop(true, true).slideUp(500);
            $(this).removeClass('minus');
            open_list();
        });
    }

    function open_nav(){
        $(".responsive_nav  .open").click(function(e){
            $(this).children('ul').stop(true, true).slideDown(500);
            $(this).removeClass('open').addClass('close-nav');
            close_nav();
        });
    }
    open_nav();
    function close_nav(){
        $(".responsive_nav .close-nav").click(function(e){
            $(this).children('ul').stop(true, true).slideUp(500);
            $(this).removeClass('close-nav').addClass('open');
            open_nav();
        });
    }


});

var matched, browser;

jQuery.uaMatch = function( ua ) {
    ua = ua.toLowerCase();

    var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
        /(webkit)[ \/]([\w.]+)/.exec( ua ) ||
        /(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
        /(msie) ([\w.]+)/.exec( ua ) ||
        ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
        [];

    return {
        browser: match[ 1 ] || "",
        version: match[ 2 ] || "0"
    };
};

matched = jQuery.uaMatch( navigator.userAgent );
browser = {};

if ( matched.browser ) {
    browser[ matched.browser ] = true;
    browser.version = matched.version;
}

// Chrome is Webkit, but Webkit is also Safari.
if ( browser.chrome ) {
    browser.webkit = true;
} else if ( browser.webkit ) {
    browser.safari = true;
}

jQuery.browser = browser;
