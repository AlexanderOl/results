define("Video",[],function(){var a='<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" frameborder="0" border="0" scroll="no" allowfullscreen scrolling="no"></iframe></div>',c=$(window);
function b(d){this.$el=d;
var e=this.$el.data("isPopup");
if(e){this.$playButton=this.$el.find("."+this.classes.button);
this.initPopup()
}else{this.$player=this.$el.find("."+this.classes.player);
this.$parent=this.$el.parent().parent();
this.$wrap=this.$el.find(".video__wrap");
this.width=parseInt(this.$wrap.data("width"));
this.height=parseInt(this.$wrap.data("height"));
this.aspectRatio=this.height/this.width;
c.on("resize",this.resizeVideo.bind(this));
this.resizeVideo();
if(this.$el.parents(".tabs-ui").length){c.on("tab.changed",this.resizeVideo.bind(this))
}}}b.prototype.initPopup=function(){var d={type:"iframe",disableOn:240,preloader:true,fixedContentPos:true,iframe:{patterns:{youtube:{index:"youtube.com/",id:"v=",src:this.$playButton.data("mfp-src")}},markup:a}};
this.$playButton.magnificPopup(d)
};
b.prototype.resizeVideo=function(){this.$wrap.css("padding-bottom",this.aspectRatio*100+"%")
};
b.prototype.classes={player:"video__player",button:"video__button"};
b.moduleName="Video";
b.selector=".video-ui";
return b
});
define("TitleSlider",["media","utils-env"],function(g,e){var d={slider:".title-slider__list",slide:".title-slider__slide",active:"active",switcherItem:".title-slider__switcher-button",switcherItemActive:"title-slider__switcher-button--active",row:".title-slider__slide-row",animation:"title-slider__slide-row--animatable",notAnimated:"title-slider--not-animated",switcherMessage:".title-slider__switcher-message"};
var c={nextSlide:"slide.next",prevSlide:"slide.prev"};
var a="(Current Item)";
var f=[];
function b(h){this.$el=h;
this.$slider=h.find(d.slider);
this.$items=h.find(d.slide);
this.$switcherItem=h.find(d.switcherItem);
this.$row=h.find(d.row);
this.$switcherMessage=h.find(d.switcherMessage);
this.slideLength=this.$items.length;
this.playspeed=h.data("playSpeed")*1000;
this.freezeSlider=false;
this.autoRotation=true;
this.isEditMode=e.isEditMode();
if(this.$el.hasClass(d.notAnimated)){return
}this.init();
f.push(this)
}b.prototype.init=function(){this.$switcherItem.on("click",this.onItemClick.bind(this));
if(Modernizr.touchevents&&g.currentMode().lessThan(g.modes.Desktop)){this.$slider.on("swipeleft",this.nextSlide.bind(this));
this.$slider.on("swiperight",this.prevSlide.bind(this));
this.$slider.on("swiperight swipeleft",this.stopAutoplay.bind(this))
}this.switchSlide(0);
this.startAutoplay();
this.$el.on(c.nextSlide,this.nextSlide.bind(this));
this.$el.on(c.prevSlide,this.prevSlide.bind(this))
};
b.prototype.nextSlide=function(){this.switchSlide(this.index<this.slideLength-1?this.index+1:0)
};
b.prototype.prevSlide=function(){this.switchSlide(this.index>0?this.index-1:this.slideLength-1)
};
b.prototype.switchSlide=function(h){if(h===this.index||this.freezeSlider){return
}var j=this.$items.eq(this.index).find(d.row),i=this.$items.eq(h).find(d.row);
this.freezeSlider=true;
this.toggleRowClass(j,false).promise().done(function(){this.toggleRowClass(i,true);
this.freezeSlider=false
}.bind(this));
this.updateSwitcher(h);
this.handleFocusState(i);
this.$items.eq(this.index).removeClass(d.active);
this.$items.eq(h).addClass(d.active);
this.index=h
};
b.prototype.handleFocusState=function(h){!this.autoRotation&&h.last().on("transitionend",function(){this.$items.eq(this.index).focus();
h.last().off("transitionend")
}.bind(this))
};
b.prototype.updateSwitcher=function(h){this.$switcherItem.removeClass(d.switcherItemActive);
this.$switcherItem.eq(h).addClass(d.switcherItemActive);
this.$switcherMessage.empty();
this.$switcherMessage.eq(h).text(a)
};
b.prototype.toggleRowClass=function(h,k){var i=this.isEditMode?0:500,j=this.isEditMode?0:300;
return h.delay(i).each(function(l){$(this).delay(j*l).queue(function(){$(this).toggleClass(d.animation,k).dequeue()
})
})
};
b.prototype.onItemClick=function(h){this.stopAutoplay();
this.switchSlide($(h.target).data("index"))
};
b.prototype.startAutoplay=function(){if(this.playspeed<1||this.isEditMode){return
}this.interval=setInterval(function(){this.nextSlide()
}.bind(this),this.playspeed)
};
b.prototype.stopAutoplay=function(){this.autoRotation=false;
clearInterval(this.interval)
};
b.moduleName="Title Slider";
b.activatedComponents=f;
b.events=c;
b.selector=".title-slider-ui";
return b
});
define("Text",["utils"],function(a){function b(c){this.$el=c;
this.$el.find("table").wrap('<div class="'+this.classes.tableWrapper+'"></div>');
a.insertArrowForLinks(this.$el)
}b.prototype.classes={tableWrapper:"text__table-wrapper"};
b.moduleName="Text";
b.selector=".text-ui";
return b
});
define("Tabs",["TabsUtil","utils","media","jquery-plugins"],function(f,a,d){var e=$(window);
var c={title:".tabs__title",hideDivider:"tabs__title--no-divider"};
function b(g){f.call(this,g,{useHistory:true,responsiveView:true,responsiveBreakpoint:d.modes.Tablet.end,autoWidth:true,nav:false,dots:false});
this.$titles=this.$el.find(c.title);
e.on("popstate",this.onPopState.bind(this));
a.checkDividers(this.$titles,c.hideDivider);
a.redirectToPageAnchor()
}b.prototype=Object.create(f.prototype);
b.prototype.onPopState=function(j){var h='[href="'+location.hash+'"]',g=this.$links.filter(h),i=g.data("item");
if(!g.length&&j.state){history.back()
}g.length&&this.$el.trigger(f.events.tabChange,{tab:i})
};
b.moduleName="Tabs";
b.selector=".tabs-ui";
return b
});
define("SliderWithParallax",["utils-env","utils","media"],function(e,a,f){var b=$("html");
var d={slides:"slider-with-parallax__wrapper > div",slidesChild:"slider-with-parallax__single-slide",slider:"slider-with-parallax__wrapper",cueWrapper:"slider-with-parallax__cue-wrapper",textContainers:"slider-with-parallax__single-slide-text",sliderNavigation:"slider-navigation",slideText:"slider-with-parallax__single-slide-text",dots:"slider-with-parallax__cue-item",singleSlideImageWrapper:".slider-with-parallax__single-slide-image-wrapper"};
function c(g){this.$el=g;
this.$slider=this.$el.find("."+d.slider);
this.$slides=this.$el.find("."+d.slides);
this.$slidesChild=this.$el.find("."+d.slidesChild);
this.$cueWrapper=this.$el.find("."+d.cueWrapper);
this.$sliderTextContainers=this.$el.find("."+d.textContainers);
this.$speed=this.$el.attr("data-play-speed");
this.isTestIO=this.$el.attr("class").indexOf("test-io")!==-1;
this.$slideText=this.$el.find("."+d.slideText);
this.$sliderTimerId=null;
this.$slideLinks=this.$el.find("a");
this.handle={};
this.isAnimationRunning=false;
this.pause=false;
this.focus=false;
this.init();
a.applyShadowOnImage(this.$el,this.$el.find(d.singleSlideImageWrapper));
a.insertArrowForLinks(this.$el)
}c.prototype.init=function(){if(e.isEditMode()){return
}this.initEvents();
this.initSlides();
this.createCue();
$.onFontLoad(this.fontLoadedCallback.bind(this));
this.runAutoSlideFlip()
};
c.prototype.fontLoadedCallback=function(){this.setCue();
this.adjustSliderHeight()
};
c.prototype.adjustSliderHeight=function(){var g=this.$slidesChild[0].getBoundingClientRect().height;
$.each(this.$slidesChild,function(k,j){var l=j.getBoundingClientRect().height;
if(g<l){g=l
}});
var h=f.currentMode().lessThan(f.modes.Tablet);
var i=this.isTestIO&&h?699:869;
if(g<=i){return
}this.$slider.css("height",g);
$.each(this.$slidesChild,function(k,j){$(j).css("height",g)
})
};
c.prototype.stopAutoSlideFlip=function(){clearInterval(this.$sliderTimerId);
this.$sliderTimerId=null
};
c.prototype.runAutoSlideFlip=function(){if(!this.$sliderTimerId&&!this.$el.find(":focus").length){this.focus=false;
this.$sliderTimerId=setInterval(function(){this.moveForward()
}.bind(this),this.$speed*1000)
}};
c.prototype.getCurrentSlide=function(){return this.$slider.find(".active-slide")
};
c.prototype.initSlides=function(){this.$el.removeClass("author");
$.each(this.$slides,function(i,h){$(h).attr("data-index",i).addClass("hidden-slide")
});
$(this.$slides[0]).addClass("active-slide");
this.sliderL=this.$slides.length-1;
var g=this.$slides.length;
$.each(this.$slideText,function(i,h){$(h).attr("aria-label",i+1+" of "+g)
})
};
c.prototype.nextSlide=function(){var g=parseInt(this.getCurrentSlide().attr("data-index"));
if(g===this.sliderL){return $(this.$slides[0])
}return $(this.$slides[g+1])
};
c.prototype.prevSlide=function(){var g=parseInt(this.getCurrentSlide().attr("data-index"));
if(g===0){return $(this.$slides[this.sliderL])
}return $(this.$slides[g-1])
};
c.prototype.moveForward=function(h,g){if(this.isAnimationRunning){return
}this.isAnimationRunning=true;
var i=this.getCurrentSlide();
this.next=g?g:this.nextSlide();
this.$slider.find(".active-slide").removeClass("active-slide");
i.addClass("current");
this.next.addClass("next").addClass("active-slide");
this.updateCue(this.next.attr("data-index"))
};
c.prototype.createCue=function(){this.$sliderNavigation=$(document.createElement("ul"));
this.$sliderNavigation.attr("role","tablist").attr("class",d.sliderNavigation).attr("aria-label","Slides");
this.$sliderNavigation.on("keydown",this.cueKeyPressHandler.bind(this));
this.$sliderNavigation.on("focusin",function(){if(b.hasClass("key-used")){this.stopAutoSlideFlip();
this.focus=true
}else{if(!this.$sliderTimerId){this.runAutoSlideFlip()
}}}.bind(this));
for(var h=0;
h<=this.sliderL;
h++){var j=document.createElement("span");
var g=$(document.createElement("li"));
j.className="sr-only";
j.textContent="Slide "+(h+1)+this.$slideText[h].textContent;
g.append(j);
g.attr("data-index",h).attr("role","tab");
if(h===0){g.attr("tabindex",0).addClass("slider-with-parallax__cue-item cue-active")
}else{g.attr("tabindex",-1).addClass("slider-with-parallax__cue-item")
}this.$sliderNavigation.append(g)
}this.$cueWrapper.children().append(this.$sliderNavigation)
};
c.prototype.cueKeyPressHandler=function(g){var i=g.key;
var h=null;
if(i==="ArrowLeft"){h=this.prevSlide()
}if(i==="ArrowRight"){h=this.nextSlide()
}if(i==="ArrowLeft"||i==="ArrowRight"){this.focus=true;
this.moveForward(null,h)
}};
c.prototype.getCueRect=function(){if(this.$sliderTextContainers.length===0){return{bottom:714}
}var j=this.$sliderTextContainers[0];
var i=$(j).innerHeight();
$.each(this.$sliderTextContainers,function(m,l){var k=$(l).innerHeight();
if(i<k){i=k;
j=l
}});
var h=j.getBoundingClientRect().bottom+window.pageYOffset;
var g=this.$el[0].getBoundingClientRect().top+window.pageYOffset;
return{bottom:h-g}
};
c.prototype.updateCue=function(g){this.$cueWrapper.find(".cue-active").removeClass("cue-active");
this.$cueWrapper.find('[data-index="'+g+'"]').addClass("cue-active");
this.$sliderNavigation.find("[tabindex=0]").attr("tabindex",-1);
var h=this.$sliderNavigation.find(".cue-active");
h.attr("tabindex",0);
if(this.focus){h.focus();
this.focus=false
}};
c.prototype.endOfAnimation=function(g){if(!$(g.target).hasClass("active-slide")){return
}this.isAnimationRunning=false;
this.$slider.find(".current, .next").removeClass("next current")
};
c.prototype.setCue=function(){var g=this.getCueRect();
this.$cueWrapper.css({top:g.bottom+"px"})
};
c.prototype.resizeHandler=function(){this.setCue()
};
c.prototype.cueEventHandler=function(g){if(this.isAnimationRunning){return
}var h=$(g.target);
if(!h.hasClass("slider-with-parallax__cue-item")){return
}this.moveForward(null,this.$slider.find('[data-index="'+h.attr("data-index")+'"]'))
};
c.prototype.swipeRightHandler=function(){if(this.isAnimationRunning){return
}this.moveForward(null,this.prevSlide())
};
c.prototype.swipeLeftHandler=function(){if(this.isAnimationRunning){return
}this.moveForward(null,this.nextSlide())
};
c.prototype.initEvents=function(){this.$slider.on("animationend",this.endOfAnimation.bind(this));
this.$cueWrapper.on("click",this.cueEventHandler.bind(this));
this.$slider.on("swipeleft",this.swipeLeftHandler.bind(this));
this.$slider.on("swiperight",this,this.swipeRightHandler.bind(this));
this.$el.on("focusout",this.runAutoSlideFlip.bind(this));
this.$el.on("mousemove",a.debounceExtend(function(){this.stopAutoSlideFlip()
}.bind(this),200));
this.$el.on("mouseleave",a.debounceExtend(function(){this.runAutoSlideFlip()
}.bind(this),200));
this.$slideLinks.on("focusin",this.stopAutoSlideFlip.bind(this));
$(window).on("resize",a.debounceExtend(this.resizeHandler.bind(this),300))
};
c.moduleName="SliderWithParallax";
c.selector=".slider-with-parallax-ui";
return c
});
define("Slider",["utils-env","imager","constants","ResponsiveImage","utils","SliderA11YLayer"],function(h,b,g,c,a,e){var f={nav:"slider__navigation",dot:"slider__dot",sliderSlide:"slider__slide",active:".active",sliderDrag:"slider--drag",sliderLoaded:"slider--loaded",expanded:"slider--expanded",twoCellsSlideUi:".two-cells-slide-ui",singleSlideUi:"single-slide-ui",singleSlider:"slider--single",singleSlideContent:".single-slide__content",twoCellsSlideContent:".two-cells-slide__content",sliderPositionContentSide:"slider-position-content-side",twoCellsSlideContentLeft:"two-cells-slide__content-left",twoCellsSlideContentRight:"two-cells-slide__content-right"};
function d(i){this.$el=i;
this.isEditMode=h.isEditMode();
this.isExpanded=this.$el.hasClass(f.expanded);
this.itemCount=this.$el.children().length;
this.$sliderSlide=i.find("."+f.sliderSlide);
this.playspeed=this.$el.data("playSpeed");
this.dotsColor=this.$el.data("dots-color");
this.dotActiveColor=this.$el.data("dot-active-color");
this.isDragging=false;
this.config=$.extend({},this.defaultConfig,this.playspeed?{autoplayTimeout:this.playspeed*1000,onDragged:this.stopAutoplay.bind(this),lazyLoadEager:0,dotsData:true}:{autoplay:false},{dotClass:f.dot+" "+this.dotsColor});
this.setDotsHiddenText();
this.initSliding(h.isEditMode());
this.setDotsPosition();
this.initEvents();
if(this.$sliderA11YLayer){this.$sliderA11YLayer.adjustSliderButtonsAndLinksTabindex()
}a.applyShadowOnImage(this.$el,this.$el.find(".single-slide__image--mobile"))
}d.prototype.initEvents=function(){window.addEventListener("resize",a.debounce(this.setDotsPosition.bind(this),300));
window.addEventListener("resize",a.debounceExtend(this.setDotsPosition.bind(this),300))
};
d.prototype.setDotsHiddenText=function(){for(var m=0;
m<this.$sliderSlide.length;
m++){var j=m+1;
var n=this.$sliderSlide[m].querySelector(".layout-box__wrapper");
var o=this.$sliderSlide[m].querySelector(".text-ui");
var l=this.$sliderSlide[m].querySelector(f.twoCellsSlideContent);
var r=this.$sliderSlide[m].querySelector(".button");
var p="";
if(r){var k=r.querySelector(".button__content--mobile");
p=this.$sliderSlide[m].textContent.replace(k.textContent,"")
}var q="";
if(n&&r||l&&r){q='<span class="rs-only"> Slide '+j+": "+p+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}else{if(n){q='<span class="rs-only"> Slide '+j+": "+n.textContent+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}else{if(l){q='<span class="rs-only"> Slide '+j+": "+l.textContent+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}else{if(o){q='<span class="rs-only"> Slide '+j+": "+o.textContent+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}}}}}};
d.prototype.setDotsPosition=function(){if(this.$el.hasClass(f.singleSlider)&&this.$el.hasClass(f.sliderPositionContentSide)){this.setContentSide(f.singleSlideContent,0)
}if(this.$el.hasClass(f.sliderPositionContentSide)){if(this.$el.find(f.twoCellsSlideUi).hasClass(f.twoCellsSlideContentLeft)){this.setContentSide(f.twoCellsSlideContent,0,".two-cells-slide__content-left")
}if(this.$el.find(f.twoCellsSlideUi).hasClass(f.twoCellsSlideContentRight)){this.setContentSide(f.twoCellsSlideContent,0,".two-cells-slide__content-right")
}}};
d.prototype.setContentSide=function(k,j,n){var m=this.$el.find(".owl-item.active "+(n?n:"")+" "+k)[0];
if(m){var l=this.$el.find("."+f.nav);
l.css({left:""});
var o=l.offset().left;
var q=m.firstElementChild?m.firstElementChild:m;
var p=q.getBoundingClientRect().left;
var i=parseInt(window.getComputedStyle(q,null).getPropertyValue("padding-left"));
l.css({left:p+j+i-o+"px"})
}};
d.prototype.initDotsColors=function(){if(this.dotsColor===this.dotActiveColor){return
}this.toggleActiveDotClass(this.dots.filter(f.active),true);
this.$el.on("translated.owl.carousel",function(){setTimeout(function(){if(!this.isDragging){this.setDotsPosition()
}}.bind(this),50)
}.bind(this));
this.$el.on("drag.owl.carousel",function(){this.isDragging=true
}.bind(this));
this.$el.on("dragged.owl.carousel",function(){this.isDragging=false
}.bind(this));
this.$el.on("changed.owl.carousel",function(){this.toggleActiveDotClass(this.dots,false);
this.toggleActiveDotClass(this.dots.filter(f.active),true);
this.$sliderA11YLayer.adjustSliderButtonsAndLinksTabindex();
this.$sliderA11YLayer.adjustSliderNavigationTabindex()
}.bind(this))
};
d.prototype.toggleActiveDotClass=function(i,j){i.toggleClass(this.dotsColor,!j).toggleClass(this.dotActiveColor,j)
};
d.prototype.initSliding=function(j){var i=!(this.isExpanded&&j)&&this.itemCount>1;
if(!i){return
}this.$el.owlCarousel(this.config);
this.carouselData=this.$el.data("owl.carousel");
this.dots=this.$el.find("."+f.dot);
if(this.playspeed){$(document).on("visibilitychange",this.continueAutoplay.bind(this));
this.$el.find("."+f.dot).on("click",this.stopAutoplay.bind(this))
}this.reloadClonedImages();
this.initDotsColors.call(this);
this.$sliderA11YLayer=new e(this.$el);
this.$sliderA11YLayer.init()
};
d.prototype.wcmModeChange=function(i){if(this.carouselData){this.carouselData.destroy()
}this.initSliding(i==="edit")
};
d.prototype.continueAutoplay=function(){if(this.isStopped){return
}this.carouselData.next()
};
d.prototype.stopAutoplay=function(){this.carouselData._plugins.autoplay.destroy();
this.isStopped=true
};
d.prototype.reloadClonedImages=function(){var i=this.$el.find(".cloned .responsive-image-ui");
if(i.length===1){new c(i)
}};
d.prototype.defaultConfig={loop:true,center:true,autoplay:true,items:1,loadedClass:f.sliderLoaded,dragClass:f.sliderDrag,navContainerClass:g.Classes.hidden,dotClass:f.dot,dotsClass:f.nav,responsiveRefreshRate:0,lazyLoad:true};
d.selector=".slider-ui";
d.moduleName="Slider";
return d
});
define("SliderA11YLayer",[],function(){var a=$("html");
var c={sliderNavigation:"slider__navigation",sliderDot:"slider__dot",owlStageOuter:"owl-stage-outer"};
function b(d){this._el=d;
this.$sliderNavigation=d.find("."+c.sliderNavigation);
this.$sliderDots=d.find("."+c.sliderDot)
}b.prototype.init=function(){this.changeNavigationDotsPosition();
this.addAriaAttributesToNavigation();
this.initEvents()
};
b.prototype.changeNavigationDotsPosition=function(){this._el.find("."+c.owlStageOuter).before(this.$sliderNavigation)
};
b.prototype.addAriaAttributesToNavigation=function(){this.$sliderNavigation.attr("role","tablist").attr("aria-label","Slides");
for(var d=0;
d<this.$sliderDots.length;
d++){$(this.$sliderDots[d]).attr("role","tab").attr("type","button").attr("tabindex",-1)
}$(this.$sliderDots[0]).attr("tabindex",0)
};
b.prototype.onFocusinHandler=function(){if(a.hasClass("key-used")){this._el.trigger("stop.owl.autoplay")
}};
b.prototype.onFocusoutHandler=function(){if(a.hasClass("key-used")){this._el.trigger("play.owl.autoplay")
}};
b.prototype.onKeyDownHandler=function(f){var e=f.key;
if(e==="ArrowRight"||e==="ArrowLeft"){var g=this.$sliderNavigation.find("[tabindex=0]");
g.attr("tabindex",-1).removeClass("active").removeClass("bg-color-almost-black").addClass("bg-color-white");
if(e==="ArrowRight"){var d=g.next();
if(!d.length){d=this.$sliderNavigation.find(">:first-child")
}this._el.trigger("next.owl.carousel")
}if(e==="ArrowLeft"){d=g.prev();
if(!d.length){d=this.$sliderNavigation.find(">:last-child")
}this._el.trigger("prev.owl.carousel")
}d.attr("tabindex",0).addClass("active").addClass("bg-color-almost-black").removeClass("bg-color-white").focus()
}};
b.prototype.adjustSliderNavigationTabindex=function(){this.$sliderNavigation.find("[tabindex=0]").attr("tabindex",-1);
this.$sliderNavigation.find(".active").attr("tabindex",0)
};
b.prototype.adjustSliderButtonsAndLinksTabindex=function(){var d=this._el.find(".owl-item");
setTimeout(function(){for(var h=0;
h<d.length;
h++){var e=$(d[h]);
var g=e.hasClass("active");
var f=e.find(".button-ui");
var j=e.find("a");
if(g){f.attr("tabindex",0);
j.attr("tabindex",0)
}else{j.attr("tabindex",-1);
f.attr("tabindex",-1)
}}},0)
};
b.prototype.initEvents=function(){this._el.on("focusin",this.onFocusinHandler.bind(this));
this._el.on("focusout",this.onFocusoutHandler.bind(this));
this._el.on("mouseover",function(){this._el.trigger("stop.owl.autoplay")
}.bind(this));
this._el.on("mouseleave",function(){if(!this._el.find(":focus").length){this._el.trigger("play.owl.autoplay")
}}.bind(this));
this.$sliderNavigation.on("keydown",this.onKeyDownHandler.bind(this))
};
return b
});
define("Section",["utils"],function(a){var c={isHasParallax:".section-ui__parallax-wrapper.parallax-wrapper"};
function b(d){this.$el=d;
this.init()
}b.prototype.init=function(){a.applyShadowOnImage(this.$el,this.$el.find(".section__image"),this.$el.find(c.isHasParallax).length)
};
b.moduleName="Section";
b.selector=".section-ui";
return b
});
define("SearchResults",["utils","utils-dust","utils-env","constants"],function(a,f,e,d){var g=$(window);
var c={form:".search-results__panel",container:".search-results__items",more:".search-results__view-more",exception:".search-results__exception-message",error:".search-results--error",emptyResult:".search-results--empty-result",counter:".search-results__counter",input:".search-results__input",titleLink:".search-results__title-link",autoCorrectMessage:".search-results__auto-correct-message",autoCorrectTotal:".search-results__auto-correct-total",autoCorrectTerm:".search-results__auto-correct-term"};
function b(h){this.$form=h.find(c.form);
this.$query=this.$form.find(c.input);
this.$container=h.find(c.container);
this.$counter=h.find(c.counter);
this.$preloader=h.find("."+d.Classes.preloader);
this.$viewMore=h.find(c.more);
this.$exceptionMessages=h.find(c.exception);
this.$autoCorrectMessage=h.find(c.autoCorrectMessage);
this.$autoCorrectTerm=this.$autoCorrectMessage.find(c.autoCorrectTerm);
this.$autoCorrectTotal=this.$autoCorrectMessage.find(c.autoCorrectTotal);
this.$errorMessage=this.$exceptionMessages.filter(c.error);
this.$emptyResultMessage=this.$exceptionMessages.filter(c.emptyResult);
this.isAuthor=e.isAuthor();
this.configPath=h.data("config-path");
this.$form.on("submit",this.submit.bind(this));
this.$viewMore.on("click",this.loadMoreResults.bind(this));
g.on("scroll",this.loadResultsOnScroll.bind(this));
g.on("popstate",this.refreshResult.bind(this));
this.init()
}b.prototype.refreshResult=function(){var i=this.getParameters().q;
var h=a.getQueryParameters(location.href.replace(location.hash,"")).q;
if(i!==h){this.cleanResult();
this.init()
}};
b.prototype.init=function(){this.updateForm();
this.loadResults(this.getParameters())
};
b.prototype.getParameters=function(h){return{q:this.$query.val().trim(),offset:h||0,config:this.configPath,bf:["events","news"]}
};
b.prototype.updateForm=function(){var h=window.location,i=a.getQueryParameters(h.href.replace(h.hash,"")).q||"";
this.$query.val(i)
};
b.prototype.loadResults=function(h){if(!h.q){this.$query.val("");
return
}$.ajax({url:this.config.searchUrl,data:h,beforeSend:this.toggleLoadingState.bind(this,true),complete:this.toggleLoadingState.bind(this,false),success:this.updateSearchResults.bind(this,h),error:this.showErrorMessage.bind(this)})
};
b.prototype.loadMoreResults=function(i){i&&i.preventDefault();
var j=this.$container.children().length,h=this.getParameters(j);
if(i){h.shouldFocusOnResult=true
}this.loadResults(h)
};
b.prototype.loadResultsOnScroll=function(){if(this.loading||!this.shouldLoadOnScroll){return
}var j=g.height(),i=g.scrollTop(),h=this.$container.children().last().offset().top;
if(j+i>h){this.loadMoreResults()
}};
b.prototype.toggleLoadingState=function(h){h&&this.$viewMore.addClass(d.Classes.hidden);
this.$preloader.toggleClass(d.Classes.hidden,!h);
this.loading=h
};
b.prototype.showErrorMessage=function(){this.$errorMessage.removeClass(d.Classes.hidden)
};
b.prototype.showAutoCorrectMessage=function(h){this.$autoCorrectMessage.removeClass(d.Classes.hidden);
this.$autoCorrectTotal.text(h.suggestedResultTotal);
this.$autoCorrectTerm.text(h.suggestedQuery);
this.$autoCorrectTerm.attr("href",this.getLink(h.suggestedQuery))
};
b.prototype.updateSearchResults=function(m,k){var l=k.total,j=k.result.length&&k.result||k.suggestedResult,i=m.offset===0,h=l>m.offset+this.config.limit;
this.shouldLoadOnScroll=i&&h;
i&&this.showResultMessage(m.q,l);
k.suggestedResultTotal&&this.showAutoCorrectMessage(k);
f.append("search-results",{items:j,isAuthor:this.isAuthor},this.$container);
this.$viewMore.toggleClass(d.Classes.hidden,i||!h);
m.shouldFocusOnResult&&this.$container.find(c.titleLink).eq(m.offset).focus()
};
b.prototype.showResultMessage=function(i,h){this.$counter.text(h?this.getResultMessage(i,h):"");
if(h){this.$counter.removeClass(d.Classes.hidden).focus();
return
}this.$emptyResultMessage.removeClass(d.Classes.hidden)
};
b.prototype.getResultMessage=function(j,i){var h=i===1?"component.search-results.found-single-result":"component.search-results.found-multiple-results";
return CQ.I18n.getMessage(h,[j,i])
};
b.prototype.submit=function(i){i.preventDefault();
this.cleanResult();
var h=this.getParameters();
this.updateUrl(h);
this.loadResults(h)
};
b.prototype.cleanResult=function(){this.$counter.addClass(d.Classes.hidden);
this.$container.empty();
this.$exceptionMessages.addClass(d.Classes.hidden);
this.$autoCorrectMessage.addClass(d.Classes.hidden);
this.$viewMore.addClass(d.Classes.hidden)
};
b.prototype.updateUrl=function(h){if(h.q!==a.getQueryParameters(window.location.href).q){window.history.pushState({},"",this.getLink(h.q))
}};
b.prototype.getLink=function(h){return window.location.pathname+"?q="+encodeURIComponent(h)
};
b.prototype.config={searchUrl:"/services/search/global",limit:10};
b.moduleName="Search Results";
b.selector=".search-results-ui";
return b
});
define("ResponsiveImage",["require","media","utils","imager"],function(b,c){var d=$(window);
function a(e){this.$el=e;
this.$placeholder=this.$el.find("."+this.classes.placeholder);
this.data=$.extend({},this.$placeholder.data(),this.$el.data());
this.hideOnMobile=this.$el.hasClass(this.classes.hideOnMobile);
this.isDownloaded=false;
this.$el.on("renderImage",function(){this.render()
}.bind(this));
if(this.shouldBeShown()){this.render()
}d.on("resize",b("utils").debounce(this.render.bind(this),100))
}a.prototype.shouldBeShown=function(){if(b("utils-env").isEditMode()){return true
}return this.data.width!==0&&(c.currentMode().greaterThan(c.modes.WideMobile)||!this.hideOnMobile)
};
a.prototype.setMaxWidth=function(e,f){if(f.width&&f.widthUnits){e.css({maxWidth:f.width+f.widthUnits})
}};
a.prototype.render=function(){var e=this.isDownloaded||!this.shouldBeShown()||!this.$placeholder.is(":visible");
if(e){d.one("tab.changed",this.render.bind(this));
return
}b("imager").create(this.$placeholder);
this.isDownloaded=true;
this.$img=this.$el.find("."+this.classes.img);
this.$img.attr("title",this.data.title);
this.setMaxWidth(this.$img,this.data)
};
a.prototype.classes={placeholder:"responsive-image__placeholder",img:"responsive-image__img",hideOnMobile:"responsive-image--hide-on-mobile"};
a.selector=".responsive-image-ui";
a.moduleName="Responsive Image";
return a
});
define("Pages",["TabsUtil","utils-env"],function(c,b){function a(d){this.viewGeneral=d.data("view")==="general";
this.viewContinuum=d.data("view")==="continuum";
c.call(this,d,{carouselForPages:true,scrollToElement:this.viewContinuum&&true,useHistory:true,nav:false,dots:false,autoWidth:true});
this.viewGeneral&&this.initCarousel();
!b.isEditMode()&&this.viewGeneral&&$(window).on("resize",this.reInitCarousel.bind(this))
}a.prototype=Object.create(c.prototype);
a.moduleName="Pages";
a.selector=".pages-ui";
return a
});
define("MultiLevelTabs",["TabsUtil","AccordionUtil","constants","media"],function(d,h,j,b){var a=$(window);
var c={accordion:".js-accordion",controlsSub:".js-tabs-controls--sub",linksSub:".js-tabs-links-list--sub",titleSub:".js-tabs-title--sub",linkSub:".js-tabs-link--sub",itemSub:".js-tabs-item--sub",active:"active",tabsContent:".multi-level-tabs__content",tabsHeading:".multi-level-tabs__heading-list",activeTitle:".active .title-ui",activeText:".active .text-ui"};
var k={tabChange:"tab.change",tabChanged:"tab.changed",tabLoaded:"tab.loaded"};
var f=37;
var e=52;
var g=70;
function i(l){this.$el=l;
this.$accordion=l.find(c.accordion);
this.$tabsContent=l.find(c.tabsContent);
this.$tabsHeading=l.find(c.tabsHeading);
this.$linksSub=l.find(c.linksSub);
this.$titleSub=l.find(c.titleSub);
this.numberOfColumns=this.$linksSub.data("columns");
this.isScrollToContentPart=this.$el.data("scroll");
this.activeColumn=1;
this.tabsReady=false;
this.subTabsReady=false;
this.initTabs();
a.on("resize",function(){this.initTabs()
}.bind(this));
this.accordionUtil=new h(this.$accordion);
this.handleAlly()
}i.prototype=Object.create(d.prototype);
i.prototype.initTabs=function(){var n=b.currentMode().greaterThan(b.modes.Tablet);
var r;
var q;
var o;
if(this.isScrollToContentPart){r=true;
q=this.$tabsContent;
o=e
}else{r=p;
q=this.$tabsHeading;
o=g
}var l=this.$tabsContent;
function m(){var t=l.find(c.activeTitle);
if(!t.length){t=l.find(c.activeText)
}var s=t.first();
return s.offset().top+s.outerHeight()
}function p(){var s=m();
var t=a.scrollTop();
var v=a.height();
var u=s+f>t+v;
return u
}if(n&&!this.subTabsReady){d.call(this,this.$el,{nav:true,dots:false,autoWidth:true,multiLevelSubTabs:true,controls:this.$el.find(c.controlsSub),links:this.$el.find(c.linksSub),link:this.$el.find(c.linkSub),items:this.$el.find(c.itemSub),scrollToElement:r,scrollToElementSelector:q,scrollToReservedSpace:o,multiLevelTabsView:true});
this.tabsReady=false;
this.subTabsReady=true
}else{if(!n&&!this.tabsReady){d.call(this,this.$el,{nav:false,dots:false,autoWidth:true,carouselView:true,multiLevelTabsView:true});
this.tabsReady=true;
this.subTabsReady=false
}}this.activeItem=null
};
i.prototype.handleAlly=function(){var l=1;
this.$titleSub.each(function(m,n){n.dataset.column=l;
l++;
if(l===this.numberOfColumns+1){l=1
}}.bind(this));
this.multiLevelAfterTabChange()
};
i.prototype.multiLevelAfterTabChange=function(){var l=this.$links.filter("."+this.classes.active).parent().data("column")||"1";
var m=this.$titleSub.filter(function(n,o){return o.dataset.column===l.toString()
});
this.$links.removeAttr("role");
m.find("a").attr("role","tab")
};
i.prototype.getRowByItemId=function(n){var p=n||0;
var q=this.$el.find('a[data-item-sub="'+p+'"]');
var m=q.parent();
var o=this.$titleSub.index(m);
var l=o%this.numberOfColumns;
return this.$titleSub.slice(o-l,o-l+this.numberOfColumns)
};
i.prototype.getRowIds=function(l){return l.map(function(m,n){return $(n).find("a")
}).filter(function(m,n){return n.length!==0
}).map(function(m,n){return n.data("item-sub")
}).get()
};
i.prototype.getActiveColumnItems=function(){var l=this.$links.filter("."+this.classes.active).parent().data("column")||"1";
var m=this.$titleSub.filter(function(n,o){return o.dataset.column===l.toString()
});
return m
};
i.prototype.getColumnsId=function(m){var l=m;
var n=this.$titleSub.filter(function(o,p){return p.dataset.column===l.toString()
});
return n
};
i.prototype.setActiveItem=function(l){this.$el.trigger(k.tabChange,{tab:l,skipSwitching:this.skipSwitching})
};
i.prototype.setActiveItemByComparison=function(m,l,n,o){if(m===l){this.setActiveItem(n)
}else{this.setActiveItem(o)
}};
i.prototype.onKeydown=function(l){var m=this.activeItem||0;
var s=this.getRowByItemId(m);
var n=this.getRowIds(s);
var o=this.getActiveColumnItems();
var p=this.getRowIds(o);
var t=this.getColumnsId(this.numberOfColumns);
var r=this.getRowIds(t);
var q=p.indexOf(m);
switch(l.key){case j.Keys.home:l.preventDefault();
this.setActiveItem(0);
break;
case j.Keys.end:l.preventDefault();
this.setActiveItem(r[r.length-1]);
break;
case j.Keys.arrowRight:l.preventDefault();
this.setActiveItemByComparison(n[n.length-1],m,n[0],this.activeItem+1);
break;
case j.Keys.arrowLeft:l.preventDefault();
this.setActiveItemByComparison(n[0],m,n[n.length-1],this.activeItem-1);
break;
case j.Keys.arrowDown:l.preventDefault();
this.setActiveItemByComparison(p[p.length-1],m,p[0],p[q+1]);
break;
case j.Keys.arrowUp:l.preventDefault();
this.setActiveItemByComparison(p[0],m,p[p.length-1],p[q-1]);
break;
case j.Keys.space:case j.Keys.enter:l.preventDefault();
this.$el.trigger(k.tabChange,{tab:this.activeItem,forceSwitching:true});
this.afterClick&&this.afterClick($(l.target));
this.onLinkClick(l);
break;
default:break
}this.scrollTo(l)
};
i.moduleName="MultiLevelTabs";
i.selector=".multi-level-tabs-ui";
return i
});
define("InfochartCellPopup",["constants"],function(c){var b={content:".infochart-cell__content",description:".infochart-cell__description",close:".infochart-cell__close"};
function d(e){return[c.Keys.space,c.Keys.enter].some(function(f){return e===f
})
}function a(e){this.$el=e;
this.$content=e.find(b.content);
this.$popup=e.find(b.description);
this.$close=this.$popup.find(b.close);
this.closePopup=this.closePopup.bind(this);
this.openPopup=this.openPopup.bind(this);
this.onFocusout=this.onFocusout.bind(this);
this.$popup.on("keydown",this.onPopupKeydown.bind(this)).on("focusin",this.onFocusin.bind(this));
this.$content.on("click",this.openPopup).on("keypress",this.onContentKeypress.bind(this));
this.$close.on("click",this.closePopup).on("keyup",function(f){f.preventDefault()
}).on("keypress",this.onButtonKeypress.bind(this))
}a.prototype.openPopup=function(){this.$popup.on("focusout",this.onFocusout).removeClass(c.Classes.hidden);
this.$close.focus();
return false
};
a.prototype.closePopup=function(){this.$popup.off("focusout",this.onFocusout).addClass(c.Classes.hidden);
this.$content.focus();
return false
};
a.prototype.onFocusout=function(){this.timeout=setTimeout(this.closePopup)
};
a.prototype.onFocusin=function(){clearTimeout(this.timeout)
};
a.prototype.onContentKeypress=function(e){d(e.key)&&this.openPopup()
};
a.prototype.onPopupKeydown=function(e){c.Keys.esc===e.key&&this.closePopup()
};
a.prototype.onButtonKeypress=function(e){d(e.key)&&this.closePopup()
};
a.prototype.classes=b;
a.moduleName="InfoChart Cell Pop-up";
a.selector=".infochart-cell--pop-up";
return a
});
define("InPageNavigation",["utils","jquery-plugins"],function(a){function b(c){this.$el=c;
this.$trigger=this.$el.find("."+this.classes.trigger);
this.$titleList=this.$el.find("."+this.classes.list);
this.$items=this.$titleList.find("."+this.classes.item);
this.$trigger.on("click",this.toggleNav.bind(this));
a.checkDividers(this.$items,this.classes.hideDivider)
}b.prototype.toggleNav=function(){this.$titleList.stop().slideToggle();
this.$trigger.toggleClass(this.classes.triggerIsExpanded);
return false
};
b.prototype.classes={list:"in-page-navigation__list",item:"in-page-navigation__item",title:"in-page-navigation__title",trigger:"in-page-navigation__trigger",triggerIsExpanded:"in-page-navigation__trigger--expanded",hideDivider:"in-page-navigation__item--no-divider"};
b.moduleName="In-Page Navigation";
b.selector=".in-page-navigation-ui";
return b
});
define("ImportantInformation",[],function(){function a(c){this.$el=c;
this.init()
}a.prototype.init=function(){this.ignoreParentPadding()
};
a.prototype.ignoreParentPadding=function(){if($(window).width()>=b.mobileDevice){var e=this.$el.attr("ignorepaddings");
if(e==="true"){var f=this.$el;
do{f=f.parent();
var c=parseFloat(f.css("padding-left"));
var d=parseFloat(f.css("padding-right"))
}while(!c&&!d);
this.$el.css("margin-left",c*-1);
this.$el.css("margin-right",d*-1)
}}};
var b={mobileDevice:991};
a.moduleName="Important Information";
a.selector=".important-information-ui";
return a
});
define("HeaderSearch",["Header","media","constants"],function(g,f,e){var b=$("html"),a=$("body").children("."+e.Classes.overlay).last();
var d={button:".header-search__button",panel:".header-search__panel",input:".header-search__input",submit:".header-search__submit",opened:"opened"};
function c(h){this.$el=h;
this.$button=this.$el.find(d.button);
this.$panel=this.$el.find(d.panel);
this.$input=this.$panel.find(d.input);
this.$submit=this.$panel.find(d.submit);
this.openPanel=this.openPanel.bind(this);
this.closePanel=this.closePanel.bind(this);
this.onShiftTabOnButton=this.onShiftTabOnButton.bind(this);
this.$button.one("click",this.triggerOpen);
this.$el.on("keyup",this.onEscPress.bind(this));
this.$submit.on("keydown",this.onTabOnSubmit.bind(this));
g.registerMenu({name:c.moduleName,hasOverlay:true,hasDisabledScroll:function(){return f.currentMode().lessThan(f.modes.Desktop)
},onOpen:this.openPanel,onClose:this.closePanel})
}c.prototype.onEscPress=function(h){if(h.key!==e.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
c.prototype.onTabOnSubmit=function(h){if(h.key!==e.Keys.tab||h.shiftKey){return
}h.preventDefault();
this.$button.focus()
};
c.prototype.onShiftTabOnButton=function(h){if(h.key!==e.Keys.tab||!h.shiftKey){return
}h.preventDefault();
this.$submit.focus()
};
c.prototype.triggerOpen=function(){b.trigger(e.Events.menuOpen,{opened:c.moduleName})
};
c.prototype.triggerClose=function(){b.trigger(e.Events.menuClose)
};
c.prototype.openPanel=function(){this.$panel.stop(true).slideDown().queue(function(){this.$input.focus();
this.$panel.addClass(d.opened)
}.bind(this));
this.$button.attr("aria-expanded",true).addClass(d.opened).one("click",this.triggerClose).on("keydown",this.onShiftTabOnButton);
a.one("click",this.triggerClose)
};
c.prototype.closePanel=function(){this.$input.blur();
this.$panel.removeClass(d.opened);
this.$panel.stop(true).slideUp();
a.off("click",this.triggerClose);
this.$button.attr("aria-expanded",false).removeClass(d.opened).off("click",this.triggerClose).one("click",this.triggerOpen).off("keydown",this.onShiftTabOnButton)
};
c.prototype.classes=d;
c.moduleName="Header Search";
c.selector=".header-search-ui";
return c
});
define("LocationSelector",["Header","utils-a11y","constants"],function(g,b,j){var d=$("html"),e=$("body"),h=e.children("."+j.Classes.overlay).last();
var c={button:".location-selector__button",locations:".location-selector__panel",link:".location-selector__link",opened:"opened"};
function a(){d.trigger(j.Events.menuOpen,{opened:i.moduleName})
}function f(){d.trigger(j.Events.menuClose)
}function i(k){this.$el=k;
this.$button=this.$el.find(c.button);
this.$locations=this.$el.find(c.locations);
this.$lastLink=this.$locations.find(c.link).last();
this.hideLocations=this.toggleLocations.bind(this,false);
this.showLocations=this.showLocations.bind(this);
this.$button.one("click",a);
this.$el.on("keyup",this.closeOnEsc.bind(this));
this.$lastLink.on("keydown",this.cycleForwardTabNavigation.bind(this));
g.registerMenu({name:i.moduleName,onOpen:this.showLocations,onClose:this.hideLocations,hasOverlay:true});
this.ariaLabelHidden=this.$button.attr("aria-label-hidden")
}i.prototype.closeOnEsc=function(k){if(k.key!==j.Keys.esc){return
}f();
this.$button.focus()
};
i.prototype.cycleForwardTabNavigation=function(k){if(k.key!==j.Keys.tab||k.shiftKey){return
}k.preventDefault();
this.$button.focus()
};
i.prototype.cycleBackwardTabNavigation=function(k){if(k.key!==j.Keys.tab||!k.shiftKey){return
}k.preventDefault();
this.$lastLink.focus()
};
i.prototype.showLocations=function(){this.toggleLocations(true);
this.$button.on("keydown",this.cycleBackwardTabNavigation.bind(this))
};
i.prototype.toggleLocations=function(k){this.$button.attr("aria-label",k?this.ariaLabelHidden:"");
this.$locations[k?"slideDown":"slideUp"]();
h[k?"one":"off"]("click",f);
this.$button.attr("aria-expanded",k).toggleClass(c.opened,k).off().one("click",k?f:a)
};
i.moduleName="Location Selector";
i.selector=".location-selector-ui";
return i
});
define("MobileLocationSelector",[],function(){var c=$(window);
var b={button:".mobile-location-selector__button",panel:".mobile-location-selector__panel"};
function a(d){this.$el=d;
this.$button=this.$el.find(b.button);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$button.one("click",this.openMenu)
}a.prototype.openMenu=function(){this.$el.addClass("opened");
this.$button.attr("aria-expanded",true).one("click",this.closeMenu);
c.on("click",this.closeMenu);
this.reApplyMenuButtonFocus();
return false
};
a.prototype.closeMenu=function(){this.$el.removeClass("opened");
this.$button.attr("aria-expanded",false).one("click",this.openMenu);
c.off("click",this.closeMenu);
this.reApplyMenuButtonFocus()
};
a.prototype.reApplyMenuButtonFocus=function(){this.$button.blur();
setTimeout(function(){this.$button.focus()
}.bind(this),100)
};
a.moduleName="Location Selector Mobile";
a.selector=".mobile-location-selector-ui";
return a
});
define("Header",["constants"],function(d){var b=$("html"),a=$("body").children("."+d.Classes.overlay).last(),e=10;
function c(f){this.$el=f;
this.$hamburgerMenu=this.$el.find(".hamburger-menu-ui");
$(window).on("scroll",this.shrinkMenu.bind(this));
b.on(d.Events.menuOpen,this.openMenu).on(d.Events.menuClose,this.closeMenu);
b.on("focusin",this.closeMenuWhenLooseFocus.bind(this))
}c.prototype.closeMenuWhenLooseFocus=function(f){if(!this.$hamburgerMenu.find(f.target).length){this.activeMenu="Hamburger Menu";
this.closeMenu()
}};
c.prototype.openMenu=function(i,h){if(!h){return
}var g=c.menus[h.opened];
this.activeMenu&&c.menus[this.activeMenu].onClose();
this.activeMenu=h.opened;
g.onOpen();
a.toggleClass(d.Classes.hidden,!g.hasOverlay);
var f=typeof g.hasDisabledScroll==="function"?g.hasDisabledScroll():!!g.hasDisabledScroll;
b.toggleClass(d.Classes.noscroll,f)
};
c.prototype.closeMenu=function(j,i){if(!this.activeMenu){return
}var h=c.menus[this.activeMenu],g=i&&i.couldBeIgnored&&h.ignoresWhenPossible,f=i&&i.closed&&this.activeMenu!==i.closed;
if(g||f){return
}h.onClose();
a.addClass(d.Classes.hidden);
b.removeClass(d.Classes.noscroll);
this.activeMenu=null
};
c.prototype.shrinkMenu=function(){var f=window.pageYOffset||document.documentElement.scrollTop;
this.$el.toggleClass(this.classes.shrink,f>=e);
$(document.body).toggleClass(this.classes.shrink,f>=e)
};
c.menus={};
c.registerMenu=function(f){c.menus[f.name]={onOpen:f.onOpen,onClose:f.onClose,hasOverlay:f.hasOverlay,hasDisabledScroll:f.hasDisabledScroll,ignoresWhenPossible:f.ignoresWhenPossible}
};
c.prototype.classes={shrink:"header--animated"};
c.moduleName="Header";
c.selector=".header-ui";
return c
});
define("HamburgerMenu",["Header","constants"],function(e,d){var a=$("html");
var c={button:".hamburger-menu__button",menu:".hamburger-menu__dropdown",accordeon:".item--collapsed",link:".hamburger-menu__link",expandedAccordeon:"item--expanded",menuExpanded:"hamburger-menu--expanded",child:"item--child",active:".active",expandChildButton:"hamburger-menu__sub-menu-toggle-button",clickableLink:"hamburger-menu__active-button",ctaButton:".cta-button-ui",openedArrowNode:'[aria-expanded="true"]',hamburgerMenuList:".hamburger-menu__list"};
function b(f){this.$el=f;
this.$button=this.$el.find(c.button);
this.$menu=this.$el.find(c.menu);
this.$hamburgerMenuList=this.$el.find(c.hamburgerMenuList);
this.$accordeon=this.$el.find(c.accordeon);
this.$link=this.$el.find(c.link);
var g=this.$el.find(c.ctaButton);
this.$lastLink=g.length&&g||this.$link.last();
this.$expandChildButton=f.find("."+c.expandChildButton);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$menu.on("keyup",this.keysPressHandler.bind(this));
this.$accordeon.on("click",this.onArrowClick.bind(this));
this.$link.on("click",function(h){h.stopPropagation()
});
this.$button.one("click",this.triggerOpen);
this.$expandChildButton.on("click",this.onRealArrowClick.bind(this));
this.$clickableLinks=f.find("."+c.clickableLink);
this.$clickableLinks.on("click",this.onClickableLinkHandler.bind(this));
e.registerMenu({name:b.moduleName,onOpen:this.openMenu,onClose:this.closeMenu,hasDisabledScroll:true,ignoresWhenPossible:true});
this.expandActiveDropdown()
}b.prototype.onEscPress=function(f){if(f.key!==d.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
b.prototype.triggerOpen=function(){a.trigger(d.Events.menuOpen,{opened:b.moduleName});
return false
};
b.prototype.triggerClose=function(){a.trigger(d.Events.menuClose,{closed:b.moduleName})
};
b.prototype.openMenu=function(){a.addClass(c.menuExpanded);
this.$menu.stop().slideDown();
this.$button.attr("aria-expanded",true).one("click",this.triggerClose)
};
b.prototype.closeMenu=function(){a.removeClass(c.menuExpanded);
this.$menu.stop().slideUp();
this.$button.attr("aria-expanded",false).off().one("click",this.triggerOpen)
};
b.prototype.onArrowClick=function(g){var f=$(g.target);
f.has("ul").length&&this.toggleDropdown(f,g);
return false
};
b.prototype.onRealArrowClick=function(g){var h=$(g.target);
var f=h.parent();
f.has("ul").length&&this.toggleDropdown(f,g)
};
b.prototype.closedOpenedHamburgerMenuItem=function(g){var f=this.$hamburgerMenuList.find(c.openedArrowNode);
if(f.length&&!g.is(f)){f.attr("aria-expanded","false")
}};
b.prototype.toggleAriaAttribute=function(f){f.attr("aria-expanded",function(g,h){return h==="false"
})
};
b.prototype.adjustAriaAttributes=function(f){if(f){var g=$(f.target);
this.closedOpenedHamburgerMenuItem(g);
this.toggleAriaAttribute(g)
}};
b.prototype.toggleDropdown=function(f,g){this.adjustAriaAttributes(g);
f.toggleClass(c.expandedAccordeon);
this.$accordeon.not(f).removeClass(c.expandedAccordeon)
};
b.prototype.expandActiveDropdown=function(){var f=this.$link.filter(c.active);
if(!f.parent().hasClass(c.child)){return
}this.toggleDropdown(f.parents(c.accordeon))
};
b.prototype.enterKeyPressHandler=function(g){var f=g.key;
var h=$(g.target);
if(f==="Enter"&&(h.hasClass(c.clickableLink)||h.hasClass(c.expandChildButton))){this.toggleDropdown(h.parent(),g)
}};
b.prototype.onClickableLinkHandler=function(f){var g=$(f.target);
this.toggleDropdown(g.parent(),f)
};
b.prototype.keysPressHandler=function(f){this.enterKeyPressHandler(f);
this.onEscPress(f)
};
b.prototype.classes=c;
b.moduleName="Hamburger Menu";
b.selector=".hamburger-menu-ui";
return b
});
define("TopNavigation",["constants"],function(d){var a=$("html");
var c={item:".top-navigation__item",dropdown:".top-navigation__flyout",openSubmenu:"js-opened",linkA11y:".top-navigation__item-link--a11y"};
function b(e){this.$el=e;
this.$items=this.$el.find(c.item);
this.$dropdowns=this.$el.find(c.dropdown);
this.$linkA11y=this.$el.find(c.linkA11y);
this.$itemsWithSubmenu=this.$items.filter(this.hasDropdown);
this.$lastSubLinks=$([]);
this.$dropdowns.each(function(g,f){this.$lastSubLinks=this.$lastSubLinks.add($(f).find("a").last())
}.bind(this));
this.$itemsWithSubmenu.on("mouseover",this.onItemHover.bind(this));
this.$itemsWithSubmenu.on("mouseleave",this.onItemLeave.bind(this));
this.$dropdowns.on("keydown",this.onEscOnItem.bind(this));
this.$linkA11y.on("click",this.openSubmenuA11y.bind(this));
this.$linkA11y.on("focus",this.closeAll.bind(this));
this.$lastSubLinks.on("keydown",this.closeAllWithoutShiftKey.bind(this));
$(document).on("click",this.closeAll.bind(this))
}b.prototype.closeAllWithoutShiftKey=function(e){if(e.shiftKey){return
}this.closeAll()
};
b.prototype.onItemHover=function(e){this.openSubmenu($(e.currentTarget))
};
b.prototype.onItemLeave=function(){this.closeAll()
};
b.prototype.openSubmenuA11y=function(e){e.stopPropagation();
var f=$(e.currentTarget).parents(c.item);
this.openSubmenu(f);
f.find("a").eq(1).focus()
};
b.prototype.onEscOnItem=function(e){if(e.key!==d.Keys.esc){return
}this.closeAll();
$(e.currentTarget).parent().find(c.linkA11y).focus()
};
b.prototype.openSubmenu=function(e){a.trigger(d.Events.menuClose,{couldBeIgnored:true});
e.addClass(c.openSubmenu)
};
b.prototype.closeAll=function(){this.$itemsWithSubmenu.removeClass(c.openSubmenu)
};
b.prototype.hasDropdown=function(){return $(this).children(c.dropdown).length>0
};
b.moduleName="Top Navigation";
b.selector=".top-navigation-ui";
return b
});
define("Breadcrumbs",["media","constants"],function(g,e){var f=5,b={shown:"shown",hidden:"hidden"},d={hidden:"breadcrumbs--hidden",lastBreadcrumbItemLink:".breadcrumbs__item:last > a"};
var h=$(window),a=$("html");
function c(i){this.$el=i;
this.lastScrollTop=0;
this.toggleBreadcrumbs=this.toggleBreadcrumbs.bind(this);
this.activateScroll();
this.addA11YAttributes();
a.on(e.Events.menuOpen,this.detach.bind(this)).on(e.Events.menuClose,this.activate.bind(this))
}c.prototype.addA11YAttributes=function(){var i=this.$el.find(d.lastBreadcrumbItemLink);
if(i.length){i.attr("aria-current","page")
}};
c.prototype.toggleBreadcrumbs=function(){var j=!g.currentMode().greaterThan(g.modes.Desktop),n=h.scrollTop(),m=Math.abs(this.lastScrollTop-n)<=f;
if(j||m){return
}var k=n>this.lastScrollTop&&n>=0,i=n+h.height()<$(document).height(),l=this.$el;
this.lastScrollTop=n;
if(k){l.addClass(d.hidden).on(e.Events.transitionEnd,function(){requestAnimationFrame(function(){l.addClass(e.Classes.hidden)
});
l.off(e.Events.transitionEnd)
});
return
}if(i){l.removeClass(e.Classes.hidden);
requestAnimationFrame(function(){l.removeClass(d.hidden).off(e.Events.transitionEnd)
})
}};
c.prototype.detach=function(){this.ignoreScroll();
this.previousState=this.$el.hasClass(this.classes.hidden)?b.hidden:b.shown;
this.$el.addClass(this.classes.hidden)
};
c.prototype.activate=function(k,j){var i=j&&j.couldBeIgnored;
if(!this.previousState||i){return
}this.activateScroll();
this.previousState===b.shown&&this.$el.removeClass(this.classes.hidden);
this.previousState=null
};
c.prototype.ignoreScroll=function(){h.off("scroll",this.toggleBreadcrumbs)
};
c.prototype.activateScroll=function(){h.on("scroll",this.toggleBreadcrumbs)
};
c.prototype.classes=d;
c.moduleName="Breadcrumbs";
c.selector=".breadcrumbs-ui";
return c
});
define("FrequentSearches",["constants"],function(c){var b={hidden:"frequent-searches--hidden",input:".frequent-searches__input",item:".frequent-searches__item",itemActive:"frequent-searches__item--active",footer:".footer-ui"};
var d=$(window);
function a(e){this.$el=e;
this.elHeight=e.height();
this.$input=e.siblings(b.input);
this.$items=e.find(b.item);
this.currentItemIndex=-1;
this.defaultPlaceholder=this.$input.attr("placeholder");
this.$footer=$(b.footer);
this.openEl=this.openEl.bind(this);
this.closeEl=this.closeEl.bind(this);
this.markActiveItem=this.markActiveItem.bind(this);
this.resetActiveItem=this.resetActiveItem.bind(this);
this.$input.attr("autocomplete","off");
this.initEvents();
this.updateHeight()
}a.prototype.initEvents=function(){this.$input.on("focus",this.openEl).on("keyup",this.openEl);
this.$items.on("click",this.onItemClick.bind(this));
d.on("resize",this.updateHeight.bind(this))
};
a.prototype.updateHeight=function(){var g=this.$footer.offset().top-20,e=this.$el.offset().top,f=e+this.elHeight;
this.$el.css("max-height",f>g?g-e:"none")
};
a.prototype.toggleEl=function(f){var e=this.$input.val().length;
if(f||e){this.resetActiveItem()
}this.$el.toggleClass(b.hidden,f||!!e);
this.updateElState(f);
if(this.$input.val().length){this.$input.removeAttr("aria-describedby")
}else{this.$input.attr("aria-describedby","search-label")
}};
a.prototype.openEl=function(){this.toggleEl(false);
d.on("click",this.closeEl)
};
a.prototype.closeEl=function(e){if(e&&this.$input.is(e.target)){return
}this.toggleEl(true);
d.off("click",this.closeEl)
};
a.prototype.updateElState=function(e){if(!e){this.$input.off("keydown");
this.$input.on("keydown",this.onKeyDown.bind(this));
this.updateHeight();
return
}this.clearElState()
};
a.prototype.clearElState=function(){this.$input.off("keydown");
this.currentItemIndex=-1;
this.$items.removeClass(b.itemActive);
this.resetActiveItem();
this.$input.attr("placeholder",this.defaultPlaceholder)
};
a.prototype.onItemClick=function(e){this.$input.val(e.target.innerText).focus();
this.closeEl()
};
a.prototype.resetActiveItem=function(){this.$input.removeAttr("aria-activedescendant");
this.$items.removeAttr("aria-selected id")
};
a.prototype.markActiveItem=function(e){var f="selected-option";
this.$input.attr("aria-activedescendant",f);
e.attr({"aria-selected":"true",id:f})
};
a.prototype.selectItem=function(e){this.activeItem=this.$items.eq(e);
this.$items.removeClass(b.itemActive);
this.activeItem.addClass(b.itemActive);
this.resetActiveItem();
this.markActiveItem(this.activeItem);
this.$input.attr("placeholder",this.activeItem[0].innerText);
this.currentItemIndex=e
};
a.prototype.selectPrev=function(){if(this.currentItemIndex<=0){this.selectItem(this.$items.length-1);
return
}this.selectItem(this.currentItemIndex-1)
};
a.prototype.selectNext=function(){if(this.currentItemIndex>=this.$items.length-1){this.selectItem(0);
return
}this.selectItem(this.currentItemIndex+1)
};
a.prototype.onKeyDown=function(e){switch(e.key){case c.Keys.arrowUp:this.selectPrev();
break;
case c.Keys.arrowDown:this.selectNext();
break;
case c.Keys.enter:this.$input.removeAttr("aria-describedby");
if(this.currentItemIndex>-1){e.preventDefault();
this.$input.val(this.$items.eq(this.currentItemIndex)[0].innerText);
this.clearElState()
}break;
case c.Keys.tab:this.closeEl();
break;
default:break
}};
a.prototype.classes=b;
a.moduleName="Frequent Searches";
a.selector=".frequent-searches-ui";
return a
});
define("TextField",["form","form-control"],function(c,a){function b(d){a.call(this,d);
this.$input=this.$el.find("input");
this.registerField();
this.setUpUrlParams()
}b.prototype=Object.create(a.prototype);
b.prototype.setUpUrlParams=function(){var d=this.$input.attr("data-fill-req-param");
var e=new RegExp("[?&]"+d+"=([^&#]*)").exec(window.location.href);
if(e){this.$input.val(decodeURIComponent(e[1]))
}};
b.prototype.registerField=function(){c.registerField({form:this.$form,field:this.$input.attr("name"),cleanField:this.cleanField.bind(this),displayValue:this.displayValue.bind(this),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),validator:this.getValidator(),validationEvent:this.validationEvents})
};
b.prototype.getValidator=function(){var d=this.context.constraintRegex?c.constraintValidator:c.requiredValidator;
return d(this.$input,this.context)
};
b.prototype.validationEvents="change blur DOMAutoComplete";
b.moduleName="Text Field";
b.selector=".text-field-ui";
return b
});
define("MultiPageForm",["form","form-control","TabsUtil","constants"],function(a,j,e,i){var g=100;
var d={page:".multi-page-form__item",formDescription:".multi-page-form__description",controlsDescription:".multi-page-form__controls-description",field:".form-component__field",skipLink:".multi-page-form__skip-link",submit:'.end button[type="submit"]',complete:"complete",visible:"visible",mainForm:"[data-open-form]",currentPage:"html, body"};
var b=":captchaKey";
var f="captcha";
function c(k){return a.requiredValidator(k,{isRequired:true})().length
}function h(k){e.call(this,k,{items:k.find(d.page)});
this.$isNeedToMove=$(k).find(this.classes.mainForm);
this.$skipLink=this.$el.find(d.skipLink);
this.$formDescription=this.$el.find(d.formDescription);
this.$pageCounterHolder=this.$formDescription.find("span");
this.$controlCounterHolder=this.$el.find(d.controlsDescription+" span");
this.$submit=this.$el.find(d.submit).on("click",this.onSubmit.bind(this));
this.itemsLength=this.$items.length;
this.$nav.off("click").on("click","button",this.onNavClick.bind(this));
this.initForm();
this.listenChanges();
this.updatePageStatus(this.activeItem);
if(this.$isNeedToMove){this.scrollToTheBeginningOfTheForm()
}}h.prototype=Object.create(e.prototype);
h.prototype.initForm=function(){this.formComponent=new a.FormComponent(this.$el);
this.formComponent.initialize();
this.requiredFieldsMap=this.mapRequiredFieldsToPages();
this.formComponent.form.on(a.events.CLEAN_UP,this.clearStatus.bind(this));
this.$skipLink.on("click",this.handleSkipLink.bind(this))
};
h.prototype.scrollToTheBeginningOfTheForm=function(){if(history.scrollRestoration){history.scrollRestoration="manual"
}$(this.classes.currentPage).scrollTop(this.$el.offset().top-g)
};
h.prototype.validatePageFields=function(){var k=this.getPageStatus(this.activeItem);
if(!k){$.each(this.requiredFieldsMap[this.activeItem],function(l,n){if(!n[0].value.length){var m=$(n).closest("[data-required]");
m.addClass(j.classes.fieldError);
m.find("."+j.classes.validationText).text(m.data("required-msg"))
}});
this.formComponent.scrollToError()
}return k
};
h.prototype.onSubmit=function(k){if(!this.getPageStatus(this.activeItem)){k.preventDefault();
this.validatePageFields()
}};
h.prototype.onNavClick=function(l){l.preventDefault();
var k=$(l.currentTarget);
k.is(this.classes.prevButton)&&this.$el.trigger(e.events.tabChange,{tab:this.activeItem-1});
if(!this.getPageStatus(this.activeItem)){this.validatePageFields();
return
}k.is(this.classes.nextButton)&&this.$el.trigger(e.events.tabChange,{tab:this.activeItem+1});
this.afterClick()
};
h.prototype.mapRequiredFieldsToPages=function(){var k=this.isRecaptchaEnable();
var l=[];
$.each(this.$items,function(n,o){if(!l[n]){l[n]=[]
}var m=$(o).find("[data-required] [name]:not([data-required=false])");
$.each(m,function(){var p=$(this).attr("name");
if(p===f&&k||p===b&&k){return
}l[n].push($(this))
})
});
return l
};
h.prototype.listenChanges=function(){var k=function(l){l.on("change",function(){this.updatePageStatus()
}.bind(this))
}.bind(this);
this.requiredFieldsMap.forEach(function(l){l.map(k)
})
};
h.prototype.updatePageStatus=function(){var k=this.activeItem+1;
this.$submit.toggleClass(d.visible,k===this.itemsLength);
this.$prevButton.toggleClass(i.Classes.hidden,k<=1);
this.$nextButton.toggleClass(i.Classes.hidden,k>=this.itemsLength)
};
h.prototype.getPageStatus=function(k){return !this.requiredFieldsMap[k].map(c).filter(Boolean).length
};
h.prototype.clearStatus=function(){this.$el.trigger(e.events.tabChange,{tab:0});
this.$controlCounterHolder.text("1")
};
h.prototype.afterClick=function(){this.updatePageStatus(this.activeItem);
this.$el.scrollToSelector({reservedSpace:100});
this.$pageCounterHolder.text(this.activeItem+1);
this.$controlCounterHolder.text(this.activeItem+1);
this.$formDescription.focus()
};
h.prototype.handleSkipLink=function(k){k.preventDefault();
var l=this.$prevButton.hasClass("hidden")?this.$nextButton:this.$prevButton;
l.focus().scrollToSelector({reservedSpace:110})
};
h.prototype.beforeScroll=function(k){k.scrollToSelector({reservedSpace:110,duration:500})
};
h.prototype.isRecaptchaEnable=function(){var m=this.$el.find(".recaptcha-ui");
var l=this.$el.find("form");
var k=l.find(".captcha-ui");
return m.length&&!k.length||m.length&&!!k.length&&k.data("recaptcha-enabled")
};
h.prototype.classes=$.extend({},e.prototype.classes,d);
h.moduleName="Multi Page Form";
h.selector=".multi-page-form-ui";
return h
});
define("ZipCode",["AbstractLocationField","form","utils-env","geolocation","constants"],function(b,f,e,a,d){function c(g){b.call(this,g);
this.$location.on(this.events.shouldUpdate,this.onParentChange.bind(this));
this.$location.on(this.events.shouldHide,this.hide.bind(this));
e.isEditMode()&&this.$el.removeClass(d.Classes.hidden);
this.$closestForm.on(f.events.ACTIVATE_FORM,function(){this.geolocationEnabled&&a.onGeolocationUpdate(this.fillWithGeolocation.bind(this))
}.bind(this))
}c.prototype=Object.create(b.prototype);
c.prototype.addOption=function(g){this.$select.append('<option value="'+g+'">'+g+"</option>")
};
c.prototype.hide=function(){this.$el.addClass(d.Classes.hidden);
this.countryName="";
this.cleanField()
};
c.prototype.onParentChange=function(g,h){this.countryName=h.countryName;
this.$select.empty().val(null).trigger("change").append(this.getDefaultOption());
this.registerSelectField({validator:this.optionalValidator});
h.postalCodes.map(this.addOption.bind(this));
this.$el.removeClass(d.Classes.hidden+" "+this.classes.errorField);
this.geolocationEnabled&&a.onGeolocationUpdate(this.fillWithGeolocation.bind(this));
this.$location.trigger(d.Events.locationSelectZipCodeUpdate)
};
c.prototype.fillWithGeolocation=function(g){var i=g.postalCode;
var h=this.$el.find(".select2-selection__rendered").attr("title");
if(!h){i&&this.$select.val(i).trigger("change")
}};
c.prototype.events={shouldHide:"location.changed.city:withoutPostalCodes location.changed.region location.changed.country:withRegions location.changed.country:withoutRegions",shouldUpdate:"location.changed.city:withPostalCodes"};
c.moduleName="Zip Code Field";
c.selector=".zip-code-field-ui";
return c
});
define("Region",["AbstractLocationField","utils-env","geolocation","constants","form"],function(c,g,b,f,h){var a="/services/location/regions";
var e={source:".region-field__source"};
function d(i){c.call(this,i);
this.$source=this.$el.find(e.source);
this.$select.on("change",this.onSelectChange.bind(this));
this.$closestForm.on(h.events.ACTIVATE_FORM,function(){this.isGeolocation&&b.onGeolocationUpdate(this.fillWithGeolocation.bind(this))
}.bind(this));
this.$location.on("location.changed.country:withRegions",this.onParentChange.bind(this));
this.$location.on("location.changed.country:withoutRegions",this.hide.bind(this));
g.isEditMode()&&this.$el.removeClass(f.Classes.hidden);
this.registerSelectField({validator:this.optionalValidator})
}d.prototype=Object.create(c.prototype);
d.prototype.hide=function(){this.$el.addClass(f.Classes.hidden);
this.countryName="";
this.cleanField()
};
d.prototype.onParentChange=function(i,j){this.$el.removeClass(this.classes.errorField);
this.shouldValidate=false;
this.countryName=j.countryName;
this.isGeolocation=j.isGeolocation;
this.$select.empty().val(null).trigger("change",{withoutValidation:true}).append(this.getDefaultOption()).append(this.$source.find("[data-country="+this.countryName+"]").clone());
this.$el.removeClass(f.Classes.hidden);
this.getRegions()
};
d.prototype.getRegions=function(){var i={country:this.countryName,locale:CQ.I18n.getLocale()};
$.ajax({url:a,data:i,cache:true,success:this.onLoadSuccess.bind(this),error:console.log})
};
d.prototype.onLoadSuccess=function(i){this.regions=i;
this.$select.empty().val(null).trigger("change",{withoutValidation:true});
var j=this.getDefaultOption();
this.shouldValidate=true;
this.$el.removeClass(f.Classes.hidden);
if(i.length){this.regions.forEach(function(l){var k=l.geolocationName||l.internationalName;
j+='<option value="'+l.internationalName+'" data-geolocation-name="'+k+'" data-iso-code-alpha-2="'+l.isoCodeAlpha2+'">'+l.name+"</option>"
});
this.$select.val("").append(j);
this.$location.trigger(f.Events.locationSelectRegionUpdate,{isEmpty:i.length})
}this.isGeolocation&&b.onGeolocationUpdate(this.fillWithGeolocation.bind(this))
};
d.prototype.fillWithGeolocation=function(i){var j=i.region;
j&&this.$select.val(j).trigger("change",{isGeolocation:true})
};
d.prototype.onSelectChange=function(i,k){var j=this.$select.val();
if(!j){return
}this.$location.trigger("location.changed.region",{countryName:this.countryName,regionName:j,isGeolocation:k&&k.isGeolocation})
};
d.prototype.classes=$.extend({},c.prototype.classes,e);
d.moduleName="Region Field";
d.selector=".region-field-ui";
return d
});
define("Country",["AbstractLocationField","geolocation","utils-env","form"],function(b,a,d,e){var f={PREFERABLE_COUNTRY:"candidatePreferableCountry"};
function c(g){b.call(this,g);
this.configurationWithRegions=this.$location.data("configuration").indexOf("region")>-1;
this.$select.on("change",this.onSelectChange.bind(this));
this.$closestForm.on(e.events.ACTIVATE_FORM,function(){this.geolocationEnabled&&a.onGeolocationUpdate(this.checkAdditionalCondition.bind(this,this.fillWithGeolocation))
}.bind(this));
this.registerSelectField();
this.$selection.addClass(this.classes.validationTarget).attr("aria-required",this.$el.data("required"));
if(!d.isEditMode()&&this.$select.val()!==""){setTimeout(function(){this.onSelectChange()
}.bind(this),0)
}}c.prototype=Object.create(b.prototype);
c.prototype.checkAdditionalCondition=function(j,g){var i=this.$el.attr("name");
var h=this.$el.find(".select2-selection__rendered").attr("title");
if(i===f.PREFERABLE_COUNTRY&&!this.$select.find('[data-geolocation-name="'+g.country+'"]').val()){return
}if(!h){j.call(this,g)
}};
c.prototype.hasRegions=function(g){return !!this.$select.children('[value="'+g+'"]').data("hasRegion")
};
c.prototype.onSelectChange=function(g,i){var q=this.$el.attr("name");
var p=$('.dropdown-list-ui[displayconditions="vacancyCountry"]');
var h=p.attr("showdropdownlist");
if(q==="applicantPreferredCountry"){var o=this.$el.find(".select2-selection__rendered").attr("title");
var n=$(".dropdown-list-ui[applicantpreferredcountries]");
if(o&&n[0]){var j=o.trim();
var k=n.attr("applicantpreferredcountries").split(",");
if(k.indexOf(j)!==-1){n.removeClass("hidden");
n.trigger("setValidation",{isRequired:true})
}else{n.addClass("hidden");
n.trigger("setValidation",{isRequired:false})
}}else{n.addClass("hidden");
n.trigger("setValidation",{isRequired:false})
}}else{if(p&&h==="false"){p.addClass("hidden");
p.trigger("setValidation",{isRequired:false})
}}var l=this.$select.val(),m=this.configurationWithRegions&&this.hasRegions(l)?"location.changed.country:withRegions":"location.changed.country:withoutRegions";
if(l){this.$el.find(".select2-selection__rendered").addClass("country-filled")
}this.$location.trigger(m,{countryName:l,isGeolocation:i&&i.isGeolocation})
};
c.prototype.fillWithGeolocation=function(g){var i=g.country;
if(!i){return
}var h=this.$select.find('[data-geolocation-name="'+i+'"]').val();
this.$select.val(h).trigger("change",{isGeolocation:true})
};
c.prototype.wcmModeChange=null;
c.moduleName="Country Field";
c.selector=".country-field-ui";
return c
});
define("AbstractLocationField",["form","constants","form-control"],function(e,d,a){var c={errorField:a.classes.fieldError,errorTooltip:a.classes.errorTooltip,validationText:a.classes.validationText,input:".form-component__input",label:".form-component__label",formComponentField:"form-component__field",field:"location-fields__column",select:".location-fields__select",location:".location-fields-ui",placeholder:"placeholder",selection:".select2-selection",selectBoxContainer:".select2-container",validationTarget:"validation-focus-target",selectedPlaceholder:".dropdown-list__selected-placeholder",epamContinuumStyle:"epam-continuum-style:not(.epam-redesign-23-style)"};
function b(f){this.$el=f;
this.$closestForm=this.$el.closest("form");
this.$select=this.$el.find(c.select);
this.$input=this.$el.find(c.input);
this.$label=this.$el.find(c.label);
this.$errorTooltip=this.$el.find("."+c.errorTooltip);
this.$location=this.$el.closest(c.location);
this.id=this.$select.attr("id");
this.geolocationEnabled=this.$location.data("useGeolocation");
this.initSelect();
this.$selection=this.$el.find(c.selection).attr("aria-describedby",this.id+"-error");
this.$selectedPlaceholder=this.$el.find(this.classes.selectedPlaceholder);
this.isEpamContinuumStyle=!!this.$el.parents("."+c.epamContinuumStyle).length;
this.initialLabelText=this.$label.text()
}b.prototype.isActive=function(){return !!this.countryName
};
b.prototype.registerSelectField=function(i){var f=i||{},h=f.context||e.extractValidationContext(this.$el),g=f.validator&&f.validator.bind(this)||e.requiredValidator;
return e.registerField({form:this.$closestForm,field:this.fieldName||this.$select.attr("name"),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),cleanField:this.cleanField.bind(this),validator:g(this.$select,h),validationEvent:this.validationEvent})
};
b.prototype.initSelect=function(){this.$select.selectWoo({dropdownParent:this.$input,width:"off"});
this.$selectBoxContainer=this.$el.find(c.selectBoxContainer);
this.$visibleInput=this.$el.find(c.selection);
this.$selectBoxContainer.addClass(c.formComponentField);
this.$visibleInput.on("blur",function(){this.$select.trigger("select2:blur")
}.bind(this));
this.$select.on("select2:selecting",function(f){this.$selectedPlaceholder.text(f.params.args.data.text)
}.bind(this))
};
b.prototype.cleanField=function(){this.$select.val("").trigger("change",{withoutValidation:true})
};
b.prototype.toggleError=function(f){this.$el.toggleClass(c.errorField,!!f);
this.$el.find("."+c.validationText).text(f||"");
this.$errorTooltip.find(".is-a11y-only").toggleClass("hidden",!f);
if(this.isEpamContinuumStyle){this.toggleErrorForNewDesignedForm(f)
}};
b.prototype.toggleErrorForNewDesignedForm=function(f){f?this.$label.text(this.initialLabelText+" ("+f+")"):this.$label.text(this.initialLabelText)
};
b.prototype.optionalValidator=function(f,g){var h=e.requiredValidator(f,g);
return function(){if(this.isActive()){return h()
}return[]
}.bind(this)
};
b.prototype.getDefaultOption=function(){return'<option value="" disabled selected/>'
};
b.prototype.wcmModeChange=function(g){var f=g==="edit";
this.$el.toggleClass("hidden",!f)
};
b.prototype.validationEvent="change blur select2:blur";
b.prototype.classes=c;
return b
});
define("City",["AbstractLocationField","form-control","form","utils-env","geolocation","constants"],function(c,i,a,d,e,h){var f="/services/location/cities";
var b={inputField:".city-field__input",renderedField:".select2-selection__rendered"};
function g(j){c.call(this,j);
this.configuration=this.$location.data("configuration");
this.locationsType=this.$location.data("locationsType");
var k=this.$el.data("disallowOther");
this.countriesWithoutOther=k&&k.split(",");
this.$select.on("change",this.onSelectChange.bind(this));
this.$selectBox=this.$el.find(".select2");
this.$inputField=this.$el.find(b.inputField);
this.fieldName=this.$el.data("fieldName");
this.dontShowCities=this.$el.data("dontShowCities");
this.shouldValidate=false;
this.$location.on("location.changed.country:withoutRegions",this.onParentChange.bind(this)).on("location.changed.region",this.onParentChange.bind(this)).on("location.changed.country:withRegions",this.cleanField.bind(this));
d.isEditMode()&&this.$el.removeClass(h.Classes.hidden);
this.validationCallback=this.registerSelectField({validator:this.validator});
this.$closestForm.on(a.events.ACTIVATE_FORM,function(m,l){this.cancelValidation=null;
if(l==="pageshow"){this.cancelValidation={withoutValidation:true}
}this.geolocationEnabled&&e.onGeolocationUpdate(this.checkAdditionalCondition.bind(this,this.fillWithGeolocation))
}.bind(this));
this.$selection.addClass(this.classes.validationTarget);
this.$inputField.on("keydown",function(){this.isMaxLengthReached()
}.bind(this))
}g.prototype=Object.create(c.prototype);
g.prototype.checkAdditionalCondition=function(l,j){var k=this.$el.find(b.renderedField).attr("title");
if(!k){l.call(this,j)
}};
g.prototype.validator=function(k,l){var m=a.requiredValidator(k,l),j=a.requiredValidator(this.$inputField,l);
return function(){if(!this.isActive()||!this.shouldValidate){return[]
}if(this.$inputField.hasClass(h.Classes.hidden)){return m()
}return j()
}.bind(this)
};
g.prototype.isMaxLengthReached=function(){var k=Number(this.$inputField.attr("maxlength"));
var j=this.$inputField.attr("data-constraint-msg");
if(k===this.$inputField.val().length){this.$el.addClass("validation-field");
$(".validation-text").text(j);
setTimeout(function(){$(".city-field-ui").removeClass("validation-field")
},5000)
}};
g.prototype.isOtherValueDisallowed=function(){return this.countriesWithoutOther&&this.countriesWithoutOther.indexOf(this.countryName)>-1
};
g.prototype.cleanField=function(){this.$el.addClass(h.Classes.hidden);
this.toggleField(this.$inputField);
this.toggleField(this.$select,true);
this.$inputField.removeClass(i.classes.focusTarget);
this.$selection.addClass(i.classes.focusTarget);
this.countryName=""
};
g.prototype.onParentChange=function(j,k){this.$el.removeClass(this.classes.errorField);
this.shouldValidate=false;
this.countryName=k.countryName;
this.regionName=k.regionName;
this.isGeolocation=k.isGeolocation;
this.countryName&&this.getCities()
};
g.prototype.getCities=function(){var j={country:this.countryName,locale:CQ.I18n.getLocale(),configuration:this.configuration,locationsType:this.locationsType};
if(this.regionName){j.region=this.regionName
}$.ajax({url:f,data:j,cache:true,success:function(k){this.clearRenderedTitle();
this.onLoadSuccess(k)
}.bind(this),error:console.log})
};
g.prototype.clearRenderedTitle=function(){this.$el.find(b.renderedField).attr("title","")
};
g.prototype.onLoadSuccess=function(l){this.cities=l;
this.$select.empty().val(null).trigger("change",{withoutValidation:true});
var k=!this.isOtherValueDisallowed(),j=!l.length&&k,m=this.getDefaultOption();
this.shouldValidate=true;
this.$el.removeClass(h.Classes.hidden);
this.$inputField.val(null);
this.toggleField(this.$inputField,j);
this.toggleField(this.$select,!j);
if(this.cities.length===0&&this.dontShowCities){this.$el.addClass("hidden")
}if(l.length){this.cities.forEach(function(o){var n=o.geolocationName||o.internationalName;
m+='<option value="'+o.internationalName+'" data-geolocation-name="'+n+'">'+o.name+"</option>"
});
this.$select.val("")
}if(k){m+='<option value="other" data-geolocation-name="other">'+CQ.I18n.getMessage("component.location-fields.other-city")+"</option>"
}if(l.length||k){this.$select.append(m)
}this.isGeolocation&&e.onGeolocationUpdate(this.fillWithGeolocation.bind(this));
this.$location.trigger(h.Events.locationSelectCityUpdate,{isEmpty:l.length})
};
g.prototype.fillWithGeolocation=function(j){var l=j.city;
if(!l||this.cities===undefined||this.cities.length===0){return
}var k=this.$select.find('[data-geolocation-name="'+l+'"]').val();
this.$select.val(k?k:"other").trigger("change");
k&&this.$inputField.val(l)
};
g.prototype.onSelectChange=function(){var l=this.$select.val();
if(l===null){return
}this.$el.removeClass(this.classes.errorField);
if(l==="other"){if(!this.dontShowCities){this.toggleField(this.$select);
this.toggleField(this.$inputField,true);
this.$inputField.val(null);
this.$selection.removeClass(i.classes.focusTarget);
this.$inputField.addClass(i.classes.focusTarget);
this.$location.trigger("location.changed.city:withoutPostalCodes")
}if(!this.cancelValidation){this.$inputField.focus()
}return
}var m=this.cities.find(function(n){return n.internationalName===l
}),j=m&&m.postalCodes,k=j.length?"location.changed.city:withPostalCodes":"location.changed.city:withoutPostalCodes";
this.$location.trigger(k,!j?null:{postalCodes:j,countryName:this.countryName,isGeolocation:this.isGeolocation})
};
g.prototype.toggleField=function(j,l){var k=this.$select===j?this.$selectBox:j;
if(l){k.removeClass(h.Classes.hidden);
j.attr("name",this.fieldName).on(this.validationEvent,function(m){this.validationCallback(m,this.cancelValidation)
}.bind(this));
return
}k.addClass(h.Classes.hidden);
j.removeAttr("name").off(this.validationEvent,this.validationCallback)
};
g.prototype.classes=$.extend({},c.prototype.classes,b);
g.moduleName="City Field";
g.selector=".city-field-ui";
return g
});
define("LocationField",["LocationField-City","LocationField-Country"],function(c,d){var b={country:".country-field",city:".city-field"};
function a(e){this.$el=e;
this.$form=this.$el.closest("form");
this.$country=this.$el.find(b.country);
this.$city=this.$el.find(b.city);
this.showCity=this.$el.data("showCity");
this.fieldOptions={$form:this.$form,requiredType:this.$el.data("requiredType"),requiredMsg:this.$el.data("requiredMsg"),geolocationEnabled:this.$el.data("useGeolocation")};
this.showCity&&this.initCityField();
this.initCountryField()
}a.prototype.initCityField=function(){var e=$.extend({$el:this.$city},this.fieldOptions);
this.city=new c(e)
};
a.prototype.initCountryField=function(){var e=$.extend({$el:this.$country,showCity:this.showCity,city:this.city},this.fieldOptions);
this.country=new d(e)
};
a.prototype.classes=b;
a.moduleName="Location Field";
a.selector=".location-field-ui";
return a
});
define("LocationField-City",["form","geolocation","constants","form-control"],function(f,b,e,a){var d={column:".location-field__column",input:".city-field__input",select:".city-field__selection",selectBox:".select2",options:"city-field__options",visibleInput:"select2-selection",selectBoxContainer:".select2-container",formComponentField:"form-component__field",selectedPlaceholder:".dropdown-list__selected-placeholder"};
function c(g){this.$el=g.$el;
this.$form=g.$form;
this.requiredType=g.requiredType;
this.requiredMsg=g.requiredMsg;
this.$column=this.$el.closest(d.column);
this.$input=this.$el.find(d.input).show().detach();
this.$select=this.$el.find(d.select);
this.$options=this.$el.find("."+d.options);
this.$errorTooltip=this.$el.find("."+a.classes.errorTooltip);
this.$errorText=this.$el.find("."+a.classes.validationText);
this.id=this.$input.attr("id");
this.$selectedPlaceholder=this.$column.find(this.classes.selectedPlaceholder);
this.eventListened={select:false,input:false};
this.fieldName=this.$el.data("name");
this.validationCallback=f.validationCallback(this.$form,this.fieldName,this.validator.bind(this));
this.initSelect();
this.registerField()
}c.prototype.initSelect=function(){this.$select.selectWoo({dropdownParent:this.$el,width:"off"}).detach();
this.$selectBox=this.$el.find(d.selectBox).addClass(e.Classes.hidden);
this.$select.on("change",this.onSelectChange.bind(this));
this.$selectBoxContainer=this.$el.find(d.selectBoxContainer);
this.$selectBoxContainer.addClass(d.formComponentField);
this.visibleInput=this.$el.find("."+d.visibleInput);
this.visibleInput.addClass(a.classes.focusTarget).attr("aria-describedby",this.id+"-error");
this.visibleInput.on("blur",function(){this.$select.trigger("select2:blur")
}.bind(this));
this.$select.on("select2:selecting",function(g){this.$selectedPlaceholder.text(g.params.args.data.text)
}.bind(this))
};
c.prototype.fillWithGeolocation=function(g){var i=g.city;
if(!i){return
}var h=this.$select.find('[data-geolocation-name="'+i+'"]').val();
if(h){this.$select.val(h).trigger("change")
}else{this.$select.val("Other").trigger("change");
this.$input.val(i)
}};
c.prototype.onSelectChange=function(){if(this.isCityOther(this.$select.val())){this.setInputVisibility(true);
this.toggleError(false)
}};
c.prototype.changeSelectionSet=function(h){var g=this.$options.children('[data-country="'+h+'"]');
this.$select.children("[data-country]").appendTo(this.$options);
this.$select.children(":first").after(g);
this.setInputVisibility(!this.hasCityOptions());
return this
};
c.prototype.setInputVisibility=function(g){if(g){this.$select=this.turnActiveContainer(this.$input,this.$select,"input","blur change DOMAutoComplete",this.validationCallback.bind(this));
this.visibleInput.removeClass(a.classes.focusTarget)
}else{this.$input=this.turnActiveContainer(this.$select,this.$input,"select","change blur select2:blur",this.selectionValidationCallback.bind(this));
this.visibleInput.addClass(a.classes.focusTarget)
}this.$selectBox.toggleClass(e.Classes.hidden,g)
};
c.prototype.turnActiveContainer=function(l,j,i,k,h){var g=j.detach();
this.$el.prepend(l);
l.addClass(a.classes.focusTarget);
j.removeClass(a.classes.focusTarget);
if(!this.eventListened[i]){l.on(k,h);
this.eventListened[i]=true
}return g
};
c.prototype.selectionValidationCallback=function(g,h){if(!this.isCityOther(this.$select.val())){this.validationCallback(g,h)
}};
c.prototype.isCityOther=function(g){return g&&g.toLowerCase()===this.constants.CITY_OTHER.toLowerCase()
};
c.prototype.registerField=function(){f.registerField({form:this.$form,field:this.fieldName,cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),cleanField:this.cleanField.bind(this),displayValue:this.setValue.bind(this),validator:this.validator.bind(this)})
};
c.prototype.toggleError=function(g){this.$column.toggleClass(a.classes.fieldError,!!g);
this.$errorText.text(g||"");
this.$errorTooltip.find(".is-a11y-only").toggleClass("hidden",!g);
return this
};
c.prototype.cleanField=function(){var g=this.hasCityOptions()?"":this.constants.CITY_OTHER;
this.$select.val(g).trigger("change",{withoutValidation:true});
this.$input.val("");
return this
};
c.prototype.setValue=function(g,h){var i=this.hasCityOptions();
if(i){this.$select.val(h).change()
}else{this.$input.val(h)
}this.setInputVisibility(!i)
};
c.prototype.hasCityOptions=function(){return this.$select.children().length>this.constants.DEFAULT_OPTIONS
};
c.prototype.validator=function(){var h=[];
if(this.requiredType==="countryAndCity"){var i=this.$select.val(),g=this.$input.val();
if(!i||this.isCityOther(i)&&!g){h.push(this.requiredMsg)
}}return h
};
c.prototype.toggle=function(g){this.$column.toggleClass(e.Classes.hidden,!g);
return this
};
c.prototype.constants={CITY_OTHER:"Other",DEFAULT_OPTIONS:2};
c.prototype.classes=d;
return c
});
define("LocationField-Country",["form","form-control","geolocation"],function(e,b,a){var d={column:".location-field__column",select:".country-field__selection",visibleInput:".select2-selection",selectBoxContainer:".select2-container",formComponentField:"form-component__field",selectedPlaceholder:".dropdown-list__selected-placeholder"};
function c(f){b.call(this,f.$el);
this.requiredType=f.requiredType;
this.requiredMsg=f.requiredMsg;
this.showCity=f.showCity;
if(this.showCity){this.city=f.city
}this.$column=this.$el.closest(d.column);
this.$input=this.$el.find(d.select);
this.id=this.$input.attr("id");
this.$selectedPlaceholder=this.$column.find(this.classes.selectedPlaceholder);
this.initSelect();
this.registerField();
if(f.geolocationEnabled){a.onGeolocationUpdate(this.fillWithGeolocation.bind(this));
this.showCity&&a.onGeolocationUpdate(this.city.fillWithGeolocation.bind(this.city))
}if(this.$input.val()!==""&&this.showCity){this.onSelectChange()
}}c.prototype=Object.create(b.prototype);
c.prototype.initSelect=function(){this.$input.selectWoo({dropdownParent:this.$el,width:"off"});
this.$selectBoxContainer=this.$el.find(d.selectBoxContainer);
this.$selectBoxContainer.addClass(d.formComponentField);
this.visibleInput=this.$el.find(d.visibleInput);
this.visibleInput.addClass(b.classes.focusTarget).attr("aria-describedby",this.id+"-error");
if(this.showCity){this.$input.on("change",this.onSelectChange.bind(this))
}this.visibleInput.on("blur",function(){this.$input.trigger("select2:blur")
}.bind(this));
this.$input.on("select2:selecting",function(f){this.$selectedPlaceholder.text(f.params.args.data.text)
}.bind(this))
};
c.prototype.fillWithGeolocation=function(f){var h=f.country;
if(!h){return
}var g=this.$input.find('[data-geolocation-name="'+h+'"]').val();
g&&this.$input.val(g).trigger("change")
};
c.prototype.onSelectChange=function(){this.city.changeSelectionSet(this.$input.val()).toggleError(false).toggle(true).cleanField()
};
c.prototype.registerField=function(){e.registerField({form:this.$form,field:this.$el.data("name"),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),cleanField:this.cleanField.bind(this),displayValue:this.setValue.bind(this),validator:this.validator.bind(this),validationEvent:this.validationEvent})
};
c.prototype.setValue=function(f,g){this.$input.val(g).change()
};
c.prototype.cleanField=function(){this.$input.val("").trigger("change",{withoutValidation:true});
if(this.showCity){this.city.toggle()
}};
c.prototype.toggleError=function(f){this.$column.toggleClass(b.classes.fieldError,!!f);
this.$errorText.text(f||"");
this.$errorTooltip.find(".is-a11y-only").toggleClass("hidden",!f)
};
c.prototype.validator=function(){var f=[];
if(this.requiredType!=="notRequired"&&!this.$input.val()){f.push(this.requiredMsg)
}return f
};
c.prototype.validationEvent="change blur select2:blur";
c.prototype.classes=$.extend({},b.prototype.classes,d);
return c
});
define("LinkedInSummary",["form","form-control","LinkedInSummaryPopup","linkedInSummaryParser","utils"],function(g,a,f,d,c){var h={EPAM_CONTINUUM_STYLE:"epam-continuum-style",LABEL:"form-component__label",FAKE_PLACEHOLDER:"fake-placeholder",HIDDEN:"hidden",STANDALONE:"form-component--standalone",BUTTON_LINK:".linkedin-summary__button-link",EDIT_POPUP:".linkedin-summary-popup-ui",TEXT_AREA_FIELD:".linkedin-summary__input"};
var b={openPopup:"summary.popup.open"};
function e(i){this.$el=i;
a.call(this,i);
this.$input=this.$el.find("textarea");
this.registerField();
this.isEpamContinuumStyle=!!this.$el.parents("."+h.EPAM_CONTINUUM_STYLE).length;
this.isStandalone=!!this.$el.parents("."+h.STANDALONE).length;
if(this.isEpamContinuumStyle&&this.$input.attr("placeholder")&&!this.isGoogleChrome()){this.$label=this.$el.find("."+h.LABEL);
this.createFakePlaceholder();
this.removeRealPlaceholder();
this.addEventListener(this.fakePlaceholder);
this.triggerEvent()
}var j=this.$el.closest(".form-constructor-ui");
this.$isStandAloneForm=j.hasClass("form-component--standalone");
this.$buttonLink=this.$el.find(h.BUTTON_LINK);
this.$editPopup=this.$el.find(h.EDIT_POPUP);
this.$textAreaInput=this.$el.find(h.TEXT_AREA_FIELD);
new f(this.$editPopup,this.$textAreaInput);
this.init()
}e.prototype=Object.create(a.prototype);
e.prototype.init=function(){this.initEvents();
if(!this.$isStandAloneForm){this.$textAreaInput.attr("readonly",true)
}};
e.prototype.initEvents=function(){this.$buttonLink.on("click",this.onButtonLinkHandler.bind(this));
$(window).on("linkedin.data.received",this.linkedinDataReceivedEventHandler.bind(this));
$(window).resize(c.debounce(this.resizeEventHandler.bind(this),250))
};
e.prototype.resizeEventHandler=function(){if(this.isStandalone){if(window.matchMedia("(max-width: 991px)").matches){this.$textAreaInput.attr("readonly",true)
}else{this.$textAreaInput.attr("readonly",false)
}}};
e.prototype.linkedinDataReceivedEventHandler=function(i,k){var j=d.formattingLinkedinSummary(k.linkedinData);
this.$textAreaInput.val(j)
};
e.prototype.onButtonLinkHandler=function(){this.$editPopup.trigger(b.openPopup);
this.$editPopup.removeClass(h.HIDDEN)
};
e.prototype.registerField=function(){g.registerField({form:this.$form,field:this.$input.attr("name"),cleanField:this.cleanField.bind(this),displayValue:this.displayValue.bind(this),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),validator:g.requiredValidator(this.$input,this.context),validationEvent:this.validationEvents})
};
e.prototype.isGoogleChrome=function(){return window.navigator.userAgent.indexOf("Chrome")!==-1
};
e.prototype.createFakePlaceholder=function(){let placeholderText=this.$input.attr("placeholder");
this.fakePlaceholder=$("<span>"+placeholderText+"</span>");
this.fakePlaceholder.addClass(h.FAKE_PLACEHOLDER);
this.calcPaddingBottom();
this.setFakePlaceholderHeight();
this.fakePlaceholder.appendTo(this.$el)
};
e.prototype.calcPaddingBottom=function(){this.paddingBottom=this.isStandalone?6.7:6.1
};
e.prototype.setFakePlaceholderHeight=function(){this.fakePlaceholder.css("bottom",this.pixelsToRems(this.$label.height())+this.paddingBottom+"rem")
};
e.prototype.pixelsToRems=function(i){return i/10
};
e.prototype.removeRealPlaceholder=function(){this.$input.removeAttr("placeholder")
};
e.prototype.addEventListener=function(i){this.$input.on("input keydown",function(){$(this).val()?i.addClass(h.HIDDEN):i.removeClass(h.HIDDEN)
})
};
e.prototype.triggerEvent=function(){var i=jQuery.Event("keydown");
this.$input.trigger(i)
};
e.prototype.validationEvents="blur";
e.moduleName="LinkedInSummary";
e.selector=".linkedin-summary-ui";
return e
});
define("LinkedInSummaryPopup",[],function(){var b={CLOSE_BUTTON:".linkedin-summary-close-button",SAVE_BUTTON:".linkedin-summary__button-save",CANCEL_BUTTON:".linkedin-summary__button-cancel",HIDDEN:"hidden",SUMMARY_INPUT:"linkedin-summary__input",EDIT_TEXTAREA:".linkedin-summary__textarea",WARNING_POPUP:".linkedin-summary-warning-popup",BUTTON_NO:".linkedin-summary__warning-button-no",BUTTON_YES:".linkedin-summary__warning-button-yes"};
function a(d,c){this.$el=d;
this.$textAreaInput=c;
this.$closeButton=d.find(b.CLOSE_BUTTON);
this.$cancelButton=d.find(b.CANCEL_BUTTON);
this.$saveButton=d.find(b.SAVE_BUTTON);
this.$editTextArea=d.find(b.EDIT_TEXTAREA);
this.$warningPopup=d.find(b.WARNING_POPUP);
this.$buttonNo=d.find(b.BUTTON_NO);
this.$buttonYes=d.find(b.BUTTON_YES);
this.hasChanged=false;
this.init()
}a.prototype.init=function(){this.initEvents()
};
a.prototype.initEvents=function(){this.$closeButton.on("click",this.onCloseButtonClick.bind(this));
this.$cancelButton.on("click",this.onCloseButtonClick.bind(this));
this.$el.on("summary.popup.open",this.summaryPopupOpenEventHandler.bind(this));
this.$editTextArea.on("keyup",this.onKeyPress.bind(this));
this.$buttonNo.on("click",this.onButtonNoClick.bind(this));
this.$buttonYes.on("click",this.onButtonYesClick.bind(this));
this.$saveButton.on("click",this.onSaveButtonClick.bind(this))
};
a.prototype.onSaveButtonClick=function(d){d.preventDefault();
var c=this.$editTextArea.val();
this.$textAreaInput.val(c);
this.hasChanged=false;
this.$el.addClass(b.HIDDEN)
};
a.prototype.onButtonNoClick=function(c){c.preventDefault();
this.$warningPopup.addClass(b.HIDDEN)
};
a.prototype.onButtonYesClick=function(c){c.preventDefault();
this.$warningPopup.addClass(b.HIDDEN);
this.$el.addClass(b.HIDDEN);
this.hasChanged=false
};
a.prototype.onKeyPress=function(){this.hasChanged=true
};
a.prototype.onCloseButtonClick=function(c){c.preventDefault();
if(this.hasChanged){this.$warningPopup.removeClass(b.HIDDEN)
}else{this.$el.addClass(b.HIDDEN);
this.hasChanged=false
}};
a.prototype.summaryPopupOpenEventHandler=function(){var c=this.$textAreaInput.val();
this.$editTextArea.val(c)
};
a.moduleName="LinkedInSummaryPopup";
a.selector=".linkedin-summary-popup-ui";
return a
});
define("HiddenField",[],function(){var a={mode:"data-value-mode",cookieName:"data-value-cookie-name",clientIdCookie:"_ga",contextHubPersistence:"ContextHubPersistence",contextHubKey:"data-context-hub-key",contextHubRoot:"store."};
function b(c){this.$el=c;
this.$firstRun=true;
this.$mode=this.$el.attr(a.mode);
this.containingForm=c.closest("form");
this.init()
}b.prototype.init=function(){if(this.$mode==="cookie"){this.setUpCookie()
}else{if(this.$mode==="contextHub"&&this.containingForm.length){this.containingForm.on("AJAX_START",this.updateFieldByContextHub.bind(this))
}}};
b.prototype.setUpCookie=function(){var f=this.$el.attr(a.cookieName);
var e=new RegExp(f+"=(.*)");
var d=document.cookie.split(";");
var c=[];
$.each(d,function(g,h){var i=h.match(e);
if(i){c.push(i[1])
}});
this.$el.val(Array.prototype.join.call(c,","));
if(f===a.clientIdCookie&&!this.$el.val().length&&this.$firstRun){setTimeout(function(){this.$firstRun=false;
this.setUpCookie()
}.bind(this),5000)
}};
b.prototype.updateFieldByContextHub=function(){var c=this.$el.attr(a.contextHubKey);
var g=window.localStorage.getItem(a.contextHubPersistence);
if(!c||!g){return
}c=c.startsWith(a.contextHubRoot)?c:a.contextHubRoot+c;
try{var d=JSON.parse(g);
var f=c.split(".").reduce(function(e,i){return e[i]
},d);
if(f){this.$el.val(f)
}}catch(h){console.error(h)
}};
b.moduleName="Hidden Field";
b.selector=".hidden-field-ui";
return b
});
define("GatedForm",["form","utils","utils-browser","analytics","constants"],function(g,a,d,b,e){var f=d.isInternetExplorer();
function c(h){this.$el=h;
this.$continuumStyle=this.$el.hasClass("epam-continuum-style");
this.$form=this.$el.find("form");
this.$email=this.$form.find('input[name="email"]');
this.$originalEmail=this.$form.find('input[name=":originalEmail"]');
this.$cancelLink=this.$el.find("."+this.classes.cancelLink);
this.$downloadButton=this.$el.find("."+this.classes.downloadButton);
this.$downloadLink=this.$el.find("."+this.classes.downloadLink);
this.$callToActionButton=this.$el.find("."+this.classes.callToAction);
this.validationCode=a.getQueryParameters(window.location.href).validationCode;
this.expanded=this.$el.data("expanded");
this.formPath=this.$el.data("form-path");
this.filePath=this.$downloadButton.attr("href");
this.$cancelLink.on("click",this.collapseForm.bind(this));
this.$callToActionButton.on("click",this.expandForm.bind(this));
this.$downloadLink.on("click",this.sendPath.bind(this));
this.$downloadButton.on("click",function(){this.sendPath();
this.sendDownloadEvent()
}.bind(this));
this.initSubmitAgainLink();
this.initFormComponent();
this.addArrow();
if($.cookie("gated-recognition")||this.validationCode&&$.cookie("gated-validation")){this.loadUserData()
}else{if(this.validationCode){this.displayFailedConfirmation()
}}}c.prototype.collapseForm=function(){if(this.expanded){return false
}this.$el.removeClass(this.classes.expandedForm+" "+this.classes.forceDownload);
this.formComponent.cleanForm();
this.$el.trigger(e.Events.gatedFormCollapse);
this.$el.scrollToSelector({reservedSpace:100});
return false
};
c.prototype.expandForm=function(){this.$el.addClass(this.classes.expandedForm);
this.$el.trigger(e.Events.gatedFormExpanded);
return false
};
c.prototype.initSubmitAgainLink=function(){var i=this.$el.find("."+this.classes.emailUpdate+" ."+this.classes.submitAgain),h=this.$el.find("."+this.classes.infoUpdate+" ."+this.classes.submitAgain),j=this.$el.find("."+this.classes.failedConfirmation+" ."+this.classes.submitAgain);
i.on("click",this.hideMessage.bind(this,this.classes.emailUpdateState));
h.on("click",this.hideMessage.bind(this,this.classes.infoUpdateState));
j.on("click",this.hideMessage.bind(this,this.classes.failedConfirmationState))
};
c.prototype.hideMessage=function(h){this.$el.removeClass(h);
this.formComponent.activateForm();
return false
};
c.prototype.initFormComponent=function(){this.formComponent=new g.FormComponent(this.$el,this.$continuumStyle);
$.extend(this.formComponent,{baseSubmitForm:this.formComponent.submitForm,displaySuccessMessage:this.displaySuccessMessage.bind(this),submitForm:this.submitForm.bind(this),cleanForm:this.cleanForm.bind(this)});
this.formComponent.initialize();
this.downloadGtmEventData=this.collectDownloadGtmEventData()
};
c.prototype.displaySuccessMessage=function(){var h=this.classes.successState;
if(this.userEmail){var i=this.equalsIgnoreCase(this.userEmail,this.$email.val());
h=i?this.classes.infoUpdateState:this.classes.emailUpdateState
}this.$el.addClass(h);
this.$el.trigger("form.showMessage");
this.formComponent.cleanForm();
this.syncUserData()
};
c.prototype.collectDownloadGtmEventData=function(){return this.formComponent.gtmEventData&&$.extend({},this.formComponent.gtmEventData,{eventAction:"download"})
};
c.prototype.sendDownloadEvent=function(){b.push(this.downloadGtmEventData)
};
c.prototype.sendPath=function(){$.ajax({url:"/services/interaction/notification/download/asset",type:"POST",data:{formPath:this.formPath,filePath:this.filePath}})
};
c.prototype.equalsIgnoreCase=function(i,h){return i.toLowerCase()===h.toLowerCase()
};
c.prototype.cleanForm=function(){if(this.userData){this.$form.trigger(g.events.CLEAN_UP,{mandatoryOnly:true})
}else{this.$form.trigger(g.events.CLEAN_UP)
}};
c.prototype.syncUserData=function(){if(!this.userData){return
}$.each(this.$form.find(":not(input[type=hidden])").serializeArray(),this.updateUserProperty.bind(this))
};
c.prototype.updateUserProperty=function(h,i){if(!this.shouldIgnoreField(i.name)){this.userData[i.name]=i.value
}};
c.prototype.submitForm=function(){if(this.isUserDataChanged()){this.formComponent.baseSubmitForm();
this.$el.removeClass(this.classes.forceDownload)
}else{this.sendDownloadEvent();
window.location=this.$downloadButton.attr("href");
this.formComponent.activateForm();
return false
}};
c.prototype.isUserDataChanged=function(){if(!this.userData){return true
}return $.grep(this.$form.find(":not(input[type=hidden])").serializeArray(),this.isUserPropertyChanged.bind(this)).length>0
};
c.prototype.isUserPropertyChanged=function(h){return !this.shouldIgnoreField(h.name)&&this.isFieldChanged(h)
};
c.prototype.shouldIgnoreField=function(h){return h.indexOf(":")===0||this.constants.IGNORED_FIELDS.indexOf(h)>=0
};
c.prototype.isFieldChanged=function(i){var h=typeof this.userData[i.name]==="undefined";
if(h&&i.value.length===0){return false
}return h||!this.equalsIgnoreCase(this.userData[i.name],i.value)
};
c.prototype.loadUserData=function(){$.ajax({url:"/services/interaction/gated-form/user-data",type:"GET",data:{validationCode:this.validationCode},cache:false,success:this.onSuccessfulDataLoaded.bind(this),error:this.onErrorDataLoaded.bind(this)})
};
c.prototype.onSuccessfulDataLoaded=function(h){if(!$.isEmptyObject(h)&&h.formData){this.userData=h.formData;
this.displayUserData(h)
}};
c.prototype.displayUserData=function(h){var i=this.classes.expandedForm+" "+this.classes.validatedForm;
this.userEmail=h.formData.email;
this.$originalEmail.val(h.originalEmail);
$.each(h.formData,this.displayFieldValue.bind(this));
if(h.gatedContentPath){this.sendDownloadEvent();
i+=" "+this.classes.forceDownload;
if(f===11){this.setWindowLocation(h.gatedContentPath)
}this.setWindowLocation(h.gatedContentPath);
this.reCheckLinkedinAutofillForm()
}this.$el.addClass(i)
};
c.prototype.addArrow=function(){var j=this.$el.find(this.classes.submitAgainButton);
for(var h=0;
h<j.length;
h++){a.insertArrowPicture($(j[h]))
}};
c.prototype.reCheckLinkedinAutofillForm=function(){var i=document.querySelector(".IN-widget");
var h=document.querySelector('script[type="IN/Form2"]');
if(!i&&h){dispatchEvent(new Event("load"))
}};
c.prototype.setWindowLocation=function(h){window.location=h
};
c.prototype.displayFieldValue=function(i,h){this.$form.trigger(g.events.DISPLAY_VALUE+":"+i,h)
};
c.prototype.onErrorDataLoaded=function(h){if(h.status===400){this.displayFailedConfirmation()
}};
c.prototype.displayFailedConfirmation=function(){this.$el.addClass(this.classes.expandedForm+" "+this.classes.failedConfirmationState);
this.$el.trigger("form.showMessage")
};
c.prototype.constants={IGNORED_FIELDS:["captcha"]};
c.prototype.classes={callToAction:"gated-form__call-to-action-button",cancelLink:"cancel-link",emailUpdate:"gated-form__email-update",infoUpdate:"gated-form__info-update",failedConfirmation:"gated-form__unsuccessful-confirmation",submitAgain:"submit-again",downloadButton:"gated-form__download-button-link",downloadLink:"gated-form__download-link",expandedForm:"gated-form--expanded",validatedForm:"gated-form--validated",successState:"show-success",emailUpdateState:"show-email-update",infoUpdateState:"show-info-update",failedConfirmationState:"show-unsuccessful-confirmation",forceDownload:"force-download",submitAgainButton:".submit-again-arrow-container"};
c.moduleName="Gated Form";
c.selector=".gated-form-ui";
return c
});
define("FormConstructor",["form","constants","utils"],function(h,f,c){var b=$("html");
var a=$("."+f.Classes.overlay);
var e="epam-com/components/form/action/apply-for-job-independent";
var g=null;
function d(i){this.$el=i;
this.$selfIdLink=this.$el.find("."+this.classes.selfIdLink);
this.$selfIdPopup=this.$el.find("."+this.classes.selfIdPopup);
this.$popupCloseTargets=this.$el.find("."+this.classes.popupCloseButton).add(this.$overlay);
this.$continuumStyle=this.$el.hasClass("epam-continuum-style");
this.formComponent=new h.FormComponent(this.$el,this.$continuumStyle);
if(this.$selfIdLink.length){this.$selfIdLink.on("click",function(){if(g!==e){this.togglePopup(false)
}}.bind(this));
this.$popupCloseTargets.on("click",this.togglePopup.bind(this,false));
this.selfIdFormPath=this.$selfIdLink.attr("href");
this.formComponent.onSuccessfulSubmit=this.onSuccessfulSubmit.bind(this)
}this.formComponent.initialize();
this.addArrow()
}d.prototype.addArrow=function(){var k=this.$el.find(this.classes.submitAgainButton);
for(var j=0;
j<k.length;
j++){c.insertArrowPicture($(k[j]))
}};
d.prototype.onSuccessfulSubmit=function(i){g=i.formType;
this.updateSelfIdLink(i);
if(g===e){if(i.isTwoStepCountry){this.$el.find(this.classes.twoStepsSuccessMessage).removeClass("hidden");
this.togglePopup(true)
}else{this.$el.find(this.classes.singleStepSuccessMessage).removeClass("hidden")
}}else{this.$el.find(this.classes.twoStepsSuccessMessage).removeClass("hidden");
this.togglePopup(true)
}};
d.prototype.updateSelfIdLink=function(i){if(i.vacancyId!==undefined){this.$selfIdLink.attr("href",this.selfIdFormPath+"?submitId="+i.submitId+"&vacancyId="+i.vacancyId)
}else{this.$selfIdLink.attr("href",this.selfIdFormPath+"?submitId="+i.submitId)
}};
d.prototype.togglePopup=function(i){b.toggleClass(f.Classes.noscroll,i);
this.$selfIdPopup.toggleClass(f.Classes.hidden,!i);
a.toggleClass(f.Classes.hidden,!i).toggleClass(f.Classes.overlayCoverHeader,i)
};
d.prototype.classes={selfIdLink:"form-component__self-id-link",selfIdPopup:"popup--self-id",popupCloseButton:"form-component__popup-close",twoStepsSuccessMessage:".form-component__two-steps-success-message",singleStepSuccessMessage:".form-component__single-steps-success-message",submitAgainButton:".submit-again-arrow-container"};
d.moduleName="Form Constructor";
d.selector=".form-constructor-ui";
return d
});
define("FileUpload",["form","form-control","utils-browser"],function(e,a,d){var b=10*1024*1024,f=["doc","docx","txt","rtf","pdf","xls","xlsx"];
function c(g){a.call(this,g);
this.$input=this.$el.find("."+this.classes.input);
this.field=this.$input.attr("name");
if(this.isStandard()){this.$path=this.$el.find("."+this.classes.path);
this.defaultPathValue=this.$path.val()
}else{this.$filename=this.$el.find("."+this.classes.filename);
this.$remove=this.$el.find("."+this.classes.removeFile);
this.$remove.on("click",this.cleanField.bind(this,false))
}this.context=this.initValidationContext();
this.registerField();
this.$input.on("change",this.uploadDone.bind(this));
this.$el.toggleClass(this.classes.standardField,this.isStandard())
}c.prototype=Object.create(a.prototype);
c.prototype.uploadDone=function(){var g=this.$input.get(0).files[0].name;
this.toggleUploadState(true);
if(this.isStandard()){this.$path.val(g)
}else{this.$filename.text(g)
}};
c.prototype.toggleUploadState=function(g){this.$el.toggleClass(this.classes.uploadDone,g)
};
c.prototype.registerField=function(){e.registerField({form:this.$form,field:this.field,cleanError:this.toggleError.bind(this),cleanField:this.extendedCleanField.bind(this),displayError:this.toggleError.bind(this),validator:this.fileValidator.bind(this),validationEvent:this.validationEvents})
};
c.prototype.extendedCleanField=function(){this.cleanField();
if(this.isStandard()){this.$path.val(this.defaultPathValue)
}};
c.prototype.afterClean=function(){this.toggleUploadState(false)
};
c.prototype.fileValidator=function(){var g=[];
var h=this.$input.val();
if(h&&!g.length){var i=h.match(/\.(\w+$)/)[1];
if(!this.isAllowedExtension(i)||!this.isAllowedSize()){g.push(this.context.constraintMsg)
}}if(Modernizr.touchevents){return g
}if(this.context.isRequired&&!h){g.push(this.context.requiredMsg)
}return g
};
c.prototype.initValidationContext=function(){var h=e.extractValidationContext(this.$el),i=this.$el.data("maxSize"),g=this.$el.data("allowedExtensions");
h.maxSize=isNaN(i)?b:i*1024*1024;
if(!g){h.allowedExtensions=f
}else{h.allowedExtensions=g.toLowerCase().split(",")
}return h
};
c.prototype.isAllowedExtension=function(g){if(!g){return false
}return this.context.allowedExtensions.indexOf(g.toLowerCase())!==-1
};
c.prototype.isAllowedSize=function(){var g=this.$input[0].files;
return !g||g[0].size<=this.context.maxSize
};
c.prototype.isStandard=function(){return d.isInternetExplorer()||Modernizr.touchevents
};
c.prototype.validationEvents="change";
c.prototype.classes=$.extend({},a.prototype.classes,{removeFile:"file-upload__remove",standardField:"file-upload--standard",uploadDone:"file-upload--done",path:"file-upload__path",filename:"file-upload__filename",input:"file-upload__input",field:"file-upload__field"});
c.moduleName="File Upload";
c.selector=".file-upload-ui";
return c
});
define("DropdownList",["form","form-control","AdditionalField","constants","multi-select"],function(d,a,e,c){function b(g){a.call(this,g);
this.$select=this.$el.find("."+this.classes.select);
this.multiple=this.$select.prop("multiple");
this.defaultValues=(this.$select.data("defaultValues")||"").toString();
this.defaultValues=this.multiple?this.defaultValues.split(","):this.defaultValues;
this.id=this.$select.attr("id");
this.errorId=this.id+"-error";
this.$selectedPlaceholder=this.$el.find(this.classes.selectedPlaceholder);
this.$additionalFieldHolder=this.$el.parent().find(this.classes.additionalFieldHolder);
var f=new e(this.$additionalFieldHolder);
this.validations={isRequired:this.$el.data("required")};
this.$el.on("setValidation",function(i,j){this.validations.isRequired=j.isRequired
}.bind(this));
this.isEpamContinuumStyle=!!this.$el.parents(".epam-continuum-style:not(.epam-redesign-23-style)").length;
this.initSelect();
this.checkNewStyle();
this.registerField();
f.initAdditionalField();
var h=this.getCurrentOptionTriggerEvent();
if(h){this.updateLabelsByEvent(h)
}}b.prototype=Object.create(a.prototype);
b.prototype.checkNewStyle=function(){if(this.isEpamContinuumStyle){this.$errorText=this.$el.find(".form-component__label")
}};
b.prototype.toggleErrorContinuumStyle=function(g){var f=!!g;
this.$el.toggleClass(a.classes.fieldError,f);
this.$input.attr("aria-invalid",f);
this.$errorTooltip.find(".is-a11y-only").toggleClass("hidden",!f);
this.$errorText.text(g||"");
if(!g){this.$errorText.text(this.$errorText.attr("data-title"))
}};
b.prototype.escapeRegExp=function(f){var g=typeof f==="string"||f instanceof String?f:"";
return g.replace(/[-[/\]{}()*+?.,\\^$|#\s]/g,"\\$&")
};
b.prototype.customSearchMatcher=function(m,j){if($.trim(m.term)===""){return j
}var h=this.escapeRegExp(m.term);
if(h.match(/[\.#&\+-\\]/)){var l=new RegExp(h,"i");
if(j.text.match(l)){return j
}}var k=new RegExp("^"+h,"i");
var f=j.text.split(/[\s.&\(/]+/);
for(var g=0;
g<f.length;
g++){if(f[g].match(k)!==null){return j
}}return null
};
b.prototype.optionalValidator=function(f,g){var h=d.requiredValidator(f,g);
return function(){if(this.validations.isRequired){return h()
}return[]
}.bind(this)
};
b.prototype.registerField=function(){d.registerField({form:this.$form,field:this.$select.attr("name"),displayValue:this.setValue.bind(this),cleanField:this.setValue.bind(this),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),validator:this.optionalValidator(this.$select,this.context),validationEvent:this.validationEvents})
};
b.prototype.setValue=function(f,g){this.$select.val(g||this.defaultValues);
this.hideAdditionalField();
this.multiple?this.$select.trigger("synchronize"):this.$select.trigger("change",{withoutValidation:true});
this.toggleError()
};
b.prototype.hideAdditionalField=function(){this.$additionalFieldHolder.addClass(c.Classes.hidden)
};
b.prototype.getCurrentOptionTriggerEvent=function(){return this.$select.find("option:selected").attr("data-trigger-event")
};
b.prototype.updateLabelsByEvent=function(f){$("[data-show-for-event]").addClass("hidden");
$("input").toArray().forEach(function(h){var g=$(h).attr("id");
var i=$('[data-show-for-event~="'+f+'"][for='+g+"]");
if(i.length){i.removeClass("hidden")
}else{$("label[for="+g+'][data-show-for-event="default"]').removeClass("hidden")
}});
$("input").prop("checked",false)
};
b.prototype.initSelect=function(){var g=this.$el.data("required");
var f=this;
this.$select.change(function(){var h=f.getCurrentOptionTriggerEvent();
if(h){f.updateLabelsByEvent(h)
}});
if(this.multiple){this.$select.multiSelectFilter({required:g,labelId:this.id+"-label",errorId:this.errorId});
this.$input=this.$el.find(".multi-select-filter");
return
}this.$select.selectWoo({dropdownParent:this.$el.find("."+this.classes.parent),width:"off",placeholderOption:"first",matcher:this.customSearchMatcher.bind(this)});
this.$selectBoxContainer=this.$el.find(this.classes.selectBoxContainer);
this.$selectBoxContainer.addClass(this.classes.formComponentField);
this.$input=this.$el.find("."+this.classes.visibleInput);
this.$input.addClass(a.classes.focusTarget).attr("aria-describedby",this.errorId).attr("aria-labelledby",this.id+"-label select2-"+this.id+"-container");
this.$input.on("blur",function(){this.$select.trigger("select2:blur")
}.bind(this));
this.$select.on("select2:selecting",function(h){this.$selectedPlaceholder.text(h.params.args.data.text)
}.bind(this))
};
b.prototype.validationEvents="change blur select2:blur";
b.prototype.classes=$.extend({},a.prototype.classes,{select:"dropdown-list__selection",visibleInput:"select2-selection",parent:"form-component__input",selectBoxContainer:".select2-container",formComponentField:"form-component__field",label:"form-component__label",selectedPlaceholder:".dropdown-list__selected-placeholder",additionalFieldHolder:".dropdown-list__additional-field-holder"});
b.moduleName="Dropdown List";
b.selector=".dropdown-list-ui";
return b
});
define("AdditionalField",["form","form-control","constants"],function(d,a,c){function b(e){a.call(this,e);
this.$el=e;
this.$select=this.$el.parent().find("."+this.classes.select);
this.$input=this.$el.find(this.classes.additionalField);
this.$additionalFieldLabel=this.$el.find(this.classes.additionalFieldLabel)
}b.prototype=Object.create(a.prototype);
b.prototype.initAdditionalField=function(){this.$select.on("select2:select",function(e){this.toggleAdditionalField(e)
}.bind(this));
this.$input.on("blur",function(){this.$input.trigger("change")
}.bind(this));
this.registerField()
};
b.prototype.toggleAdditionalField=function(i){var g=i.params.data.element.dataset.additionalValue,j=i.params.data.element.hasAttribute("data-required-field"),f=i.params.data.element.dataset.requiredMessage,e=j&&g,h=e?g+"*":g;
this.$input.val("").attr("placeholder",h);
this.$el.attr({"data-required":e?j:"false","data-required-msg":e?f:null});
this.$additionalFieldLabel.text(h);
this.$el.toggleClass(c.Classes.hidden,!g);
!j&&this.$input.trigger("change")
};
b.prototype.registerField=function(){d.registerField({form:this.$form,field:this.$input.attr("name"),cleanField:this.cleanField.bind(this),displayValue:this.displayValue.bind(this),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),validator:this.getValidator.bind(this),validationEvent:this.validationEvents})
};
b.prototype.getValidator=function(){var e=[],g=this.$el.attr("data-required-msg"),f=this.$input[0];
if(f&&!f.value){g&&e.push(g)
}return e
};
b.prototype.validationEvents="focusout change DOMAutoComplete";
b.prototype.classes=$.extend({},a.prototype.classes,{select:"dropdown-list__selection",additionalField:".dropdown-list__additional-field",additionalFieldLabel:".dropdown-list__additional-field-label"});
b.moduleName="Additional Field";
b.selector=".dropdown-list__additional-field-holder";
return b
});
define("Comment",["form","form-control"],function(c,a){var d={EPAM_CONTINUUM_STYLE:"epam-continuum-style:not(.epam-redesign-23-style)",LABEL:"form-component__label",FAKE_PLACEHOLDER:"fake-placeholder",HIDDEN:"hidden",STANDALONE:"form-component--standalone"};
function b(e){this.$el=e;
a.call(this,e);
this.$input=this.$el.find("textarea");
this.registerField();
this.isEpamContinuumStyle=!!this.$el.parents("."+d.EPAM_CONTINUUM_STYLE).length;
this.isStandalone=!!this.$el.parents("."+d.STANDALONE).length;
if(this.isEpamContinuumStyle&&this.$input.attr("placeholder")&&!this.isGoogleChrome()){this.$label=this.$el.find("."+d.LABEL);
this.createFakePlaceholder();
this.removeRealPlaceholder();
this.addEventListener(this.fakePlaceholder);
this.triggerEvent()
}}b.prototype=Object.create(a.prototype);
b.prototype.registerField=function(){c.registerField({form:this.$form,field:this.$input.attr("name"),cleanField:this.cleanField.bind(this),displayValue:this.displayValue.bind(this),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),validator:c.requiredValidator(this.$input,this.context),validationEvent:this.validationEvents})
};
b.prototype.isGoogleChrome=function(){return window.navigator.userAgent.indexOf("Chrome")!==-1
};
b.prototype.createFakePlaceholder=function(){let placeholderText=this.$input.attr("placeholder");
this.fakePlaceholder=$("<span>"+placeholderText+"</span>");
this.fakePlaceholder.addClass(d.FAKE_PLACEHOLDER);
this.calcPaddingBottom();
this.setFakePlaceholderHeight();
this.fakePlaceholder.appendTo(this.$el)
};
b.prototype.calcPaddingBottom=function(){this.paddingBottom=this.isStandalone?6.7:6.1
};
b.prototype.setFakePlaceholderHeight=function(){this.fakePlaceholder.css("bottom",this.pixelsToRems(this.$label.height())+this.paddingBottom+"rem")
};
b.prototype.pixelsToRems=function(e){return e/10
};
b.prototype.removeRealPlaceholder=function(){this.$input.removeAttr("placeholder")
};
b.prototype.addEventListener=function(e){this.$input.on("input keydown",function(){$(this).val()?e.addClass(d.HIDDEN):e.removeClass(d.HIDDEN)
})
};
b.prototype.triggerEvent=function(){var e=jQuery.Event("keydown");
this.$input.trigger(e)
};
b.prototype.validationEvents="blur";
b.moduleName="Comment";
b.selector=".comment-ui";
return b
});
define("Checkbox",["form","form-control"],function(c,a){function b(d){a.call(this,d);
this.$checkboxHolder=this.$el.find("."+this.classes.checkboxHolder);
this.$input=this.$el.find("input");
this.$errorTooltip=this.$el.find("."+a.classes.errorTooltip);
this.validator=c.requiredValidator(this.$input,this.context);
this.registerField()
}b.prototype=Object.create(a.prototype);
b.prototype.registerField=function(){c.registerField({form:this.$form,field:this.$input.attr("name"),cleanField:this.cleanField.bind(this),cleanError:this.toggleError.bind(this),displayError:this.toggleError.bind(this),validator:this.validator,validationEvent:this.validationEvents})
};
b.prototype.cleanField=function(){this.toggleError();
this.$input.prop("checked",false)
};
b.prototype.toggleError=function(e){var d=!!e;
this.$checkboxHolder.toggleClass(a.classes.fieldError,d);
this.$input.attr("aria-invalid",d);
this.$errorTooltip.text(e||"")
};
b.prototype.validationEvents="change DOMAutoComplete";
b.prototype.classes=$.extend({},a.prototype.classes,{checkboxHolder:"checkbox__holder"});
b.moduleName="Checkbox";
b.selector=".checkbox-ui";
return b
});
define("Captcha",["form","form-control","utils-env"],function(h,b,g){var e=60*1000,c="jcr_content_",d={};
var a={oldView:"/services/interaction/captcha.png?:captchaKey=",redesignView:"/services/interaction/captcha23.png?:captchaKey="};
function f(i){this.$el=i;
this._lightMode=$(document.body).hasClass(this.classes.lightMode);
this._darkMode=$(document.body).hasClass(this.classes.darkMode);
this.isEditMode=g.isEditMode();
this.reCaptchaEnabled=this.$el.data("recaptcha-enabled");
if(this.reCaptchaEnabled&&!this.isEditMode){return
}this.$window=$(window);
this.$form=this.$el.closest("form");
this.$input=this.$el.find("."+this.classes.input);
this.$captchaImage=this.$el.find("."+this.classes.captchaImage);
this.$captchaKey=this.$el.find('input[name=":captchaKey"]');
this.$errorTooltip=this.$el.find("."+b.classes.errorTooltip);
this.context=h.extractValidationContext(this.$el);
this.interval=setInterval(this.refreshCaptcha.bind(this),e);
this.isTabActive=!document.hidden;
this.captchaId=this.$captchaKey.attr("id");
this.captchaId=this.captchaId.substring(this.captchaId.indexOf(c)+c.length);
this.registerField();
this.$window.blur(this.windowBlur.bind(this));
this.$window.focus(this.windowFocus.bind(this));
$.when(d.loadPromise).then(d.loadPromise?this.refreshCaptcha.bind(this):this.initLoadPromise.bind(this))
}f.prototype.registerField=function(){h.registerField({form:this.$form,field:this.$input.attr("name"),mandatoryCleanUp:true,cleanField:this.cleanField.bind(this),cleanError:this.cleanError.bind(this),displayError:this.displayError.bind(this),validator:h.requiredValidator(this.$input,this.context)})
};
f.prototype.windowBlur=function(){this.isTabActive=false;
clearInterval(this.interval)
};
f.prototype.windowFocus=function(){this.isTabActive=true;
this.updateCaptcha()
};
f.prototype.cleanField=function(){this.$input.val("");
this.updateCaptcha()
};
f.prototype.cleanError=function(){this.$el.removeClass(b.classes.fieldError);
this.$errorTooltip.text("")
};
f.prototype.displayError=function(i){this.$el.toggleClass(b.classes.fieldError,!!i);
this.$errorTooltip.text(i||"");
this.updateCaptcha()
};
f.prototype.refreshCaptcha=function(){if(this.isTabActive){var i=this.captchaId+"_"+new Date().getTime();
this.modifyCaptchaSrcAttribute(i);
this.$captchaKey.val(i)
}};
f.prototype.modifyCaptchaSrcAttribute=function(i){if(this._lightMode){this.$captchaImage.attr("src",a.redesignView+i+"&mode=light");
return
}if(this._darkMode){this.$captchaImage.attr("src",a.redesignView+i+"&mode=dark");
return
}this.$captchaImage.attr("src",a.oldView+i)
};
f.prototype.initLoadPromise=function(){var i=$.Deferred();
this.$captchaImage.one("load",function(){i.resolve()
});
this.refreshCaptcha();
d.loadPromise=i.promise()
};
f.prototype.updateCaptcha=function(){clearInterval(this.interval);
this.refreshCaptcha();
this.interval=setInterval(this.refreshCaptcha.bind(this),e)
};
f.prototype.classes={input:"captcha__input",captchaImage:"captcha__image",parentForm:".form-component",darkMode:"dark-mode",lightMode:"light-mode"};
f.moduleName="Captcha";
f.selector=".captcha-ui";
return f
});
define("Footer",["WeChatPopup","jquery-plugins"],function(b){function a(c){this.$el=c;
this.$linksContainer=this.$el.find("."+this.classes.linksContainer);
this.$weChatLink=this.$el.find("."+this.classes.link+'[data-type="wechat"]');
this.data={src:this.$el.data("wechatQrSrc"),id:this.$el.data("wechatId")};
$(window).on("resize",this.removeLinksDot.bind(this));
$.onFontLoad(this.removeLinksDot.bind(this));
this.$weChatLink.length&&this.initWeChatPopup()
}a.prototype.removeLinksDot=function(){var d=this.classes.pipe,c;
this.$linksContainer.each(function(){var e=$(this);
e.toggleClass(d,$.isOffsetEqual([c||e,e]));
c=e
})
};
a.prototype.initWeChatPopup=function(){this.$popup=new b();
this.$weChatLink.on("click",function(c){c.preventDefault();
this.$popup.open(this.data,this.$weChatLink)
}.bind(this))
};
a.prototype.classes={linksContainer:"footer__links-container",link:"footer__social-link",pipe:"item--piped"};
a.selector=".footer-ui";
a.moduleName="Footer";
return a
});
define("DoubleSection",["imager"],function(a){function b(c){this.$el=c;
this.$placeholder=this.$el.find("."+this.classes.placeholder);
a.create(this.$placeholder)
}b.prototype.classes={placeholder:"double-section__placeholder"};
b.selector=".double-section-ui";
b.moduleName="Double Section";
return b
});
define("BackgroundVideo",["utils","media"],function(a,d){var f=$(window),e=52;
var c={container:".background-video__container",showMobileImage:"background-video--show-mobile-image",fullSizeVideo:"background-video--match-size-of-video",contentPointer:"background-video__content-pointer",soundIcon:"background-video__sound-icon",enableSound:"background-video__hasSound",showArrow:"background-video__show-arrow"};
function b(g){this.$el=g;
this.$parent=this.$el.parent(".background-video");
this.$parent.addClass("background-video--relative");
this.$player=this.$el.find(c.container)[0];
this.$contentPointer=this.$parent.find("."+c.contentPointer);
this.$soundIcon=this.$parent.find("."+c.soundIcon);
this.$isShowArrow=this.$el.hasClass(c.showArrow);
this.$playSound=this.$el.hasClass(c.enableSound);
$(document).ready(this.documentReadyCallback.bind(this));
f.on("scroll",a.debounce(this.scrollCallback.bind(this),3));
f.on("resize",a.debounce(this.resizeCallback.bind(this),100));
this.$contentPointer.on("click",this.scrollToContent.bind(this));
this.$soundIcon.on("click",this.toggleMute.bind(this))
}b.prototype.getVideoRect=function(){return{bottomY:this.$el[0].getBoundingClientRect().bottom+window.pageYOffset}
};
b.prototype.scrollToContent=function(){$("html, body").animate({scrollTop:this.getVideoRect().bottomY-e},800)
};
b.prototype.callbackFunctions=function(){this.playPauseVideo();
if(this.$isShowArrow){this.isShowAdditionalIcons()
}};
b.prototype.documentReadyCallback=function(){this.callbackFunctions();
if(!this.$isShowArrow){this.$contentPointer.addClass("hidden")
}};
b.prototype.scrollCallback=function(){this.callbackFunctions()
};
b.prototype.resizeCallback=function(){this.callbackFunctions()
};
b.prototype.isShowAdditionalIcons=function(){if(!this.$el.hasClass(c.fullSizeVideo)){return
}var g=window.innerHeight+window.pageYOffset;
if(this.getVideoRect().bottomY>g&&this.$el.hasClass(c.fullSizeVideo)&&d.currentMode().greaterThan(d.modes.Tablet)){this.$contentPointer.removeClass("hidden");
this.$soundIcon.addClass("background-video--icon-fixed");
return
}this.$contentPointer.addClass("hidden");
this.$soundIcon.removeClass("background-video--icon-fixed")
};
b.prototype.toggleMute=function(){if(this.$player.muted){this.$soundIcon.addClass("background-video--sound-enabled");
this.$player.muted=false
}else{this.$player.muted=true;
this.$soundIcon.removeClass("background-video--sound-enabled")
}};
b.prototype.isOnScreen=function(){var j=f.scrollTop(),h=j+f.height(),g=this.$el.offset().top,i=g+this.$el.outerHeight()/2;
return !(j+e>i||i>h)
};
b.prototype.playPauseVideo=function(){var g=this.$el.hasClass(c.showMobileImage)&&d.currentMode().lessThan(d.modes.Tablet);
if(!g&&this.isOnScreen()){this.$player.play();
return
}this.$player.pause()
};
b.selector=".background-video-ui";
b.moduleName="Background Video";
return b
});
define("Accordion",["utils-env"],function(d){function a(e){this.$el=e;
this.$accordionButton=e.find(b.accordionButton);
this.$accordionButtonRead=e.find(b.accordionButtonRead);
this.$accordionBackgroundPanel=e.find(b.accordionBackgroundPanel);
this.$accordionPasys=e.find(b.accordionPasys);
this.$responsiveImages=this.$el.find(b.responsiveImage);
this.init();
if(d.isEditMode()){this.$accordionPasys.removeClass(b.hidden)
}}a.prototype.init=function(){this.$accordionBackgroundPanel.click(this.toggleContent.bind(this,false));
this.$accordionButtonRead.click(this.toggleContent.bind(this,true));
var e=this.$accordionButton.attr(c.showInExpandedView);
if(e==="true"){this.$accordionPasys.removeClass(b.hidden);
this.$accordionButtonRead.text(c.readLess);
this.$accordionButton.removeClass(b.accordionButtonOpen);
this.$responsiveImages.trigger(c.renderImage);
this.$accordionButtonRead.attr("aria-label",c.readLess);
this.$accordionBackgroundPanel.attr("aria-label",c.expanded)
}};
a.prototype.toggleContent=function(e){this.$responsiveImages=this.$el.find(b.responsiveImage);
var f=this.$el.offset().top;
if(this.$accordionPasys.hasClass(b.hidden)){this.$accordionPasys.removeClass(b.hidden);
this.$accordionButton.removeClass(b.accordionButtonOpen);
this.$accordionButtonRead.text(c.readLess);
this.$responsiveImages.trigger(c.renderImage);
this.$accordionBackgroundPanel.attr("aria-expanded",true);
this.$accordionBackgroundPanel.attr("aria-label",c.expanded);
this.$accordionButtonRead.attr("aria-label",c.readLess)
}else{this.$accordionPasys.addClass(b.hidden);
this.$accordionButton.addClass(b.accordionButtonOpen);
this.$accordionButtonRead.text(c.readMore);
this.$accordionButtonRead.attr("aria-label",c.readMore);
this.$accordionBackgroundPanel.attr("aria-expanded",false);
this.$accordionBackgroundPanel.attr("aria-label",c.collapsed);
if(e&&$(window).width()<=c.mobileDevice){$(window).scrollTop(f-83)
}else{if(e){$(window).scrollTop(f-95)
}}}};
var c={readLess:Granite.I18n.get("component.accordion.read_less"),readMore:Granite.I18n.get("component.accordion.read_more"),showInExpandedView:"showInExpandedView",renderImage:"renderImage",collapsed:"collapsed",expanded:"expanded",mobileDevice:991};
var b={accordionBackgroundPanel:".accordion__background-panel",accordionButton:".accordion__button",accordionButtonRead:".accordion__button-read",accordionPasys:".accordion__parsys",responsiveImage:".responsive-image-ui",accordionButtonOpen:"accordion__button-open",hidden:"hidden"};
a.moduleName="Accordion";
a.selector=".accordion-ui";
return a
});
"use strict";
var _createClass=function(){function a(e,c){for(var b=0;
b<c.length;
b++){var d=c[b];
d.enumerable=d.enumerable||false;
d.configurable=true;
if("value" in d){d.writable=true
}Object.defineProperty(e,d.key,d)
}}return function(d,b,c){if(b){a(d.prototype,b)
}if(c){a(d,c)
}return d
}
}();
function _toConsumableArray(a){if(Array.isArray(a)){for(var c=0,b=Array(a.length);
c<a.length;
c++){b[c]=a[c]
}return b
}else{return Array.from(a)
}}function _classCallCheck(a,b){if(!(a instanceof b)){throw new TypeError("Cannot call a class as a function")
}}define("ColumnControl",[],function(){var b={COLUMN_CONTROL_COLUMN:"colctrl__col",TEXT_UI:"text-ui"};
var a=function(){function l(o){var q=this;
_classCallCheck(this,l);
this.el=o[0];
var p=this.el.getAttribute("data-is-list");
p&&window.addEventListener("DOMContentLoaded",function(){q.items=q.getInteractiveItems();
q.items.length&&q.init()
})
}_createClass(l,[{key:"getInteractiveItems",value:function m(){var o=this;
return Array.from(this.el.querySelectorAll("."+b.COLUMN_CONTROL_COLUMN)).map(function(q){var p=q.querySelectorAll("img, ."+b.TEXT_UI);
if(p.length===0){return q
}if(p.length===1){return p[0]
}return o.getClosestCommonParent(Array.from(p))
})
}},{key:"getClosestCommonParent",value:function d(o){var p=o[0];
while(p.parentNode){p=p.parentNode;
if(o.every(function(q){return p.contains(q)
})){return p
}}}},{key:"init",value:function n(){var o;
if(!window.accessibility){window.accessibility={startIndexes:[],items:[],indexOfCurrentItem:-1};
this.addEventListenerForNavigationOnPage();
this.addEventListenerForNavigationInList();
this.addEventListenerOnTabPress()
}this.createRefresherForIndexOfCurrentItem();
window.accessibility.startIndexes.push(window.accessibility.items.length);
(o=window.accessibility.items).push.apply(o,_toConsumableArray(this.items))
}},{key:"addEventListenerForNavigationOnPage",value:function h(){var o=this;
window.addEventListener("keydown",function(p){if(p.key.toLowerCase()==="l"){!p.shiftKey?o.changeIndexOfCurrentItem(o.findNextStartIndex()):o.changeIndexOfCurrentItem(o.findPreviousStartIndex())
}})
}},{key:"findNextStartIndex",value:function j(){for(var o=0;
o<window.accessibility.startIndexes.length;
o++){if(window.accessibility.startIndexes[o]>window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"findPreviousStartIndex",value:function e(){for(var o=window.accessibility.startIndexes.length-1;
o>=0;
o--){if(window.accessibility.startIndexes[o]<window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"changeIndexOfCurrentItem",value:function f(o){if(o>=0&&o<=window.accessibility.items.length-1){window.accessibility.indexOfCurrentItem=o;
this.setFocusToCurrentItem()
}}},{key:"setFocusToCurrentItem",value:function k(){var q=window.accessibility.items[window.accessibility.indexOfCurrentItem];
var p=q.getAttribute("tabindex")&&q.getAttribute("tabindex")!=="-1";
if(!p){q.setAttribute("tabindex",0);
q.addEventListener("focusout",function o(){q.setAttribute("tabindex",-1);
q.removeEventListener("focusout",o)
})
}q.focus()
}},{key:"addEventListenerForNavigationInList",value:function i(){var o=this;
window.addEventListener("keydown",function(p){if(p.key==="ArrowRight"||!p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem+1)
}else{if(p.key==="ArrowLeft"||p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem-1)
}}})
}},{key:"addEventListenerOnTabPress",value:function c(){window.addEventListener("keydown",function(o){if(o.key==="Tab"){setTimeout(function(){var p=window.accessibility.items.findIndex(function(q){return document.activeElement.compareDocumentPosition(q)!==Node.DOCUMENT_POSITION_PRECEDING
});
window.accessibility.indexOfCurrentItem=p===-1?window.accessibility.items.length-1:p
},0)
}})
}},{key:"createRefresherForIndexOfCurrentItem",value:function g(){this.items.forEach(function(o){o.addEventListener("focus",function(){window.accessibility.indexOfCurrentItem=window.accessibility.items.indexOf(o)
})
})
}}]);
return l
}();
a.moduleName="Column Control";
a.selector=".colctrl-ui";
return a
});
define("MultiStyleSliderConstants",function(){var c={common:{carousel:".owl-carousel",disabledArrow:"disable-nav-arrow",prevButton:".owl-prev",nextButton:".owl-next",navigationPanel:".owl-nav",isHasImagesSlide:".multi-style-slider-slide-type.slider--images",disableOwlSwipe:"disable-owl-swipe",activeSlide:".owl-item.active",hideTitle:"hide-title"},manual:{imageSlide:".slider--images",imagesTrack:".multi-style-slider-images-track",image:".multi-style-slider-image"}};
var b={stopAutoPlay:"stop.owl.autoplay",translated:"translated.owl.carousel",initialized:"initialized.owl.carousel",swipeEvents:"touchstart mousedown",slide:{nextSlide:"next.owl.carousel",prevSlide:"prev.owl.carousel"},swipe:{left:"swipeleft",right:"swiperight"},resumeAutoPlay:"play.owl.autoplay",mouse:{leave:"mouseleave",enter:"mouseenter"}};
var d=20;
var e='<svg class="navigation__arrow" width="35" height="15" viewBox="0 0 35 15" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M33.7337 8.18953C34.1242 7.799 34.1242 7.16584 33.7337 6.77532L27.3697 0.411354C26.9792 0.0208297 26.346 0.0208297 25.9555 0.411354C25.565 0.801878 25.565 1.43504 25.9555 1.82557L31.6124 7.48242L25.9555 13.1393C25.565 13.5298 25.565 14.163 25.9555 14.5535C26.346 14.944 26.9792 14.944 27.3697 14.5535L33.7337 8.18953ZM0 8.48242H33.0266V6.48242H0V8.48242Z" fill="#222222"/>\n</svg>';
var a={items:1,dots:false,loop:true,autoplay:false,nav:true,navText:[e,e]};
return{classes:c,defaultSliderOptions:a,events:b,RESPONSIVE_PADDING:d}
});
define("MultiStyleSlider",["MultiStyleSliderConstants","MultiStyleSliderHandlers","utils-env"],function(c,a,d){var b=function(){function l(n){_classCallCheck(this,l);
this._el=n[0];
this.isEditMode=d.isEditMode();
this.sliderSpeed=this._el.dataset.playSpeed;
this.slider=this._el.querySelector(c.classes.common.carousel);
this.isHasImagesSlide=this._el.querySelector(c.classes.common.isHasImagesSlide);
this._context={self:this};
this.init()
}_createClass(l,[{key:"init",value:function m(){this.initSliderEvents()
}},{key:"initSliderEvents",value:function k(){var n=this;
window.addEventListener("DOMContentLoaded",function(){if(!n.isEditMode){$(n.slider).one(c.events.initialized,a.carouselInitialized(n._context));
$(n.slider).one(c.events.translated,a.enableNavigationArrow(n._context));
$(n.slider).on(c.events.translated,a.removeTitleUnderImagesSlide(n._context));
a.initOwlCarousel(n._context);
n.initAdditionalSliderVariables();
n.unbindDefaultCarouselEvents();
n.initSliderNavigation();
n.initImagesSliderNavigation();
n.initSpecialEvents();
a.initCustomAutoPlay(n._context);
a.removeTitleUnderImagesSlide(n._context)()
}});
this.handleSliderStopAutoPlay()
}},{key:"handleSliderStopAutoPlay",value:function j(){if(this.sliderSpeed>0){this._el.addEventListener(c.events.mouse.enter,a.mouseEnterEventHandler(this._context));
this._el.addEventListener(c.events.mouse.leave,a.mouseLeaveEventHandler(this._context))
}}},{key:"initAdditionalSliderVariables",value:function i(){this.nextButton=this._el.querySelector(c.classes.common.nextButton);
this.prevButton=this._el.querySelector(c.classes.common.prevButton);
this.navigationPanel=this._el.querySelector(c.classes.common.navigationPanel)
}},{key:"unbindDefaultCarouselEvents",value:function e(){if(this.isHasImagesSlide){$(this.nextButton).unbind();
$(this.prevButton).unbind()
}}},{key:"initSliderNavigation",value:function h(){if(!this.isHasImagesSlide){var n={self:this};
this.nextButton.addEventListener("click",a.stopAutoPlay(n));
this.prevButton.addEventListener("click",a.stopAutoPlay(n))
}}},{key:"initImagesSliderNavigation",value:function f(){var n=this;
if(this.isHasImagesSlide){this.nextButton.addEventListener("click",function(){a.stopAutoPlay({self:n});
a.handleImagesNavigations({self:n,direction:"right"})()
});
this.prevButton.addEventListener("click",function(){a.stopAutoPlay({self:n});
a.handleImagesNavigations({self:n,direction:"left"})()
})
}}},{key:"initSpecialEvents",value:function g(){this.navigationPanel.addEventListener("click",a.enableNavigationArrow({self:this}),{once:true})
}}]);
return l
}();
b.selector=".multi-style-slider-ui";
b.moduleName="Multi Style Slider";
return b
});
define("MultiStyleSliderHandlers",["MultiStyleSliderConstants","MultiStyleSliderUtils"],function(m,l){var e=function e(r){var q=r.self;
var p=l.getSliderConfig({isHasImagesSlide:q.isHasImagesSlide,speed:q.sliderSpeed,self:q,callback:n});
$(q.slider).owlCarousel(p)
};
var n=function n(q){var p=q.self;
return function(){if(p.isHasImagesSlide){clearInterval(p.customTimerId)
}else{$(p.slider).trigger(m.events.stopAutoPlay)
}}
};
var a=function a(q){var p=q.self;
if(p.isHasImagesSlide){b({self:p})
}else{$(p.slider).trigger(m.events.resumeAutoPlay,[p.sliderSpeed*1000])
}};
var b=function b(q){var p=q.self;
if(p.isHasImagesSlide&&p.sliderSpeed>0){p.customTimerId=l.createInterval(function(){f({self:p,direction:"right"})()
},p.sliderSpeed)
}};
var i=function i(q){var p=q.self;
return function(){n({self:p})()
}
};
var g=function g(q){var p=q.self;
return function(){a({self:p})
}
};
var c=function c(p){return function(){p.self._el.classList.remove(m.classes.common.disabledArrow)
}
};
var h=function h(p){return function(){k(p);
d(p)
}
};
var k=function k(q){var p=q.self;
var r=$(p._el).find(m.classes.manual.imageSlide);
if(r.length>0){r.on(m.events.swipeEvents,function(s){s.stopPropagation()
})
}};
var d=function d(q){var p=q.self;
var r=$(p._el).find(m.classes.manual.imagesTrack);
if(r.length>0){r.on(m.events.swipe.left,function(s){o(p,s.currentTarget,"left")
});
r.on(m.events.swipe.right,function(s){o(p,s.currentTarget,"right")
})
}};
var o=function o(p,s,q){var r=l.isPossibleSlideToSwitch(s,q);
if(r&&r.event){$(p.slider).trigger(r.event)
}};
var f=function f(q){var p=q.self,r=q.direction;
return function(){var u=l.getActiveSlide(p);
var t=u.querySelector(m.classes.manual.imagesTrack);
if(r==="right"){if(t){var v=l.getScrollMoveDistance(t,"right");
if(v>0){l.moveScrollToPosition(t,v+10)
}if(v<0){$(p.slider).trigger(m.events.slide.nextSlide)
}}else{$(p.slider).trigger(m.events.slide.nextSlide)
}}if(r==="left"){if(t){var s=l.getScrollMoveDistance(t,"left");
if(s>=0){$(p.slider).trigger(m.events.slide.prevSlide)
}if(s<0){l.moveScrollToPosition(t,s)
}}else{$(p.slider).trigger(m.events.slide.prevSlide)
}}}
};
var j=function j(q){var p=q.self;
return function(){var r=l.getActiveSlide(p);
var s=r.querySelector(m.classes.manual.imageSlide);
if(s){p._el.classList.add(m.classes.common.hideTitle)
}else{p._el.classList.remove(m.classes.common.hideTitle)
}}
};
return{initOwlCarousel:e,enableNavigationArrow:c,stopAutoPlay:n,carouselInitialized:h,handleImagesNavigations:f,removeTitleUnderImagesSlide:j,mouseEnterEventHandler:i,mouseLeaveEventHandler:g,initCustomAutoPlay:b}
});
define("MultiStyleSliderUtils",["MultiStyleSliderConstants"],function(j){var h=function h(q){var p=q.isHasImagesSlide,r=q.speed,n=q.self,t=q.callback;
var s=r*1000;
var m=j.defaultSliderOptions;
var o=null;
if(s>0){o={autoplayTimeout:s,autoplay:!p,onDragged:t({self:n})}
}return o?Object.assign({},m,o):m
};
var g=function g(o,n){var m=o.offsetWidth+o.scrollLeft;
if(n==="right"&&o.scrollLeft===0){return{event:j.events.slide.prevSlide}
}if(n==="left"&&m>=o.scrollWidth){return{event:j.events.slide.nextSlide}
}return null
};
var k=function k(n){var m=n.offsetWidth+n.scrollLeft;
return n.scrollWidth-m
};
var d=function d(p){var m=p.getBoundingClientRect(),o=m.left,n=m.right;
return{left:o,right:n}
};
var e=function e(m,u){var p=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;
var s=d(m),v=s.left,t=s.right;
var w={currentImage:null,nextImage:null,fullyDisplayedImage:null,prevImage:null};
for(var r=0;
r<u.length;
r++){var o=d(u[r]),q=o.left,n=o.right;
if(v<q&&t>n){w.fullyDisplayedImage=u[r];
w.nextImage=u[r+1]||u[r];
w.prevImage=u[r-1]||u[r]
}if(v>q&&q<t&&n>v){w.currentImage=u[r];
w.nextImage=u[r+1]||u[r]
}if(p&&(w.currentImage||w.fullyDisplayedImage)){return w
}}return w
};
var b=function b(p,n){var t=e(p,n);
var r=t.nextImage;
var o=d(p),q=o.left;
if(r){var m=d(r),s=m.left;
return s-q
}return -1
};
var i=function i(n,r){var q=e(n,r,true);
var o=q.currentImage,w=q.fullyDisplayedImage,m=q.prevImage;
var x=d(n),u=x.left;
if(w){var v=d(m),p=v.left;
return p-u
}else{if(o){var t=d(o),s=t.left;
return s-u
}}return 0
};
var f=function f(n,r){var m=n.querySelectorAll(j.classes.manual.image);
if(r==="right"){var o=b(n,m);
var q=k(n);
if(q<=1){return -1
}return o-j.RESPONSIVE_PADDING
}if(r==="left"){var p=i(n,m);
return p-j.RESPONSIVE_PADDING
}};
var c=function c(m,n){m.scrollBy({left:n,behavior:"smooth"})
};
var a=function a(n,m){if(m>0){return setInterval(function(){n()
},m*1000)
}};
var l=function l(m){return m._el.querySelector(j.classes.common.activeSlide)
};
return{getSliderConfig:h,isPossibleSlideToSwitch:g,moveScrollToPosition:c,getScrollMoveDistance:f,createInterval:a,getActiveSlide:l}
});
define("PaddingComponent",["utils"],function(a){var d={DATA_DESKTOP_HEIGHT:"data-desktopHeight",DATA_RESPONSIVE_HEIGHT:"data-responsiveHeight",DATA_RESPONSIVE_BREAKPOINTS:"data-responsiveBreakpoints",TABLET:"tablet",MOBILE:"mobile"};
var c={mobile:"(max-width: 767px)",tablet:"(min-width: 768px) and (max-width: 991px)"};
var b=function(){function e(h){_classCallCheck(this,e);
this._el=h[0];
this.desktopHeight=this._el.getAttribute(d.DATA_DESKTOP_HEIGHT);
this.responsiveHeight=this._el.getAttribute(d.DATA_RESPONSIVE_HEIGHT)||this.desktopHeight;
this.breakPoint=this._el.getAttribute(d.DATA_RESPONSIVE_BREAKPOINTS);
this.isTabletBreakPoint=this.breakPoint===d.TABLET;
this.isMobileBreakPoint=this.breakPoint===d.MOBILE;
this.init()
}_createClass(e,[{key:"init",value:function g(){this.resizeEventHandler();
window.addEventListener("resize",a.debounce(this.resizeEventHandler.bind(this),300))
}},{key:"resizeEventHandler",value:function f(){var i=window.matchMedia(c.tablet).matches;
var h=window.matchMedia(c.mobile).matches;
if(this.isTabletBreakPoint&&(h||i)){this._el.style.height=this.responsiveHeight+"px"
}else{if(this.isMobileBreakPoint&&h){this._el.style.height=this.responsiveHeight+"px"
}else{this._el.style.height=this.desktopHeight+"px"
}}}}]);
return e
}();
b.moduleName="Padding Component";
b.selector=".padding-component-ui";
return b
});
define("RolloverBlocks",[],function(){var b={BLOCK:"rollover-blocks__block",FOCUSED_BLOCK:"rollover-blocks__block--focused",BLOCK_CONTENT:"rollover-blocks__content",ROLLOVER_BLOCK:"rollover-blocks__description-rollover",LINK_A11Y:"rollover-blocks__link-holder--a11y",LINK_LEARN_MORE:"rollover-blocks__link",RTE_LINKS:"rollover-blocks__text a"};
var a=function(){function d(h){_classCallCheck(this,d);
this.el=h[0];
this.blocks=this.el.querySelectorAll("."+b.BLOCK);
this.addEventListenersToBlocks()
}_createClass(d,[{key:"addEventListenersToBlocks",value:function g(){var h=this;
this.blocks.forEach(function(p,n){var m=p.querySelector("."+b.BLOCK_CONTENT);
var j=p.querySelector("."+b.LINK_A11Y);
var l=p.querySelector("."+b.ROLLOVER_BLOCK);
var i=p.querySelector("."+b.LINK_LEARN_MORE);
var o=p.querySelectorAll("."+b.RTE_LINKS);
var k=[i].concat(_toConsumableArray(o));
if(n===0){h.showForAccessibility(m)
}m.addEventListener("click",function(){if(i){i.click()
}else{if(o[0]){o[0].click()
}}});
h.hideForAccessibility.apply(h,_toConsumableArray(o));
h.addEventListenerToRolloverBlock(p,l,k);
j.addEventListener("click",function(){h.showForAccessibility.apply(h,[l].concat(_toConsumableArray(k)));
l.focus({preventScroll:true})
})
})
}},{key:"addEventListenerToRolloverBlock",value:function c(k,j,i){var h=this;
j.addEventListener("focus",function(){setTimeout(function(){k.classList.add(b.FOCUSED_BLOCK);
h.showForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
},5)
});
j.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
h.hideForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
});
i.forEach(function(l){if(l){l.addEventListener("focus",function(){k.classList.add(b.FOCUSED_BLOCK);
h.showForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
});
l.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
h.hideForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
})
}})
}},{key:"showForAccessibility",value:function e(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",0);
k.removeAttribute("aria-hidden")
}})
}},{key:"hideForAccessibility",value:function f(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",-1);
k.setAttribute("aria-hidden",true)
}})
}}]);
return d
}();
a.selector=".rollover-blocks-ui";
a.moduleName="Rollover Blocks";
return a
});
define("TileList",[],function(){var b={TILE:"tile-list__item",TILE_ACTIVE:"tile-list__item--active",TILE_LINK:"tile-list__link",TILE_LINK_EXTERNAL:"tile-list__external-link",LINK_A11Y:"tile-list__link--a11y",LINK_A11Y_HOLDER:"tile-list__link-holder--a11y",TILE_CONTENT:"tile-list__content",TABS_UI:"tabs-ui",TABS_ITEM:"tabs__item"};
var a=function(){function k(m){_classCallCheck(this,k);
this.el=m[0];
this.tiles=this.el.querySelectorAll("."+b.TILE);
this.addEventListeners();
this.disableTabsFocus()
}_createClass(k,[{key:"addEventListeners",value:function g(){var m=this;
this.tiles.forEach(function(s,q){var p=s.querySelector("."+b.LINK_A11Y);
var r=s.querySelector("."+b.LINK_A11Y_HOLDER);
var o=s.querySelector("."+b.TILE_LINK);
var n=s.querySelector("."+b.TILE_CONTENT);
var u=s.querySelector("."+b.TILE_LINK_EXTERNAL);
var t=[o,u];
if(q===0){m.showA11yForTile(n,s)
}m.hideA11yForTile(n);
m.addEventListenersToTileContent(s,n,t);
m.addEventListenersToA11yLink(s,n,p,r,t);
m.addEventListenerToTile(s,r,t);
m.addEventListenersToLinks(s,n,t)
})
}},{key:"addEventListenersToLinks",value:function l(n,m,o){var p=this;
o.forEach(function(q){if(q){q.addEventListener("focus",function(){n.classList.add(b.TILE_ACTIVE);
p.showA11yForTile.apply(p,[m].concat(_toConsumableArray(o)))
});
q.addEventListener("focusout",function(){n.classList.remove(b.TILE_ACTIVE);
p.hideA11yForTile.apply(p,[m].concat(_toConsumableArray(o)))
})
}})
}},{key:"addEventListenerToTile",value:function j(n,m,p){var o=this;
n.addEventListener("focus",function(){m.setAttribute("aria-hidden",true)
});
n.addEventListener("click",function(){o.simulateClickOnTileLinks(p)
})
}},{key:"addEventListenersToA11yLink",value:function i(q,m,n,o,r){var p=this;
n.addEventListener("focus",function(){o.setAttribute("aria-hidden",false)
});
n.addEventListener("click",function(s){s.stopPropagation();
q.classList.add(b.TILE_ACTIVE);
p.showA11yForTile.apply(p,[m].concat(_toConsumableArray(r)));
setTimeout(function(){m.focus()
},5)
})
}},{key:"addEventListenersToTileContent",value:function c(o,m,p){var n=this;
m.addEventListener("focus",function(){setTimeout(function(){o.classList.add(b.TILE_ACTIVE);
n.showA11yForTile.apply(n,[m].concat(_toConsumableArray(p)))
},5)
});
m.addEventListener("focusout",function(){o.classList.remove(b.TILE_ACTIVE);
n.hideA11yForTile.apply(n,[m].concat(_toConsumableArray(p)))
});
m.addEventListener("click",function(q){q.stopPropagation();
n.simulateClickOnTileLinks(p)
})
}},{key:"simulateClickOnTileLinks",value:function h(m){m.forEach(function(n){if(n){n.click()
}})
}},{key:"showA11yForTile",value:function d(){for(var o=arguments.length,m=Array(o),n=0;
n<o;
n++){m[n]=arguments[n]
}m.forEach(function(p){if(p){p.setAttribute("tabindex",0);
p.removeAttribute("aria-hidden")
}})
}},{key:"hideA11yForTile",value:function f(){for(var o=arguments.length,m=Array(o),n=0;
n<o;
n++){m[n]=arguments[n]
}m.forEach(function(p){if(p){p.setAttribute("tabindex",-1);
p.setAttribute("aria-hidden",true)
}})
}},{key:"disableTabsFocus",value:function e(){var m=this.el.closest("."+b.TABS_UI);
if(m){m.querySelectorAll("."+b.TABS_ITEM).forEach(function(n){n.setAttribute("tabindex",-1)
})
}}}]);
return k
}();
a.moduleName="Tile List";
a.selector=".tile-list-ui";
return a
});
define("ObserversAPI",[],function(){var b={root:null,rootMargin:"0px",threshold:1};
var a=function a(f,d){var c=arguments.length>2&&arguments[2]!==undefined?arguments[2]:b;
var e=new IntersectionObserver(f,c);
e.observe(d)
};
return{intersectionObserver:a}
});
define("RequestAnimationFrame",[],function(){var e=60;
var g=[];
var d=0;
function f(i,h){i.fps=h?h:e;
i.then=Date.now();
i.fpsInterval=1000/i.fps;
g.push(i);
b()
}function b(){if(d!==0){return
}a()
}function a(){d=Date.now();
c()
}function c(){if(g.length===0){d=0;
return
}requestAnimationFrame(c);
var j=Date.now();
for(var k=0;
k<g.length;
k++){var h=j-g[k].then;
if(h>g[k].fpsInterval){g[k].then=j-h%g[k].fpsInterval;
g[k].func();
if(g[k].isEnd()){g.splice(k,1)
}}}}return{increaseAnimationQueue:f}
});
define(["utils","RequestAnimationFrame"],function(o,g){var d=window.innerHeight/100*80;
var e=2;
var h=9*e;
var b=[];
var j=function j(){var r=this.el.getBoundingClientRect();
if(r.top<=d){this.startValue+=this.step;
if(this.startValue===this.string||this.startValue>this.string){this.el.innerHTML=this.originalString;
this.finish=true;
return
}this.el.innerHTML=c.call(this,this.startValue.toString())
}};
var a=function a(){if(this.finish){return true
}};
function c(s){var r=this.signCount>1?m.call(this,s):i.call(this,s);
return this.sign===-1?Math.ceil(r):r
}var q=function q(s,r){var t=s/r;
if(this.signCount>1){return Math.ceil(t)
}if(t>0.1){return +parseFloat(t).toFixed(this.precise)
}return +parseFloat(t).toFixed(2)
};
function p(){if(this.originalString.indexOf(",")!==-1){this.sign=","
}else{if(this.originalString.indexOf(".")!==-1){this.sign="."
}}}function n(){var r=this.originalString.lastIndexOf(this.sign);
if(r!==-1){this.precise=this.originalString.length-1-r;
return
}if(this.string<h){this.precise=1
}}function l(r){if(this.sign&&this.sign===","){return r.replaceAll(".",",")
}return r
}function i(r){if(this.precise!==0){return l.call(this,parseFloat(r).toFixed(this.precise))
}else{return l.call(this,r)
}}function m(v){var s=v;
var u=s.length;
var r=Math.floor(u/this.precise);
var t=u-this.precise*r;
while(t<=u){if(t===0){t+=this.precise
}else{s=s.slice(0,t)+this.sign+s.slice(t);
t+=this.precise+1
}}return s
}function f(t){var r=arguments.length>1&&arguments[1]!==undefined?arguments[1]:1;
if(this.sign!==-1){var s=t.indexOf(this.sign,r);
if(s!==-1){this.signCount+=1;
f.call(this,t,s+1)
}}}var k=function k(r){Array.prototype.forEach.call(r,function(t){var s={signCount:0,startValue:0,finish:false,sign:-1,precise:0};
s.originalString=t.innerHTML;
p.call(s);
f.call(s,s.originalString);
if(s.signCount>1){s.string=parseFloat(s.originalString.replaceAll(s.sign,""))
}else{s.string=parseFloat(s.originalString.replaceAll(",","."))
}if(!isNaN(s.string)){n.call(s);
s.step=q.call(s,s.string,h);
s.el=t;
t.innerHTML=0;
b.push({func:j.bind(s),endFunc:a.bind(s)})
}})
};
document.addEventListener("DOMContentLoaded",function(){var r=document.querySelectorAll(".rte-number-animation");
k(r);
Array.prototype.forEach.call(b,function(s){g.increaseAnimationQueue({func:s.func,isEnd:s.endFunc},10)
})
})
});
define("animation-tools",["utils"],function(l){var n=window.innerHeight;
var b=n/2;
var d={multipleBlock:"multiple-topics-list__block-image-wrapper",multipleParallaxSection:"multiple-topics-list__animation-placeholder-wrapper",parallaxSection:"parallax-section",featureParallaxBlock:"featured-content-card__parallax-block",featureSection:"featured-content-card__image-wrapper"};
var f=10;
var e=function e(){return window.scrollY
};
var c=function c(o){var p=o.getBoundingClientRect();
return{top:p.top+e(),rawTop:p.top,bottom:p.bottom+e(),rawBottom:p.bottom,height:o.offsetHeight}
};
var g=function g(s,r,p,o){var q=c(s);
var u=Math.ceil(q.height/100*o);
var t=u/100*r*p;
s.style.transform="translateY("+t+"px)"
};
var h=function h(p){var r=c(p);
var q=0;
var o=0;
if(r.rawTop<b){q=100-r.rawTop/b*100;
o=1
}else{q=r.rawTop/b*100-100;
o=-1
}return{percent:q,translateDirection:o}
};
function k(q){if(l.isElementInViewport(q)){var r=h(q),p=r.percent,o=r.translateDirection;
g(this,p,o,f)
}}var j=function j(o){var p=void 0;
if(o.classList.contains(d.multipleBlock)){p=o.closest("."+d.multipleParallaxSection)
}else{if(o.classList.contains(d.featureParallaxBlock)){p=o.closest("."+d.featureSection)
}else{p=o.closest(".section")
}}p.classList.add(d.parallaxSection);
return p
};
var a={applyParallax:function i(o){var p=j(o);
return k.bind(o,p)
},parallaxStopCondition:function m(){return false
}};
return{Parallax:a,getElRect:c}
});
define(["utils","RequestAnimationFrame"],function(a,b){document.addEventListener("DOMContentLoaded",function(){var d=document.querySelectorAll(".rte-text-animation");
var e=Array.prototype.slice.call(d);
function c(){for(var g=0;
g<e.length;
g++){if(a.isElementInViewport(e[g])){e[g].classList.add("live-text");
e.splice(g,1)
}}}function f(){return e.length===0
}if(e.length!==0){b.increaseAnimationQueue({func:c,isEnd:f})
}})
});
define(["RequestAnimationFrame","animation-tools","constants"],function(e,d,b){var a="applied-parallax";
var c=function c(){var f=document.querySelectorAll(".parallax-wrapper:not(."+a+")");
f.forEach(function(g){g.classList.add(a);
e.increaseAnimationQueue({func:d.Parallax.applyParallax(g),isEnd:d.Parallax.parallaxStopCondition})
})
};
document.addEventListener(b.Events.featureGridAddedNewItems,function(){c()
});
document.addEventListener("DOMContentLoaded",function(){c()
})
});
define("SolutionsHubReferrer",[],function(){var d={referrerKey:"SolutionsHubReferrer",referrerField:'.hidden-field-ui[name="source"]'};
var a=function a(){var e=sessionStorage.getItem(d.referrerKey);
if(e===null){sessionStorage.setItem(d.referrerKey,JSON.stringify({referrer:document.referrer,isPaidTraffic:b()}))
}};
var c=function c(e){var f=e.querySelector(d.referrerField);
if(f){f.value=sessionStorage.getItem(d.referrerKey)
}};
var b=function b(){var e=/gclid|gclsrc|compaignSource|utm_source/gi;
var f=document.location.search;
return e.test(f)
};
a();
return{setReferrerHiddenField:c}
});
define("sticky-scroll",[],function(){var o='[data-sticky-scroll="true"]';
var j=[];
window.addEventListener("load",l);
function l(){var u=document.querySelectorAll(o);
var t=u.length>0;
if(!t){return
}r();
s();
b();
c();
g()
}function g(){var u=document.documentElement.scrollTop;
var t=j.find(function(w){var x=w.start,v=w.end;
return u>=x&&u<=v
});
if(t){p(u,t)
}else{q(u)
}}function r(){var u=document.createElement("div");
u.classList.add("pin-spacer");
u.style.width="100%";
u.style.position="relative";
var t=document.querySelector("body");
while(t.firstChild){u.appendChild(t.firstChild)
}t.appendChild(u)
}function n(w,v,x){var u=document.querySelector(".pin-spacer");
var t=w?{position:"fixed",top:"-"+v+"px"}:{position:"relative",top:v+"px"};
Object.assign(u.style,t);
Array.from(document.querySelectorAll(o)).forEach(function(z){var A=h(z),B=A.start,y=A.end;
z.dataset.stickyScrollStarted=B<=x;
z.dataset.stickyScrollEnded=y<=x;
if(x>y){f(z,y-B);
return
}if(x<B){f(z,0);
return
}f(z,x-B)
})
}function c(){window.addEventListener("scroll",d);
window.addEventListener("resize",i)
}function i(){s();
b();
g()
}function a(v){var u=0;
var t=v;
var w=document.querySelector(".pin-spacer");
while(t.offsetParent){if(t!==w&&!isNaN(t.offsetTop)){u+=t.offsetTop
}t=t.offsetParent
}return u
}function e(t){return t.dataset.stickyScrollVertical==="true"
}function h(u){var w=u.offsetHeight,E=u.scrollHeight,C=u.offsetWidth,z=u.scrollWidth;
var v=a(u);
var t=v+w;
var A=document.documentElement.clientHeight;
var x=j.filter(function(F){return F.offsetTop<v
}).reduce(function(H,G){var I=G.start,F=G.end;
return H+F-I
},0);
var y=t-A<0?x:t-A+x;
var D=e(u)?E-w:z-C;
var B=y+D;
return{start:y,end:B,offsetTop:v}
}function s(){j=[];
document.querySelectorAll(o).forEach(function(t){j.push(h(t))
})
}function b(){var u=document.querySelector("body");
var x=document.querySelector(".pin-spacer");
var t=x.offsetHeight;
var w=j.reduce(function(A,z){var B=z.start,y=z.end;
return A+y-B
},0);
var v=t+w;
u.style.height=v+"px"
}function m(u,w){var v=u.start,t=u.end;
return w>=v&&w<=t
}function k(t){Array.from(document.querySelectorAll(o)).some(function(u){var v=h(u);
if(!m(v,t)){return null
}f(u,t-v.start);
return true
})
}function f(t,u){if(e(t)){t.style.transform="translate3d(0px, -"+u+"px, 0px)"
}else{t.style.transform="translate3d(-"+u+"px, 0px, 0px)"
}}function p(w,v){var u=v.start;
var t=j.filter(function(x){return x.start<u
}).reduce(function(x,y){return x-y.end+y.start
},u);
n(true,t,w)
}function q(u){var t=j.filter(function(w){var v=w.end;
return u>v
}).reduce(function(x,v){var y=v.start,w=v.end;
return x+w-y
},0);
n(false,t,u)
}function d(){var v=document.documentElement.scrollTop;
var u=j.find(function(y){var x=y.start,w=y.end;
return v>=x&&v<=w
});
var t=document.querySelector(".pin-spacer").style.position==="fixed";
if(u&&!t){p(v,u)
}if(!u&&t){q(v)
}if(t){k(v)
}}});
define("Section",["utils"],function(a){var c={isHasParallax:".section-ui__parallax-wrapper.parallax-wrapper"};
function b(d){this.$el=d;
this.init()
}b.prototype.init=function(){a.applyShadowOnImage(this.$el,this.$el.find(".section__image"),this.$el.find(c.isHasParallax).length)
};
b.moduleName="Section";
b.selector=".section-ui";
return b
});
define("WeChatPopup",["utils-dust","utils-a11y","constants"],function(b,a,j){var c={id:".wechat-popup__id",close:".wechat-popup__close",qr:".wechat-popup__qr"};
var d=$(document),e=$("html"),f=$("body"),h=f.find("."+j.Classes.overlay),g;
function i(){if(g){return g
}g=this;
b.render("wechat-popup",{},function(k){this.markup=k
}.bind(this));
this.close=this.close.bind(this);
this.keyupHandler=this.keyupHandler.bind(this)
}i.prototype.keyupHandler=function(k){if(k.key===j.Keys.esc){this.close()
}};
i.prototype.setData=function(k){this.$qr.attr("src",k.src);
this.$id.text(CQ.I18n.getMessage("component.we-chat-popup.title",k.id));
return this
};
i.prototype.render=function(){this.$popup=f.append(this.markup).children("."+i.selector);
this.$id=this.$popup.find(c.id);
this.$close=this.$popup.find(c.close);
this.$qr=this.$popup.find(c.qr);
this.$close.on("click",this.close);
i.rendered=true
};
i.prototype.open=function(l,k){if(!i.rendered){this.render()
}this.focusTarget=k;
this.setData(l);
d.on("keyup",this.keyupHandler);
e.addClass(j.Classes.noscroll);
this.$popup.show();
h.removeClass(j.Classes.hidden).addClass(j.Classes.overlayCoverHeader).on("click",this.close);
a.handlePopupFocus(this.$popup)
};
i.prototype.close=function(){e.removeClass(j.Classes.noscroll);
this.$popup.hide();
d.off("keyup",this.keyupHandler);
h.addClass(j.Classes.hidden).removeClass(j.Classes.overlayCoverHeader).off("click",this.close);
this.focusTarget.focus();
this.focusTarget=null
};
i.selector="wechat-popup";
i.classes=c;
return i
});
define("TabsUtil",["HistoryUtil","constants","utils","utils-env","media"],function(h,l,j,i,c){var b=$(window);
var d={item:".js-tabs-item",link:".js-tabs-link",links:".js-tabs-links-list",active:"active",stage:".owl-stage",owlItem:".owl-item",controls:".js-tabs-controls",nav:".js-tabs-nav",prevButton:".js-tabs-prev",nextButton:".js-tabs-next",navAllyActiveTab:".js-nav-a11y-active-tab",navAllyContent:".js-tab-a11y-content",navAlly:".js-nav-a11y",linkContent:".js-tabs-link-content"};
var m={tabChange:"tab.change",tabChanged:"tab.changed",tabLoaded:"tab.loaded"};
var a=[];
function g(o){var n={};
n[o.componentId]=o.activeItem;
h.push("activeTabs",n,o.hash&&location.pathname+o.hash)
}function e(o,n){n.dataset.item=o
}function f(n,o){return n+$(o).outerWidth(true)
}function k(n,o){this.config=o||{};
this.$el=n;
this.$list=this.config.links||n.find(d.links).first();
this.$links=this.config.link||this.$list.find(d.link);
this.$items=this.config.items||n.children(d.item);
this.$nav=n.find(d.nav);
this.$prevButton=n.find(d.prevButton);
this.$nextButton=n.find(d.nextButton);
this.$navA11y=this.$nav.find(d.navAlly);
this.subTabs=this.config.multiLevelSubTabs;
this.subItemsDataCorrect=false;
!this.subTabs&&this.$links.each(e);
!this.subTabs&&this.$items.each(e);
this.subTabs&&!this.subItemsDataCorrect&&this.updateSubItemsData();
this.lastIndex=this.$links.length-1;
this.useHistory=this.config.useHistory;
this.skipSwitching=this.config.skipSwitching;
this.responsiveView=this.config.responsiveView;
this.carouselView=this.config.carouselView;
this.carouselForPages=this.config.carouselForPages;
this.responsiveBreakpoint=this.config.responsiveBreakpoint;
this.scrollToElement=this.config.scrollToElement;
this.scrollToElementSelector=this.config.scrollToElementSelector;
this.scrollToReservedSpace=this.config.scrollToReservedSpace;
this.multiLevelTabsView=this.config.multiLevelTabsView;
this.verticalNavigation=this.config.verticalNavigation;
this.id=this.$el.attr("id");
this.onTabChange=this.onTabChange.bind(this);
this.setEventListeners();
this.$el.trigger(m.tabChange,{tab:0,skipHistory:true,skipFocus:true});
a.push(this);
this.$controls=this.config.controls||n.find(d.controls);
this.dragEnabled=this.shouldEnableDrag();
this.windowWidth=b.width();
this.responsiveView&&c.getViewportWidth()<=this.responsiveBreakpoint&&this.initCarousel();
this.responsiveView&&!i.isEditMode()&&b.on("resize orientationchange",function(){if(b.width()!==this.windowWidth){this.reInitCarousel();
this.reInitCarouselOnResponsiveView()
}}.bind(this));
this.multiLevelTabsView&&!i.isEditMode()&&b.on("orientationchange",function(){setTimeout(function(){this.reInitCarousel()
}.bind(this),100)
}.bind(this));
this.carouselView&&this.initCarousel();
$(".slider-ui").on("initialized.owl.carousel",function(r){var s=$(r.target);
var p=s.find(".owl-item").css("width");
if(parseFloat(p)!==0){this.$sliderItemWidth=p
}if(parseFloat(p)===0){var q=s.find(".owl-item");
q.css("width",this.$sliderItemWidth)
}}.bind(this))
}k.prototype.updateSubItemsData=function(){this.$links.each(function(p,o){var n=this.$items.filter('[data-item-sub="'+o.dataset.itemSub+'"]');
o.dataset.itemSub=p;
n.attr("data-item-sub",p)
}.bind(this));
this.subItemsDataCorrect=true
};
k.prototype.initCarousel=function(){if(this.config.multiLevelSubTabs){return
}this.$list.owlCarousel($.extend({},this.config,{mouseDrag:this.dragEnabled,touchDrag:this.dragEnabled}));
this.$controls.find(d.stage).attr("role","tablist");
this.$controls.find(d.owlItem).attr("role","presentation");
this.$owlStage=this.$el.find(d.stage);
this.carouselWidth=this.$owlStage.width();
this.updateStagePosition=j.updateStagePosition(this.$owlStage,this.$controls);
this.dragEnabled&&this.$list.on("translated.owl.carousel",this.updateStagePosition.bind(this,this.carouselWidth))
};
k.prototype.shouldEnableDrag=function(){return this.$controls.width()<[].reduce.call(this.$links,f,0)
};
k.prototype.reInitCarousel=function(){var n=this.shouldEnableDrag()||this.multiLevelTabsView;
if(!n){return
}this.dragEnabled=n;
this.$list.owlCarousel("destroy");
this.initCarousel();
this.scrollTo()
};
k.prototype.reInitCarouselOnResponsiveView=function(){var n=c.getViewportWidth();
if(this.responsiveView&&n>this.responsiveBreakpoint){this.$list.owlCarousel("destroy");
return
}this.$list.owlCarousel("destroy");
this.initCarousel();
this.scrollTo()
};
k.prototype.onLoad=function(){if(location.hash){this.switchByHash();
return
}this.useHistory&&this.updateFromHistory();
this.$el.trigger(m.tabLoaded)
};
k.prototype.setEventListeners=function(){this.$el.on(m.tabChange,this.onTabChange);
this.$links.on("click",this.onLinkClick.bind(this)).on("keydown",this.onKeydown.bind(this));
this.$nav.on("click","button",this.onNavClick.bind(this));
this.$navA11y.length&&this.$nav.on("focus blur","button",this.onNavFocusToggle.bind(this));
this.useHistory&&b.on("popstate",this.updateFromHistory.bind(this));
b.on("load",this.onLoad.bind(this))
};
k.prototype.onNavFocusToggle=function(){if(this.$navA11y.attr("aria-atomic")||this.$navA11y.attr("aria-polite")){this.$navA11y.removeAttr("aria-atomic aria-live")
}else{this.$navA11y.attr({"aria-atomic":true,"aria-live":"polite"})
}};
k.prototype.updateFromHistory=function(){var o=h.getStateByKey("activeTabs"),n=o[this.id]||0;
this.$el.trigger(m.tabChange,{tab:n,skipHistory:true})
};
k.prototype.afterClick=null;
k.prototype.onLinkClick=function(n){var q=$(n.currentTarget),u=q.attr("href"),t=this.subTabs?q.data("item-sub"):q.data("item"),w=this.scrollToElementSelector||this.$el,r=this.scrollToReservedSpace||100,o=c.getViewportWidth()<=c.modes.Tablet.end,p=q.parents(d.links).parent(),v=o&&p.hasClass("open");
var s=this.scrollToElement;
if(typeof this.scrollToElement==="function"){s=this.scrollToElement()
}this.$el.trigger(m.tabChange,{tab:t,hash:u});
this.afterClick&&this.afterClick(q);
s&&v&&w.scrollToSelector({reservedSpace:r,duration:400});
p.toggleClass("open");
return false
};
k.prototype.beforeTabChange=function(n){!n.skipSwitching&&this.$items.removeClass(d.active).attr("tabindex",-1);
this.$links.removeClass(d.active).attr({"aria-selected":"false",tabindex:-1});
this.$links.parent(".js-tabs-title").removeClass(d.active)
};
k.prototype.afterTabChange=function(p){this.$list.trigger("to.owl.carousel",this.activeItem);
var o=this.subTabs?this.$links.filter("[data-item-sub="+this.activeItem+"]"):this.$links.filter("[data-item="+this.activeItem+"]");
var n=this.subTabs?this.$links.filter("[data-item-sub="+this.activeItem+"]").parent(".js-tabs-title"):this.$links.filter("[data-item="+this.activeItem+"]").parent(".js-tabs-title");
o.addClass(d.active).attr({"aria-selected":"true",tabindex:0});
n.addClass(d.active);
this.$nav.find(d.navAllyContent).text(o.find(d.linkContent).text());
this.$nav.find(d.navAllyActiveTab).text(this.activeItem+1);
!p.skipFocus&&o.focus();
this.useHistory&&!p.skipHistory&&g({componentId:this.id,activeItem:this.activeItem,hash:p.hash});
this.multiLevelAfterTabChange&&this.multiLevelAfterTabChange();
b.trigger(m.tabChanged)
};
k.prototype.multiLevelAfterTabChange=null;
k.prototype.onTabChange=function(o,p){if(!$.isNumeric(p.tab)||!p.forceSwitching&&this.activeItem===p.tab){return false
}this.beforeTabChange(p);
if(p.tab<0){this.activeItem=this.lastIndex
}else{if(p.tab>this.lastIndex){this.activeItem=0
}else{this.activeItem=p.tab
}}var n=this.subTabs?"[data-item-sub=":"[data-item=";
!p.skipSwitching&&this.$items.filter(n+this.activeItem+"]").addClass(d.active).attr("tabindex",0);
this.afterTabChange(p);
return false
};
k.prototype.onNavClick=function(n){n.preventDefault();
$(n.currentTarget).is(d.nextButton)&&this.$el.trigger(m.tabChange,{tab:this.activeItem+1,skipSwitching:this.skipSwitching,skipFocus:true});
$(n.currentTarget).is(d.prevButton)&&this.$el.trigger(m.tabChange,{tab:this.activeItem-1,skipSwitching:this.skipSwitching,skipFocus:true})
};
k.prototype.onKeydown=function(p){var n=this.verticalNavigation?l.Keys.arrowDown:l.Keys.arrowRight,o=this.verticalNavigation?l.Keys.arrowUp:l.Keys.arrowLeft;
switch(p.key){case l.Keys.home:p.preventDefault();
this.$el.trigger(m.tabChange,{tab:0});
break;
case l.Keys.end:p.preventDefault();
this.$el.trigger(m.tabChange,{tab:this.lastIndex});
break;
case n:p.preventDefault();
this.$el.trigger(m.tabChange,{tab:this.activeItem+1,skipSwitching:this.skipSwitching});
break;
case o:p.preventDefault();
this.$el.trigger(m.tabChange,{tab:this.activeItem-1,skipSwitching:this.skipSwitching});
break;
case l.Keys.space:case l.Keys.enter:p.preventDefault();
this.$el.trigger(m.tabChange,{tab:this.activeItem,forceSwitching:true});
this.afterClick&&this.afterClick($(p.target));
break;
default:break
}if(p.key===l.Keys.arrowLeft||p.key===l.Keys.arrowRight){this.scrollTo()
}};
k.prototype.beforeScroll=null;
k.prototype.scrollTo=function(){var n=this.$links.filter("."+this.classes.active),o=this.subTabs?n.data("item-sub"):n.data("item");
this.beforeScroll&&this.beforeScroll(n);
this.$list.trigger("to.owl.carousel",o)
};
k.prototype.switchByHash=function(){var p=location.hash.slice(1),n=this.$items.filter('[data-anchor="'+p+'"]'),o=this.subTabs?n.data("item-sub"):n.data("item");
if(!n.length||!p){return
}this.$el.trigger(m.tabChange,{tab:o,skipHistory:true});
n.scrollToSelector({reservedSpace:100})
};
k.prototype.classes=d;
k.pushToHistory=g;
k.activatedComponents=a;
k.events=m;
k.moduleName="TabsUtil";
return k
});
define("SocialIcons",["WeChatPopup","constants"],function(c,e){var d={weChatLink:".social-icons__link-wechat"};
var a=$("html");
function b(g,f){this.$el=g;
this.focusTarget=f;
this.$weChatLink=this.$el.find(d.weChatLink);
if(this.$weChatLink.length){this.initWeChatPopup()
}}b.prototype.initWeChatPopup=function(){this.$weChatPopup=new c();
this.$weChatLink.on("click",this.openWeChat.bind(this))
};
b.prototype.openWeChat=function(f){f.preventDefault();
var g=$(f.currentTarget);
a.trigger(e.Events.menuClose);
this.$weChatPopup.open({src:g.data("src"),id:g.data("id")},this.focusTarget||this.$weChatLink)
};
b.classes=d;
return b
});
define("ReCaptcha",[],function(){var c=$(window);
var b={siteKey:"sitekey",widgetId:"recaptcha-widget-id"};
function a(e,f){var d=f||{};
this.$el=e;
this.reCaptchaEnabled=this.$el.data("recaptcha-enabled");
this.recaptchaId=this.$el.attr("id");
this.siteKey=this.$el.data(b.siteKey);
this.submitForm=d.submitForm
}a.prototype.render=function(){this.reCaptchaEnabled&&c.on("load",function(){this.id=grecaptcha.render(this.recaptchaId,{size:"invisible",sitekey:this.siteKey,callback:this.submitForm});
this.$el.data(b.widgetId,this.id)
}.bind(this))
};
a.prototype.execute=function(){grecaptcha.execute(this.id)
};
a.prototype.reset=function(){setTimeout(function(){grecaptcha.reset(this.id)
},500)
};
a.moduleName="ReCaptcha";
return a
});
define("multi-select",["utils-dust","constants","jquery-plugins"],function(e,d){var f=$(window);
var c={open:"open",selectedParams:".selected-params",dropdown:".multi-select-dropdown",filterWrap:".multi-select-filter-wrapper",selectedItems:".selected-items",counter:".counter",unselectTag:".unselect-tag",filterTag:".filter-tag",checkboxLabel:".checkbox-custom-label",showWaitMessage:"show-wait-message"},b={close:"dropdown:close",open:"dropdown:open",focusItem:"dropdown:focus",next:"dropdown:next",prev:"dropdown:prev",change:"dropdown:change"};
function a(h,g){this.$el=$("<div/>").addClass("multi-select-filter").addClass("validation-focus-target").attr("role","combobox").attr("tabindex",0).attr("aria-autocomplete","list").attr("aria-haspopup",true).attr("aria-expanded",false).attr("aria-required",g.required).attr("aria-labelledby",g.labelId).attr("aria-describedby",g.errorId);
g.className&&this.$el.addClass(g.className);
this.$select=h;
this.config=g;
this.$options=this.$select.find("option");
this.selectedCount=this.$select.find("option:checked").length;
a.counter=a.counter||0;
this.init();
this.initItemsUpdateEvent();
this.isDropdownAbove=this.isDropdownAbove.bind(this)
}a.prototype.init=function(){this.eventNamespace="multiSelectFilter"+a.counter++;
this.$select.hide().data("multiSelectFilter",this);
this.render()
};
a.prototype.isOpened=function(){return this.$el.hasClass(c.open)
};
a.prototype.renderCallback=function(g,h){if(h){console.log('"multi-select-dropdown" rendering error: '+h);
return
}this.draw(g);
typeof this.config.callback==="function"&&this.config.callback()
};
a.prototype.render=function(){e.render("multi-select-dropdown",this.generateRenderContext(),this.renderCallback.bind(this))
};
a.prototype.generateRenderContext=function(){var h={defaultText:this.$select.data("defaultText"),selectedCountKey:this.config.selectedCount||"component.multi-select-filter.selected-count",selectedCount:this.selectedCount,columns:this.config.columns||2,columnSize:this.config.columnSize,showTags:this.config.showTags||false,options:[],emptyOptions:[]};
this.$options.each(function(){var j=$(this),i=j.prop("selected");
h.options.push({text:j.html(),value:j.val(),selected:i})
});
if(this.$options.length===0){var g=CQ.I18n.getMessage("component.general.search-empty-result-for-combination");
h.emptyOptions=[{value:g}]
}h.columnSize=h.columnSize||Math.ceil(h.options.length/h.columns);
h.columnLastItemIndex=h.columnSize-1;
h.fixedLengthColumns=h.columns-1;
return h
};
a.prototype.setDrawElements=function(g){this.$el.html(g);
this.$select.after(this.$el);
this.$selectedParams=this.$el.find(c.selectedParams);
this.$checkboxesContainer=this.$el.find(c.dropdown);
this.$checkboxes=this.$checkboxesContainer.find(":checkbox");
this.currentItemIndex=0;
this.$tagsContainer=this.$el.parents(c.filterWrap).find(c.selectedItems);
this.$counterHolder=this.$el.find(c.counter)
};
a.prototype.draw=function(g){this.setDrawElements(g);
this.initEvents();
this.onLoad()
};
a.prototype.initItemsUpdateEvent=function(){this.$select.on(d.Events.multiSelectUpdate,function(){$(".multi-select-dropdown").removeClass(c.showWaitMessage);
var g=this.$select.find("option");
this.findMatchOptions(g);
this.$options=g;
e.render("multi-select-dropdown",this.generateRenderContext(),function(h){this.reInitDropdownOptions(h);
this.resetSkillsCounter();
this.resetAllTags();
this.toggleDropdown(true)
}.bind(this));
this.checkMatchTags()
}.bind(this));
this.$select.one(d.Events.multiSelectFirstUpdate,function(){$(".multi-select-dropdown").removeClass(c.showWaitMessage);
this.$options=this.$select.find("option");
e.render("multi-select-dropdown",this.generateRenderContext(),function(g){this.reInitDropdownOptions(g);
this.onLoad()
}.bind(this));
this.updateCounter(this.$select.find(":selected").length)
}.bind(this));
this.$select.on(d.Events.multiSelectBeforeUpdate,function(){var g=$(".multi-select-dropdown");
g.empty();
g.addClass(c.showWaitMessage);
g.html('<span class="">Waiting for results...</span>')
})
};
a.prototype.checkMatchTags=function(){for(var g=0;
g<this.$matchedOptions.length;
g++){this.select(this.$matchedOptions[g])
}};
a.prototype.findMatchOptions=function(l){this.$matchedOptions=[];
var m=this.getSelectedItems();
for(var h=0;
h<m.length;
h++){var k=m[h].value;
for(var g=0;
g<l.length;
g++){if(k===l[g].value){this.$matchedOptions.push(k)
}}}};
a.prototype.reInitDropdownOptions=function(g){this.setDrawElements(g);
this.initReusedEvents()
};
a.prototype.toggleDropdown=function(g){this.$checkboxesContainer.toggleClass(d.Classes.hidden,!g);
this.$el.toggleClass(c.open,g);
f.off("click."+this.eventNamespace+" touchstart."+this.eventNamespace);
if(!g){f.off("scroll resize",this.isDropdownAbove);
return
}f.on("scroll resize",this.isDropdownAbove).on("click."+this.eventNamespace+" touchstart."+this.eventNamespace,this.onWindowClick.bind(this));
this.isDropdownAbove();
this.$checkboxes.first().focus().attr("aria-selected",true)
};
a.prototype.removeTag=function(g){var h=$(g.target).parent().data("value");
this.$options.findByValue(h).length&&this.unselect(h);
return false
};
a.prototype.resetAllTags=function(){$(c.selectedItems).empty()
};
a.prototype.onClose=function(){this.$el.focus();
this.$el.attr("aria-expanded",false);
this.currentItemIndex=0;
this.toggleDropdown(false)
};
a.prototype.onOpen=function(){this.$el.attr("aria-expanded",true);
this.toggleDropdown(true)
};
a.prototype.onEscPress=function(){this.isOpened()&&this.$el.trigger(b.close)
};
a.prototype.onTabPress=function(){this.isOpened()&&this.$el.trigger(b.close)
};
a.prototype.onSpaceOrEnterPress=function(g){if(this.isOpened()){return
}g.preventDefault();
this.$el.trigger(b.open)
};
a.prototype.onCheckboxChange=function(h){var g=$(h.target),i=g.data("value");
if(g.prop("checked")){this.select(i)
}else{this.unselect(i)
}};
a.prototype.getSelectedItems=function(){return this.$options.filter(":selected")
};
a.prototype.onLoad=function(){this.getSelectedItems().each(function(g,h){this.addTag(h.value)
}.bind(this))
};
a.prototype.onSync=function(){var g=this.getSelectedItems();
this.$checkboxes.each(function(j,m){var k=$(m),l=k.data("value").toString(),i=k.prop("checked"),h=g.findByValue(l).length;
if(i&&!h){this.unselect(l,true)
}else{if(!i&&h){this.select(l,true)
}}}.bind(this))
};
a.prototype.onWindowClick=function(g){!$(g.target).closest(this.$el).length&&this.$el.trigger(b.close)
};
a.prototype.onArrowDown=function(g){if(!this.isOpened()){return
}g.preventDefault();
this.$el.trigger(b.next)
};
a.prototype.onArrowUp=function(g){if(!this.isOpened()){return
}g.preventDefault();
this.$el.trigger(b.prev)
};
a.prototype.onClick=function(h){var g=$(h.target).closest("li[role=treeitem]").data("index");
if(!g){return
}this.selectItem(g)
};
a.prototype.onKeyDown=function(g){switch(g.key){case d.Keys.arrowUp:this.onArrowUp(g);
break;
case d.Keys.arrowDown:this.onArrowDown(g);
break;
case d.Keys.tab:this.onTabPress();
break;
case d.Keys.esc:this.onEscPress();
break;
case d.Keys.enter:g.preventDefault();
this.onSpaceOrEnterPress(g);
break;
case d.Keys.space:this.onSpaceOrEnterPress(g);
break;
default:break
}};
a.prototype.selectItem=function(i){var h=this.$checkboxes.eq(i),g=h.siblings(c.checkboxLabel);
this.currentItemIndex=i;
this.$checkboxes.filter("[aria-selected=true]").attr("aria-selected",false);
h.focus().attr("aria-selected",true);
if(i===0){this.$checkboxesContainer.scrollTop(0);
return
}var j=h.offset().top-h.offsetParent().offset().top-g.height();
this.$checkboxesContainer.scrollTop(j)
};
a.prototype.selectPrev=function(){if(this.currentItemIndex<1){return
}this.selectItem(this.currentItemIndex-1)
};
a.prototype.selectNext=function(){if(this.currentItemIndex>=this.$checkboxes.length-1){return
}this.selectItem(this.currentItemIndex+1)
};
a.prototype.initEvents=function(){this.$el.on(b.close,this.onClose.bind(this)).on(b.open,this.onOpen.bind(this)).on(b.next,this.selectNext.bind(this)).on(b.prev,this.selectPrev.bind(this)).on("click",this.onClick.bind(this)).on("keydown",this.onKeyDown.bind(this));
this.$tagsContainer.on("click."+this.eventNamespace,c.unselectTag,this.removeTag.bind(this));
this.initReusedEvents()
};
a.prototype.initReusedEvents=function(){this.$checkboxesContainer.on("change."+this.eventNamespace,":checkbox",this.onCheckboxChange.bind(this));
this.$selectedParams.on("click."+this.eventNamespace,function(){this.$el.trigger(this.isOpened()?b.close:b.open)
}.bind(this));
this.$select.on("synchronize",this.onSync.bind(this));
this.$select.on("reset",this.resetSkillsCounter.bind(this))
};
a.prototype.unselect=function(h,g){this.config.showTags&&this.$tagsContainer.children(c.filterTag).findByAttr("data-value",h.toString()).remove();
this.$checkboxes.findByAttr("data-value",h).removeAttr("checked");
!g&&this.changeSelection(h,false);
this.decrementCounter()
};
a.prototype.changeSelection=function(h,g){var i=this.$options.findByValue(h);
if(g){i.attr("selected","selected").prop("selected",true)
}else{i.removeAttr("selected").prop("selected",false)
}this.$select.trigger("change");
this.$select.trigger(b.change,h)
};
a.prototype.select=function(h,g){!g&&this.changeSelection(h,true);
this.addTag(h);
this.$checkboxes.findByAttr("data-value",h).prop("checked",true);
this.incrementCounter()
};
a.prototype.addTag=function(g){if(!this.config.showTags){return
}var h=this.$options.findByValue(g).html();
e.append("multi-select-filter-tag",{text:h,value:g},this.$tagsContainer)
};
a.prototype.isDropdownAbove=function(){var g=f.scrollTop()+f.height()<this.$el.offset().top+this.$el.height()+this.$checkboxesContainer.outerHeight();
this.isOpened()&&this.$el.toggleClass("above",g)
};
a.prototype.incrementCounter=function(){this.$selectedParams.addClass("selected");
this.selectedCount++;
this.$counterHolder.html(this.selectedCount)
};
a.prototype.updateCounter=function(g){if(g>0){this.$selectedParams.addClass("selected");
this.selectedCount=g;
this.$counterHolder.html(this.selectedCount)
}};
a.prototype.decrementCounter=function(){this.selectedCount--;
if(this.selectedCount>0){this.$counterHolder.html(this.selectedCount)
}else{this.$counterHolder.html("");
this.$selectedParams.removeClass("selected")
}};
a.prototype.resetSkillsCounter=function(){this.selectedCount=0;
this.$counterHolder.html("");
this.$selectedParams.removeClass("selected")
};
a.prototype.destroy=function(){this.$tagsContainer.off("click."+this.eventNamespace);
this.$checkboxesContainer.off("change."+this.eventNamespace);
this.$selectedParams.off("click."+this.eventNamespace);
f.off("click."+this.eventNamespace+" touchstart."+this.eventNamespace);
this.$select.removeData("multiSelectFilter");
this.$el.remove()
};
$.fn.multiSelectFilter=function(g){return this.each(function(){new a($(this),g||{})
})
};
return a
});
define("form-control",["form"],function(c){var b={errorTooltip:"validation-tooltip",fieldError:"validation-field",validationText:"validation-text",focusTarget:"validation-focus-target",epamContinuumStyle:"epam-continuum-style:not(.epam-redesign-23-style)",continuumLabel:"form-component__continuum-label-title",label:"form-component__label",fakePlaceholder:"fake-placeholder"};
function a(d){this.$el=d;
this.$form=this.$el.closest("form");
this.$errorTooltip=this.$el.find("."+b.errorTooltip);
this.$errorText=this.$errorTooltip.find("."+b.validationText);
this.defaultValue=this.$el.data("defaultValue")||"";
this.context=c.extractValidationContext(this.$el);
this.isEpamContinuumStyle=!!this.$el.parents("."+b.epamContinuumStyle).length;
this.$label=this.$el.find("."+b.label);
this.initialLabelText=this.$label.text()
}a.prototype.cleanField=function(){this.toggleError();
this.$input.val(this.defaultValue);
this.afterClean&&this.afterClean()
};
a.prototype.displayValue=function(d,e){this.$input.val(e)
};
a.prototype.toggleError=function(e){var d=!!e;
this.$el.toggleClass(b.fieldError,d);
this.$input.attr("aria-invalid",d);
this.$errorTooltip.find(".is-a11y-only").toggleClass("hidden",!d);
if(this.isEpamContinuumStyle){d?this.$label.text(this.initialLabelText+" ("+e+")"):this.$label.text(this.initialLabelText)
}else{this.$errorText.text(e||"")
}if(this.$el.find("."+b.fakePlaceholder).length){this.setFakePlaceholderHeight()
}};
a.classes=b;
return a
});
define(["utils-dust"],function(e){var g="https://twitter.com/intent/tweet";
function d(i){var h=$("meta[name='"+i+"']").first();
return h&&h.attr("content")||""
}function c(k,n,j){var m=k.text(),i=k.attr("click-to-tweet-url"),h=k.attr("click-to-tweet-view"),l=a(m,i,n,j);
e.jQueryFunc("click-to-tweet",{url:l,view:h,spritePath:window.EPAM.spritePath},k,k.after)
}function a(m,h,l,j){var k={},i=m;
if(l&&l!==j){i+=CQ.I18n.getMessage("rte.click-to-tweet.by-prefix",l)
}else{if(j){k.via=j.substring(1)
}}if(h){k.url=h
}k.text=i;
return g+"?"+$.param(k)
}var f=d("twitter:creator"),b=d("twitter:site");
$(".click-to-tweet-wrapper").each(function(h,i){c($(i),f,b)
})
});
define("AccordionUtil",[],function(){var b={item:".js-accordion-item",link:".js-accordion-link",content:".js-accordion-content",active:"active-item"};
function a(c,d){this.config=d||{};
this.$el=c;
this.$items=this.$el.find(b.item);
this.$links=this.$el.find(b.link);
this.$content=this.$el.find(b.content);
this.$links.on("click",this.onLinkClick.bind(this))
}a.prototype.onLinkClick=function(d){var f=$(d.target),e=f.parent(),c=f.next();
if(e.hasClass(b.active)){e.removeClass(b.active);
c.slideUp();
return false
}this.$items.removeClass(b.active);
this.$content.slideUp();
e.addClass(b.active);
c.slideDown(400,function(){c.scrollToSelector({reservedSpace:52,duration:400})
});
return false
};
a.prototype.classes=b;
return a
});