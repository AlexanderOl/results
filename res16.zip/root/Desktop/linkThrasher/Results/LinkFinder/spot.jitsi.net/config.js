window.JitsiMeetSpotConfig={
  ADVERTISEMENT:{APP_NAME:"Virtual Office"},
  CALENDARS:{BACKEND:{SERVICE_URL:"https://api-vo.jitsi.net/vo-calendar/v1/events?tzid={tzid}"}},
  DEFAULT_AVATAR_URL:"https://8x8.vc/images/avatar.png",
  DEFAULT_BACKGROUND_IMAGE_URL:"https://web-cdn.jitsi.net/spot/newgrayshards.jpg",
  DEFAULT_MEETING_DOMAIN:"8x8.vc",
  EXTERNAL_API_SRC:"https://meet.jit.si/external_api.js",
  LOGGING:{
    ANALYTICS_APP_KEY:"6kWM4WZIZjmRTAwBDv5jyi9jE0COENVp",
    ENDPOINT:"",
    JITSI_APP_NAME:"Jitsi Meet Spot",
  },
  MEDIA:{WIRELESS_SS_MAX_FPS:60},
  MEETING_DOMAINS_WHITELIST:["8x8.vc","beta.meet.jit.si","meet.jit.si"],
  MEETING_INTEGRATIONS:{
    ZOOM:{
      API_KEY: "Vv1ZJd5PSaOpru6V7ogB8A",
      MEETING_SIGN_SERVICE_URL: "https://api-vo.jitsi.net/zoom/sign"
    }
  },
  PRODUCT_NAME:"8x8 Spaces",
  SPOT_SERVICES:{
    jwtDomains:["8x8.vc"],
    pairingServiceUrl:"https://api-vo.jitsi.net/spot-pairing/v1/pair",
    phoneAuthorizeServiceUrl:"https://api-vo.jitsi.net/phone-authorize",
    roomKeeperServiceUrl:"https://api-vo.jitsi.net/spot-roomkeeper/v1/room/info",
  },
  TEMPORARY_FEATURE_FLAGS:{
  },
  MODE_DOMAINS:{SHARE:"share.8x8.vc"},
  ULTRASOUND:{
    EMSCRIPTEN_PATH:"/dist/",
    MEM_INITIALIZER_PATH:"/dist/",
    SUPPORTED_ENV_REGEX:"spotcontroller",
    TRANSMISSION_DELAY:void 0
  },
  XMPP_CONFIG:{bosh:"wss://spot-prosody.jitsi.net/xmpp-websocket",hosts:{domain:"spot-prosody.jitsi.net",muc:"conference.spot-prosody.jitsi.net"}}
}
