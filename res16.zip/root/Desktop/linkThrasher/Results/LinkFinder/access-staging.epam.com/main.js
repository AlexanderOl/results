window.addEventListener('load', function() {
    document.body.removeAttribute('style');
});