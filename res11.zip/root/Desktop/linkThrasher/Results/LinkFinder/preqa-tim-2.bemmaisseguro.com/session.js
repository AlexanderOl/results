﻿(function () {
    //var isAuthenticated = false;
    //function CheckIfUserStillLoggedOn() {
    //    jQuery.ajax({
    //        type: 'GET',
    //        url: '/RestApi/session/is-authenticated',
    //        contentType: "application/json",
    //        accepts: {
    //            text: "application/json"
    //        },
    //        cache: false,
    //        success: function (data) {
    //            if (data.IsAuthenticated && !isAuthenticated)
    //                isAuthenticated = true;

    //            if (!data.IsAuthenticated && isAuthenticated) {
    //                alert("Sua sessão expirou! Por favor, realize novamente o login.");
    //                location.href = '/home';
    //            }
    //        }
    //    });
    //}

    //setInterval(function () {
    //    if (isAuthenticated)
    //        CheckIfUserStillLoggedOn();
    //}, 30000);

    //CheckIfUserStillLoggedOn();
})();
