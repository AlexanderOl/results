// COMMON SCRIPTS

var site = {
    init: function() {
        site.hamburguerInit();
        site.afterHelpClick();
        site.afterHamburguerClick();

        //Loop para colocar class para os �cones do menu
        $(".nav-stacked li").each(function (index) {
            var item = $(this);
            var linkItem = item.find("a");

            if (linkItem != undefined) {
                var urlLinkItem = linkItem.attr("href");
                if (urlLinkItem.split('/').reverse().length > 0) {
                    var className = urlLinkItem.split('/').reverse()[0];
					className = className.replace("2","segunda");
                    item.removeClass(className);
                    item.addClass(className);
                }
            }
        })

        if ($.datepicker != undefined){
            $.datepicker.regional['pt-BR'] = {
                closeText: 'Fechar',
                prevText: '&#x3c;Anterior',
                nextText: 'Pr&oacute;ximo&#x3e;',
                currentText: 'Hoje',
                monthNames: ['Janeiro', 'Fevereiro', 'Mar&ccedil;o', 'Abril', 'Maio', 'Junho',
                'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
                monthNamesShort: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
                'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
                dayNames: ['Domingo', 'Segunda-feira', 'Ter&ccedil;a-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sabado'],
                dayNamesShort: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
                dayNamesMin: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'],
                weekHeader: 'Sm',
                dateFormat: 'dd/mm/yy',
                firstDay: 0,
                isRTL: false,
                showMonthAfterYear: false,
                yearSuffix: '',
                changeMonth: true,
                changeYear: true
            };

            $.datepicker.setDefaults($.datepicker.regional['pt-BR']);
        }
    },
    hamburguerInit: function() { //MAKES THE BOOTSTRAP HAMBURGUER MAGIC ABLE TO HAPPEN
        $(".navigation").attr('id', 'navbar');
    },
    afterHelpClick: function() { //SOLVE ISSUES WITH THE ERROR ICON ON IOS OPERATIONAL SYSTEM
        if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){ 
            $(".help-block").on('click', function(){
                $(this).toggleClass('selected');
            });
        }
    },
    afterHamburguerClick: function(){ // MOVES THE USER VIEW FOR WHERE THE NAVIGATION IS OPENING
        $(".navbar-toggle").on('click', function(){
            $(this).toggleClass('opened');
            if ( $(window).scrollTop() >= 0){
                $('html,body').animate({scrollTop: $("body").offset().top}, 500);
            }
        });
    }
}

$(function(){
    site.init();
});

//General angular validate CPF
angular.module('assurant')
.directive('numericOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, modelCtrl) {

            modelCtrl.$parsers.push(function (inputValue) {
                var transformedInput = inputValue ? inputValue.replace(/[^\d\.]/g, '') : null;

                if (transformedInput != inputValue) {
                    modelCtrl.$setViewValue(transformedInput);
                    modelCtrl.$render();
                }

                return transformedInput;
            });
        }
    };
})
.directive('charactersonly', function () {
    return {
        link: function (scope, elem, attrs) {
            $(elem).keypress(function (e) {
                if (e.keyCode == 8 || e.charCode == 8 || e.keyCode == 9 || e.charCode == 9)
                    return;

                var valid_chars = 'ãÃáÁàÀâÂêÊéÉèÈíÍìÌôÔõÕòÒóÓúÚùÙabcçdefghijlmnopqrstuvxzwykABCDEFGHIJLMNOPQRSTUVXZWYK ';
                var chr = String.fromCharCode(e.keyCode || e.charCode);     
                if (!(valid_chars.indexOf(chr) > -1)) 
                    e.preventDefault();
            });
        }
    }
})
.directive('loginOnly', function () {
    return {
        link: function (scope, elem, attrs) {
            $(elem).keypress(function (e) {
                if (e.keyCode == 8 || e.charCode == 8 || e.keyCode == 9 || e.charCode == 9)
                    return;

                var valid_chars = '._abcdefghijlmnopqrstuvxzwykABCDEFGHIJLMNOPQRSTUVXZWYK0123456789';
                var chr = String.fromCharCode(e.keyCode || e.charCode);
                if (!(valid_chars.indexOf(chr) > -1))
                    e.preventDefault();
            });
        }
    }
})
.directive('passwordOnly', function () {
    return {
        link: function (scope, elem, attrs) {
            $(elem).keypress(function (e) {
                if (e.keyCode == 8 || e.charCode == 8 || e.keyCode == 9 || e.charCode == 9)
                    return;

                var valid_chars = 'ãÃáÁàÀâÂêÊéÉèÈíÍìÌôÔõÕòÒóÓúÚùÙçÇÃ ';

                var chr = String.fromCharCode(e.keyCode || e.charCode);
                if (valid_chars.indexOf(chr) > -1)
                    e.preventDefault();
            });
        }
    }
})
.directive('validdate', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            scope.$watch(attrs.ngModel, function () {
                var ua = window.navigator.userAgent;
                var msie = ua.indexOf("MSIE");

                var newDate = elem[0].value;
                var splitDate = newDate.split('/');

                var d = parseInt(splitDate[0], 10);
                var m = parseInt(splitDate[1], 10);
                var y = parseInt(splitDate[2], 10);

                var date = new Date(y, m - 1, d);

                if (msie !== -1) {
                    if (date.getDate() != d )
                    date.setDate(date.getDate() + 1);
                }

                if (date.getFullYear() == y && date.getMonth() + 1 == m && date.getDate() == d)
                    ctrl.$setValidity("validdate", true);
                else
                    ctrl.$setValidity("validdate", false);
            });
        }
    };
})
.directive('validemail', function () {
    return {
        link: function (scope, elem, attrs) {
            $(elem).keypress(function (e) {
                if (e.keyCode == 8 || e.charCode == 8 || e.keyCode == 9 || e.charCode == 9)
                    return;

                var valid_chars = '@abcçdefghijlmnopqrstuvxzwykABCDEFGHIJLMNOPQRSTUVXZWYK.-_0123456789';
                var chr = String.fromCharCode(e.keyCode || e.charCode);
                if (!(valid_chars.indexOf(chr) > -1))
                    e.preventDefault();
            });
        }
    }
})
.directive('denywhitespaces', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            $(elem).keypress(function (e) {
                if (e.which === 32)
                    return false;
            });
        }
    };
})
.directive('cpfinvalido', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {

            scope.$watch(attrs.ngModel, function () {

                var strCPF = elem[0].value;
                strCPF = strCPF.replace(/[^a-z0-9\s]/gi, '').replace(/[_\s]/g, '-');

                if (strCPF.length == 0)
                    ctrl.$setValidity('cpfinvalido', true);
                else if (strCPF.length < 11) {
                    ctrl.$setValidity('cpfinvalido', false);
                }
                else {
                    var Soma;
                    var Resto;
                    Soma = 0;
                    if (strCPF == "00000000000" ||
                        strCPF == "00000000000" ||
                        strCPF == "11111111111" || 
                        strCPF == "22222222222" || 
                        strCPF == "33333333333" || 
                        strCPF == "44444444444" || 
                        strCPF == "55555555555" || 
                        strCPF == "66666666666" || 
                        strCPF == "77777777777" || 
                        strCPF == "88888888888" || 
                        strCPF == "99999999999"){
                        ctrl.$setValidity('cpfinvalido', false);
                        return;
                    }
                    for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
                    Resto = (Soma * 10) % 11;
                    if ((Resto == 10) || (Resto == 11)) Resto = 0;
                    if (Resto != parseInt(strCPF.substring(9, 10))) ctrl.$setValidity('cpfinvalido', false);
                    Soma = 0;
                    for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
                    Resto = (Soma * 10) % 11;

                    if ((Resto == 10) || (Resto == 11))
                        Resto = 0;

                    if (Resto != parseInt(strCPF.substring(10, 11)))
                        ctrl.$setValidity('cpfinvalido', false);
                    else
                        ctrl.$setValidity('cpfinvalido', true);
                }
            });
        }
    };
})
.directive('cnpjinvalido', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {

            scope.$watch(attrs.ngModel, function () {

                var cnpj = elem[0].value;
                cnpj = cnpj.replace(/[^\d]+/g, '');

                if (cnpj.length == 0)
                    ctrl.$setValidity('cnpjinvalido', false);
                else if (cnpj.length != 14) {
                    ctrl.$setValidity('cnpjinvalido', false);
                }
                else {
                    // Elimina CNPJs invalidos conhecidos
                    if (cnpj == "00000000000000" ||
                        cnpj == "11111111111111" ||
                        cnpj == "22222222222222" ||
                        cnpj == "33333333333333" ||
                        cnpj == "44444444444444" ||
                        cnpj == "55555555555555" ||
                        cnpj == "66666666666666" ||
                        cnpj == "77777777777777" ||
                        cnpj == "88888888888888" ||
                        cnpj == "99999999999999")
                        ctrl.$setValidity('cnpjinvalido', false);

                    // Valida DVs
                    tamanho = cnpj.length - 2
                    numeros = cnpj.substring(0, tamanho);
                    digitos = cnpj.substring(tamanho);
                    soma = 0;
                    pos = tamanho - 7;
                    for (i = tamanho; i >= 1; i--) {
                        soma += numeros.charAt(tamanho - i) * pos--;
                        if (pos < 2)
                            pos = 9;
                    }
                    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                    if (resultado != digitos.charAt(0))
                        return false;

                    tamanho = tamanho + 1;
                    numeros = cnpj.substring(0, tamanho);
                    soma = 0;
                    pos = tamanho - 7;
                    for (i = tamanho; i >= 1; i--) {
                        soma += numeros.charAt(tamanho - i) * pos--;
                        if (pos < 2)
                            pos = 9;
                    }
                    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
                    if (resultado != digitos.charAt(1))
                        ctrl.$setValidity('cnpjinvalido', false);
                    else
                        ctrl.$setValidity('cnpjinvalido', true);
                }
            });
        }
    };
})
.directive('accessibleForm', function () {
    return {
        restrict: 'A',
        link: function (scope, elem) {

            // set up event handler on the form element
            elem.on('submit', function () {

                // find the first invalid element
                var firstInvalid = elem[0].querySelector('.ng-invalid');

                // if we find one, set focus
                if (firstInvalid) {
                    firstInvalid.focus();
                }
            });
        }
    };
});

function scrollToElement(el) {
    $('html,body').animate({
        scrollTop: $(el).offset().top
    }, 600);
}