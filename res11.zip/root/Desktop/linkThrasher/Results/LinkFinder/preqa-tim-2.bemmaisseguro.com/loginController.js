﻿
(function () {

    $('#cpf').mask('000.000.000-00');

    function Form(login, password) {
        this.login = login;
        this.password = password;
    }

    function FormForgotPW(cpf, login) {
        this.cpf = cpf;
        this.login = login;
    }

    function LoginResult(success, message) {
        this.success = success;
        this.message = message;
    }

    angular.module('assurant')
        .controller('LoginController', ['$scope', 'LoginService', function ($scope, LoginService) {
            $scope.data = new Form();
            $scope.dataForgotPW = new FormForgotPW();
            $scope.successForgotMessage = false;

            $scope.hideMessage = function () {
                $scope.message = "";
            }

            $scope.hideMessageForgotPW = function () {
                $scope.resetFormForgotPW();
            }

            $scope.authenticate = function (login, password) {
                // do not call remote service with invalid form data
                if (!$scope.form.$valid) {
                    $scope.form.$submitted = true;
                    return;
                }

                $(".busy").show();
                LoginService.authenticate(login, password, function (result) {
                
                    if (!result.success) {
                        // display error message on screen
                        $scope.message = result.message;
                        $(".busy").hide();
                    } else {
                        if ($scope.message == "")
                            window.location.href = "/dashboard";
                        else
                            window.location.href = result.message;
                    }
                });
            };

            $scope.resetFormForgotPW = function () {
                $scope.successForgotMessage = false;
                $scope.messageForgotMessage = '';
                $scope.dataForgotPW.login = '';
                $scope.dataForgotPW.cpf = '';
            }

            $scope.forgotPW = function (cpf, login) {
                // do not call remote service with invalid form data
                if (!$scope.formForgotPW.$valid) {
                    $scope.formForgotPW.$submitted = true;
                    return;
                }

                $scope.busyForgotPW = true;
                LoginService.forgotPW(cpf, login, function (result) {
                    $scope.busyForgotPW = false;
                    $scope.successForgotPW = result.success;
                    if (!result.success) {
                        // display error message on screen
                        $scope.messageForgotMessage = result.message;
                    } else {
                        $scope.successForgotMessage = true;
                    }
                });
            };

        }]);

})();
