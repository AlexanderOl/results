﻿
(function () {

    function Form(login, password) {
        this.login = login;
        this.password = password;
    }

    function FormForgotPW(cpf, login) {
        this.cpf = cpf;
        this.login = login;
    }

    function LoginResult(success, message) {
        this.success = success;
        this.message = message;
    }

    angular.module('assurant').service('LoginService', ['$http', function ($http) {
        function authenticate(login, password, callback) {
            var url = '/sitefinity/public/services/authentication/loginservice.svc/authenticateuser';

            $http.post(url, angular.toJson(new Form(login, password))).then(
              function (result) {
                  // works
                  return callback(new LoginResult(result.data.success, result.data.message));
              },
              function (result) {
                  // error reaching remote server
                  var messageError = 'unexpected error occurred';
                  if (result.statusText != '')
                      messageError = 'Status: ' + result.status.toString() + ' | StatusText: ' + result.statusText;
                  return callback(new LoginResult(false, messageError));
              });
        }

        function forgotPW(cpf, login, callback) {
            var url = '/sitefinity/public/services/authentication/loginservice.svc/resetpassword';

            $http.post(url, angular.toJson(new FormForgotPW(cpf, login))).then(
              function (result) {
                  // works
                  return callback(new LoginResult(result.data.success, result.data.message));
              },
              function (result) {
                  // error reaching remote server
                  var messageError = 'unexpected error occurred';
                  if (result.statusText != '')
                      messageError = 'Status: ' + result.status.toString() + ' | StatusText: ' + result.statusText;
                  return callback(new LoginResult(false, messageError));
              });
        }

        return {
            authenticate: authenticate,
            forgotPW: forgotPW
        };
    }]);

})();
