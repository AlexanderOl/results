// Any new comment in this section is part of the new configuration for AUL integration 

if( location.hostname == 'localhost') {
  window.config = {
    //gsp server side url 
    site: {
      apiUrl: 'http://localhost:5000/',
      //apiUrl: 'https://dev-api.sales.assurant.com/',
      apiVersion: '1',
    },
      core: {
      cmsApiUrl: 'http://localhost:5000/api/v1',

      //clientCMS: '4d29ad14-6fe5-41c4-87cc-0afab812d44d',//D2C SF id
      //parentCMS: '4d29ad14-6fe5-41c4-87cc-0afab812d44d',//D2C SF id

      // PYB
      //clientCMS: 'e9fa1cfc-2e37-483c-8a7a-61a7142e2667',
      //parentCMS: '4d29ad14-6fe5-41c4-87cc-0afab812d44d',

      // LUX
      //clientCMS: '31359713-68d2-4877-b026-18a775941ae5',
      //parentCMS: '4d29ad14-6fe5-41c4-87cc-0afab812d44d',

      //Samsung UK
      //clientCMS: 'b5ee48a0-7b08-4d3f-b43a-360c5c66c197',
      parentCMS: '4d29ad14-6fe5-41c4-87cc-0afab812d44d',

      // Keep this in Sync with Home Components in Angular Route for Optimal performance
      //-- D2C landing page components
      homeComponents: 'Global,Login,Support,Dashboard',

      language: 'en',
      systemRole: '',
      production: 'false',

      //core.D2C
      // clientCMS: '4d29ad14-6fe5-41c4-87cc-0afab812d44d',//D2C SF id
      // program: 'D2C',//program for D2C
      // resourceClient: 'D2C',//resourceClient for D2C

      //core.PYB
      // clientCMS: 'e9fa1cfc-2e37-483c-8a7a-61a7142e2667',//PYB SF id
      // program: 'PYB',//program for PYB
      // resourceClient: 'PYB',//resourceClient for PYB

      //core.LUX
      //clientCMS: '31359713-68d2-4877-b026-18a775941ae5',//LUX SF id
      //program: 'LUX',//program for LUX
      //resourceClient: 'LUX',//resourceClient for LUX

      //core.SAMSUNG
      clientCMS: '7096d627-e48e-40a6-b0f6-79a54a9a37e9',//SAMSUNG SF id
      program: 'SAMSUNG-UK',//program for SAMSUNG
      resourceClient: 'SAMSUNG',//resourceClient for SAMSUNG

      //core.SAMSUNG
      // clientCMS: '6a254709-2cf8-4229-8d08-dd8a531e9d59',//SAMSUNG SF id
      // program: 'SAMSUNG-IT',//program for SAMSUNG
      // resourceClient: 'SAMSUNG',//resourceClient for SAMSUNG
    },
    ewayConfig: {
      publicApiKey: "epk-7C64D753-D277-423E-A83E-71B87AA37C54"
    },
    aul: {
      //Direct2Consumer Dev
      aulUrl: 'http://dev-mylogin.assurant.com/aulv1/', // this is where AUL is deployed 
      aulClient: 'SAMSUNG'
    },
    oktaSettings: {
      // OKTA DEV
      oktaBaseUrl: 'https://dev-assurant.oktapreview.com',
      oktaClientId: '0oapiglx03SA82Vjg0h7',   // AUL OKTA APP ID
      oktaInternalEndPoint: 'https://id-dev.assurant.com',
      oktkaIssuer: 'https://dev-assurant.oktapreview.com/oauth2/v1/',
      oktaAuthIssuer: 'https://dev-assurant.oktapreview.com/oauth2/ausppjb0n7Ven7InY0h7',
      oktaAuthorizeUrl: 'https://dev-assurant.oktapreview.com/oauth2/ausppjb0n7Ven7InY0h7/v1/authorize',
      redirectUrl: '',

      //okta.D2c
      //oktaPrefix: 'AUL__D2C',  // AUL with SSO users, please contact AUL team for more information

      //okta.PYB
      //oktaPrefix: 'AUL__PYB',  // AUL with SSO users, please contact AUL team for more information

      //okta.LUX
      //oktaPrefix: 'AUL__LUX',  // AUL with SSO users, please contact AUL team for more information

      //okta.SAMSUNG
      oktaPrefix: 'AUL__SAMSUNG',  // AUL with SSO users, please contact AUL team for more information

      // OKTA MODEL
      // oktaBaseUrl: 'https://assurant.oktapreview.com',
      // oktaClientId: '0oaq2qf2i1bgZiCYS0h7',
      // oktaInternalEndPoint: 'https://id-model.assurant.com',
      // oktkaIssuer: 'https://assurant.oktapreview.com/oauth2/v1/',
      // oktaAuthIssuer: 'https://assurant.oktapreview.com/oauth2/ausppiuqtmYzAsRY60h7',
      // oktaAuthorizeUrl: 'https://assurant.oktapreview.com/oauth2/ausppiuqtmYzAsRY60h7/v1/authorize',
      // redirectUrl: '',
    },

    googleAnalytics: {
      gtmId: 'GTM-W9W9FRC',
    },

    sitefinitySettings: {
      resourceEditMode: 'true',
    },

    misc: {
      version: '1.0.0.0',
    },

    legacyPayment: {
      paymentUrl: 'https://dev.payment-gateway.assurant.co.uk',
      brand: 'samsung',
      client: 'samsung',
      originatorPrefix: 'S-AUK-',
      currency: 'Global_Settings_DefaultCurrencyCode',
      amount: 0,
      secret: 'iamasecret',
      isPaymentSuccess: 'false',
      originatorNumber: 'originatorId',
    },
    appInsights: {
      instrumentationKey: ''
  }
  };
} else {
    // Variables Substituted through ADO VGs
    window.config = {

      site:{
        apiUrl: 'https://gsp-samsung-model-fr-api.ase4s1.assurant.com/',
        apiVersion: '1',
      },
      core:{
        cmsApiUrl:  'https://gsp-samsung-model-fr-api.ase4s1.assurant.com/api/v1/',
        clientCMS: '7096d627-e48e-40a6-b0f6-79a54a9a37e9',
        parentCMS: '4d29ad14-6fe5-41c4-87cc-0afab812d44d',
        homeComponents: 'Global,Login,DemandsAndNeedsQuestions,CustomerInformation,EligibilityQuestions,PaymentInformation,CreditCardInformation,IBANInformation,ProductSearchResults,SearchPlans,ReviewPlanDetail,Confirmation,Sales,Signature,FooterLayout',
        language: 'fr-FR',
        culture: '',
        program: 'SAMSUNG-FR',
        resourceClient: 'SAMSUNG',
        systemRole: 'NA',
        production: 'false',
      },
      ewayConfig: {
        publicApiKey: ''
      },
      aul:{
        aulUrl: 'https://model-mylogin.assurant.com/aulv1/',
        aulApiUrl: 'https://model-api.mylogin.assurant.com/aulv1/',
        aulClient: 'Samsung',
        aulApplicationName: 'GSP-Samsung',
        bypassLogin: 'false',
      },
      oktaSettings:{
        oktaPrefix: 'AUL__SAMSUNG',
        oktaBaseUrl: 'https://assurant.oktapreview.com',
        oktaClientId: '0oaq2qf2i1bgZiCYS0h7',
        oktaInternalEndPoint: 'https://id-model.assurant.com',
        oktkaIssuer: '',
        oktaAuthIssuer: 'https://assurant.oktapreview.com/oauth2/ausppiuqtmYzAsRY60h7',
        oktaAuthorizeUrl: 'https://assurant.oktapreview.com/oauth2/ausppiuqtmYzAsRY60h7/v1/authorize',
        redirectUrl: 'https://gsp-samsung-model-fr-api.ase4s1.assurant.com/',
      },
      googleAnalytics:{
        gtmId: 'GTM-MS2896D',
      },
      sitefinitySettings:{
        resourceEditMode: 'true',
      },
      misc:{
        version: 'NA',
      },
      preneed:{
        acc_SSO_GroupName: '',
        fe_SSO_GroupName: '',
      },
      legacyPayment: {
        paymentUrl: 'https://uat.payment-gateway.assurant.co.uk',
        brand: 'samsung',
        client: 'samsung',
        originatorPrefix: 'S-AUK-',
        currency: 'Global_Settings_DefaultCurrencyCode',
        amount: '0',
        secret: 'cxEMLtTrx4Q4tc8p',
        isPaymentSuccess: 'false',
        originatorNumber: 'originatorId',
      },
      appInsights: {
        instrumentationKey: ''
    },

    };
  }
