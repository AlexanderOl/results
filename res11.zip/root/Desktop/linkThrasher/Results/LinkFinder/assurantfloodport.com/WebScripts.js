/*********************************************************************************** 
 * 
 * JavaScript for supporting web applications 
 * 
 ***********************************************************************************/


/*********************************************************************************** 
 * Form submit functions
 *   Include various combinations of abilities such as:
 *     - choosing which form to submit  
 *     - invoking the Struts JavaScript validations  
 *     - setting the navigation field to a value 
 *     - setting a form field to a value
 *     - invoking the saveValue() function (implemented in detail JSPs) 
 ***********************************************************************************/
function submitFormWithEdits(formId, validateMethod){
	if(pageEdits(validateMethod, document.forms[formId])) {
		determineTransparent();
		document.forms[formId].submit();
	}
}

/* This does not appear to be used (1/2015) - please avoid
 * using anyway and use the execFormXXX functions instead */
function execCmdAfterSave(cmd){
	document.getElementById('action').value = cmd;
	saveValues();
	document.forms[0].submit();
}

function execCmdAfterSaveWithEdits(cmd, validateMethod){
	if(pageEdits(validateMethod, document.forms[0]))	{
		execCmdAfterSave(cmd);
	}
}

/* Try to avoid after 1-1-2015; use execFormCmd if possible,
 * or at least use execCmdIE10 as a last resort */
function execCmd(cmd){
	document.getElementById('action').value = cmd;
	determineTransparent();
	document.forms[0].submit();
}

/* supporting IE10 and later*/
function execCmdIE10(cmd, actionId){
	document.getElementById(actionId).value = cmd;
	determineTransparent();
	document.forms[0].submit();
}

/* Try to avoid after 1-1-2015; use execFormCmdWithEdits if possible,
 * or at least use execCmdWithEditsIE10 as a last resort */
function execCmdWithEdits(cmd, validateMethod){
	if(pageEdits(validateMethod, document.forms[0]))	{
		execCmd(cmd);
	}
}

/* supporting IE10 and later*/
function execCmdWithEditsIE10(cmd, validateMethod, actionId){
	if(pageEdits(validateMethod, document.forms[0]))	{
		execCmdIE10(cmd, actionId);
	}
}

/* Try to avoid after 1-1-2015; use execFormCmdWithEdits if possible,
 * or at least use execCmdWithEdits2IE10 as a last resort */
function execCmdWithEdits2(cmd, validateMethod){
	document.getElementById('action').value = cmd; //set action first so struts validations can do requiredWhen tests on action
	if(pageEdits(validateMethod, document.forms[0])){
		makePageTransparent();
		execCmd(cmd);
	}else{
		undoMakePageTransparent();
		document.getElementById('action').value = ""; //clear action since not being performed
	}
}

/* supporting IE10 and later*/
function execCmdWithEdits2IE10(cmd, validateMethod, actionId){
	document.getElementById(actionId).value = cmd; //set action first so struts validations can do requiredWhen tests on action
	if(pageEdits(validateMethod, document.forms[0])){
		makePageTransparent();
		execCmdIE10(cmd,actionId);
	}else{
		undoMakePageTransparent();
		document.getElementById(actionId).value = ""; //clear action since not being performed
	}
}
/*
 * Do not use this function in Floodport.
 * In Floodport, navigation element id is nav.  
 * use formNavigateTo and pass in form, id, and page.
 * lmredman
 */
function navigateTo(page){
	document.getElementById('navigation').value=page;
	determineTransparent();
	document.forms[0].submit();
}

function navigateToWithEdits(page, validateMethod){
	if(pageEdits(validateMethod, document.forms[0]))	{
		navigateTo(page);
	}
}

function execFormCmdAfterSave(formId, actionId, cmd){
	document.getElementById(actionId).value = cmd;
	saveValues();
	determineTransparent();
	document.forms[formId].submit();
}

function execFormCmdAfterSaveWithEdits(formId, actionId, cmd, validateMethod){
	var priorAction = document.getElementById(actionId).value;
	document.getElementById(actionId).value = cmd;  //set before validate so edits can test this value if desired
	if(pageEdits(validateMethod, document.forms[formId]))	{
		execFormCmdAfterSave(formId, actionId, cmd);
	}else {
		document.getElementById(actionId).value = priorAction;
	}
}

function execFormCmd(formId, actionId, cmd){
	document.getElementById(actionId).value = cmd;
	determineTransparent();
	document.forms[formId].submit();
}

function execFormCmdWithEdits(formId, actionId, cmd, validateMethod){
	var priorAction = document.getElementById(actionId).value;
	document.getElementById(actionId).value = cmd;  //set before validate so edits can test this value if desired
	if(pageEdits(validateMethod, document.forms[formId]))	{
		execFormCmd(formId, actionId, cmd);
	}else {
		document.getElementById(actionId).value = priorAction;
	}
}

function formNavigateTo(formId, navId, page){
	document.getElementById(navId).value=page;
	determineTransparent();
	document.forms[formId].submit();
}

function formNavigateToWithEdits(formId, navId, page, validateMethod){
	if(pageEdits(validateMethod, document.forms[formId]))	{
		formNavigateTo(formId, navId, page);
	}
}

function pageEdits(validateFunction, theForm)	{
	 resetDisplay(this); 
	 validateFunction(theForm); 
	 return testForErrors(this);
}
/**
 * Used in Agency for the next button
 */
function navigateToWizard(page){
	if (document.getElementById('wizardNavigation')){
		document.getElementById('wizardNavigation').value=page;
		if (validatePage(document.forms[0])) {
			determineTransparent();
			document.forms[0].submit();
		}
	}
}

function determineTransparent(){
			makePageTransparent();
	
}
//**********************************************************************************


/*********************************************************************************** 
 * Document display functions
 ***********************************************************************************/
/* 
 * Show document in a pop-up window. Parameter 'document' can be DecPage, RenewalInvoice etc.
 */
function showDocument(document, policyId, activityId){
	if (activityId != null){
	    window.open('PolicyActivityDisplayServlet?sessiontype=0&viewkey=' + document + 
                '&viewvalue=' +  policyId + '&activityId=' + activityId, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
	}else{
	    window.open('ObjectDisplayServlet?sessiontype=0&viewkey=' + document + 
	                '&viewvalue=' +  policyId, '', 
	                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
	}
}

/** 
 * Show image in a pop-up window. Essentially same as above but expects
 * to use a response output stream to display an raw image to the window.
 */
function showDocumentImage(document, policyId){
    window.open('ImageDisplayServlet?sessiontype=0&viewkey=' + document + 
                '&viewvalue=' +  policyId, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/** 
 * Show document image in a pop-up window.  The idea of "quick view" is that
 * no other info is needed (i.e. no model info) to get the image.  Access
 * can be obtained using some (usually http) client and the urn parameter
 * 
 * This is the same as showImageQuickView but allows more information to be 
 * passed to the servlet, such as the mimetype and filename of the image to
 * be displayed.
 * 
 * Origin: there were mimetype problems using CI when tryin to display .doc, 
 * .docx, .xls, and .xlsx files.  This is an attempt to correct that from the
 * application side.  Actually, to really fix this, the CI should send the
 * correct mimetype and filename, but it isn't doing that, so... there.
 */
function showImageQuickViewEnhanced(urn,ext,ifn){
    //alert('ImageQuickView?urn='+urn+'&ext='+ext+'&ifn='+ifn);
    
    window.open('ImageQuickView?urn='+urn+'&ext='+ext+'&ifn='+ifn, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/** 
 * Show document image in a pop-up window.  The idea of "quick view" is that
 * no other info is needed (i.e. no model info) to get the image.  Access
 * can be obtained using some (usually http) client and the urn parameter
 */
function showImageQuickView(urn){
    window.open('ImageQuickView?urn='+urn, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/* 
 * Show document in a pop-up window. The model should have a method with getModelForxxx
 * where xxxx is the document name receiving String policyId as the parm. 
 * For example getModelForDecPage(String policyId) for DecPage.
 */
function showDocumentUsingModel(document, policyId){
    window.open('ObjectDisplayServlet?sessiontype=0&viewkey=' + document + 
                '&viewattribute=getModelFor' + document + 
                '&viewvalue=' +  policyId, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/*
 * Essentially same as above but expects to use a response output stream
 * to display an raw image to the window.
 */
function showDocumentImageUsingModel(document, policyId){
    window.open('ImageDisplayServlet?sessiontype=0&viewkey=' + document + 
                '&viewattribute=getModelFor' + document + 
                '&viewvalue=' +  policyId, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/* 
 * Show document in a pop-up window. The model should have a method with getModelForxxx
 * where xxxx is the document name without any parm. 
 * For example getModelForDecPage() for DecPage.
 */
function showDocumentUsingModelNoViewKey(document){
    window.open('ObjectDisplayServlet?sessiontype=0&viewkey=' + document + 
                '&viewattribute=getModelFor' + document, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/*
 * Essentially same as above but expects to use a response output stream
 * to display an raw image to the window.
 */

function showDocumentImageUsingModelNoViewKey(document){
    window.open('ImageDisplayServlet?sessiontype=0&viewkey=' + document + 
                '&viewattribute=getModelFor' + document, '', 
                'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/* 
 * Show Manual output in a pop-up window. 
 */
function showManualOutput( document )
{
    window.open('ManualOutputDisplayServlet?server=OPUS&keyName=xyz&keyValue=xyz&sessiontype=0' +
                '&viewKey=manual' + document, '', 'width=800,height=300,resizable=1,scrollbars=yes,menubar=yes');
}

/* 
 * Show Manual output in a pop-up window. The model should have a method with getModelForXxx
 * where xxxx is the document name.  Optional parm viewKey method will be called on the object returned
 * from getModelForXxx if it is supplied, else "manual"+document will be called.
 */
function showManualOutputUsingModel( document, viewKey )
{
	var key = arguments.length == 2? viewKey : "manual" + document;
    window.open('ManualOutputDisplayServlet?server=OPUS&keyName=xyz&keyValue=xyz&sessiontype=0' +
                '&viewKey=' + key + '&viewattribute=getModelFor' + document, 
                '', 'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}

/* 

 * Show Manual output in a pop-up window. The model should have a method with getModelForxxx
 * where xxxx is the document name receiving String policyId as the parm. 
 * For example getModelForDecPage(String policyId) for DecPage.
 */
function showManualOutputUsingModelKey( document, policyId )
{
    window.open('ManualOutputDisplayServlet?server=OPUS&keyName=xyz&keyValue=xyz&sessiontype=0' +
                '&viewKey=manual' + document + '&viewattribute=getModelFor' + document + '&viewvalue=' +  policyId, 
                '', 'width=800,height=750,resizable=1,scrollbars=yes,menubar=yes');
}
//**********************************************************************************


/*********************************************************************************** 
 *  Various functions used to change the CSS Style class of a table row 
 *  to the style class of a mouseover row and then back to it's
 *  original style class on mouseout.  Also for the visual display of 
 *  a selected row by using an image (like a check mark) on that row.
 ***********************************************************************************/
var saveClassName = "";
var saveColorBeforeMouseOver = "";
var saveColorBeforeSelecting = "";
function changeRow(rowId){
	saveClassName = document.getElementById(rowId).className;
	document.getElementById(rowId).className = "selectrow";
	document.getElementById(rowId).style.cursor = "pointer";
}
function changeRowBack(rowId){
	document.getElementById(rowId).className = saveClassName; 
}
function changeMouseInColor(rowId){
	saveColorBeforeMouseOver = document.getElementById(rowId).className;
	document.getElementById(rowId).className = "hoverrow";
	document.getElementById(rowId).style.cursor = "hand";
}
function changeMouseOutColor(rowId){
	document.getElementById(rowId).className = saveColorBeforeMouseOver; 
}
function changeMouseInColorTo(targetColor, rowId){
	saveColorBeforeMouseOver = document.getElementById(rowId).className;
	document.getElementById(rowId).className = targetColor;
	document.getElementById(rowId).style.cursor = "hand";
}

function setCheckMark(rowType, rowMark, rowId) {
	if (document.getElementById("selectedRow")){
		var selectedrowvar = document.getElementById("selectedRow").value;
		if (rowId == selectedrowvar) {return;}
		// Set image to spacer on the previous selection and reset its' original color before selecting.
		if (document.getElementById(rowMark+selectedrowvar)){
			document.getElementById(rowMark+selectedrowvar).src = document.getElementById("Spacer").src;
			document.getElementById(rowType+selectedrowvar).className = saveColorBeforeSelecting; 
		}
		// Set image to checkmark on the new row. Save off its old color and highlight.
		document.getElementById(rowMark+rowId).src = document.getElementById("CheckMark").src;
		document.getElementById("selectedRow").value=rowId;
		saveColorBeforeSelecting = saveColorBeforeMouseOver;
		saveColorBeforeMouseOver = document.getElementById("selectrow").className;
		document.getElementById(rowType+rowId).className = "selectrow"; 
	}
}
//**********************************************************************************


/*********************************************************************************** 
 * Functions for showing navigation tabs as active or not active.
 ***********************************************************************************/
function turnOn(tab){
	document.getElementById(tab).className = "tab_on";
}
function turnOff(tab){
	document.getElementById(tab).className = "tab_off";
}
function makeUnavailable(tab){
	document.getElementById(tab).className = "tab_unavailable";
}
function doMouseover(tab){
	if (document.getElementById(tab).className == "tab_off" ){
		document.getElementById(tab).className="tab_off_underline";
		document.getElementById(tab).style.cursor="pointer";
	}
}
function doMouseout(tab){
	if (document.getElementById(tab).className == "tab_off_underline" ){
		document.getElementById(tab).className="tab_off";
	}
}
//**********************************************************************************


/*********************************************************************************** 
* Functions used to create and maintain collapsable headers and panels. 
* To use:
* The header row that is dynamic in the jsp needs to be id="collapsable_header_#" where
* the "#" is a numeric that increments for the number of collapsable panels.
* The panel that needs hide or show needs to have a div id ="collapsable_panel_#"
* The arrow used to hide or show the panel needs to have a styleId = "collapsable_header_arrow_#".
* If you wish to apply focus to a field within collapsable panel when it opens you will need to specify a 
* focus field,and an alternateFocusField.  The alternateFocusField needs to be a field not within a 
* collapsable panel.
 ***********************************************************************************/
var collapsableHeader = "collapsable_header_";
var collapsablePanel = "collapsable_panel_";
var collapsableArrow = "collapsable_header_arrow_";
var focusField = "focus_field_";
var alternateFocusField = "alternate_focus_field";
var activecolor = "headercolor";
var inactivecolor = "subheadercolor";
var altactivecolor = "collapsableheadercolor";
var altinactivecolor = "collapsablesubheadercolor";

function swapCollapsablePanel(id, alternate, focusIn) {
	var panel = document.getElementById(collapsablePanel + id);
        if (panel) {
    	if(panel.style.display == '') {
    		panel.style.display = 'none';
    		document.getElementById(collapsableArrow + id).src = document.getElementById('button_down_arrow_on').src;
    	}else{
    		panel.style.display='';
    		document.getElementById(collapsableHeader + id).className = activecolor;
    		document.getElementById(collapsableArrow + id).src = document.getElementById('button_up_arrow_on').src;
    		if (arguments.length > 1 && alternate != null){
    			document.getElementById(collapsableHeader + id).className = altactivecolor;
    		}else{
    			document.getElementById(collapsableHeader + id).className = activecolor;
    		}
    	}
    }
	if (arguments.length == 3){
		applyCollapsableFocus(id, focusIn);
	}else{
		applyCollapsableFocus(id);
	}
}
function openCollapsablePanel(id){
	var panel = document.getElementById(collapsablePanel + id);
		panel.style.display='';
		document.getElementById(collapsableHeader + id).className = activecolor;
		document.getElementById(collapsableArrow + id).src = document.getElementById('button_up_arrow_on').src;
		if (arguments.length > 1 && alternate != null){
			document.getElementById(collapsableHeader + id).className = altactivecolor;
		}else{
			document.getElementById(collapsableHeader + id).className = activecolor;
		}
}
function applyCollapsableFocus(id, focusIn){
	//if collapsable panel is closed, try to set focus on the page alternate focus field
	if (document.getElementById(collapsablePanel + id)) {
		if ( document.getElementById(collapsablePanel + id).style.display == "none"){
			if (document.getElementById(alternateFocusField)){
				document.getElementById(alternateFocusField).focus();
			}
		}else{
			if (arguments.length == 2){
				if (document.getElementById(focusIn)){
					document.getElementById(focusIn).focus();
				}else{
					document.getElementById(collapsableArrow + id).focus();
				}
			}else{
				if (document.getElementById(focusField + id)) {
					document.getElementById(focusField + id).focus();
				}else{
					document.getElementById(collapsableArrow + id).focus();
				}
			}
		}
	}else{
		document.getElementById(alternateFocusField).focus();
	}
}

function highlightCollapsableHeader(id, alternate){
    highlightArrow(collapsableArrow + id);
    if (document.getElementById(collapsablePanel+id)){
        if (document.getElementById(collapsablePanel+id).style.display == 'none'){
            if (arguments.length == 2){
                document.getElementById(collapsableHeader + id).className = altactivecolor;
            }else{
                document.getElementById(collapsableHeader + id).className = activecolor;
            }
        }
    }
}
function unhighlightCollapsableHeader(id, alt){
    unhighlightArrow(collapsableArrow + id);
    if (document.getElementById(collapsablePanel+id)){
        if (document.getElementById(collapsablePanel+id).style.display == 'none'){
            if (arguments.length == 2){
                document.getElementById(collapsableHeader + id).className = altinactivecolor;
            }else{
                document.getElementById(collapsableHeader + id).className = inactivecolor;
            }
        }
    }
}

/* First time page is entered some of these button_down and button_up thingys 
 * have not been created, so need to check for 'existence' - mpetry, 3/2015
 */
function highlightArrow(id){
    if (document.getElementById(id)) {
        if (document.getElementById('button_down_arrow_off') &&
            document.getElementById(id).src == document.getElementById('button_down_arrow_off').src ){
             
            if (document.getElementById('button_down_arrow_on')) {
                document.getElementById(id).src = document.getElementById('button_down_arrow_on').src;
            }
        }
        else{
            if (document.getElementById('button_up_arrow_on')) {
                document.getElementById(id).src = document.getElementById('button_up_arrow_on').src;
            }
        }
    }
}
function unhighlightArrow(id){
    if (document.getElementById(id)) {
        if (document.getElementById('button_down_arrow_on') &&
            document.getElementById(id).src == document.getElementById('button_down_arrow_on').src ){
            
            if (document.getElementById('button_down_arrow_off')) {
                document.getElementById(id).src = document.getElementById('button_down_arrow_off').src;
            }
        }
        else{
            if (document.getElementById('button_up_arrow_off')) {
                document.getElementById(id).src = document.getElementById('button_up_arrow_off').src;
            }
        }
    }
}
//**********************************************************************************


/*********************************************************************************** 
 * Miscellanous functions
 ***********************************************************************************/

/* Given an array of radio dial elements, loop thru and determine
 * if it is checked/selected.  If so, make it's corresponding span or div
 * visable, else hide it.  this logic assumes that the span or div has 
 * an ID of element name plus "Div" appended to end.
 */
function setDisplayChoice(choices) {
	for (var i=0; i<choices.length; i++) {
		var element = document.getElementById(choices[i]);
		if (element && element.checked) {
			document.getElementById(choices[i] + "_Div").style.display='';
			if (document.getElementById(choices[i] + "_Div_2")){
				document.getElementById(choices[i] + "_Div_2").style.display='';
			}
			if (document.getElementById(choices[i] + "_Div_3")){
				document.getElementById(choices[i] + "_Div_3").style.display='';
			}
		}else {
			document.getElementById(choices[i] + "_Div").style.display='none';
			if (document.getElementById(choices[i] + "_Div_2")){
				document.getElementById(choices[i] + "_Div_2").style.display='none';
			}
			if (document.getElementById(choices[i] + "_Div_3")){
				document.getElementById(choices[i] + "_Div_3").style.display='none';
			}
		}
	}
} 

function setValue(obj, value){
	document.getElementById(obj).value=value;
}

function swapImage(id, alternateId){
	document.getElementById(id).src = document.getElementById(alternateId).src;
}

function openHelpResource (URL, resource, features) {
	if (arguments.length == 3) var helpFeatures=features;
	else var helpFeatures="'width=800,height=500,resizable=yes, left=0,top=100'";

	var currURL = document.location.toString();
	var urlArr = currURL.split('/');
	if (currURL.search(/localhost/) < 0) {
        if ((urlArr[3].search(/sandbox/) >= 0)     || 
            (urlArr[3].search(/development/) >= 0) ||
            (urlArr[3].search(/modeloffice/) >= 0) ||           
            (urlArr[3].search(/maintenance/) >= 0)) {
    			var loc= 'http://www.rateflood.com/' + urlArr[3] + '/';
        }else{
    		if (urlArr[3].search(/usaa/) >= 0) {
    			var loc= 'http://www.rateflood.com/ushelp/';
    		}else{
    			var loc= 'http://www.rateflood.com/arhelp/';
    		}
        }	
	}else{
		var loc= location.protocol + '//' + location.host + '/' + urlArr[3] + '/';
	}	
	var hsURL= loc + resource;
	if (URL.search(/\?/) >= 0) var helpURL=loc + URL + '&hsURL=' + hsURL;
	else var helpURL=loc + URL + '?hsURL=' + hsURL;

	var newWindow = open (helpURL, 'helpWindow', helpFeatures);
    newWindow.focus();
}

function openWindow (URL, target, features) {
	if (arguments.length == 3) 
		var newWindow = open(URL, target, features); 
	else
	if (arguments.length == 2) 
		var newWindow = open(URL, target); 
	else 
		var newWindow = open(URL); 
	
	newWindow.focus();
}


function checkMaxChars (textarea, max){
	if (textarea.value.length < max){
    	return true;
	} else {
		textarea.selected = false;
		return false;
	}
}

function checkRemainingChars (textarea, max, remainingFieldName){
	if (textarea!=null && remainingFieldName!=null) {
		remaining = max - textarea.value.length;
		remainingFieldName.innerHTML = remaining;
	}
}


/* Applies form field focus (cursor placement) on the field of choice according to the 3 field 
 * names passed in.  It checks each serially, and the first one that is found to exist will 
 * get focus.  This is to handle situations where fields are placed on a form conditionally.
 * 
 * USAGE NOTES:  Javascript does not perform function signature checks so this function can be
 * called with any number of paramaters.  Therefore, it can be used for setting focus on a single
 * field.  Furthermore, it offers advantages over the Struts Form Focus attribute in that it can
 * be used on non-Struts forms and it checks if the field exists before applying focus, thus 
 * preventing a Javascript error if not found.
 */
function applyFieldFocus(focusField1, focusField2, focusField3){
    if (document.getElementById(focusField1) && 
    	document.getElementById(focusField1).disabled != true && 
    	document.getElementById(focusField1).type != "hidden") {
		try {
	        document.getElementById(focusField1).focus();
	    }catch (e) {}
    }else
    if (document.getElementById(focusField2) && 
    	document.getElementById(focusField2).disabled != true && 
    	document.getElementById(focusField2).type != "hidden") {
		try {
	        document.getElementById(focusField2).focus();
	    }catch (e) {}
    }else
    if (document.getElementById(focusField3) && 
    	document.getElementById(focusField3).disabled != true && 
    	document.getElementById(focusField3).type != "hidden") {
		try {
	        document.getElementById(focusField3).focus();
	    }catch (e) {}
    }
}

function swapArrow(id){
    if (document.getElementById(id)) {
        if (document.getElementById('button_down_arrow_on') &&
            document.getElementById(id).src == document.getElementById('button_down_arrow_on').src ){
            if (document.getElementById('button_up_arrow_on')) {
                document.getElementById(id).src = document.getElementById('button_up_arrow_on').src;
            }
        }
        else{
            if (document.getElementById('button_down_arrow_on')) {
                document.getElementById(id).src = document.getElementById('button_down_arrow_on').src;
            }
        }
    }
}
	
function clearField(element,valueToClear) {
	if (element && element.value==valueToClear) {
		element.value = '';
	}
}

function isRadioSelected(choices) {
	if (!choices) return false;
	for(i=0; i<choices.length; i++) {
		theType = document.getElementById(choices[i]);
		if(theType.checked) return true;
	}
	return false;
}

function closePopupWindow() {
    popdiv = parent.document.getElementById('popupDiv');
	if (popdiv != null && popdiv.style.display != 'none') parent.closePopup();
	else window.close();
}

