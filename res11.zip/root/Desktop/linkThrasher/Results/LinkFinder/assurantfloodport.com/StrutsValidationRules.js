errorFlag = false;
messageDisplayId = 'display';
informationalMessageDisplayId = 'informationalMessageDisplay';
allMessages = "";
errorCount = 0;
erredProperties= new Array();
erredPropertiesCount = 0;

//company specific error message display handling
errorsHeader                = window.errorsHeaderCompany? errorsHeaderCompany : "<table class='systemmessagetable'><tr><td class='systemmessageheader' >Please correct the following errors.</td></tr>";
errorsMessagePrefix         = window.errorsMessagePrefixCompany? errorsMessagePrefixCompany : "<tr class='systemmessage'><td class='data'>";
errorsMessageIncludeCounter = window.errorsMessageIncludeCounterCompany? errorsMessageIncludeCounterCompany=="true" : true;
errorsMessageSuffix         = window.errorsMessageSuffixCompany? errorsMessageSuffixCompany : "</td></tr>";
errorsFooter                = window.errorsFooterCompany? errorsFooterCompany : "</table>";
errorsLabelImage            = window.errorsLabelImageCompany? errorsLabelImageCompany : "<IMG src='agencyweb/images/gfx_error.gif'>";
errorsFieldMessagePrefix    = window.errorsFieldMessagePrefixCompany? errorsFieldMessagePrefixCompany: "";
errorsFieldMessageSuffix    = window.errorsFieldMessageSuffixCompany? errorsFieldMessageSuffixCompany: "";


function resetDisplay(aForm){ 
	// alert("In reset"); //debug code
	var outMsg = document.getElementById(messageDisplayId);
	if(outMsg.innerHTML != "")
		outMsg.innerHTML = "";
	errorFlag = false; 
	allMessages = "";
	errorCount = 0; 
	for(var i = 0; i < erredProperties.length; i++)
	 {

	 	propName = erredProperties[i];
	 	try	{
	 		document.getElementById(propName).innerHTML = "";
			if (document.getElementById(propName + "Row")) {
				document.getElementById(propName + "Row").style.display = 'none';
			}
	 	}  catch (e) {}
	 	
	}
	erredProperties = new Array();
	erredPropertiesCount = 0;
	if (document.getElementById(informationalMessageDisplayId)) {
		document.getElementById(informationalMessageDisplayId).style.display = 'none';
	}
}
function testForErrors(aForm){ 
	// alert("In test: " + errorFlag); //debug code
   	if(errorFlag)	{
		setErrorMsg();
	}
	return !errorFlag; 
}

function setErrorMsg()	{
	messageDisplay = document.getElementById(messageDisplayId);
	messageDisplay.innerHTML = errorsHeader  + allMessages + errorsFooter;
	scroll(0,0);
}

function recordError(aMessage, anAttribute){ 
	errorFlag = true;
	//record the group messages for all errors shown together at top of page
	errorCount++;
	if (errorsMessageIncludeCounter) allMessages = allMessages + errorsMessagePrefix + errorCount + ". " + aMessage + errorsMessageSuffix;
	else 			                 allMessages = allMessages + errorsMessagePrefix + aMessage + errorsMessageSuffix;

	//set either the icon image next to the label or the complete message somewhere near the field.
   	attributeErrorName = getAttributeErrorName(anAttribute);
	if(errorsFieldMessagePrefix == "") setLabelErrorImage(attributeErrorName);
	else                               setFieldErrorMessage(attributeErrorName,aMessage);
}

function setLabelErrorImage(attributeErrorName) {
	erredElement = document.getElementById(attributeErrorName);
   	if(erredElement != null) {
   		erredProperties[erredPropertiesCount++] = attributeErrorName;
		erredElement.innerHTML = errorsLabelImage;
	}
}
           
function setFieldErrorMessage(attributeErrorName,aMessage) {
	attributeErrorFieldName = attributeErrorName + "Field";
	erredElement = document.getElementById(attributeErrorFieldName);
   	if(erredElement != null) {
   		erredProperties[erredPropertiesCount++] = attributeErrorFieldName;
		erredElement.innerHTML = errorsFieldMessagePrefix + aMessage + errorsFieldMessageSuffix;
		if (document.getElementById(attributeErrorFieldName + "Row")) {
			document.getElementById(attributeErrorFieldName + "Row").style.display = '';
		}
	}
}


//===========================================================================================================
 
function validateFloatRange(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oRange = new floatRange();
                for (x in oRange) {
                    var field = form[oRange[x][0]];
            		var noBypassField = oRange[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                    
                    if ((field.type == 'text' ||
                         field.type == 'textarea') &&
                        (field.value.length > 0)) {
                        
                        var aValue = trim(field.value);
                        //  remove ',' before checking digits
                        
                        var commaOutArray;
                       	if(aValue.charAt(0) == '$')
                       			commaOutArray =  aValue.substring(1, aValue.length).split(',');
                       	else
                       			commaOutArray =  aValue.split(',');
                        aValue = commaOutArray.join('');
						
                        
                        var fMin = parseFloat(oRange[x][2]("min"));
                        var fMax = parseFloat(oRange[x][2]("max"));
                        var fValue = parseFloat(aValue);
                        if (!(fValue >= fMin && fValue <= fMax)) {
                            if (i == 0) {
                                focusField = field;
                            }
                            recordError(oRange[x][1],oRange[x][0]);

                        }
                    }
                }
                return true;
}

function validateByte(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oByte = new ByteValidations();
                for (x in oByte) {
                	var field = form[oByte[x][0]];
            		var noBypassField = oByte[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                	
                    if (field.type == 'text' ||
                        field.type == 'textarea' ||
                        field.type == 'select-one' ||
						field.type == 'radio') {

						var value = '';
						// get field's value
						if (field.type == "select-one") {
							var si = field.selectedIndex;
							if (si >= 0) {
								value = field.options[si].value;
							}
						}
						else	{
							value = field.value;
						}
                        
                        if (value.length > 0) {

                            if (!isAllDigits(value)) {
                               
                                if (i == 0) {
                                    focusField = field;
                                }
                                recordError(oByte[x][1], oByte[x][0]);

                            } else {

	                            var iValue = parseInt(value);
	                            if (isNaN(iValue) || !(iValue >= -128 && iValue <= 127)) {
	                                if (i == 0) {
	                                    focusField = field;
	                                }
	                                recordError(oByte[x][1], oByte[x][0]);
	                               
	                            }
                            }
						}
	
                    }
                }
                return true;
}

function validateMaxLength(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oMaxLength = new maxlength();
                for (x in oMaxLength) {
                    var field = form[oMaxLength[x][0]];
            		var noBypassField = oMaxLength[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                    if(field)	{
 	                    if (field.type == 'text' ||
							field.type == 'hidden'  ||
	                        field.type == 'textarea') {
	                        
	                        var iMax = parseInt(oMaxLength[x][2]("maxlength"));
	                       
	                        if (field.value.length > iMax) {
	                        	if (i == 0) {
	                                focusField = field;
	                            }
	                            recordError(oMaxLength[x][1], oMaxLength[x][0]);
	
	                        }
	                    }
                    }
               }
                return true;
}

function validateRequired(form) {
                var isValid = true;
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oRequired = new required();
                for (x in oRequired) {
                	
					var field = form[oRequired[x][0]];
                	var value = getValueFrom(field);
            		var noBypassField = oRequired[x][2]("noBypassField");
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
 

        	    	if (trim(value).length == 0) {
	                        	recordError(oRequired[x][1], oRequired[x][0]);
    	  	        }
                }

                return true;
}
            
// Trim whitespace from left and right sides of s.
function trim(s) {
            	if(s == null)
            		return "";
            	else
                	return s.replace( /^\s*/, "" ).replace( /\s*$/, "" );
}

function validateInteger(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oInteger = new IntegerValidations();
                for (x in oInteger) {
                	var field = form[oInteger[x][0]];
                   	var noBypassField = oInteger[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                	
                    if(field)	{
	                    if (field.type == 'text' ||
	                        field.type == 'textarea' ||
	                        field.type == 'select-one' ||
	                        field.type == 'radio') {
	                        
	                        var value = '';
							// get field's value
							if (field.type == "select-one") {
								var si = field.selectedIndex;
							    if (si >= 0) {
								    value = field.options[si].value;
							    }
							} else {
								value = field.value;
							}
	                        
	                        if (value.length > 0) {
	                       		//  remove ',' before checking digits
	                       		value = trim(value);
	                       		var commaOutArray;
	                       		if(value.charAt(0) == '$')
									commaOutArray =  value.substring(1, value.length).split(',');
	                       		else	
	                       			commaOutArray =  value.split(',');
	                        	value = commaOutArray.join('');
	                        	
	                            if (!isAllDigits(value)) {
	                               
	                                if (i == 0) {
		                                focusField = field;
		                            }
							        recordError(oInteger[x][1], oInteger[x][0]);
							        
	                            } else {
		                            var iValue = parseInt(value);
		                            if (isNaN(iValue) || !(iValue >= -2147483648 && iValue <= 2147483647)) {
		                                if (i == 0) {
		                                    focusField = field;
		                                }
		                                recordError(oInteger[x][1], oInteger[x][0]);
		                               
		                           }
	                           }
	                       }
	                    }
                    }
                }
                return true;
            }

            function isAllDigits(argvalue) {
                argvalue = argvalue.toString();
                var validChars = "0123456789";
                var startFrom = 0;
                if (argvalue.substring(0, 2) == "0x") {
                   validChars = "0123456789abcdefABCDEF";
                   startFrom = 2;
                /*  Not sure what this was supposed to mean  DTG   
                } else if (argvalue.charAt(0) == "0") {
                   validChars = "01234567";
                   startFrom = 1;
                } else if (argvalue.charAt(0) == "-" ) {
                */
                } else if (argvalue.charAt(0) == "-" || argvalue.charAt(0) == "+" ) {
                    startFrom = 1;
                }
                
                for (var n = startFrom; n < argvalue.length; n++) {
                    if (validChars.indexOf(argvalue.substring(n, n+1)) == -1) return false;
                }
                return true;
            }
function validateRange(form) {
                return validateIntRange(form);
            }
function validateDate(form) {
               
               var focusField = null;
               var i = 0;
               var fields = new Array();
               oDate = new DateValidations();
               for (x in oDate) {
                   var value = form[oDate[x][0]].value;
	           		var noBypassField = oDate[x][2]("noBypassField");
	            	
	        	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
	        	    	if (noBypassField == null || noBypassField == "false"){
	        	    		continue;
	        	    	}
	        	    }

                   var datePattern = oDate[x][2]("datePatternStrict");
                   if ((form[oDate[x][0]].type == 'text' ||
                        form[oDate[x][0]].type == 'textarea') &&
                       (value.length > 0) &&
                       (datePattern != null && datePattern.length > 0)) {
                     var MONTH = "MM";
                     var DAY = "dd";
                     var YEAR = "yyyy";
                     var orderMonth = datePattern.indexOf(MONTH);
                     var orderDay = datePattern.indexOf(DAY);
                     var orderYear = datePattern.indexOf(YEAR);
                     if ((orderDay < orderYear && orderDay > orderMonth)) {
                         var iDelim1 = orderMonth + MONTH.length;
                         var iDelim2 = orderDay + DAY.length;
                         var delim1 = datePattern.substring(iDelim1, iDelim1 + 1);
                         var delim2 = datePattern.substring(iDelim2, iDelim2 + 1);
                         if (iDelim1 == orderDay && iDelim2 == orderYear) {
                            dateRegexp = new RegExp("^(\\d{2})(\\d{2})(\\d{4})$");
                         } else if (iDelim1 == orderDay) {
                            dateRegexp = new RegExp("^(\\d{2})(\\d{2})[" + delim2 + "](\\d{4})$");
                         } else if (iDelim2 == orderYear) {
                            dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})(\\d{4})$");
                         } else {
                            dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})[" + delim2 + "](\\d{4})$");
                         }
                         var matched = dateRegexp.exec(value);
                         if(matched != null) {
                            if (!isValidDate(matched[2], matched[1], matched[3])) {
                               if (i == 0) {
                                   focusField = form[oDate[x][0]];
                               }
                               recordError(oDate[x][1], oDate[x][0]);

                            }
                         } else {
                            if (i == 0) {
                                focusField = form[oDate[x][0]];
                            }
                            recordError(oDate[x][1], oDate[x][0]);

                         }
                     } else if ((orderMonth < orderYear && orderMonth > orderDay)) {
                         var iDelim1 = orderDay + DAY.length;
                         var iDelim2 = orderMonth + MONTH.length;
                         var delim1 = datePattern.substring(iDelim1, iDelim1 + 1);
                         var delim2 = datePattern.substring(iDelim2, iDelim2 + 1);
                         if (iDelim1 == orderMonth && iDelim2 == orderYear) {
                             dateRegexp = new RegExp("^(\\d{2})(\\d{2})(\\d{4})$");
                         } else if (iDelim1 == orderMonth) {
                             dateRegexp = new RegExp("^(\\d{2})(\\d{2})[" + delim2 + "](\\d{4})$");
                         } else if (iDelim2 == orderYear) {
                             dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})(\\d{4})$");
                         } else {
                             dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})[" + delim2 + "](\\d{4})$");
                         }
                         var matched = dateRegexp.exec(value);
                         if(matched != null) {
                             if (!isValidDate(matched[1], matched[2], matched[3])) {
                                 if (i == 0) {
                                     focusField = form[oDate[x][0]];
                                 }
                                 recordError(oDate[x][1], oDate[x][0]);
                              }
                         } else {
                             if (i == 0) {
                                 focusField = form[oDate[x][0]];
                             }
                             recordError(oDate[x][1], oDate[x][0]);
                         }
                     } else if ((orderMonth > orderYear && orderMonth < orderDay)) {
                         var iDelim1 = orderYear + YEAR.length;
                         var iDelim2 = orderMonth + MONTH.length;
                         var delim1 = datePattern.substring(iDelim1, iDelim1 + 1);
                         var delim2 = datePattern.substring(iDelim2, iDelim2 + 1);
                         if (iDelim1 == orderMonth && iDelim2 == orderDay) {
                             dateRegexp = new RegExp("^(\\d{4})(\\d{2})(\\d{2})$");
                         } else if (iDelim1 == orderMonth) {
                             dateRegexp = new RegExp("^(\\d{4})(\\d{2})[" + delim2 + "](\\d{2})$");
                         } else if (iDelim2 == orderDay) {
                             dateRegexp = new RegExp("^(\\d{4})[" + delim1 + "](\\d{2})(\\d{2})$");
                         } else {
                             dateRegexp = new RegExp("^(\\d{4})[" + delim1 + "](\\d{2})[" + delim2 + "](\\d{2})$");
                         }
                         var matched = dateRegexp.exec(value);
                         if(matched != null) {
                             if (!isValidDate(matched[3], matched[2], matched[1])) {
                                 if (i == 0) {
                                     focusField = form[oDate[x][0]];
                                  }
                                  recordError(oDate[x][1], oDate[x][0]);
                              }
                          } else {
                              if (i == 0) {
                                  focusField = form[oDate[x][0]];
                              }
                              recordError(oDate[x][1], oDate[x][0]);
                           }
                     } else {
                         if (i == 0) {
                             focusField = form[oDate[x][0]];
                         }
                         recordError(oDate[x][1], oDate[x][0]);
                     }
                  }
               }
                return true;
            }

	    function isValidDate(day, month, year) {
	        if (month < 1 || month > 12) {
                    return false;
                }
                if (day < 1 || day > 31) {
                    return false;
                }
                if ((month == 4 || month == 6 || month == 9 || month == 11) &&
                    (day == 31)) {
                    return false;
                }
                if (month == 2) {
                    var leap = (year % 4 == 0 &&
                               (year % 100 != 0 || year % 400 == 0));
                    if (day>29 || (day == 29 && !leap)) {
                        return false;
                    }
                }
                return true;
            }
            
function validateCreditCard(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oCreditCard = new creditCard();
                for (x in oCreditCard) {
            		var noBypassField = oCreditCard[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
               	
                    if ((form[oCreditCard[x][0]].type == 'text' ||
                         form[oCreditCard[x][0]].type == 'textarea') &&
                        (form[oCreditCard[x][0]].value.length > 0)) {
                        if (!luhnCheck(form[oCreditCard[x][0]].value)) {
                            if (i == 0) {
                                focusField = form[oCreditCard[x][0]];
                            }
                            recordError(oCreditCard[x][1], oCreditCard[x][0]);
                           
                        }
                    }
                }
                return true;
            }

            /**
             * Reference: http://www.ling.nwu.edu/~sburke/pub/luhn_lib.pl
             */
            function luhnCheck(cardNumber) {
                if (isLuhnNum(cardNumber)) {
                    var no_digit = cardNumber.length;
                    var oddoeven = no_digit & 1;
                    var sum = 0;
                    for (var count = 0; count < no_digit; count++) {
                        var digit = parseInt(cardNumber.charAt(count));
                        if (!((count & 1) ^ oddoeven)) {
                            digit *= 2;
                            if (digit > 9) digit -= 9;
                        };
                        sum += digit;
                    };
                    if (sum == 0) return false;
                    if (sum % 10 == 0) return true;
                };
                return false;
            }

            function isLuhnNum(argvalue) {
                argvalue = argvalue.toString();
                if (argvalue.length == 0) {
                    return false;
                }
                for (var n = 0; n < argvalue.length; n++) {
                    if ((argvalue.substring(n, n+1) < "0") ||
                        (argvalue.substring(n,n+1) > "9")) {
                        return false;
                    }
                }
                return true;
            }
function validateIntRange(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oRange = new intRange();
                for (x in oRange) {
            		var noBypassField = oRange[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }

                    var field = form[oRange[x][0]];
                    
                    if ((field.type == 'text' ||
                         field.type == 'textarea') &&
                        (field.value.length > 0)) {
                        var aValue = trim(field.value);
                        //  remove ',' before checking digits
                       
                        var commaOutArray;
                       	if(aValue.charAt(0) == '$')
                       			commaOutArray =  aValue.substring(1, aValue.length).split(',');
                       	else
                       			commaOutArray =  aValue.split(',');
                        aValue = commaOutArray.join('');
                        
                        
                        var iMin = parseInt(oRange[x][2]("min"));
                        var iMax = parseInt(oRange[x][2]("max"));
                        var iValue = parseInt(aValue);
                        if (!(iValue >= iMin && iValue <= iMax)) {
                            if (i == 0) {
                                focusField = field;
                            }
                            recordError(oRange[x][1], oRange[x][0]);

                        }
                    }
                }
                return true;
            }
function validateShort(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oShort = new ShortValidations();
                for (x in oShort) {
            		var noBypassField = oShort[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }

                	var field = form[oShort[x][0]];
                	
                    if (field.type == 'text' ||
                        field.type == 'textarea' ||
                        field.type == 'select-one' ||
                        field.type == 'radio') {
                        
                        var value = '';
						// get field's value
						if (field.type == "select-one") {
							var si = field.selectedIndex;
							if (si >= 0) {
								value = field.options[si].value;
							}
						} else {
							value = field.value;
						}
                        
                        if (value.length > 0) {
                            //  remove ',' before checking digits
                           
                        	var commaOutArray;
                        	if(value.charAt(0) == '$')
                       			commaOutArray =  value.substring(1, value.length).split(',');
                       		else
                       			commaOutArray =  value.split(',');
                        	value = commaOutArray.join('');
                        	
                            if (!isAllDigits(value)) {
                               
                                if (i == 0) {
                                    focusField = field;
                                }
                                recordError(oShort[x][1], oShort[x][0]);

                            } else {
                        
	                            var iValue = parseInt(value);
	                            if (isNaN(iValue) || !(iValue >= -32768 && iValue <= 32767)) {
	                                if (i == 0) {
	                                    focusField = field;
	                                }
	                                recordError(oShort[x][1], oShort[x][0]);
	                               
	                            }
	                       }
                       }
                    }
                }
                return true;
            }
function validateFloat(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oFloat = new FloatValidations();
                for (x in oFloat) {
                	var field = form[oFloat[x][0]];
            		var noBypassField = oFloat[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }

                	if(field)	{
                	
                    if (field.type == 'text' ||
                        field.type == 'textarea' ||
                        field.type == 'select-one' ||
                        field.type == 'radio') {
                        
                    	var value = '';
						// get field's value
						if (field.type == "select-one") {
							var si = field.selectedIndex;
							if (si >= 0) {
							    value = field.options[si].value;
							}
						} else {
							value = field.value;
						}
                        
                        if (value.length > 0) {
                        	//  remove ',' before checking digits
                        	value = trim(value);
                        	var commaOutArray;
                        	if(value.charAt(0) == '$')
                       			commaOutArray =  value.substring(1, value.length).split(',');
                       		else
                       			commaOutArray =  value.split(',');
                        	value = commaOutArray.join('');
                        	
                            // remove '.' before checking digits
                            var tempArray = value.split('.');
                            var joinedString= tempArray.join('');

                            if (!isAllDigits(joinedString)) {
                               
                                if (i == 0) {
                                    focusField = field;
                                }
                                recordError(oFloat[x][1], oFloat[x][0]);

                            } else {
	                            var iValue = parseFloat(value);
	                            if (isNaN(iValue)) {
	                                if (i == 0) {
	                                    focusField = field;
	                                }
	                                recordError(oFloat[x][1], oFloat[x][0]);
	                               
	                            }
                            }
                        }
                    }
                    } // end if field not null
                }
                return true;
            }
function validateEmail(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oEmail = new email();
                for (x in oEmail) {
                	var field = form[oEmail[x][0]];
            		var noBypassField = oEmail[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                	
                	if (field != null){
                	
	                    if ((field.type == 'text' || field.type == 'textarea') && (field.value.length > 0)) {
	                        if (!checkEmail(field.value)) {
	                            if (i == 0) {
	                                focusField = field;
	                            }
	                            recordError(oEmail[x][1], oEmail[x][0]);
	                        }
	                    }
                	}
                }
                return true;
            }

            /**
             * Reference: Sandeep V. Tamhankar (stamhankar@hotmail.com),
             * http://javascript.internet.com
             */
            function checkEmail(emailStr) {
               if (emailStr.length == 0) {
                   return true;
               }
               var emailPat=/^(.+)@(.+)$/;
               var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";
               var validChars="\[^\\s" + specialChars + "\]";
               var quotedUser="(\"[^\"]*\")";
               var ipDomainPat=/^(\d{1,3})[.](\d{1,3})[.](\d{1,3})[.](\d{1,3})$/;
               var atom=validChars + '+';
               var word="(" + atom + "|" + quotedUser + ")";
               var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
               var domainPat=new RegExp("^" + atom + "(\\." + atom + ")*$");
               var matchArray=emailStr.match(emailPat);
               if (matchArray == null) {
                   return false;
               }
               var user=matchArray[1];
               var domain=matchArray[2];
               if (user.match(userPat) == null) {
                   return false;
               }
               var IPArray = domain.match(ipDomainPat);
               if (IPArray != null) {
                   for (var i = 1; i <= 4; i++) {
                      if (IPArray[i] > 255) {
                         return false;
                      }
                   }
                   return true;
               }
               var domainArray=domain.match(domainPat);
               if (domainArray == null) {
                   return false;
               }
               var atomPat=new RegExp(atom,"g");
               var domArr=domain.match(atomPat);
               var len=domArr.length;
               if ((domArr[domArr.length-1].length < 2) ||
                   (domArr[domArr.length-1].length > 10)) {
                   return false;
               }
               if (len < 2) {
                   return false;
               }
               return true;
            }
function validateMask(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oMasked = new mask();
                for (x in oMasked) {
             		var noBypassField = oMasked[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                   
                   var field = form[oMasked[x][0]];
                   if(field)	{
	                   if ((field.type == 'text' || 
	                         field.type == 'textarea') && 
	                         (field.value.length > 0)) {
	                        
	                        if (!matchPattern(field.value, oMasked[x][2]("mask"))) {
	                            if (i == 0) {
	                                focusField = field;
	                            }
	                            recordError(oMasked[x][1], oMasked[x][0]);
	
	                        }
	                    }
                   }
                }
                
                return true;
            }

            function matchPattern(value, mask) {
               return mask.exec(value);
            }
function validateMinLength(form) {
                
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oMinLength = new minlength();
                for (x in oMinLength) {
            		var noBypassField = oMinLength[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                	
                    var field = form[oMinLength[x][0]];
                    if(field)	{
                    
	                    if (field.type == 'text' ||
	                        field.type == 'hidden' ||
	                        field.type == 'textarea') {
	                        
	                        var iMin = parseInt(oMinLength[x][2]("minlength"));
	                        if ((trim(field.value).length > 0) && (field.value.length < iMin)) {
	                            if (i == 0) {
	                                focusField = field;
	                            }
	                            recordError(oMinLength[x][1], oMinLength[x][0]);
	
	                        }
	                    }
                    }
                }
                return true;
            }
            
function vvalidateRequiredWhen(form) {
            var bValid = true;
            var focusField = null;
            var i = 0;
            var fields = new Array();
            var oRequiredWhen = new requiredWhen();
            for (x in oRequiredWhen) {
				var field = form[oRequiredWhen[x][0]];

				var noBypassField = oRequiredWhen[x][2]("noBypassField");
				var forceTestField = form[oRequiredWhen[x][2]("forceTestField")];
				var forceTestCondition = oRequiredWhen[x][2]("forceTestCondition");
				var forceTestField2 = form[oRequiredWhen[x][2]("forceTestField2")];
				var forceTestCondition2 = oRequiredWhen[x][2]("forceTestCondition2");
				var forceTestField3 = form[oRequiredWhen[x][2]("forceTestField3")];
				var forceTestCondition3 = oRequiredWhen[x][2]("forceTestCondition3");
				var testConditional = oRequiredWhen[x][2]("testConditional");
				
                if(testConditional != "AND")
                	testConditional = "OR";
                var testCount;
                var testCountString = oRequiredWhen[x][2]("testCount");
                if(testCountString == null)
                	testCount = 1;
                else
                	testCount = parseInt(testCountString);
                var doRequiredEdit = false;
                var continueCheckingTest = true;
                var testFieldValue;
                var testCondiiton;

                if (field == null){continue;}  
                
                //Bypass all validations except for the fields that have a variable of 'noBypassField' set to true
                if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
                	if (noBypassField == null || noBypassField == "false"){
                		continue;
                	}
                }
                if (  forceTestField == null || 
                	( 
                	  forceTestCondition == getValueFrom(forceTestField)	&&
                	  (forceTestField2 == null ||	forceTestCondition2 == getValueFrom(forceTestField2)) &&
                	  
                	  (forceTestField3 == null ||	forceTestCondition3 == getValueFrom(forceTestField3))	
               	  
                	)		
                   )	
                {
	                for(j= 1; j <= testCount; j++){ 		        
	                   if(continueCheckingTest)   {
	                    	testField = form[oRequiredWhen[x][2]("testField" + j)];
 	              	    	testCondiiton = oRequiredWhen[x][2]("testCondition" + j);
	  	             		testFieldValue = getValueFrom(testField);
// alert('In the loop - value:' + testFieldValue);					  
		 	                if (testFieldValue != null && testFieldValue != ""){
		 	                	try{//All of this checking is done to ensure that 0 is treated as a null for the NOTNULL/NULL testing
		 	                		var testFieldInt = parseInt(testFieldValue);
		 	                		var testFieldDate = new Date(testFieldValue);
		 	                		if(testFieldInt == 0){//LMR: Sencha Dates could parseInt to 0, so have to check for dates as well.
		 	                			if ( !(testFieldDate instanceof Date && !isNaN(testFieldDate.valueOf()))   ){
		 	                				testFieldValue = "0";//LMR: Only update the value to be a String 0 if parseInt = 0 and the value is not a date
		 	                			}
		 	                		}
		 	                	}catch(e) {}
		 	                	
		 	               		if(	(testFieldValue == testCondiiton) ||
		 	               			(testCondiiton == "NOTNULL" && testFieldValue !="0")  ||
		 	               			(testCondiiton == "NULL" && testFieldValue =="0")	){
		 	               			if(testConditional == "OR")	{
		 	               				continueCheckingTest = false;
 			               			}
 			               			doRequiredEdit = true;
 			               		}else{
		 	               			if(testConditional == "AND"){
 	                   					continueCheckingTest = false;
 	                   					doRequiredEdit = false;
			 	               		}
 			              		}
		 	               	}else{
		 	               		if(testCondiiton == "NULL"){
		 	               			if(testConditional == "OR"){
		 	               				continueCheckingTest = false;
 			               			}
 			               			doRequiredEdit = true;
 			               		}else{
		 	               			if(testConditional == "AND"){
 	                   					continueCheckingTest = false;
 	                   					doRequiredEdit = false;
			 	               		}
 			              		}
 			              }
 	                   }  // end if should continue checking 
        	        }  // end for looping test conditions
        	    }  // end if forceTestCondition true
                
        	    if(doRequiredEdit)	{
// alert('In the required Edit'); 
					var mustEqualValue = oRequiredWhen[x][2]("mustEqualValue");
        	    	if (mustEqualValue) {
	                    if (getValueFrom(field).toLowerCase() != mustEqualValue.toLowerCase()) {
                        	recordError(oRequiredWhen[x][1], oRequiredWhen[x][0]);
	    	  	        }
        	    	}else if (trim(getValueFrom(field)).length == 0) {
                       	recordError(oRequiredWhen[x][1], oRequiredWhen[x][0]);
    	  	        }
                }  // end if have to do required edit
           }	//  end for each edit
// alert('end of req when');
           return true;
        }	// end function
        
        
function validateRequiredWhenGeneric(form) {
            var bValid = true;
            var focusField = null;
            var i = 0;
            var fields = new Array();
            var oRequiredWhenGeneric = new requiredWhenGeneric();

            for (x in oRequiredWhenGeneric) {
				var field = form[oRequiredWhenGeneric[x][0]];
				var forceTestField = form[oRequiredWhenGeneric[x][2]("forceTestField")];
				var forceTestCondition = oRequiredWhenGeneric[x][2]("forceTestCondition");
				var noBypassField = oRequiredWhenGeneric[x][2]("noBypassField");

                if (field == null){continue;}  
                //Bypass all validations except for the fields that have a variable of 'noBypassField' set to true
			    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
			    	if (noBypassField == null || noBypassField == "false"){
			    		continue;
			    	}
			    }
				

				var testConditional = oRequiredWhenGeneric[x][2]("testConditional");
                if(testConditional != "AND")
                	testConditional = "OR";
                var testCount;
                var testCountString = oRequiredWhenGeneric[x][2]("testCount");
                if(testCountString == null)
                	testCount = 1;
                else
                	testCount = parseInt(testCountString);
                var doRequiredEdit = false;
                var continueCheckingTest = true;
                var testFieldValue;
                var testCondiiton;
                if(forceTestField == null ||
                	forceTestCondition == getValueFrom(forceTestField))	
                {
	                for(j= 1; j <= testCount; j++)
	                { 		        
	                   if(continueCheckingTest)   {
	                    	testField = form[oRequiredWhenGeneric[x][2]("testField" + j)];
 	              	    	testCondiiton = oRequiredWhenGeneric[x][2]("testCondition" + j);
	  	             		testFieldValue = getValueFrom(testField);
		 	                if (testFieldValue != null && testFieldValue != "")
		 	                {
		 	                	try	{
		 	                		var testFieldInt = parseInt(testFieldValue);
		 	                		if(testFieldInt == 0)
		 	                			testFieldValue = "0";
		 	                	}	catch(e) {}
		 	                	
		 	               		if(	(testFieldValue == testCondiiton) ||
		 	               			(testCondiiton == "NOTNULL" && testFieldValue !="0")  ||
		 	               			(testCondiiton == "NULL" && testFieldValue =="0")	)		{

		 	               			if(testConditional == "OR")	{
		 	               				continueCheckingTest = false;
 			               			}
 			               			doRequiredEdit = true;
 			               		}
 			               		else	{
		 	               			if(testConditional == "AND")	{
 	                   					continueCheckingTest = false;
 	                   					doRequiredEdit = false;
			 	               		}
 			              		}
 	               		
		 	               }	else	{
		 	               		if(testCondiiton == "NULL")		{

		 	               			if(testConditional == "OR")	{
		 	               				continueCheckingTest = false;
 			               			}
 			               			doRequiredEdit = true;
 			               		}
 			               		else	{
		 	               			if(testConditional == "AND")	{
 	                   					continueCheckingTest = false;
 	                   					doRequiredEdit = false;
			 	               		}
 			              		}
 			              }
                 	
 	                   }  // end if should continue checking 
        	        }  // end for looping test conditions
        	    }  // end if forceTestCondition true

        	    if(doRequiredEdit)	{
					var mustEqualValue = oRequiredWhenGeneric[x][2]("mustEqualValue");
        	    	if (mustEqualValue) {
	                    if (getValueFrom(field).toLowerCase() != mustEqualValue.toLowerCase()) {
                        	recordError(oRequiredWhenGeneric[x][1], oRequiredWhenGeneric[x][0]);
	    	  	        }
        	    	}else if (trim(getValueFrom(field)).length == 0) {
                       	recordError(oRequiredWhenGeneric[x][1], oRequiredWhenGeneric[x][0]);
    	  	        }
                }  // end if have to do required edit
           }	//  end for each edit
           return true;
        }	// end function
        
        
function validateRequiredGeneric(form) {
                var isValid = true;
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oRequiredGeneric = new requiredGeneric();
                for (x in oRequiredGeneric) {
					var field = form[oRequiredGeneric[x][0]];
                	var value = getValueFrom(field);
            		var noBypassField = oRequiredGeneric[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }
                	

        	    	if (trim(value).length == 0) {
	                        	recordError(oRequiredGeneric[x][1], oRequiredGeneric[x][0]);
    	  	        }
                }
                return true;
}
            
function validateBooleanTrueGeneric(form) {
                var isValid = true;
                var focusField = null;
                var i = 0;
                var fields = new Array();
                oBooleanTrue = new booleanTrueGeneric();
                for (x in oBooleanTrue) {
            		var noBypassField = oBooleanTrue[x][2]("noBypassField");
                	
            	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
            	    	if (noBypassField == null || noBypassField == "false"){
            	    		continue;
            	    	}
            	    }

					var field = form[oBooleanTrue[x][0]];
                	var value = getValueFrom(field);
                    if (value.toLowerCase() != 'true') {
                        recordError(oBooleanTrue[x][1], oBooleanTrue[x][0]);
    	  	        }
                }

                return true;
}
            
function validateDateRange(form) {
			/*
            var oDateRange = new dateRange();
 
            for (x in oDateRange) {
				var field = form[oDateRange[x][0]];
				if(field != null)	{
				  var dateString = field.value;
				  var compareField;
                  var minCompareField;
                  var maxCompareField;
				
				  try	{
				  var tDate = new Date(dateString);
				  compareField = (tDate.getFullYear()) * 10000;
                  compareField = compareField + ((tDate.getMonth()) * 100);
                  compareField = compareField + (tDate.getDate());
				  
				  var minDate = new Date(oDateRange[x][2]("mindate"));
				  minCompareField = (minDate.getFullYear()) * 10000;
                  minCompareField = minCompareField + ((minDate.getMonth()) * 100);
                  minCompareField = minCompareField + (minDate.getDate());

                  var maxDate = new Date(oDateRange[x][2]("maxdate"));
                  maxCompareField = (maxDate.getFullYear()) * 10000;
                  maxCompareField = maxCompareField + ((maxDate.getMonth()) * 100);
                  maxCompareField = maxCompareField + (maxDate.getDate());

				  if (compareField < minCompareField ||
				  	  compareField > maxCompareField	) {
	                 recordError(oDateRange[x][1], oDateRange[x][0]);
	              }
				  }  catch(e) {}
				}  // end if date exists

           }	//  end for each edit
			*/ 
                return true;
        }	// end function

   function validateDateSimple(form) {
   				/*
               oDateSimple = new dateSimple();
               for (x in oDateSimple) {
			
               	   var field = form[oDateSimple[x][0]];
               	   
               	  
               	   var val = null;
               	   if(field != null)	{
               	   	val = field.value
               	   }
               	    
                   if(val != null && val.length > 0)	{
							try {
								asDate = new Date(field.value);
                    			 if(	!((asDate.getDate()) > 0)  )
                    			 	recordError(oDateSimple[x][1], oDateSimple[x][0]); 
                  			}	catch (e2)	{
                   				recordError(oDateSimple[x][1], oDateSimple[x][0]);
                   	   	    }
                   
                   }
                   
               }  // end for loop
				*/
               return true;
            }
           
function getValueFrom(aField)	{
// alert('in getvaluefrom - type is:' + aField.type);
	try	{
    	if(aField.type == 'select-one')  {
        	var si = aField.selectedIndex;
			if(si != null)
				return aField.options[si].value;
			else
				return "";
		}

		if(aField.length != null)	{
// alert('length is not null');             	    	
			if(aField[0].type == 'radio')	{
// alert('is radio array');
				for(z = 0; z < aField.length; z++) {
// alert('in radio - value is:' + aField[z].value);
					if(aField[z].checked)	{
						return aField[z].value;
					}
				}  // end of loop
			} // end field type	
		} //if field length
 		       	    	
 		if(aField.type == 'radio')	{
// alert('is radio single');
   			if(aField.checked)
				return aField.value;
		}
		 		       	    	
 		if (aField.type == 'text' ||
			aField.type == 'textarea' ||
			aField.type == 'file' ||
			aField.type == 'hidden'  ||
			aField.type == 'password' ) {
				return aField.value;
		}
		
		if (aField.type == 'checkbox')  {
			if (aField.checked == true) 
				return "on";  
			else
				return "";
		}
             	    	
	} catch(e)  {}

	return "";
}

function validateNumeric(form) {
    var focusField = null;
    var i = 0;
    var fields = new Array();
    oInteger = new NumericValidations();
    for (x in oInteger) {
    	var field = form[oInteger[x][0]];
		var noBypassField = oInteger[x][2]("noBypassField");
    	
	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
	    	if (noBypassField == null || noBypassField == "false"){
	    		continue;
	    	}
	    }

    	
        if(field)	{
	        if (field.type == 'text' ||
	            field.type == 'textarea') {
	            var value = '';
				value = field.value;
	            if (value.length > 0) {
	           		value = trim(value);
	                if (!isAllDigits(value)) {
				        recordError(oInteger[x][1], oInteger[x][0]);
	                }
	           }
	        }
        }
    }
    return true;
}

function validateMustMatch(form) {
    
    var focusField = null;
    var i = 0;
    var fields = new Array();
    
    
    oMatch = new mustMatch();
    for (x in oMatch) {
    	var field = form[oMatch[x][0]];
    	var matchField = form[oMatch[x][2]("matchField")];
		var noBypassField = oMatch[x][2]("noBypassField");

		if (field == null){
			continue;
		}
		var fieldValue = getValueFrom(field);
		var matchValue = getValueFrom(matchField);
		
	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
	    	if (noBypassField == null || noBypassField == "false"){
	    		continue;
	    	}
	    }

	    if (fieldValue != matchValue){
	    	recordError(oMatch[x][1], oMatch[x][0]);
	    }
    }
    return true;
}
function validateNumericDate(form) {
    var focusField = null;
    var i = 0;
    var fields = new Array();
    oInteger = new numericDate();
    for (x in oInteger) {
    	var field = form[oInteger[x][0]];
		var noBypassField = oInteger[x][2]("noBypassField");
    	
	    if (document.getElementById("bypassPageValidation") && document.getElementById("bypassPageValidation").value == "true"){
	    	if (noBypassField == null || noBypassField == "false"){
	    		continue;
	    	}
	    }

    	
        if(field)	{
	        if (field.type == 'text') {
	            var value = '';
				value = field.value;
				value = value.replace(/\D/g,'');
	            if (value.length > 0) {
	           		value = trim(value);
	                if (!isAllDigits(value)) {
				        recordError(oInteger[x][1], oInteger[x][0]);
	                }
	           }
	        }
        }
    }
    return true;
}


        