var popupClass = null
var popupStyle =  'width: 96%; left: 10%; border-color: black; border-style: solid; border-width: 2px; background-color: white;';
var popupStyle2 =  'width: 800px; left: 80px; border-color: black; border-style: solid; border-width: 2px; background-color: white;';
var popupBackgroundClass = null;
var popupTop = '75px';
var popupHeight = '550px';
var popupPath = location.pathname;    
var popupPos = popupPath.indexOf("/",1);
var popupContext = popupPos != -1 ? popupPath.substr(0,popupPos+1) : "";


function closePopup(iGetFocus){
	if (window.postClosePopup != null){
		postClosePopup();
	}
    if (document.getElementById('popupDiv')) document.getElementById('popupDiv').style.display="none";
    if (document.getElementById('popupFrame')) document.getElementById('popupFrame').src = popupContext + "html/empty.html";//TODO this will probably cause a mixed mode message
    undoMakePageTransparent();
    var theElement = document.getElementById(iGetFocus);
    if (theElement != null) theElement.focus();
}
function openPopup(goToAddress, widthPix, heightPix, topPix, leftPix){
	if (arguments.length < 5) leftPix=null;
	if (arguments.length < 4) topPix=null;
	if (arguments.length < 3) heightPix=null;
	if (arguments.length < 2) widthPix=null;
	
	//alert (document.getElementById('interruptIframe').value.toString() + " , " + goToAddress);
	if ((!document.getElementById('interruptIframe') || document.getElementById('interruptIframe').value != 'true') ){
		if (window.preOpenPopup != null){
			preOpenPopup();
		} 
		makePageTransparent();
	
	    popdiv = document.getElementById('popupDiv');
	    popdiv.style.display="";
	    popframe = document.getElementById('popupFrame');
	    popframe.height    = heightPix!=null ? heightPix + 'px' : popupHeight; 
	    popdiv.style.width = widthPix!=null  ? widthPix + 'px' : '810px';
	    popdiv.style.left  = leftPix!=null   ? leftPix + 'px' : '80px';
	    if (topPix!=null) {
	    	if (top.document.documentElement) totalTop = topPix + top.document.documentElement.scrollTop;
	    	else totalTop = topPix;
	    	popdiv.style.top = totalTop + 'px';
	    }else {
	    	scroll(0,0);
	    	popdiv.style.top=popupTop;
	    }
	    if (goToAddress != "") popframe.src = goToAddress;
	}
}

function writePopup(){
    document.write('<span id="popupDiv"');
    if (popupClass != null) document.write( ' class="' + popupClass + '"');
    document.write( ' style="position: absolute; z-index:1; display: none; ' + popupStyle2 + '">');
    document.write('<iframe name="popupFrame" id="popupFrame" src="' + popupContext + 'html/empty.html" frameborder="0" marginwidth="5px" width="100%" height="' );
    document.write( popupHeight );
    document.write('"></iframe></span>');
}
function closePopup2(iGetFocus){
    parent.document.getElementById('popupDiv2').style.display="none";
    parent.document.getElementById('popupFrame2').src = popupContext + "html/empty.html";//TODO this will probably cause a mixed mode message
	undoMakePageTransparent();
    var theElement = document.getElementById(iGetFocus);
    if (theElement != null) theElement.focus();
}
function openPopup2(goToAddress){
	parent.scroll(0,0);
    popdiv2 = parent.document.getElementById('popupDiv2');
    popdiv2.style.display="";
    var totalTop = 8 + top.document.documentElement.scrollTop;
	popdiv2.style.top = totalTop + 'px';
    parent.document.getElementById('popupFrame2').src = goToAddress;
}

function writePopup2(){
    document.write('<div id="popupDiv2"');
    if (popupClass != null) document.write( ' class="' + popupClass + '"');
    document.write( ' style="position: absolute; display: none; ' + popupStyle2 + '">');
    document.write('<iframe id="popupFrame2" src="' + popupContext + 'html/empty.html" frameborder="yes" marginwidth="0px" width="100%" height="525px"></iframe></div>');
}

function closePopup3(iGetFocus){
	if (window.postClosePopup3 != null){
		postClosePopup3();
	}
    document.getElementById('popupDiv3').style.display="none";
    document.getElementById('popupFrame3').src = popupContext + "html/empty.html";
    var theElement = document.getElementById(iGetFocus);
    if (theElement != null) theElement.focus();
}
function openPopup3(goToAddress, widthPix, heightPix, topPix, leftPix){
	if (arguments.length < 5) leftPix=null;
	if (arguments.length < 4) topPix=null;
	if (arguments.length < 3) heightPix=null;
	if (arguments.length < 2) widthPix=null;
	
	if (window.preOpenPopup3 != null){
		preOpenPopup3();
	} 

    popdiv = document.getElementById('popupDiv3');
    popdiv.style.display="";
    popframe = document.getElementById('popupFrame3');
    popframe.height    = heightPix!=null ? heightPix + 'px' : '500px'; 
    popdiv.style.width = widthPix!=null  ? widthPix + 'px' : '800px';
    popdiv.style.left  = leftPix!=null   ? leftPix + 'px' : '80px';
    if (topPix!=null) {
    	if (top.document.documentElement) totalTop = topPix + top.document.documentElement.scrollTop;
    	else totalTop = topPix;
    	popdiv.style.top = totalTop + 'px';
    }else {
    	scroll(0,0);
    	popdiv.style.top='75px';
    }
    if (goToAddress!="") popframe.src = goToAddress;
}

function writePopup3(styleClass){
	if (arguments.length < 1) styleClass='popupStyleDefault';
    document.write('<span id="popupDiv3" class="' + styleClass + '" ' + 'style="position:absolute; z-index:1; display:none;">');
    document.write('<iframe id="popupFrame3" src="' + popupContext + 'html/empty.html" frameborder="1" marginwidth="5px" width="100%" height="550px"></iframe></span>');
}

function closeThisFrame() {
	if (parent.document.getElementById('data.iframeControl')) parent.document.getElementById('data.iframeControl').value='';
	if (parent.closeMe!=null) parent.closeMe(window);
	else parent.closePopup('');
	hideEmergencyCloseBox(); 
}

function updateOrcloseFrame() {
	if(window.submitAndDoUpdate != null){
		submitAndDoUpdate();
	}else{
		closeThisFrame();
	}
}

function makePageTransparent() {
	var transparentPanelDiv = document.getElementById("transparentPanelDiv");
	if (transparentPanelDiv) {
		var hw = getBrowserHeightWidth();
		transparentPanelDiv.className="transparentPanel";
		transparentPanelDiv.style.width = hw[1]; 
		transparentPanelDiv.style.height = hw[0]; 
		var transparentPanelIframe = document.getElementById("transparentPanelIframe");
		transparentPanelIframe.className="transparentPanel";
		transparentPanelIframe.width = hw[1]; 
		transparentPanelIframe.height = hw[0];
		transparentPanelDiv.style.display = ""; 
		document.body.onresize=makePageTransparent;
		if (window.makePageTransparentPostHandler) makePageTransparentPostHandler();
	}
}

function undoMakePageTransparent() {
	var transparentPanelDiv = document.getElementById("transparentPanelDiv");
	if (transparentPanelDiv) {
		transparentPanelDiv.className="";
		transparentPanelDiv.style.width = "1"; 
		transparentPanelDiv.style.height = "1"; 
		var transparentPanelIframe = document.getElementById("transparentPanelIframe");
		transparentPanelIframe.className="";
		transparentPanelIframe.width = "1";
		transparentPanelIframe.height = "1";
		transparentPanelDiv.style.display = "none"; 
		document.body.onresize=null;
		if (window.undoMakePageTransparentPostHandler) undoMakePageTransparentPostHandler();
	}
}

function showEmergencyCloseBox() {
	var popupDiv = parent.document.getElementById("popupDiv");
	var popupTop = popupDiv.style.posTop;
	var popupLeft = popupDiv.style.posLeft;
	var popupWidth = popupDiv.style.width;
	var popupHeight = new Number(parent.document.getElementById('popupFrame').height).valueOf();
	var emergencyCloseBoxDiv = parent.document.getElementById("emergencyCloseBoxDiv");
	emergencyCloseBoxDiv.style.position = "absolute"; 
	emergencyCloseBoxDiv.style.posTop = popupTop + popupHeight; 
	emergencyCloseBoxDiv.style.posLeft = popupLeft;
	parent.document.getElementById("emergencyCloseTable").style.width = popupWidth; 
	parent.document.getElementById("emergencyCloseBoxDiv").style.display = ""; 
}

function hideEmergencyCloseBox() {
	if (parent.document.getElementById("emergencyCloseBoxDiv")) {
		parent.document.getElementById("emergencyCloseBoxDiv").style.display = "none"; 
	}
}

function loadXML(xmlFile){
	var xmlDoc;
	if (window.ActiveXObject) 
    { 
    	   xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
           xmlDoc.async = false ;
           xmlDoc.load(xmlFile);
    }
	else
    if(document.implementation && document.implementation.createDocument) 
    { 
              var xmlhttp = new window.XMLHttpRequest();
              xmlhttp.open("GET",xmlFile,false);
              xmlhttp.send(null);
              xmlDoc = xmlhttp.responseXML.documentElement;

    }
    return xmlDoc;
}

function getBrowserURL(){
    var theURL = window.location.href;
    return theURL.substring(0, theURL.lastIndexOf("/") + 1);
}

function getBrowserHeightWidth() {
  var myWidth = 0, myHeight = 0;
  if( typeof( window.innerWidth ) == 'number' ) {
    //Non-IE
    myWidth = window.innerWidth;
    myHeight = window.innerHeight;
  } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
    //IE 6+ in 'standards compliant mode'
    myWidth = document.documentElement.clientWidth;
    myHeight = document.documentElement.clientHeight;
  } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
    //IE 4 compatible
    myWidth = document.body.clientWidth;
    myHeight = document.body.clientHeight;
  }
  if (document.body.scrollHeight && document.body.scrollHeight > myHeight) myHeight = document.body.scrollHeight;
  if (document.body.scrollWidth  && document.body.scrollWidth  > myWidth)  myWidth  = document.body.scrollWidth;
  return [myHeight,myWidth];
}

function getDocumentElementHeight(elem) {
    var h = 0;
    if(navigator.userAgent.indexOf("Chrome") == -1 || navigator.vendor.indexOf("Google")  == -1) {
          h = elem.offsetHeight;
    }else{
         if (elem.clientHeight > 0){
               return elem.clientHeight;
         }
          var i;
          var j;
          for (i = 0; i < elem.children.length; i++) { 
                for (j=0; j < elem.children[i].children.length; j++) {
                       h += getChildsHeight(elem.children[i].children[j]);
                }
          }
          h= h+ 250;         
    }
    return h;
}


function getChildsHeight(elem){
       var height = 0;
       var i=0;
       for (i=0; i < elem.children.length; i++) { 

       height = elem.children[i].clientHeight;
       if (height == 0){
          height = getChildsHeight(elem.children[i]);
       }
       }
       return height;
       }






//start code from milligansisland XML library
var transformLocation = '';
var transformXSL = '';
var transformXML = '';
var transformPost = null;

function loadXSLT(aLocation, anXSL, anXML, aPostMethod){
    transformLocation = aLocation;
    transformXSL = anXSL;
    transformXML = anXML;
    transformPost = aPostMethod;
    
    if(window.ActiveXObject ){ //ie 6-9
      xsldoc = new ActiveXObject("Microsoft.XMLDOM");
      xsldoc.ondataavailable = xslLoaded;
      xsldoc.load( transformXSL );
    }
    else if("ActiveXObject" in window){ //ie10,11 and maybe beyond
      xsldoc = new ActiveXObject("MSXML2.DOMDocument.6.0");
      xsldoc.ondataavailable = xslLoaded;
      xsldoc.load( transformXSL );
    }
    else if ( window.XSLTProcessor){// support Mozilla/Gecko based browsers
      xsldoc = document.implementation.createDocument("", "", null);
      var xmlhttp = new window.XMLHttpRequest();
      xmlhttp.open("GET",transformXSL,false);
      xmlhttp.send();
      xsldoc = xmlhttp.responseXML;
      xslLoaded();
     }
    else {
      //youch - can't process
    }
}

//used only in floodport - will need changing for IE11
function ajaxDocObject() {
	this.doc = null;
	if (window.XMLHttpRequest){// browser has native support for XMLHttpRequest object
		this.doc  = new XMLHttpRequest();
	}
	else if (window.ActiveXObject){// try XMLHTTP ActiveX (Internet Explorer) version
		this.doc  = new ActiveXObject("Microsoft.XMLHTTP");
	}
}
function ajaxCall(url, responseHandler, anAjaxDocObject){
	if (anAjaxDocObject==null) return;
	anAjaxDocObject.doc.onreadystatechange = responseHandler;
	anAjaxDocObject.doc.open("GET", url, true);
	anAjaxDocObject.doc.setRequestHeader("content-type","application/x-www-form-urlencoded");
	anAjaxDocObject.doc.send(null);
}    

function xslLoaded(){ getXML(transformXML, transformXSLT); }

function postXML(url, toSend, responseHandler){ openXML("POST", url, toSend, responseHandler); }

function getXML(url, responseHandler){ openXML("GET", url, null, responseHandler); }

function openXML(method, url, toSend, responseHandler){
    if (window.ActiveXObject) { //ie
        xmldoc = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else if (window.XMLHttpRequest){// browser has native support for XMLHttpRequest object
        xmldoc = new XMLHttpRequest();
    }
    //else if ("ActiveXObject" in window) { //ie10+
      //  xmldoc  = new ActiveXObject("MSXML2.DOMDocument");
    //}
    
    if(xmldoc){
        xmldoc.onreadystatechange = responseHandler;
        xmldoc.open(method, url, true);
        xmldoc.setRequestHeader("content-type","application/x-www-form-urlencoded");
        
        try {xmldoc.responseType = "msxml-document";} catch(e){}
        xmldoc.send(toSend);
    }
    else{
        alert('Your browser does not seem to support XMLHttpRequest.');
    }
}    
function transformXSLT(){
    if (xmldoc.readyState == 4){// Make sure the request is loaded (readyState = 4)
        if (xmldoc.status == 200){// Make sure the status is "OK"
            var swappableSection = document.getElementById(transformLocation);
            
            if (window.XSLTProcessor){// support Mozilla/Gecko based browsers
              var xsltProcessor = new XSLTProcessor();
              xsltProcessor.importStylesheet(xsldoc);
              var outputXHTML = xsltProcessor.transformToFragment(xmldoc.responseXML, document);
              swappableSection.innerHTML = "";
              swappableSection.appendChild(outputXHTML)
            }
            else if (window.ActiveXObject || "ActiveXObject" in window) {
              var outputXHTML = xmldoc.responseXML.transformNode(xsldoc);
              swappableSection.innerHTML = "";
              swappableSection.innerHTML = outputXHTML;
            }
            else {
                //no way to process this!
                alert("There was a problem process the XML response: " + xmldoc.statusText);
            }
            
            if (transformPost!=null)eval(transformPost);
        }else{
            alert("There was a problem retrieving the XML data:\n" + xmldoc.statusText);
        }
    }
}
//end milligansisland code

function autoResizeIFrame()
{
    // Get a reference to the frame element.
    var frame = document.getElementById("popupFrame");
    
    // Create the onload event.
    var load_function = function(){resizeIFrame();} 

    // If necessary, assign it the internet-explorer way
    if (frame.readyState) frame.onreadystatechange = 
        function() {if (frame.readyState=="complete") load_function();}

    // Otherwise assign it the normal way.
    else frame.onload = load_function;
}

function getParentContentWidth(){
	var width;
	//Getting content width using different approach for IE as document.body.scrollWidth
	//did not work with chrome and safari
	if(navigator.appName == 'Microsoft Internet Explorer'){
		width = document.body.scrollWidth;
	}else{
		var e = window, a = 'inner'; 
		if ( !( 'innerWidth' in window ) ) { 
			a = 'client'; e = document.documentElement || document.body; 
		}
		width = e[ a+'Width' ];
	}
	return width; 
}
function convertSpecialChars(aString, withEncode){
	if (aString == null){
		return;
	}
	if (withEncode == null ) withEncode = false;
	aString = aString.replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[\u2026]/g, "...");
	aString = aString.replace(/[\u00BC]/g, "1/4").replace(/[\u00BD]/g, "1/2").replace(/[\u00BE]/g, "3/4");
	if (withEncode) aString = encodeURIComponent(aString);
	aString = aString.replace(/'/g, "`");
    return aString;
}
function escapeSpecialChars(aString){
	if (aString == null){
		return;
	}
	aString = aString.replace(/[^a-zA-Z0-9\s.,&#@:()\/+*$%\\'-]/gi, '');
	aString = aString.replace(/'/g, "`");
    return aString;
}
