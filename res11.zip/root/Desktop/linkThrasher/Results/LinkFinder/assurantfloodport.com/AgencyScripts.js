/*********************************************************************************** 
 * 
 * JavaScript for supporting agency functions in web application
 * 
 ***********************************************************************************/

function requiresDisasterAssistanceFor(aDate){
    eff = null;
    if (document.getElementById(aDate)){
        eff = new Date(document.getElementById(aDate).value);
    }
    if (document.getElementById('effectiveAfterMay1') && eff != null ){
        var myDate= new Date();
        myDate.setFullYear(2008,04,01);
        myDate.setHours(00,00,00,00);
        if (eff<myDate){
            document.getElementById('effectiveAfterMay1').value= true;
        }else{
            document.getElementById('effectiveAfterMay1').value= false;
        }
    }
}

/* Left in for possible current usage somewhere.  Please avoid using below
 * function; instead, use above requiresDisasterAssistanceFor(aDate) -
 * this will conform better to IE11 and later.  Thanks.  1/2015
 */
function requiresDisasterAssistance(){
		eff = null;
		if (document.getElementById('model.effectiveDate')  ){
			eff = new Date(document.getElementById('model.effectiveDate').value);
		}
		if (document.getElementById('effectiveAfterMay1') && eff != null ){
	 		var myDate= new Date();
			myDate.setFullYear(2008,04,01);
			myDate.setHours(00,00,00,00);
			if (eff<myDate){
				document.getElementById('effectiveAfterMay1').value= true;
			}else{
				document.getElementById('effectiveAfterMay1').value= false;
			}
		}
}

/* 
 * Open JavaHelp in a new window.
 */
function openHelp (URL, features) {
	var resource = 'agencyweb/help/agencyHelp.hs';
	if (document.getElementById("userProfileAbbrev")) {
		var userProfile = document.getElementById("userProfileAbbrev").value;
		if (userProfile=="C" || userProfile=="J") resource = 'claimweb/help/claimsHelp.hs';
	}
	openHelpResource(URL, resource, features);
}

/* 
 * Get the selected row, reduce by 1 to get index, and set index on model.
 */
function setSelectedFinancial(){
	var theRow = document.getElementById("selectedRow").value;
	document.getElementById("selectFinancialBySequence").value = theRow;
	document.getElementById("nav").value = "next";
}

/* 
 * Get the selected row, reduce by 1 to get index, and set index on model.
 */
function selectRenewal(){
	var theRow = document.getElementById("selectedRow").value;
	theRow--;
	document.getElementById("selectRenewalOptionByIndex").value = theRow;
}

/* 
 * Discarding while in policy detail functions.
 */
function discard(id){
	document.location ="PolicyDetail.do?navigation=PolicyOverview&policyId=" + id; 
}

/* 
 * Used in AgencyValidationRules.js for Struts JavaScript validations to map a group of 
 * field elements to one error element that displays an error icon. 
 */
function getAttributeErrorName(attributeName)	{
			//  Attributes on DetailQuoteCusomter.jsp and DetailApplicationCustomer.jsp
			if(attributeName == "data.partyChooser.individualName.firstName"  ||
				attributeName == "data.partyChooser.individualName.middleInitial"	||
				attributeName == "data.partyChooser.individualName.lastName"  ||
				attributeName == "fullName")
					return "IndividualNameError";
					
			if(attributeName == "model.currentLossDetail.contact.name.firstName"  ||
				attributeName == "model.currentLossDetail.contact.name.lastName")
					return "ContactNameError";


			//  Attributes on DetailZoneRequestEdit.jsp
			if	(attributeName == "zoneRequest.user.user.userContacts.contactName"  	||
				 attributeName == "zoneRequest.user.user.userContacts.phoneAreaCode"	||
				 attributeName == "zoneRequest.user.user.userContacts.phonePrefix"  	||
				 attributeName == "zoneRequest.user.user.userContacts.phoneSuffix"		||
				 attributeName == "zoneRequest.user.user.userContacts.faxAreaCode"		||
				 attributeName == "zoneRequest.user.user.userContacts.faxPrefix"		||
				 attributeName == "zoneRequest.user.user.userContacts.faxSuffix"		||
				 attributeName == "zoneRequest.user.user.userContacts.emailAddress")
					return "zoneRequest.user.user.userContacts.editContactError";

			//  Attributes on DetailAgencyMaintenance.jsp
			if(attributeName == "model.userContacts.phoneAreaCode"  ||
				attributeName == "model.userContacts.phonePrefix"	||
				attributeName == "model.userContacts.phoneSuffix")
					return "model.userContacts.phoneNumberError";

			if(attributeName == "model.userContacts.faxAreaCode"  ||
				attributeName == "model.userContacts.faxPrefix"	||
				attributeName == "model.userContacts.faxSuffix")
					return "model.userContacts.faxNumberError";


			if(attributeName == "model.policy.insured.dayTimePhoneNumber.areaCode"  ||
				attributeName == "model.policy.insured.dayTimePhoneNumber.prefix"	||
				attributeName == "model.policy.insured.dayTimePhoneNumber.suffix")
					return "DayTimePhoneNumberError";

			//  Attributes on DetailApplicationCustomer.jsp
			if(attributeName == "model.policy.insured.eveningPhoneNumber.areaCode"  ||
				attributeName == "model.policy.insured.eveningPhoneNumber.prefix"	||
				attributeName == "model.policy.insured.eveningPhoneNumber.suffix")
					return "EveningPhoneNumberError";
			
			//  Attributes on DetailPropertyAddress.jsp
			if(attributeName == "data.propertyAddressChooser.deliveryAddress.city"  ||
				attributeName == "data.propertyAddressChooser.deliveryAddress.state"	||
				attributeName == "data.propertyAddressChooser.deliveryAddress.zip.zip"	||
				attributeName == "data.propertyAddressChooser.deliveryAddress.zip.zipPlus4")	
				    return "data.propertyAddressChooser.deliveryAddress.cityError";

			if(attributeName == "data.propertyAddressChooser.rangeAddress.city"  ||
				attributeName == "data.propertyAddressChooser.rangeAddress.state"	||
				attributeName == "data.propertyAddressChooser.rangeAddress.zip.zip"	||
				attributeName == "data.propertyAddressChooser.rangeAddress.zip.zipPlus4")	
				    return "data.propertyAddressChooser.rangeAddress.cityError";
			
			if(attributeName == "data.propertyAddressChooser.descriptionAddress.city"  ||
				attributeName == "data.propertyAddressChooser.descriptionAddress.state"	||
				attributeName == "data.propertyAddressChooser.descriptionAddress.zip.zip"	||
				attributeName == "data.propertyAddressChooser.descriptionAddress.zip.zipPlus4")	
				    return "data.propertyAddressChooser.descriptionAddress.cityError";
			
			//  Attributes on DetailPolicy.jsp
            if(attributeName == "buildingAndContents")  
                	return "model.selectedFinancialQQ.buildingCoverageError";
                    
            if(attributeName == "prpEligibility") 
			        return "model.policy.policyTypeError";

			//  Attributes on DetailCommunity.jsp
			if(attributeName == "0000.1.model.policy.risk.location.AACommunityByNumber"	||
				attributeName == "model.policy.risk.location.AACommunityByNumber")  						
					return "communityNumberError";
					
			if(attributeName == "0000.2.model.policy.risk.location.mapPanelInfo"	||
				attributeName == "model.policy.risk.location.mapPanelInfo")  						
					return "panelError";
			
			if(attributeName == "data.paymentChooser.creditCard.expirationMonth"  ||
				attributeName == "data.paymentChooser.creditCard.expirationYear")	
					return "data.paymentChooser.creditCard.expirationDateError";

			//  Attributes for DetailCertificate
			if(attributeName == "model.policy.risk.elevationAZoneV2.feetAboveBelowHAG"	||
				attributeName == "model.policy.risk.elevationAZoneV2.aboveBelow"	||  						
				attributeName == "model.policy.risk.elevationAOZoneV2.feetAboveBelowHAG"	|| 
				attributeName == "model.policy.risk.elevationAOZoneV2.aboveBelow") 
					return "model.policy.risk.elevation.feetAboveBelowHAGError";
			
			if(attributeName == "model.policy.risk.elevationAZoneV2.nextFloorFtAboveBelowHAG"	||
				attributeName == "model.policy.risk.elevationAZoneV2.nextFloorAboveBelow"	||
				attributeName == "model.policy.risk.elevationAOZoneV2.nextFloorFtAboveBelowHAG"	||
				attributeName == "model.policy.risk.elevationAOZoneV2.aboveBelow")
					return "model.policy.risk.elevation.nextFloorFtAboveBelowHAGError";
					
			if(attributeName == "model.policy.risk.elevationAZoneV2.MEFtAboveBelowHAG"	||
				attributeName == "model.policy.risk.elevationAZoneV2.MEAboveBelow"	||
				attributeName == "model.policy.risk.elevationAOZoneV2.MEFtAboveBelowHAG"	||
				attributeName == "model.policy.risk.elevationAOZoneV2.MEAboveBelow")
					return "model.policy.risk.elevation.mEFtAboveBelowHAGError";
					
			if(attributeName == "model.policy.risk.elevationAZoneV2.garageAboveBelowHAG"	||
				attributeName == "model.policy.risk.elevationAZoneV2.garageAboveBelow"	||
				attributeName == "model.policy.risk.elevationAOZoneV2.garageAboveBelowHAG"	||
				attributeName == "model.policy.risk.elevationAOZoneV2.garageAboveBelow")
					return "model.policy.risk.elevation.garageAboveBelowHAGError";
					
			//  Attribute on DetailElevatedBuilding and DetailGarage and DetailBasement
			if(attributeName == "model.policy.risk.MAEProxy.enclosureError"	||
				attributeName == "model.policy.risk.MAEProxy.basementError" ||
				attributeName == "model.policy.risk.MAEProxy.garageError")  						
					return "hasMachineryError";
			
			//  Attributes for DetailGarage
			if(attributeName == "model.policy.risk.garageLength"	||
				attributeName == "model.policy.risk.garageWidth")  						
					return "model.policy.risk.garageSquareFeetError";

			//  Attributes for payment
			if(attributeName == "checkNumber")
				return "data.paymentChooser.check.checkNumberError";
			if(attributeName == "number" )
				return "data.paymentChooser.creditCard.numberForViewError";
			if(attributeName == "cardSecurityCode" )
				return "data.paymentChooser.creditCard.cardSecurityCodeError";
			if(attributeName =="expirationDate")
				return "data.paymentChooser.creditCard.expirationDateError";
			if(attributeName =="cardHolderName")
				return "data.paymentChooser.creditCard.cardholderNameError";
			if(attributeName =="agentId")
				return "data.model.permissionBroker.AAAgentUserIdError";
			if(attributeName =="previousDecExpirationDate")
				return "data.model.previousDecExpirationDateError";
			if(attributeName =="payerName")
				return "data.paymentChooser.eft.payerNameError";
			if(attributeName =="bankABANumber")
				return "data.paymentChooser.eft.bankABANumberError";
			if(attributeName =="bankAccountNumber")
				return "data.paymentChooser.eft.bankAccountNumberError";
			if(attributeName =="eftDisclaimerRead")
				return "eftDisclaimerReadError";
			if(attributeName =="creditCardProvisionRead")
				return "ccProvisionViewError";
			if(attributeName =="submitAsRollover")
				return "data.model.submitAsRolloverError";
						
											
			if(attributeName =="esignDisclaimerRead")
				return "data.model.esignDisclaimerReadError";
			if(attributeName =="emailAddress" )
				return "data.model.emailAddressError";

			if(attributeName =="refundPayTo")
				return "data.model.refundPayDescriptionError";
			if(attributeName =="refundMailTo")
				return "data.model.refundRecipientDescriptionError";
											
			//  Attributes for User Profile Admin
			if(attributeName == "model.firstName" || attributeName == "model.lastName")
				return "model.nameError";
			if(attributeName == "model.phoneAreaCode" || attributeName == "model.phonePrefix" || attributeName == "model.phoneSuffix")
				return "model.phoneNumberError";

			//  Attributes for claims
			if(attributeName == "model.currentLossDetail.contact.mailingAddress.city"  ||
			   attributeName == "model.currentLossDetail.contact.mailingAddress.state"	||
			   attributeName == "model.currentLossDetail.contact.mailingAddress.zip.zip"	||
			   attributeName == "model.currentLossDetail.contact.mailingAddress.zip.zipPlus4")	
				    return "model.currentLossDetail.contact.mailingAddress.cityStateZipError";

			return attributeName + "Error";
}
