
$(document).ready(function (){	
	
    setTimeout(function(){ 
		//$('.panel').hide();
		//$('.btnSeta').after("<span class='txtSeta'>Clique na seta para visualizar os filtros</span>");
		
		$('.btnSeta').click( function(){
			$('.panel').slideToggle('slow');
			$('.btnSeta').toggleClass('btnSetaAtivo');
			
			var txt = $('.txtSeta');
			var isVisible = txt.is(':visible');
			
			if(isVisible === true){
				$('.txtSeta').hide();
			} else {
				setTimeout(function(){
					$('.txtSeta').show();
				},500);
			}

		});
	}, 1000);
	
});