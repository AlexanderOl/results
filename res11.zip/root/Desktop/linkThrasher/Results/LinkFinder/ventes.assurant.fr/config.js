
//Octopus
window.config = {

  site:{
    apiUrl: 'https://api.ventes.assurant.fr/ms1/',
    apiVersion: '1',
  },
  core:{
    cmsApiUrl:  'https://api.ventes.assurant.fr/ms1/api/v1',
    clientCMS: 'b680cde7-487e-4acf-ba1a-59113c791834',
    parentCMS: 'af2f760f-e66e-48a8-a7d1-34c0aab2a3b1',
    homeComponents: 'Global,Login,DemandsAndNeedsQuestions,CustomerInformation,EligibilityQuestions,PaymentInformation,CreditCardInformation,IBANInformation,ProductSearchResults,SearchPlans,ReviewPlanDetail,Confirmation,Sales,Signature,FooterLayout',
    language: 'fr-FR',
    program: 'MS1',
    systemRole: '',
    production: 'false',
    resourceClient: 'MS1',
  },
  aul:{
    aulUrl: 'https://maconnexion.assurant.fr/aulv1/',
    aulApiUrl: 'https://api.maconnexion.assurant.fr/aulv1/',
    aulClient: 'MS1',
    aulApplicationName: 'GSP-MS1',
    bypassLogin: 'false',
  },
  oktaSettings:{
    oktaPrefix: 'AUL__MS1',  
    oktaBaseUrl: 'https://assurant-eu.okta-emea.com',
    oktaClientId: '0oa3x0uhmk9AvDUx00i7',
    oktaInternalEndPoint: 'https://id.assurant.com',
    oktaIssuer: 'https://assurant-eu.okta-emea.com/oauth2/v1/',
    oktaAuthIssuer: 'https://assurant-eu.okta-emea.com/oauth2/aus3x0unsxOvE08RT0i7',
    oktaAuthorizeUrl: 'https://assurant-eu.okta-emea.com/oauth2/aus3x0unsxOvE08RT0i7/v1/authorize',
  },
  googleAnalytics:{
    gtmId: 'GTM-M6RJX3C',
  },
  sitefinitySettings:{
    resourceEditMode: 'false',
  },
  misc:{
    version: '1.2.14-MS1',
  }
 
};