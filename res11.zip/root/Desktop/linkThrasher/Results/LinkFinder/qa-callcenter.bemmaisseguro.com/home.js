! function() {
  var a, c = {},
    s = {},
    e = {};
  c.init = function(e) {
    switch ($(".quick-quotation .quick-quotation-steps .list").hide(), $(e).fadeIn("fast"), $(".quick-quotation .products button").removeClass("active"), $(".quick-quotation-steps").empty(), $(".quick-quotation-steps").append("<div class='preloader'><span></span><div class='overlay'></div></div>"), c.showPreloader(), $(".results-content .theft-only-wrapper").hide(), a && (a.abort(), a = null), $(".coverage .icons li").hide(), e) {
      case ".quick-quotation-cellphone":
        $(".results-header .text").text("Seguro Celular a partir de:"), $(".quick-quotation .products .cellphone").addClass("active"), $(".results-content .theft-only-wrapper").show(), TweenLite.to(".quick-quotation", .5, {
          height: 355,
          ease: Expo.easeOut
        }), $(".coverage .repairs").show(), null != $("#coverages") && -1 < $("#coverages").val().indexOf("Theft") && $(".coverage .theft").show(), $(".coverage .liquid-spill").show(), s.isCurrentPartner("tim") && ($(".results-header .icon-wrapper").remove(), $(".results-header .text").text("TIM Protect Seguro Aparelho"), $(".results-header .text").css("border", "none"));
        var o = "",
          t = "",
          r = "";
        null != $("#cp-productCode") && null != $("#cp-productCode") && null != $("#cp-productCode").val() && null != $("#cp-productCode").val() && "" != $("#cp-productCode").val() && (o = $("#cp-productCode").val()), null != $("#cp-gadgetMarcaNome") && null != $("#cp-gadgetMarcaNome") && null != $("#cp-gadgetMarcaNome").val() && null != $("#cp-gadgetMarcaNome").val() && "" != $("#cp-gadgetMarcaNome").val() && (t = $("#cp-gadgetMarcaNome").val()), null != $("#cp-filtro") && null != $("#cp-filtro") && null != $("#cp-filtro").val() && null != $("#cp-filtro").val() && "" != $("#cp-filtro").val() && (r = $("#cp-filtro").val()), a = $.ajax({
          url: "/seguro-celular/cotacao-rapida-v2?device=" + o,
          success: function(e) {
            $(".quick-quotation-steps").append($(e)), BMS.QQCellphone.restart(o, t, r), c.hidePreloader()
          },
          method: "GET"
        });
        break;
      case ".quick-quotation-electronics":
        $(".results-header .text").text("Seguro Eletrônicos a partir de:"), $(".quick-quotation .products .electronics").addClass("active"), TweenLite.to(".quick-quotation", .5, {
          height: 355,
          ease: Expo.easeOut
        }), $(".coverage .repairs").show(), null != $("#coverages") && -1 < $("#coverages").val().indexOf("Thieft") && $(".coverage .theft").show(), $(".coverage .liquid-spill").show(), a = $.ajax({
          url: "/seguro-eletronico/cotacao-rapida-v2",
          success: function(e) {
            $(".quick-quotation-steps").append($(e)), BMS.QQElectronics.restart(), c.hidePreloader()
          },
          method: "GET"
        }), a = $.ajax({
          url: "/seguro-eletronico/VerificaCoberturas",
          success: function(e) {
            $("#coverages").val(e), -1 < e.indexOf("Thieft") ? $(".coverage .theft").show() : $(".coverage .theft").hide()
          },
          method: "GET"
        })
    }
  }, c.showPreloader = function() {
    $(".preloader").show(), TweenLite.to(".preloader", .5, {
      autoAlpha: 1,
      top: 0,
      ease: Sine.easeOut
    })
  }, c.hidePreloader = function() {
    TweenLite.to(".preloader", .5, {
      autoAlpha: 0,
      top: 0,
      ease: Expo.easeOut
    })
  }, s.show = function(e) {
    var o, t;
    switch ($(".other-services .items button").removeClass("active"), e) {
      case "cellphone":
        o = "Seguro para Celular", t = "Cobertura completa para seu celular", $(".other-services .items .cell").addClass("active"), $(".other-services .icon-wrapper").empty(), $(".other-services .icon-wrapper").append('<div class="icon icon-cellphone-square-white"></div>'), $(".other-services .btn-mosaic").attr("href", "/seguro-celular/cotacao"), $(".other-services").css("background-image", "url('public/img/home/bg-os-cellphone.jpg')");
        break;
      case "electronics":
        o = "Seguro Eletrônico", t = "Cobertura completa para seu eletrônico", $(".other-services .items .electronics").addClass("active"), $(".other-services .icon-wrapper").empty(), $(".other-services .icon-wrapper").append('<div class="icon icon-electronic-square-white"></div>'), $(".other-services .btn-mosaic").attr("href", "/seguro-eletronico/cotacao"), $(".other-services").css("background-image", "url('public/img/home/bg-os-electronic.jpg')");
        break;
      case "auto":
        o = "Seguro Auto", t = "Cobertura completa para seu carro", $(".other-services .items .auto").addClass("active"), $(".other-services .icon-wrapper").empty(), $(".other-services .icon-wrapper").append('<div class="icon icon-auto-square-white"></div>'), $(".other-services .btn-mosaic").attr("href", "/seguro-auto/cotacao"), $(".other-services").css("background-image", "url('public/img/home/bg-os-auto.jpg')");
        break;
      case "travel":
        o = "Seguro Viagem", t = "Cobertura completa para sua viagem", $(".other-services .items .travel").addClass("active"), $(".other-services .icon-wrapper").empty(), $(".other-services .icon-wrapper").append('<div class="icon icon-travel-square-white"></div>'), $(".other-services .btn-mosaic").attr("href", "/seguro-viagem/cotacao"), $(".other-services").css("background-image", "url('public/img/home/bg-os-travel2.jpg')")
    }
    $(".other-services .text h2").text(o), $(".other-services .text p").text(t)
  }, s.isCurrentPartner = function(e) {
    return -1 != window.top.location.href.toString().indexOf(e)
  }, e.show = function(e, o) {
    var o = null != o && o,
      t = $("#error-lightbox");
    t.show(), o ? t.find("p").text("") : t.find("p").text("Ocorreu um erro"), t.find(".message").text(e), t.find(".close-btn").bind("click", function() {
      t.hide()
    })
  }, window.Lightbox = e, window.qq = c, window.otherServices = s
}();
