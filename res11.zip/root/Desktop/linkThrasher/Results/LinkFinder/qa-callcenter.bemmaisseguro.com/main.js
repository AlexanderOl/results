var _currentModal;

function showModal(t) {
  _currentModal = t, $(t).fadeIn(), $(t).bind("click", hideCurrentModal), $(window).bind("keydown", hideCurrentModalByKey)
}

function hideCurrentModal() {
  var t = $(_currentModal);
  t.fadeOut(), t.unbind("click", hideCurrentModal), $(window).unbind("keydown", hideCurrentModalByKey)
}

function hideCurrentModalByKey(t) {
  27 == t.keyCode && _currentModal && hideCurrentModal()
}

function hideModal(t) {
  $(t).unbind("click"), $(t).fadeOut()
}! function() {
  function t() {}
  for (var e, n = ["assert", "clear", "count", "debug", "dir", "dirxml", "error", "exception", "group", "groupCollapsed", "groupEnd", "info", "log", "markTimeline", "profile", "profileEnd", "table", "time", "timeEnd", "timeline", "timelineEnd", "timeStamp", "trace", "warn"], i = n.length, o = window.console = window.console || {}; i--;) o[e = n[i]] || (o[e] = t)
}(),
function(r) {
  function n(o, m, v) {
    var i, g = this,
      y = (o = r(o), m = "function" == typeof m ? m(o.val(), void 0, o, v) : m, g.init = function() {
        v = v || {}, g.byPassKeys = [9, 16, 17, 18, 36, 37, 38, 39, 40, 91], g.translation = {
          0: {
            pattern: /\d/
          },
          9: {
            pattern: /\d/,
            optional: !0
          },
          "#": {
            pattern: /\d/,
            recursive: !0
          },
          A: {
            pattern: /[a-zA-Z0-9]/
          },
          S: {
            pattern: /[a-zA-Z]/
          }
        }, g.translation = r.extend({}, g.translation, v.translation), g = r.extend(!0, {}, g, v), o.each(function() {
          !1 !== v.maxlength && o.attr("maxlength", m.length), o.attr("autocomplete", "off"), y.destroyEvents(), y.events(), y.val(y.getMasked())
        })
      }, {
        getCaret: function() {
          var t = 0,
            e = o.get(0),
            n = document.selection,
            i = e.selectionStart;
          return n && -1 === navigator.appVersion.indexOf("MSIE 10") ? (e.focus(), (t = n.createRange()).moveStart("character", -e.value.length), t = t.text.length) : !i && "0" !== i || (t = i), t
        },
        setCaret: function(t) {
          var e = o.get(0);
          e.setSelectionRange ? (e.focus(), e.setSelectionRange(t, t)) : e.createTextRange && ((e = e.createTextRange()).collapse(!0), e.moveEnd("character", t), e.moveStart("character", t), e.select())
        },
        events: function() {
          o.on("keydown.mask", function() {
            i = y.val()
          }), o.on("keyup.mask", y.behaviour), o.on("paste.mask", function() {
            setTimeout(function() {
              o.keydown().keyup()
            }, 100)
          })
        },
        destroyEvents: function() {
          o.off("keydown.mask keyup.mask paste.mask")
        },
        val: function(t) {
          var e = "input" === o.get(0).tagName.toLowerCase();
          return 0 < arguments.length ? e ? o.val(t) : o.text(t) : e ? o.val() : o.text()
        },
        behaviour: function(t) {
          var e, n;
          if (t = t || window.event, -1 === r.inArray(t.keyCode || t.which, g.byPassKeys)) return (n = y.getCaret()) < y.val().length && (e = !0), y.val(y.getMasked()), e && y.setCaret(n), y.callbacks(t)
        },
        getMasked: function(t) {
          for (var e, n = [], i = y.val(), o = 0, r = m.length, s = 0, a = i.length, l = 1, c = "push", u = -1, d = v.reverse ? (c = "unshift", l = -1, e = 0, o = r - 1, s = a - 1, function() {
              return -1 < o && -1 < s
            }) : (e = r - 1, function() {
              return o < r && s < a
            }); d();) {
            var h = m.charAt(o),
              f = i.charAt(s),
              p = g.translation[h];
            p ? (f.match(p.pattern) ? (n[c](f), p.recursive && (-1 === u ? u = o : o === e && (o = u - l), e === u && (o -= l)), o += l) : p.optional && (o += l, s -= l), s += l) : (t || n[c](h), f === h && (s += l), o += l)
          }
          return t = m.charAt(e), r !== a + 1 || g.translation[t] || n.push(t), n.join("")
        },
        callbacks: function(t) {
          var e = y.val(),
            n = y.val() !== i;
          !0 == n && "function" == typeof v.onChange && v.onChange(e, t, o, v), !0 == n && "function" == typeof v.onKeyPress && v.onKeyPress(e, t, o, v), "function" == typeof v.onComplete && e.length === m.length && v.onComplete(e, t, o, v)
        }
      });
    g.remove = function() {
      y.destroyEvents(), y.val(g.getCleanVal()).removeAttr("maxlength")
    }, g.getCleanVal = function() {
      return y.getMasked(!0)
    }, g.init()
  }
  r.fn.mask = function(t, e) {
    return this.each(function() {
      r(this).data("mask", new n(this, t, e))
    })
  }, r.fn.unmask = function() {
    return this.each(function() {
      try {
        r(this).data("mask").remove()
      } catch (t) {}
    })
  }, r.fn.cleanVal = function() {
    return r(this).data("mask").getCleanVal()
  }, r("*[data-mask]").each(function() {
    var t = r(this),
      e = {};
    "true" === t.attr("data-mask-reverse") && (e.reverse = !0), "false" === t.attr("data-mask-maxlength") && (e.maxlength = !1), t.mask(t.attr("data-mask"), e)
  })
}(window.jQuery || window.Zepto), $(".trigger-insurance").click(function(t) {
    t.preventDefault(), $("#seguro").fadeIn(300)
  }), $(".cancel-policy").click(function(t) {
    t.preventDefault(), $("#cancelar-seguro").fadeIn(300)
  }), $(".btn-close-mobile").click(function() {
    $("#seguro,#cancelar-seguro").fadeOut(300)
  }),
  function() {
    $(".products-info");
    var n = $(".products-info .justifyed-list li"),
      i = $("ul.content-panel"),
      o = $(".products-info button"),
      t = $(".square-arrow-up"),
      r = $(".products-info .justifyed-list .icon"),
      e = {};
    o.click(function() {
      var t = $(this).parents("li"),
        e = (n.css("background", "#577415"), t.css("background", "#88BA14"), t.find(".icon")),
        e = (r.removeClass("active"), e.addClass("active"), o.show(), $(this).hide(), $(".square-arrow-up").hide(), t.find(".square-arrow-up").show(), $(this).data("panel"));
      i.find(".hidden-line").hide(), i.find("#line-" + e).show(), i.slideDown(300)
    }), t.click(function() {
      i.find(".hidden-line").slideUp(300), i.hide(), $(this).hide(), o.show(), r.removeClass("active"), n.css("background", "#577415")
    }), $("#contact-form").submit(function() {
      return $.ajax({
        url: $(this).attr("action"),
        data: $(this).serializeArray(),
        type: "post",
        dataType: "json",
        success: function(t) {
          window.Lightbox.show("Mensagem enviada com sucesso.", !0), e.hideForm()
        },
        error: function(t) {
          window.Lightbox.show("Ocorreu um erro tente novamente mais tarde.", !0), e.hideForm()
        }
      }), !1
    }), e.showForm = function() {
      $(".bg-1 .hide-button").fadeOut(200), setTimeout(function() {
        $(".bg-1 form").fadeIn(200)
      }, 200)
    }, e.hideForm = function() {
      $(".bg-1 form").fadeOut(200), $(".bg-1 form input").val(""), setTimeout(function() {
        $(".bg-1 .hide-button").fadeIn(200)
      }, 200)
    }, window.weCallYou = e, $("form.instruction").submit(function() {
      return $.ajax({
        url: $(this).attr("action"),
        data: $(this).serializeArray(),
        type: "post",
        dataType: "json",
        success: function(t) {
          document.title;
          var t = t.split(","),
            e = window.location;
          if (console.log(e.pathname.match("/finalizacao")), (e.pathname.match("/finalizacao") || e.pathname.match("/confirma")) && e.reload(), "false" != t[0]) return $(".login-error-message").hide(), $(".instruction").fadeOut(200), $(".links").fadeOut(200), setTimeout(function() {
            $(".box-logged-in").fadeIn(200), $(".btn-login .label").text(t[1])
          }, 200), !1;
          $(".login-error-message").text(t[1]), $(".login-error-message").show()
        },
        error: function() {}
      }), !1
    }), $("a.logout").click(function() {
      $.ajax({
        url: "/account/log-off",
        dataType: "html",
        data: "html",
        success: function(t) {
          return $(".btn-login .label").text("Login"), $(".box-logged-in").fadeOut(200), setTimeout(function() {
            $(".login-error-message").hide(), $(".instruction").fadeIn(200), $(".links").fadeIn(200)
          }, 200), "/home" == window.location.pathname.toLowerCase() || "/" == window.location.pathname.toLowerCase() || (window.location = getLocation("home")), !1
        },
        error: function(t) {}
      })
    }), $(".forgot-password").click(function() {
      $(".instruction").fadeOut(200), $(".links").fadeOut(200), setTimeout(function() {
        $(".forgot-my-pass").fadeIn(200)
      }, 200)
    }), $(".back-to-login").click(function() {
      $(".forgot-my-pass").fadeOut(200), setTimeout(function() {
        $(".instruction").fadeIn(200), $(".links").fadeIn(200)
      }, 200)
    }), $("form.forgot-my-pass").submit(function() {
      return $.ajax({
        dataType: "json",
        type: "POST",
        data: $(this).serializeArray(),
        url: "/cliente/esqueci-minha-senha",
        success: function(t) {
          $(".login-error-message").text(t).fadeIn(300), setTimeout(function() {
            $(".forgot-my-pass").fadeOut(200)
          }, 2e3), setTimeout(function() {
            $(".login-error-message").text(""), $(".instruction").fadeIn(200), $(".links").fadeIn(200)
          }, 2200)
        },
        error: function(t) {}
      }), !1
    });
    $('input[name="telefone"]') && $('input[name="telefone"]').mask("(99) 9999-99999"), $('input[name="telefone"]').on("blur", function() {
      var t, e = $(this).val().substr($(this).val().indexOf("-") + 1);
      3 == e.length && (e = $(this).val().substr($(this).val().indexOf("-") - 1, 1) + e, t = $(this).val().substr(0, 9), $(this).val(t + "-" + e))
    }), $("#bandeiras-trigger").on("click", function(t) {
      t.preventDefault(), $(this).parents("#bandeiras-container").toggleClass("ativado")
    })
  }(),
  function(t) {
    var e = !1,
      n = !1,
      i = !1;

    function o(t) {}

    function r() {
      t.hideSearchBar(), t.hideLoginBar(), t.hidePhonesBar(), $(window).unbind("click", s), $(window).unbind("keydown", o)
    }

    function s(t) {
      for (var e = $(t.target), n = !1;
        "BODY" != e.prop("tagName");) {
        if (e.attr("id") == _currentBarID) {
          n = !0;
          break
        }
        e = e.parent()
      }
      n || r()
    }
    $(window).bind("scroll", function(t) {
      window.scrollY < 140 ? ($("#fixed-nav").hide(), $(".bar").css({
        position: "absolute",
        top: 141
      })) : ($("#fixed-nav").show(), $(".bar").css({
        position: "fixed",
        top: 78
      }))
    }), t.toggleSearchBar = function() {
      (e = !e) ? t.showSearchBar(): t.hideSearchBar()
    }, t.showSearchBar = function() {
      _currentBarID = "search-bar", console.log("showSearchBar"), r(), e = !0, $("#search-bar input").val(""), $("#search-bar").stop(!0).slideDown("fast", function() {
        $("#search-bar input").focus(), $(window).bind("click", s), $(window).bind("keydown", o)
      })
    }, t.hideSearchBar = function() {
      e = !1, $("#search-bar").slideUp("fast"), $("#search-bar input").blur()
    }, t.toggleLoginBar = function() {
      (n = !n) ? t.showLoginBar(): t.hideLoginBar()
    }, t.showLoginBar = function() {
      _currentBarID = "login-bar", console.log("showLoginBar"), r(), n = !0, $("#login-bar input").val(""), $("#login-bar").stop(!0).slideDown("fast", function() {
        $("#login-bar .email").focus(), $(window).bind("click", s)
      })
    }, t.hideLoginBar = function() {
      n = !1, $("#login-bar").slideUp("fast"), $("#login-bar input").blur()
    }, t.togglePhonesBar = function() {
      (i = !i) ? t.showPhonesBar(): t.hidePhonesBar()
    }, t.showPhonesBar = function() {
      _currentBarID = "phones-bar", r(), i = !0, $("#phones-bar input").val(""), $("#phones-bar").stop(!0).slideDown("fast", function() {
        $(window).bind("click", s)
      })
    }, t.hidePhonesBar = function() {
      i = !1, $("#phones-bar").slideUp("fast"), $("#phones-bar input").blur()
    }, window.Header = t
  }(window.Header || {}),
  function() {
    function t(p) {
      return function(t, e, n, i) {
        e = D(e, i, 4);
        for (var o = !E(t) && M.keys(t), r = (o || t).length, s = 0 < p ? 0 : r - 1, a = (arguments.length < 3 && (n = t[o ? o[s] : s], s += p), t), l = e, c = n, u = o, d = s, h = r; 0 <= d && d < h; d += p) {
          var f = u ? u[d] : d;
          c = l(c, a[f], f, a)
        }
        return c
      }
    }

    function e(r) {
      return function(t, e, n) {
        e = O(e, n);
        for (var i = Y(t), o = 0 < r ? 0 : i - 1; 0 <= o && o < i; o += r)
          if (e(t[o], o, t)) return o;
        return -1
      }
    }

    function n(r, s, a) {
      return function(t, e, n) {
        var i = 0,
          o = Y(t);
        if ("number" == typeof n) 0 < r ? i = 0 <= n ? n : Math.max(n + o, i) : o = 0 <= n ? Math.min(n + 1, o) : n + o + 1;
        else if (a && n && o) return t[n = a(t, e)] === e ? n : -1;
        if (e != e) return 0 <= (n = s(g.call(t, i, o), M.isNaN)) ? n + i : -1;
        for (n = 0 < r ? i : o - 1; 0 <= n && n < o; n += r)
          if (t[n] === e) return n;
        return -1
      }
    }

    function i(t, e) {
      var n = $.length,
        i = t.constructor,
        o = M.isFunction(i) && i.prototype || p,
        r = "constructor";
      for (M.has(t, r) && !M.contains(e, r) && e.push(r); n--;)(r = $[n]) in t && t[r] !== o[r] && !M.contains(e, r) && e.push(r)
    }

    function o(l, c) {
      return function(t) {
        var e = arguments.length;
        if (e < 2 || null == t) return t;
        for (var n = 1; n < e; n++)
          for (var i = arguments[n], o = l(i), r = o.length, s = 0; s < r; s++) {
            var a = o[s];
            c && void 0 !== t[a] || (t[a] = i[a])
          }
        return t
      }
    }

    function r(e) {
      return function(t) {
        return null == t ? void 0 : t[e]
      }
    }

    function s(r) {
      return function(n, i, t) {
        var o = {};
        return i = O(i, t), M.each(n, function(t, e) {
          e = i(t, e, n);
          r(o, t, e)
        }), o
      }
    }

    function a(t, e, n, i, o) {
      return i instanceof e ? (i = T(t.prototype), e = t.apply(i, o), M.isObject(e) ? e : i) : t.apply(n, o)
    }

    function l(e) {
      function n(t) {
        return e[t]
      }
      var t = "(?:" + M.keys(e).join("|") + ")",
        i = RegExp(t),
        o = RegExp(t, "g");
      return function(t) {
        return i.test(t = null == t ? "" : "" + t) ? t.replace(o, n) : t
      }
    }

    function c(t) {
      return "\\" + P[t]
    }

    function u(t, e) {
      return t._chain ? M(e).chain() : e
    }
    var d = this,
      h = d._,
      f = Array.prototype,
      p = Object.prototype,
      m = Function.prototype,
      v = f.push,
      g = f.slice,
      y = p.toString,
      A = p.hasOwnProperty,
      b = Array.isArray,
      w = Object.keys,
      _ = m.bind,
      S = Object.create,
      k = function() {},
      M = function(t) {
        return t instanceof M ? t : this instanceof M ? void(this._wrapped = t) : new M(t)
      },
      D = ("undefined" != typeof exports ? (exports = "undefined" != typeof module && module.exports ? module.exports = M : exports)._ = M : d._ = M, M.VERSION = "1.8.3", function(o, r, t) {
        if (void 0 === r) return o;
        switch (null == t ? 3 : t) {
          case 1:
            return function(t) {
              return o.call(r, t)
            };
          case 2:
            return function(t, e) {
              return o.call(r, t, e)
            };
          case 3:
            return function(t, e, n) {
              return o.call(r, t, e, n)
            };
          case 4:
            return function(t, e, n, i) {
              return o.call(r, t, e, n, i)
            }
        }
        return function() {
          return o.apply(r, arguments)
        }
      }),
      O = function(t, e, n) {
        return null == t ? M.identity : M.isFunction(t) ? D(t, e, n) : M.isObject(t) ? M.matcher(t) : M.property(t)
      },
      T = (M.iteratee = function(t, e) {
        return O(t, e, 1 / 0)
      }, function(t) {
        if (!M.isObject(t)) return {};
        if (S) return S(t);
        k.prototype = t;
        t = new k;
        return k.prototype = null, t
      }),
      I = Math.pow(2, 53) - 1,
      Y = r("length"),
      E = function(t) {
        t = Y(t);
        return "number" == typeof t && 0 <= t && t <= I
      },
      x = (M.each = M.forEach = function(t, e, n) {
        if (e = D(e, n), E(t))
          for (o = 0, r = t.length; o < r; o++) e(t[o], o, t);
        else
          for (var i = M.keys(t), o = 0, r = i.length; o < r; o++) e(t[i[o]], i[o], t);
        return t
      }, M.map = M.collect = function(t, e, n) {
        e = O(e, n);
        for (var i = !E(t) && M.keys(t), o = (i || t).length, r = Array(o), s = 0; s < o; s++) {
          var a = i ? i[s] : s;
          r[s] = e(t[a], a, t)
        }
        return r
      }, M.reduce = M.foldl = M.inject = t(1), M.reduceRight = M.foldr = t(-1), M.find = M.detect = function(t, e, n) {
        e = E(t) ? M.findIndex(t, e, n) : M.findKey(t, e, n);
        return void 0 !== e && -1 !== e ? t[e] : void 0
      }, M.filter = M.select = function(t, i, e) {
        var o = [];
        return i = O(i, e), M.each(t, function(t, e, n) {
          i(t, e, n) && o.push(t)
        }), o
      }, M.reject = function(t, e, n) {
        return M.filter(t, M.negate(O(e)), n)
      }, M.every = M.all = function(t, e, n) {
        e = O(e, n);
        for (var i = !E(t) && M.keys(t), o = (i || t).length, r = 0; r < o; r++) {
          var s = i ? i[r] : r;
          if (!e(t[s], s, t)) return !1
        }
        return !0
      }, M.some = M.any = function(t, e, n) {
        e = O(e, n);
        for (var i = !E(t) && M.keys(t), o = (i || t).length, r = 0; r < o; r++) {
          var s = i ? i[r] : r;
          if (e(t[s], s, t)) return !0
        }
        return !1
      }, M.contains = M.includes = M.include = function(t, e, n, i) {
        return E(t) || (t = M.values(t)), 0 <= M.indexOf(t, e, n = "number" == typeof n && !i ? n : 0)
      }, M.invoke = function(t, n) {
        var i = g.call(arguments, 2),
          o = M.isFunction(n);
        return M.map(t, function(t) {
          var e = o ? n : t[n];
          return null == e ? e : e.apply(t, i)
        })
      }, M.pluck = function(t, e) {
        return M.map(t, M.property(e))
      }, M.where = function(t, e) {
        return M.filter(t, M.matcher(e))
      }, M.findWhere = function(t, e) {
        return M.find(t, M.matcher(e))
      }, M.max = function(t, i, e) {
        var n, o, r = -1 / 0,
          s = -1 / 0;
        if (null == i && null != t)
          for (var a = 0, l = (t = E(t) ? t : M.values(t)).length; a < l; a++) n = t[a], r < n && (r = n);
        else i = O(i, e), M.each(t, function(t, e, n) {
          o = i(t, e, n), (s < o || o === -1 / 0 && r === -1 / 0) && (r = t, s = o)
        });
        return r
      }, M.min = function(t, i, e) {
        var n, o, r = 1 / 0,
          s = 1 / 0;
        if (null == i && null != t)
          for (var a = 0, l = (t = E(t) ? t : M.values(t)).length; a < l; a++)(n = t[a]) < r && (r = n);
        else i = O(i, e), M.each(t, function(t, e, n) {
          ((o = i(t, e, n)) < s || 1 / 0 === o && 1 / 0 === r) && (r = t, s = o)
        });
        return r
      }, M.shuffle = function(t) {
        for (var e, n = E(t) ? t : M.values(t), i = n.length, o = Array(i), r = 0; r < i; r++)(e = M.random(0, r)) !== r && (o[r] = o[e]), o[e] = n[r];
        return o
      }, M.sample = function(t, e, n) {
        return null == e || n ? (t = E(t) ? t : M.values(t))[M.random(t.length - 1)] : M.shuffle(t).slice(0, Math.max(0, e))
      }, M.sortBy = function(t, i, e) {
        return i = O(i, e), M.pluck(M.map(t, function(t, e, n) {
          return {
            value: t,
            index: e,
            criteria: i(t, e, n)
          }
        }).sort(function(t, e) {
          var n = t.criteria,
            i = e.criteria;
          if (n !== i) {
            if (i < n || void 0 === n) return 1;
            if (n < i || void 0 === i) return -1
          }
          return t.index - e.index
        }), "value")
      }, M.groupBy = s(function(t, e, n) {
        M.has(t, n) ? t[n].push(e) : t[n] = [e]
      }), M.indexBy = s(function(t, e, n) {
        t[n] = e
      }), M.countBy = s(function(t, e, n) {
        M.has(t, n) ? t[n]++ : t[n] = 1
      }), M.toArray = function(t) {
        return t ? M.isArray(t) ? g.call(t) : E(t) ? M.map(t, M.identity) : M.values(t) : []
      }, M.size = function(t) {
        return null == t ? 0 : (E(t) ? t : M.keys(t)).length
      }, M.partition = function(t, i, e) {
        i = O(i, e);
        var o = [],
          r = [];
        return M.each(t, function(t, e, n) {
          (i(t, e, n) ? o : r).push(t)
        }), [o, r]
      }, M.first = M.head = M.take = function(t, e, n) {
        return null == t ? void 0 : null == e || n ? t[0] : M.initial(t, t.length - e)
      }, M.initial = function(t, e, n) {
        return g.call(t, 0, Math.max(0, t.length - (null == e || n ? 1 : e)))
      }, M.last = function(t, e, n) {
        return null == t ? void 0 : null == e || n ? t[t.length - 1] : M.rest(t, Math.max(0, t.length - e))
      }, M.rest = M.tail = M.drop = function(t, e, n) {
        return g.call(t, null == e || n ? 1 : e)
      }, M.compact = function(t) {
        return M.filter(t, M.identity)
      }, function(t, e, n, i) {
        for (var o = [], r = 0, s = i || 0, a = Y(t); s < a; s++) {
          var l = t[s];
          if (E(l) && (M.isArray(l) || M.isArguments(l))) {
            var c = 0,
              u = (l = e ? l : x(l, e, n)).length;
            for (o.length += u; c < u;) o[r++] = l[c++]
          } else n || (o[r++] = l)
        }
        return o
      }),
      C = (M.flatten = function(t, e) {
        return x(t, e, !1)
      }, M.without = function(t) {
        return M.difference(t, g.call(arguments, 1))
      }, M.uniq = M.unique = function(t, e, n, i) {
        M.isBoolean(e) || (i = n, n = e, e = !1), null != n && (n = O(n, i));
        for (var o = [], r = [], s = 0, a = Y(t); s < a; s++) {
          var l = t[s],
            c = n ? n(l, s, t) : l;
          e ? (s && r === c || o.push(l), r = c) : n ? M.contains(r, c) || (r.push(c), o.push(l)) : M.contains(o, l) || o.push(l)
        }
        return o
      }, M.union = function() {
        return M.uniq(x(arguments, !0, !0))
      }, M.intersection = function(t) {
        for (var e = [], n = arguments.length, i = 0, o = Y(t); i < o; i++) {
          var r = t[i];
          if (!M.contains(e, r)) {
            for (var s = 1; s < n && M.contains(arguments[s], r); s++);
            s === n && e.push(r)
          }
        }
        return e
      }, M.difference = function(t) {
        var e = x(arguments, !0, !0, 1);
        return M.filter(t, function(t) {
          return !M.contains(e, t)
        })
      }, M.zip = function() {
        return M.unzip(arguments)
      }, M.unzip = function(t) {
        for (var e = t && M.max(t, Y).length || 0, n = Array(e), i = 0; i < e; i++) n[i] = M.pluck(t, i);
        return n
      }, M.object = function(t, e) {
        for (var n = {}, i = 0, o = Y(t); i < o; i++) e ? n[t[i]] = e[i] : n[t[i][0]] = t[i][1];
        return n
      }, M.findIndex = e(1), M.findLastIndex = e(-1), M.sortedIndex = function(t, e, n, i) {
        for (var o = (n = O(n, i, 1))(e), r = 0, s = Y(t); r < s;) {
          var a = Math.floor((r + s) / 2);
          n(t[a]) < o ? r = a + 1 : s = a
        }
        return r
      }, M.indexOf = n(1, M.findIndex, M.sortedIndex), M.lastIndexOf = n(-1, M.findLastIndex), M.range = function(t, e, n) {
        null == e && (e = t || 0, t = 0), n = n || 1;
        for (var i = Math.max(Math.ceil((e - t) / n), 0), o = Array(i), r = 0; r < i; r++, t += n) o[r] = t;
        return o
      }, M.bind = function(t, e) {
        if (_ && t.bind === _) return _.apply(t, g.call(arguments, 1));
        if (!M.isFunction(t)) throw new TypeError("Bind must be called on a function");

        function n() {
          return a(t, n, e, this, i.concat(g.call(arguments)))
        }
        var i = g.call(arguments, 2);
        return n
      }, M.partial = function(o) {
        function r() {
          for (var t = 0, e = s.length, n = Array(e), i = 0; i < e; i++) n[i] = s[i] === M ? arguments[t++] : s[i];
          for (; t < arguments.length;) n.push(arguments[t++]);
          return a(o, r, this, this, n)
        }
        var s = g.call(arguments, 1);
        return r
      }, M.bindAll = function(t) {
        var e, n, i = arguments.length;
        if (i <= 1) throw new Error("bindAll must be passed function names");
        for (e = 1; e < i; e++) t[n = arguments[e]] = M.bind(t[n], t);
        return t
      }, M.memoize = function(i, o) {
        function r(t) {
          var e = r.cache,
            n = "" + (o ? o.apply(this, arguments) : t);
          return M.has(e, n) || (e[n] = i.apply(this, arguments)), e[n]
        }
        return r.cache = {}, r
      }, M.delay = function(t, e) {
        var n = g.call(arguments, 2);
        return setTimeout(function() {
          return t.apply(null, n)
        }, e)
      }, M.defer = M.partial(M.delay, M, 1), M.throttle = function(n, i, o) {
        function r() {
          u = !1 === o.leading ? 0 : M.now(), c = null, l = n.apply(s, a), c || (s = a = null)
        }
        var s, a, l, c = null,
          u = 0;
        o = o || {};
        return function() {
          var t = M.now(),
            e = (u || !1 !== o.leading || (u = t), i - (t - u));
          return s = this, a = arguments, e <= 0 || i < e ? (c && (clearTimeout(c), c = null), u = t, l = n.apply(s, a), c || (s = a = null)) : c || !1 === o.trailing || (c = setTimeout(r, e)), l
        }
      }, M.debounce = function(e, n, i) {
        function o() {
          var t = M.now() - l;
          t < n && 0 <= t ? r = setTimeout(o, n - t) : (r = null, i || (c = e.apply(a, s), r || (a = s = null)))
        }
        var r, s, a, l, c;
        return function() {
          a = this, s = arguments, l = M.now();
          var t = i && !r;
          return r = r || setTimeout(o, n), t && (c = e.apply(a, s), a = s = null), c
        }
      }, M.wrap = function(t, e) {
        return M.partial(e, t)
      }, M.negate = function(t) {
        return function() {
          return !t.apply(this, arguments)
        }
      }, M.compose = function() {
        var n = arguments,
          i = n.length - 1;
        return function() {
          for (var t = i, e = n[i].apply(this, arguments); t--;) e = n[t].call(this, e);
          return e
        }
      }, M.after = function(t, e) {
        return function() {
          return --t < 1 ? e.apply(this, arguments) : void 0
        }
      }, M.before = function(t, e) {
        var n;
        return function() {
          return 0 < --t && (n = e.apply(this, arguments)), t <= 1 && (e = null), n
        }
      }, M.once = M.partial(M.before, 2), !{
        toString: null
      }.propertyIsEnumerable("toString")),
      $ = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"],
      L = (M.keys = function(t) {
        if (!M.isObject(t)) return [];
        if (w) return w(t);
        var e, n = [];
        for (e in t) M.has(t, e) && n.push(e);
        return C && i(t, n), n
      }, M.allKeys = function(t) {
        if (!M.isObject(t)) return [];
        var e, n = [];
        for (e in t) n.push(e);
        return C && i(t, n), n
      }, M.values = function(t) {
        for (var e = M.keys(t), n = e.length, i = Array(n), o = 0; o < n; o++) i[o] = t[e[o]];
        return i
      }, M.mapObject = function(t, e, n) {
        e = O(e, n);
        for (var i, o = M.keys(t), r = o.length, s = {}, a = 0; a < r; a++) s[i = o[a]] = e(t[i], i, t);
        return s
      }, M.pairs = function(t) {
        for (var e = M.keys(t), n = e.length, i = Array(n), o = 0; o < n; o++) i[o] = [e[o], t[e[o]]];
        return i
      }, M.invert = function(t) {
        for (var e = {}, n = M.keys(t), i = 0, o = n.length; i < o; i++) e[t[n[i]]] = n[i];
        return e
      }, M.functions = M.methods = function(t) {
        var e, n = [];
        for (e in t) M.isFunction(t[e]) && n.push(e);
        return n.sort()
      }, M.extend = o(M.allKeys), M.extendOwn = M.assign = o(M.keys), M.findKey = function(t, e, n) {
        e = O(e, n);
        for (var i, o = M.keys(t), r = 0, s = o.length; r < s; r++)
          if (e(t[i = o[r]], i, t)) return i
      }, M.pick = function(t, e, n) {
        var i, o, r = {},
          s = t;
        if (null == s) return r;
        M.isFunction(e) ? (o = M.allKeys(s), i = D(e, n)) : (o = x(arguments, !1, !1, 1), i = function(t, e, n) {
          return e in n
        }, s = Object(s));
        for (var a = 0, l = o.length; a < l; a++) {
          var c = o[a],
            u = s[c];
          i(u, c, s) && (r[c] = u)
        }
        return r
      }, M.omit = function(t, e, n) {
        var i;
        return e = M.isFunction(e) ? M.negate(e) : (i = M.map(x(arguments, !1, !1, 1), String), function(t, e) {
          return !M.contains(i, e)
        }), M.pick(t, e, n)
      }, M.defaults = o(M.allKeys, !0), M.create = function(t, e) {
        t = T(t);
        return e && M.extendOwn(t, e), t
      }, M.clone = function(t) {
        return M.isObject(t) ? M.isArray(t) ? t.slice() : M.extend({}, t) : t
      }, M.tap = function(t, e) {
        return e(t), t
      }, M.isMatch = function(t, e) {
        var n = M.keys(e),
          i = n.length;
        if (null == t) return !i;
        for (var o = Object(t), r = 0; r < i; r++) {
          var s = n[r];
          if (e[s] !== o[s] || !(s in o)) return !1
        }
        return !0
      }, function(t, e, n, i) {
        if (t === e) return 0 !== t || 1 / t == 1 / e;
        if (null == t || null == e) return t === e;
        t instanceof M && (t = t._wrapped), e instanceof M && (e = e._wrapped);
        var o = y.call(t);
        if (o !== y.call(e)) return !1;
        switch (o) {
          case "[object RegExp]":
          case "[object String]":
            return "" + t == "" + e;
          case "[object Number]":
            return +t != +t ? +e != +e : 0 == +t ? 1 / +t == 1 / e : +t == +e;
          case "[object Date]":
          case "[object Boolean]":
            return +t == +e
        }
        o = "[object Array]" === o;
        if (!o) {
          if ("object" != typeof t || "object" != typeof e) return !1;
          var r = t.constructor,
            s = e.constructor;
          if (r !== s && !(M.isFunction(r) && r instanceof r && M.isFunction(s) && s instanceof s) && "constructor" in t && "constructor" in e) return !1
        }
        i = i || [];
        for (var a = (n = n || []).length; a--;)
          if (n[a] === t) return i[a] === e;
        if (n.push(t), i.push(e), o) {
          if ((a = t.length) !== e.length) return !1;
          for (; a--;)
            if (!L(t[a], e[a], n, i)) return !1
        } else {
          var l, c = M.keys(t),
            a = c.length;
          if (M.keys(e).length !== a) return !1;
          for (; a--;)
            if (l = c[a], !M.has(e, l) || !L(t[l], e[l], n, i)) return !1
        }
        return n.pop(), i.pop(), !0
      }),
      m = (M.isEqual = function(t, e) {
        return L(t, e)
      }, M.isEmpty = function(t) {
        return null == t || (E(t) && (M.isArray(t) || M.isString(t) || M.isArguments(t)) ? 0 === t.length : 0 === M.keys(t).length)
      }, M.isElement = function(t) {
        return !(!t || 1 !== t.nodeType)
      }, M.isArray = b || function(t) {
        return "[object Array]" === y.call(t)
      }, M.isObject = function(t) {
        var e = typeof t;
        return "function" == e || "object" == e && !!t
      }, M.each(["Arguments", "Function", "String", "Number", "Date", "RegExp", "Error"], function(e) {
        M["is" + e] = function(t) {
          return y.call(t) === "[object " + e + "]"
        }
      }), M.isArguments(arguments) || (M.isArguments = function(t) {
        return M.has(t, "callee")
      }), "function" != typeof /./ && "object" != typeof Int8Array && (M.isFunction = function(t) {
        return "function" == typeof t || !1
      }), M.isFinite = function(t) {
        return isFinite(t) && !isNaN(parseFloat(t))
      }, M.isNaN = function(t) {
        return M.isNumber(t) && t !== +t
      }, M.isBoolean = function(t) {
        return !0 === t || !1 === t || "[object Boolean]" === y.call(t)
      }, M.isNull = function(t) {
        return null === t
      }, M.isUndefined = function(t) {
        return void 0 === t
      }, M.has = function(t, e) {
        return null != t && A.call(t, e)
      }, M.noConflict = function() {
        return d._ = h, this
      }, M.identity = function(t) {
        return t
      }, M.constant = function(t) {
        return function() {
          return t
        }
      }, M.noop = function() {}, M.property = r, M.propertyOf = function(e) {
        return null == e ? function() {} : function(t) {
          return e[t]
        }
      }, M.matcher = M.matches = function(e) {
        return e = M.extendOwn({}, e),
          function(t) {
            return M.isMatch(t, e)
          }
      }, M.times = function(t, e, n) {
        var i = Array(Math.max(0, t));
        e = D(e, n, 1);
        for (var o = 0; o < t; o++) i[o] = e(o);
        return i
      }, M.random = function(t, e) {
        return null == e && (e = t, t = 0), t + Math.floor(Math.random() * (e - t + 1))
      }, M.now = Date.now || function() {
        return (new Date).getTime()
      }, {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#x27;",
        "`": "&#x60;"
      }),
      b = M.invert(m),
      j = (M.escape = l(m), M.unescape = l(b), M.result = function(t, e, n) {
        e = null == t ? void 0 : t[e];
        return M.isFunction(e = void 0 === e ? n : e) ? e.call(t) : e
      }, 0),
      W = (M.uniqueId = function(t) {
        var e = ++j + "";
        return t ? t + e : e
      }, M.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
      }, /(.)^/),
      P = {
        "'": "'",
        "\\": "\\",
        "\r": "r",
        "\n": "n",
        "\u2028": "u2028",
        "\u2029": "u2029"
      },
      B = /\\|'|\r|\n|\u2028|\u2029/g;
    M.template = function(r, t, e) {
      t = M.defaults({}, t = !t && e ? e : t, M.templateSettings);
      var e = RegExp([(t.escape || W).source, (t.interpolate || W).source, (t.evaluate || W).source].join("|") + "|$", "g"),
        s = 0,
        a = "__p+='";
      r.replace(e, function(t, e, n, i, o) {
        return a += r.slice(s, o).replace(B, c), s = o + t.length, e ? a += "'+\n((__t=(" + e + "))==null?'':_.escape(__t))+\n'" : n ? a += "'+\n((__t=(" + n + "))==null?'':__t)+\n'" : i && (a += "';\n" + i + "\n__p+='"), t
      }), a += "';\n", a = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + (a = t.variable ? a : "with(obj||{}){\n" + a + "}\n") + "return __p;\n";
      try {
        var n = new Function(t.variable || "obj", "_", a)
      } catch (t) {
        throw t.source = a, t
      }

      function i(t) {
        return n.call(this, t, M)
      }
      e = t.variable || "obj";
      return i.source = "function(" + e + "){\n" + a + "}", i
    }, M.chain = function(t) {
      t = M(t);
      return t._chain = !0, t
    };
    M.mixin = function(n) {
      M.each(M.functions(n), function(t) {
        var e = M[t] = n[t];
        M.prototype[t] = function() {
          var t = [this._wrapped];
          return v.apply(t, arguments), u(this, e.apply(M, t))
        }
      })
    }, M.mixin(M), M.each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(e) {
      var n = f[e];
      M.prototype[e] = function() {
        var t = this._wrapped;
        return n.apply(t, arguments), "shift" !== e && "splice" !== e || 0 !== t.length || delete t[0], u(this, t)
      }
    }), M.each(["concat", "join", "slice"], function(t) {
      var e = f[t];
      M.prototype[t] = function() {
        return u(this, e.apply(this._wrapped, arguments))
      }
    }), M.prototype.value = function() {
      return this._wrapped
    }, M.prototype.valueOf = M.prototype.toJSON = M.prototype.value, M.prototype.toString = function() {
      return "" + this._wrapped
    }, "function" == typeof define && define.amd && define("underscore", [], function() {
      return M
    })
  }.call(this),
  function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : t.moment = e()
  }(this, function() {
    "use strict";

    function f() {
      return Gt.apply(null, arguments)
    }

    function I(t) {
      return "[object Array]" === Object.prototype.toString.call(t)
    }

    function j(t) {
      return t instanceof Date || "[object Date]" === Object.prototype.toString.call(t)
    }

    function p(t, e) {
      return Object.prototype.hasOwnProperty.call(t, e)
    }

    function P(t, e) {
      for (var n in e) p(e, n) && (t[n] = e[n]);
      return p(e, "toString") && (t.toString = e.toString), p(e, "valueOf") && (t.valueOf = e.valueOf), t
    }

    function B(t, e, n, i) {
      return yt(t, e, n, i, !0).utc()
    }

    function m(t) {
      return null == t._pf && (t._pf = {
        empty: !1,
        unusedTokens: [],
        unusedInput: [],
        overflow: -2,
        charsLeftOver: 0,
        nullInput: !1,
        invalidMonth: null,
        invalidFormat: !1,
        userInvalidated: !1,
        iso: !1
      }), t._pf
    }

    function R(t) {
      var e;
      return null == t._isValid && (e = m(t), t._isValid = !(isNaN(t._d.getTime()) || !(e.overflow < 0) || e.empty || e.invalidMonth || e.invalidWeekday || e.nullInput || e.invalidFormat || e.userInvalidated), t._strict && (t._isValid = t._isValid && 0 === e.charsLeftOver && 0 === e.unusedTokens.length && void 0 === e.bigHour)), t._isValid
    }

    function X(t) {
      var e = B(NaN);
      return null != t ? P(m(e), t) : m(e).userInvalidated = !0, e
    }

    function H(t, e) {
      var n, i, o;
      if (void 0 !== e._isAMomentObject && (t._isAMomentObject = e._isAMomentObject), void 0 !== e._i && (t._i = e._i), void 0 !== e._f && (t._f = e._f), void 0 !== e._l && (t._l = e._l), void 0 !== e._strict && (t._strict = e._strict), void 0 !== e._tzm && (t._tzm = e._tzm), void 0 !== e._isUTC && (t._isUTC = e._isUTC), void 0 !== e._offset && (t._offset = e._offset), void 0 !== e._pf && (t._pf = m(e)), void 0 !== e._locale && (t._locale = e._locale), 0 < Vt.length)
        for (n in Vt) i = Vt[n], o = e[i], void 0 !== o && (t[i] = o);
      return t
    }

    function q(t) {
      H(this, t), this._d = new Date(null != t._d ? t._d.getTime() : NaN), !1 === Zt && (Zt = !0, f.updateOffset(this), Zt = !1)
    }

    function r(t) {
      return t instanceof q || null != t && null != t._isAMomentObject
    }

    function c(t) {
      return t < 0 ? Math.ceil(t) : Math.floor(t)
    }

    function a(t) {
      var t = +t,
        e = 0;
      return e = 0 != t && isFinite(t) ? c(t) : e
    }

    function F(t, e, n) {
      for (var i = Math.min(t.length, e.length), o = Math.abs(t.length - e.length), r = 0, s = 0; s < i; s++)(n && t[s] !== e[s] || !n && a(t[s]) !== a(e[s])) && r++;
      return r + o
    }

    function U() {}

    function N(t) {
      return t && t.toLowerCase().replace("_", "-")
    }

    function G(t) {
      var e;
      if (!_[t] && "undefined" != typeof module && module && module.exports) try {
        e = zt._abbr, require("./locale/" + t), z(e)
      } catch (t) {}
      return _[t]
    }

    function z(t, e) {
      return t && ((t = void 0 === e ? u(t) : V(t, e)) && (zt = t)), zt._abbr
    }

    function V(t, e) {
      return null !== e ? (e.abbr = t, _[t] = _[t] || new U, _[t].set(e), z(t), _[t]) : (delete _[t], null)
    }

    function u(t) {
      var e;
      if (!(t = t && t._locale && t._locale._abbr ? t._locale._abbr : t)) return zt;
      if (!I(t)) {
        if (e = G(t)) return e;
        t = [t]
      }
      for (var n, i, o, r, s = t, a = 0; a < s.length;) {
        for (n = (r = N(s[a]).split("-")).length, i = (i = N(s[a + 1])) ? i.split("-") : null; 0 < n;) {
          if (o = G(r.slice(0, n).join("-"))) return o;
          if (i && i.length >= n && F(r, i, !0) >= n - 1) break;
          n--
        }
        a++
      }
      return null
    }

    function t(t, e) {
      var n = t.toLowerCase();
      Kt[n] = Kt[n + "s"] = Kt[e] = t
    }

    function d(t) {
      return "string" == typeof t ? Kt[t] || Kt[t.toLowerCase()] : void 0
    }

    function Z(t) {
      var e, n, i = {};
      for (n in t) p(t, n) && (e = d(n), e && (i[e] = t[n]));
      return i
    }

    function e(e, n) {
      return function(t) {
        return null != t ? (J(this, e, t), f.updateOffset(this, n), this) : K(this, e)
      }
    }

    function K(t, e) {
      return t._d["get" + (t._isUTC ? "UTC" : "") + e]()
    }

    function J(t, e, n) {
      t._d["set" + (t._isUTC ? "UTC" : "") + e](n)
    }

    function Q(t, e) {
      if ("object" == typeof t)
        for (var n in t) this.set(n, t[n]);
      else if ("function" == typeof this[t = d(t)]) return this[t](e);
      return this
    }

    function tt(t, e, n) {
      var i = "" + Math.abs(t);
      return (0 <= t ? n ? "+" : "" : "-") + Math.pow(10, Math.max(0, e - i.length)).toString().substr(1) + i
    }

    function i(t, e, n, i) {
      var o = "string" == typeof i ? function() {
        return this[i]()
      } : i;
      t && (ee[t] = o), e && (ee[e[0]] = function() {
        return tt(o.apply(this, arguments), e[1], e[2])
      }), n && (ee[n] = function() {
        return this.localeData().ordinal(o.apply(this, arguments), t)
      })
    }

    function et(t, e) {
      return t.isValid() ? (e = nt(e, t.localeData()), te[e] = te[e] || function(n) {
        for (var t, i = n.match(Jt), o = 0, r = i.length; o < r; o++) ee[i[o]] ? i[o] = ee[i[o]] : i[o] = (t = i[o]).match(/\[[\s\S]/) ? t.replace(/^\[|\]$/g, "") : t.replace(/\\/g, "");
        return function(t) {
          var e = "";
          for (o = 0; o < r; o++) e += i[o] instanceof Function ? i[o].call(t, n) : i[o];
          return e
        }
      }(e), te[e](t)) : t.localeData().invalidDate()
    }

    function nt(t, e) {
      function n(t) {
        return e.longDateFormat(t) || t
      }
      var i = 5;
      for (Qt.lastIndex = 0; 0 <= i && Qt.test(t);) t = t.replace(Qt, n), Qt.lastIndex = 0, --i;
      return t
    }

    function n(t, e, n) {
      ue[t] = "function" == typeof(t = e) && "[object Function]" === Object.prototype.toString.call(t) ? e : function(t) {
        return t && n ? n : e
      }
    }

    function s(t, n) {
      var e, i = n;
      for ("string" == typeof t && (t = [t]), "number" == typeof n && (i = function(t, e) {
          e[n] = a(t)
        }), e = 0; e < t.length; e++) de[t[e]] = i
    }

    function it(t, o) {
      s(t, function(t, e, n, i) {
        n._w = n._w || {}, o(t, n._w, n, i)
      })
    }

    function ot(t, e) {
      return new Date(Date.UTC(t, e + 1, 0)).getUTCDate()
    }

    function rt(t, e) {
      var n;
      "string" == typeof e && "number" != typeof(e = t.localeData().monthsParse(e)) || (n = Math.min(t.date(), ot(t.year(), e)), t._d["set" + (t._isUTC ? "UTC" : "") + "Month"](e, n))
    }

    function st(t) {
      return null != t ? (rt(this, t), f.updateOffset(this, !0), this) : K(this, "Month")
    }

    function at(t) {
      var e = t._a;
      return e && -2 === m(t).overflow && (e = e[Y] < 0 || 11 < e[Y] ? Y : e[E] < 1 || e[E] > ot(e[T], e[Y]) ? E : e[x] < 0 || 24 < e[x] || 24 === e[x] && (0 !== e[C] || 0 !== e[$] || 0 !== e[L]) ? x : e[C] < 0 || 59 < e[C] ? C : e[$] < 0 || 59 < e[$] ? $ : e[L] < 0 || 999 < e[L] ? L : -1, m(t)._overflowDayOfYear && (e < T || E < e) && (e = E), m(t).overflow = e), t
    }

    function lt(t) {
      !1 === f.suppressDeprecationWarnings && "undefined" != typeof console && console.warn && console.warn("Deprecation warning: " + t)
    }

    function o(t, e) {
      var n = !0;
      return P(function() {
        return n && (lt(t + "\n" + (new Error).stack), n = !1), e.apply(this, arguments)
      }, e)
    }

    function ct(t) {
      var e, n, i = t._i,
        o = me.exec(i);
      if (o) {
        for (m(t).iso = !0, e = 0, n = ve.length; e < n; e++)
          if (ve[e][1].exec(i)) {
            t._f = ve[e][0];
            break
          } for (e = 0, n = ge.length; e < n; e++)
          if (ge[e][1].exec(i)) {
            t._f += (o[6] || " ") + ge[e][0];
            break
          } i.match(ce) && (t._f += "Z"), vt(t)
      } else t._isValid = !1
    }

    function ut(t, e, n, i, o, r, s) {
      e = new Date(t, e, n, i, o, r, s);
      return t < 1970 && e.setFullYear(t), e
    }

    function dt(t) {
      var e = new Date(Date.UTC.apply(null, arguments));
      return t < 1970 && e.setUTCFullYear(t), e
    }

    function ht(t) {
      return ft(t) ? 366 : 365
    }

    function ft(t) {
      return t % 4 == 0 && t % 100 != 0 || t % 400 == 0
    }

    function h(t, e, n) {
      var e = n - e,
        n = n - t.day();
      return e < n && (n -= 7), n < e - 7 && (n += 7), e = v(t).add(n, "d"), {
        week: Math.ceil(e.dayOfYear() / 7),
        year: e.year()
      }
    }

    function pt(t, e, n) {
      return null != t ? t : null != e ? e : n
    }

    function mt(t) {
      var e, n, i, o, r, s, a, l, c, u = [];
      if (!t._d) {
        for (l = t, c = new Date, n = l._useUTC ? [c.getUTCFullYear(), c.getUTCMonth(), c.getUTCDate()] : [c.getFullYear(), c.getMonth(), c.getDate()], t._w && null == t._a[E] && null == t._a[Y] && (null != (c = (l = t)._w).GG || null != c.W || null != c.E ? (s = 1, a = 4, i = pt(c.GG, l._a[T], h(v(), 1, 4).year), o = pt(c.W, 1), r = pt(c.E, 1)) : (s = l._locale._week.dow, a = l._locale._week.doy, i = pt(c.gg, l._a[T], h(v(), s, a).year), o = pt(c.w, 1), null != c.d ? (r = c.d) < s && ++o : r = null != c.e ? c.e + s : s), c = function(t, e, n, i, o) {
            var r = dt(t, 0, 1 + (i = 6 + o - i)).getUTCDay();
            return r < o && (r += 7), {
              year: 0 < (i = 1 + i + 7 * (e - 1) - r + (n = null != n ? +n : o)) ? t : t - 1,
              dayOfYear: 0 < i ? i : ht(t - 1) + i
            }
          }(i, o, r, a, s), l._a[T] = c.year, l._dayOfYear = c.dayOfYear), t._dayOfYear && (i = pt(t._a[T], n[T]), t._dayOfYear > ht(i) && (m(t)._overflowDayOfYear = !0), o = dt(i, 0, t._dayOfYear), t._a[Y] = o.getUTCMonth(), t._a[E] = o.getUTCDate()), e = 0; e < 3 && null == t._a[e]; ++e) t._a[e] = u[e] = n[e];
        for (; e < 7; e++) t._a[e] = u[e] = null == t._a[e] ? 2 === e ? 1 : 0 : t._a[e];
        24 === t._a[x] && 0 === t._a[C] && 0 === t._a[$] && 0 === t._a[L] && (t._nextDay = !0, t._a[x] = 0), t._d = (t._useUTC ? dt : ut).apply(null, u), null != t._tzm && t._d.setUTCMinutes(t._d.getUTCMinutes() - t._tzm), t._nextDay && (t._a[x] = 24)
      }
    }

    function vt(t) {
      if (t._f === f.ISO_8601) return ct(t);
      t._a = [], m(t).empty = !0;
      for (var e, n, i, o, r, s, a, l = "" + t._i, c = l.length, u = 0, d = nt(t._f, t._locale).match(Jt) || [], h = 0; h < d.length; h++) e = d[h], (r = (l.match((r = t, p(ue, o = e) ? ue[o](r._strict, r._locale) : new RegExp(o.replace("\\", "").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(t, e, n, i, o) {
        return e || n || i || o
      }).replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")))) || [])[0]) && (0 < (o = l.substr(0, l.indexOf(r))).length && m(t).unusedInput.push(o), l = l.slice(l.indexOf(r) + r.length), u += r.length), ee[e] ? (r ? m(t).empty = !1 : m(t).unusedTokens.push(e), o = e, i = t, null != (n = r) && p(de, o) && de[o](n, i._a, i, o)) : t._strict && !r && m(t).unusedTokens.push(e);
      m(t).charsLeftOver = c - u, 0 < l.length && m(t).unusedInput.push(l), !0 === m(t).bigHour && t._a[x] <= 12 && 0 < t._a[x] && (m(t).bigHour = void 0), t._a[x] = (c = t._locale, s = t._a[x], null == (a = t._meridiem) ? s : null != c.meridiemHour ? c.meridiemHour(s, a) : null != c.isPM ? ((c = c.isPM(a)) && s < 12 && (s += 12), s = c || 12 !== s ? s : 0) : s), mt(t), at(t)
    }

    function gt(t) {
      var e = t._i,
        n = t._f; {
        var i, o;
        if (t._locale = t._locale || u(t._l), null === e || void 0 === n && "" === e) return X({
          nullInput: !0
        });
        else return "string" == typeof e && (t._i = e = t._locale.preparse(e)), r(e) ? new q(at(e)) : (I(n) ? function(t) {
          var e, n, i, o, r;
          if (0 === t._f.length) return m(t).invalidFormat = !0, t._d = new Date(NaN);
          for (o = 0; o < t._f.length; o++) r = 0, e = H({}, t), null != t._useUTC && (e._useUTC = t._useUTC), e._f = t._f[o], vt(e), R(e) && (r = (r += m(e).charsLeftOver) + 10 * m(e).unusedTokens.length, m(e).score = r, (null == i || r < i) && (i = r, n = e));
          P(t, n || e)
        }(t) : n ? vt(t) : j(e) ? t._d = e : void 0 === (e = (n = t)._i) ? n._d = new Date : j(e) ? n._d = new Date(+e) : "string" == typeof e ? (i = n, null !== (o = ye.exec(i._i)) ? i._d = new Date(+o[1]) : (ct(i), !1 === i._isValid && (delete i._isValid, f.createFromInputFallback(i)))) : I(e) ? (n._a = function(t, e) {
          for (var n = [], i = 0; i < t.length; ++i) n.push(e(t[i], i));
          return n
        }(e.slice(0), function(t) {
          return parseInt(t, 10)
        }), mt(n)) : "object" == typeof e ? (o = n)._d || (i = Z(o._i), o._a = [i.year, i.month, i.day || i.date, i.hour, i.minute, i.second, i.millisecond], mt(o)) : "number" == typeof e ? n._d = new Date(e) : f.createFromInputFallback(n), t)
      }
    }

    function yt(t, e, n, i, o) {
      var r = {};
      return "boolean" == typeof n && (i = n, n = void 0), r._isAMomentObject = !0, r._useUTC = r._isUTC = o, r._l = n, r._i = t, r._f = e, r._strict = i, (o = new q(at(gt(o = r))))._nextDay && (o.add(1, "d"), o._nextDay = void 0), o
    }

    function v(t, e, n, i) {
      return yt(t, e, n, i, !1)
    }

    function bt(t, e) {
      var n, i;
      if (!(e = 1 === e.length && I(e[0]) ? e[0] : e).length) return v();
      for (n = e[0], i = 1; i < e.length; ++i) e[i].isValid() && !e[i][t](n) || (n = e[i]);
      return n
    }

    function wt(t) {
      var t = Z(t),
        e = t.year || 0,
        n = t.quarter || 0,
        i = t.month || 0,
        o = t.week || 0,
        r = t.day || 0,
        s = t.hour || 0,
        a = t.minute || 0,
        l = t.second || 0,
        t = t.millisecond || 0;
      this._milliseconds = +t + 1e3 * l + 6e4 * a + 36e5 * s, this._days = +r + 7 * o, this._months = +i + 3 * n + 12 * e, this._data = {}, this._locale = u(), this._bubble()
    }

    function _t(t) {
      return t instanceof wt
    }

    function St(t, n) {
      i(t, 0, 0, function() {
        var t = this.utcOffset(),
          e = "+";
        return t < 0 && (t = -t, e = "-"), e + tt(~~(t / 60), 2) + n + tt(~~t % 60, 2)
      })
    }

    function kt(t) {
      var t = (t || "").match(ce) || [],
        t = ((t[t.length - 1] || []) + "").match(Se) || ["-", 0, 0],
        e = 60 * t[1] + a(t[2]);
      return "+" === t[0] ? e : -e
    }

    function Mt(t, e) {
      var n;
      return e._isUTC ? (e = e.clone(), n = (r(t) || j(t) ? +t : +v(t)) - +e, e._d.setTime(+e._d + n), f.updateOffset(e, !1), e) : v(t).local()
    }

    function Dt(t) {
      return 15 * -Math.round(t._d.getTimezoneOffset() / 15)
    }

    function Ot() {
      return this._isUTC && 0 === this._offset
    }

    function g(t, e) {
      var n, i, o = t,
        r = null;
      return _t(t) ? o = {
        ms: t._milliseconds,
        d: t._days,
        M: t._months
      } : "number" == typeof t ? (o = {}, e ? o[e] = t : o.milliseconds = t) : (r = ke.exec(t)) ? (n = "-" === r[1] ? -1 : 1, o = {
        y: 0,
        d: a(r[E]) * n,
        h: a(r[x]) * n,
        m: a(r[C]) * n,
        s: a(r[$]) * n,
        ms: a(r[L]) * n
      }) : (r = Me.exec(t)) ? (n = "-" === r[1] ? -1 : 1, o = {
        y: l(r[2], n),
        M: l(r[3], n),
        d: l(r[4], n),
        h: l(r[5], n),
        m: l(r[6], n),
        s: l(r[7], n),
        w: l(r[8], n)
      }) : null == o ? o = {} : "object" == typeof o && ("from" in o || "to" in o) && (e = v(o.from), r = Mt(r = v(o.to), e), e.isBefore(r) ? i = Tt(e, r) : ((i = Tt(r, e)).milliseconds = -i.milliseconds, i.months = -i.months), n = i, (o = {}).ms = n.milliseconds, o.M = n.months), r = new wt(o), _t(t) && p(t, "_locale") && (r._locale = t._locale), r
    }

    function l(t, e) {
      t = t && parseFloat(t.replace(",", "."));
      return (isNaN(t) ? 0 : t) * e
    }

    function Tt(t, e) {
      var n = {
        milliseconds: 0,
        months: 0
      };
      return n.months = e.month() - t.month() + 12 * (e.year() - t.year()), t.clone().add(n.months, "M").isAfter(e) && --n.months, n.milliseconds = +e - +t.clone().add(n.months, "M"), n
    }

    function Yt(o, r) {
      return function(t, e) {
        var n, i;
        return null === e || isNaN(+e) || (i = "moment()." + (n = r) + "(period, number) is deprecated. Please use moment()." + r + "(number, period).", pe[n] || (lt(i), pe[n] = !0), i = t, t = e, e = i), Et(this, g(t = "string" == typeof t ? +t : t, e), o), this
      }
    }

    function Et(t, e, n, i) {
      var o = e._milliseconds,
        r = e._days,
        e = e._months;
      i = null == i || i, o && t._d.setTime(+t._d + o * n), r && J(t, "Date", K(t, "Date") + r * n), e && rt(t, K(t, "Month") + e * n), i && f.updateOffset(t, r || e)
    }

    function xt() {
      var t = this.clone().utc();
      return 0 < t.year() && t.year() <= 9999 ? "function" == typeof Date.prototype.toISOString ? this.toDate().toISOString() : et(t, "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]") : et(t, "YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]")
    }

    function Ct(t) {
      return void 0 === t ? this._locale._abbr : (null != (t = u(t)) && (this._locale = t), this)
    }

    function $t() {
      return this._locale
    }

    function Lt(t, e) {
      i(0, [t, t.length], 0, e)
    }

    function Wt(t, e, n) {
      return h(v([t, 11, 31 + e - n]), e, n).week
    }

    function At(t, e) {
      i(t, 0, 0, function() {
        return this.localeData().meridiem(this.hours(), this.minutes(), e)
      })
    }

    function It(t, e) {
      return e._meridiemParse
    }

    function jt(t, e) {
      e[L] = a(1e3 * ("0." + t))
    }

    function Pt(t) {
      return t
    }

    function Bt(t, e, n, i) {
      var o = u(),
        i = B().set(i, e);
      return o[n](i, t)
    }

    function Rt(t, e, n, i, o) {
      if ("number" == typeof t && (e = t, t = void 0), t = t || "", null != e) return Bt(t, e, n, o);
      for (var r = [], s = 0; s < i; s++) r[s] = Bt(t, s, n, o);
      return r
    }

    function Xt(t, e, n, i) {
      e = g(e, n);
      return t._milliseconds += i * e._milliseconds, t._days += i * e._days, t._months += i * e._months, t._bubble()
    }

    function Ht(t) {
      return t < 0 ? Math.floor(t) : Math.ceil(t)
    }

    function qt(t) {
      return 4800 * t / 146097
    }

    function Ft(t) {
      return 146097 * t / 4800
    }

    function y(t) {
      return function() {
        return this.as(t)
      }
    }

    function b(t) {
      return function() {
        return this._data[t]
      }
    }

    function Ut(t, e, n) {
      var i = g(t).abs(),
        o = xe(i.as("s")),
        r = xe(i.as("m")),
        s = xe(i.as("h")),
        a = xe(i.as("d")),
        l = xe(i.as("M")),
        i = xe(i.as("y")),
        o = (o < A.s ? ["s", o] : 1 === r && ["m"]) || r < A.m && ["mm", r] || 1 === s && ["h"] || s < A.h && ["hh", s] || 1 === a && ["d"] || a < A.d && ["dd", a] || 1 === l && ["M"] || l < A.M && ["MM", l] || 1 === i && ["y"] || ["yy", i];
      return o[2] = e, o[3] = 0 < +t, o[4] = n,
        function(t, e, n, i, o) {
          return o.relativeTime(e || 1, !!n, t, i)
        }.apply(null, o)
    }

    function Nt() {
      var t = Ce(this._milliseconds) / 1e3,
        e = Ce(this._days),
        n = Ce(this._months),
        i = c(t / 60),
        o = c(i / 60),
        r = (t %= 60, i %= 60, c(n / 12)),
        n = n %= 12,
        s = this.asSeconds();
      return s ? (s < 0 ? "-" : "") + "P" + (r ? r + "Y" : "") + (n ? n + "M" : "") + (e ? e + "D" : "") + (o || i || t ? "T" : "") + (o ? o + "H" : "") + (i ? i + "M" : "") + (t ? t + "S" : "") : "P0D"
    }
    var Gt, zt, w, Vt = f.momentProperties = [],
      Zt = !1,
      _ = {},
      Kt = {},
      Jt = /(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Q|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,
      Qt = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g,
      te = {},
      ee = {},
      ne = /\d/,
      S = /\d\d/,
      k = /\d{3}/,
      ie = /\d{4}/,
      oe = /[+-]?\d{6}/,
      M = /\d\d?/,
      re = /\d{1,3}/,
      se = /\d{1,4}/,
      D = /[+-]?\d{1,6}/,
      ae = /\d+/,
      le = /[+-]?\d+/,
      ce = /Z|[+-]\d\d:?\d\d/gi,
      O = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i,
      ue = {},
      de = {},
      T = 0,
      Y = 1,
      E = 2,
      x = 3,
      C = 4,
      $ = 5,
      L = 6,
      he = (i("M", ["MM", 2], "Mo", function() {
        return this.month() + 1
      }), i("MMM", 0, 0, function(t) {
        return this.localeData().monthsShort(this, t)
      }), i("MMMM", 0, 0, function(t) {
        return this.localeData().months(this, t)
      }), t("month", "M"), n("M", M), n("MM", M, S), n("MMM", O), n("MMMM", O), s(["M", "MM"], function(t, e) {
        e[Y] = a(t) - 1
      }), s(["MMM", "MMMM"], function(t, e, n, i) {
        i = n._locale.monthsParse(t, i, n._strict);
        null != i ? e[Y] = i : m(n).invalidMonth = t
      }), "January_February_March_April_May_June_July_August_September_October_November_December".split("_")),
      fe = "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
      pe = {},
      me = (f.suppressDeprecationWarnings = !1, /^\s*(?:[+-]\d{6}|\d{4})-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d+)?)?)?)?([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/),
      ve = [
        ["YYYYYY-MM-DD", /[+-]\d{6}-\d{2}-\d{2}/],
        ["YYYY-MM-DD", /\d{4}-\d{2}-\d{2}/],
        ["GGGG-[W]WW-E", /\d{4}-W\d{2}-\d/],
        ["GGGG-[W]WW", /\d{4}-W\d{2}/],
        ["YYYY-DDD", /\d{4}-\d{3}/]
      ],
      ge = [
        ["HH:mm:ss.SSSS", /(T| )\d\d:\d\d:\d\d\.\d+/],
        ["HH:mm:ss", /(T| )\d\d:\d\d:\d\d/],
        ["HH:mm", /(T| )\d\d:\d\d/],
        ["HH", /(T| )\d\d/]
      ],
      ye = /^\/?Date\((\-?\d+)/i,
      be = (f.createFromInputFallback = o("moment construction falls back to js Date. This is discouraged and will be removed in upcoming major release. Please refer to https://github.com/moment/moment/issues/1407 for more info.", function(t) {
        t._d = new Date(t._i + (t._useUTC ? " UTC" : ""))
      }), i(0, ["YY", 2], 0, function() {
        return this.year() % 100
      }), i(0, ["YYYY", 4], 0, "year"), i(0, ["YYYYY", 5], 0, "year"), i(0, ["YYYYYY", 6, !0], 0, "year"), t("year", "y"), n("Y", le), n("YY", M, S), n("YYYY", se, ie), n("YYYYY", D, oe), n("YYYYYY", D, oe), s(["YYYYY", "YYYYYY"], T), s("YYYY", function(t, e) {
        e[T] = 2 === t.length ? f.parseTwoDigitYear(t) : a(t)
      }), s("YY", function(t, e) {
        e[T] = f.parseTwoDigitYear(t)
      }), e("FullYear", !(f.parseTwoDigitYear = function(t) {
        return a(t) + (68 < a(t) ? 1900 : 2e3)
      }))),
      we = (i("w", ["ww", 2], "wo", "week"), i("W", ["WW", 2], "Wo", "isoWeek"), t("week", "w"), t("isoWeek", "W"), n("w", M), n("ww", M, S), n("W", M), n("WW", M, S), it(["w", "ww", "W", "WW"], function(t, e, n, i) {
        e[i.substr(0, 1)] = a(t)
      }), i("DDD", ["DDDD", 3], "DDDo", "dayOfYear"), t("dayOfYear", "DDD"), n("DDD", re), n("DDDD", k), s(["DDD", "DDDD"], function(t, e, n) {
        n._dayOfYear = a(t)
      }), f.ISO_8601 = function() {}, o("moment().min is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548", function() {
        var t = v.apply(null, arguments);
        return t < this ? this : t
      })),
      _e = o("moment().max is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548", function() {
        var t = v.apply(null, arguments);
        return this < t ? this : t
      }),
      Se = (St("Z", ":"), St("ZZ", ""), n("Z", ce), n("ZZ", ce), s(["Z", "ZZ"], function(t, e, n) {
        n._useUTC = !0, n._tzm = kt(t)
      }), /([\+\-]|\d\d)/gi),
      ke = (f.updateOffset = function() {}, /(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/),
      Me = /^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/,
      De = (g.fn = wt.prototype, Yt(1, "add")),
      Oe = Yt(-1, "subtract"),
      Te = (f.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ", o("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", function(t) {
        return void 0 === t ? this.localeData() : this.locale(t)
      })),
      se = (i(0, ["gg", 2], 0, function() {
        return this.weekYear() % 100
      }), i(0, ["GG", 2], 0, function() {
        return this.isoWeekYear() % 100
      }), Lt("gggg", "weekYear"), Lt("ggggg", "weekYear"), Lt("GGGG", "isoWeekYear"), Lt("GGGGG", "isoWeekYear"), t("weekYear", "gg"), t("isoWeekYear", "GG"), n("G", le), n("g", le), n("GG", M, S), n("gg", M, S), n("GGGG", se, ie), n("gggg", se, ie), n("GGGGG", D, oe), n("ggggg", D, oe), it(["gggg", "ggggg", "GGGG", "GGGGG"], function(t, e, n, i) {
        e[i.substr(0, 2)] = a(t)
      }), it(["gg", "GG"], function(t, e, n, i) {
        e[i] = f.parseTwoDigitYear(t)
      }), i("Q", 0, 0, "quarter"), t("quarter", "Q"), n("Q", ne), s("Q", function(t, e) {
        e[Y] = 3 * (a(t) - 1)
      }), i("D", ["DD", 2], "Do", "date"), t("date", "D"), n("D", M), n("DD", M, S), n("Do", function(t, e) {
        return t ? e._ordinalParse : e._ordinalParseLenient
      }), s(["D", "DD"], E), s("Do", function(t, e) {
        e[E] = a(t.match(M)[0])
      }), e("Date", !0)),
      ie = (i("d", 0, "do", "day"), i("dd", 0, 0, function(t) {
        return this.localeData().weekdaysMin(this, t)
      }), i("ddd", 0, 0, function(t) {
        return this.localeData().weekdaysShort(this, t)
      }), i("dddd", 0, 0, function(t) {
        return this.localeData().weekdays(this, t)
      }), i("e", 0, 0, "weekday"), i("E", 0, 0, "isoWeekday"), t("day", "d"), t("weekday", "e"), t("isoWeekday", "E"), n("d", M), n("e", M), n("E", M), n("dd", O), n("ddd", O), n("dddd", O), it(["dd", "ddd", "dddd"], function(t, e, n) {
        var i = n._locale.weekdaysParse(t);
        null != i ? e.d = i : m(n).invalidWeekday = t
      }), it(["d", "e", "E"], function(t, e, n, i) {
        e[i] = a(t)
      }), "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_")),
      D = "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
      oe = "Su_Mo_Tu_We_Th_Fr_Sa".split("_"),
      O = (i("H", ["HH", 2], 0, "hour"), i("h", ["hh", 2], 0, function() {
        return this.hours() % 12 || 12
      }), At("a", !0), At("A", !1), t("hour", "h"), n("a", It), n("A", It), n("H", M), n("h", M), n("HH", M, S), n("hh", M, S), s(["H", "HH"], x), s(["a", "A"], function(t, e, n) {
        n._isPm = n._locale.isPM(t), n._meridiem = t
      }), s(["h", "hh"], function(t, e, n) {
        e[x] = a(t), m(n).bigHour = !0
      }), e("Hours", !0)),
      Ye = (i("m", ["mm", 2], 0, "minute"), t("minute", "m"), n("m", M), n("mm", M, S), s(["m", "mm"], C), e("Minutes", !1)),
      Ee = (i("s", ["ss", 2], 0, "second"), t("second", "s"), n("s", M), n("ss", M, S), s(["s", "ss"], $), e("Seconds", !1));
    for (i("S", 0, 0, function() {
        return ~~(this.millisecond() / 100)
      }), i(0, ["SS", 2], 0, function() {
        return ~~(this.millisecond() / 10)
      }), i(0, ["SSS", 3], 0, "millisecond"), i(0, ["SSSS", 4], 0, function() {
        return 10 * this.millisecond()
      }), i(0, ["SSSSS", 5], 0, function() {
        return 100 * this.millisecond()
      }), i(0, ["SSSSSS", 6], 0, function() {
        return 1e3 * this.millisecond()
      }), i(0, ["SSSSSSS", 7], 0, function() {
        return 1e4 * this.millisecond()
      }), i(0, ["SSSSSSSS", 8], 0, function() {
        return 1e5 * this.millisecond()
      }), i(0, ["SSSSSSSSS", 9], 0, function() {
        return 1e6 * this.millisecond()
      }), t("millisecond", "ms"), n("S", re, ne), n("SS", re, S), n("SSS", re, k), w = "SSSS"; w.length <= 9; w += "S") n(w, ae);
    for (w = "S"; w.length <= 9; w += "S") s(w, jt);
    var ne = e("Milliseconds", !1),
      S = (i("z", 0, 0, "zoneAbbr"), i("zz", 0, 0, "zoneName"), q.prototype),
      re = (S.add = De, S.calendar = function(t, e) {
        var n = Mt(t = t || v(), this).startOf("day"),
          n = (n = this.diff(n, "days", !0)) < -6 ? "sameElse" : n < -1 ? "lastWeek" : n < 0 ? "lastDay" : n < 1 ? "sameDay" : n < 2 ? "nextDay" : n < 7 ? "nextWeek" : "sameElse";
        return this.format(e && e[n] || this.localeData().calendar(n, this, v(t)))
      }, S.clone = function() {
        return new q(this)
      }, S.diff = function(t, e, n) {
        var i, o, r, s, a, l = 6e4 * ((t = Mt(t, this)).utcOffset() - this.utcOffset());
        return "year" === (e = d(e)) || "month" === e || "quarter" === e ? (i = this, s = 12 * ((o = t).year() - i.year()) + (o.month() - i.month()), a = i.clone().add(s, "months"), i = o - a < 0 ? (r = i.clone().add(s - 1, "months"), (o - a) / (a - r)) : (r = i.clone().add(1 + s, "months"), (o - a) / (r - a)), o = -(s + i), "quarter" === e ? o /= 3 : "year" === e && (o /= 12)) : (r = this - t, o = "second" === e ? r / 1e3 : "minute" === e ? r / 6e4 : "hour" === e ? r / 36e5 : "day" === e ? (r - l) / 864e5 : "week" === e ? (r - l) / 6048e5 : r), n ? o : c(o)
      }, S.endOf = function(t) {
        return void 0 === (t = d(t)) || "millisecond" === t ? this : this.startOf(t).add(1, "isoWeek" === t ? "week" : t).subtract(1, "ms")
      }, S.format = function(t) {
        return t = et(this, t || f.defaultFormat), this.localeData().postformat(t)
      }, S.from = function(t, e) {
        return this.isValid() ? g({
          to: this,
          from: t
        }).locale(this.locale()).humanize(!e) : this.localeData().invalidDate()
      }, S.fromNow = function(t) {
        return this.from(v(), t)
      }, S.to = function(t, e) {
        return this.isValid() ? g({
          from: this,
          to: t
        }).locale(this.locale()).humanize(!e) : this.localeData().invalidDate()
      }, S.toNow = function(t) {
        return this.to(v(), t)
      }, S.get = Q, S.invalidAt = function() {
        return m(this).overflow
      }, S.isAfter = function(t, e) {
        return "millisecond" === (e = d(void 0 !== e ? e : "millisecond")) ? +(t = r(t) ? t : v(t)) < +this : (r(t) ? +t : +v(t)) < +this.clone().startOf(e)
      }, S.isBefore = function(t, e) {
        return "millisecond" === (e = d(void 0 !== e ? e : "millisecond")) ? +this < +(t = r(t) ? t : v(t)) : (t = r(t) ? +t : +v(t), +this.clone().endOf(e) < t)
      }, S.isBetween = function(t, e, n) {
        return this.isAfter(t, n) && this.isBefore(e, n)
      }, S.isSame = function(t, e) {
        return "millisecond" === (e = d(e || "millisecond")) ? +this == +(t = r(t) ? t : v(t)) : (t = +v(t), +this.clone().startOf(e) <= t && t <= +this.clone().endOf(e))
      }, S.isValid = function() {
        return R(this)
      }, S.lang = Te, S.locale = Ct, S.localeData = $t, S.max = _e, S.min = we, S.parsingFlags = function() {
        return P({}, m(this))
      }, S.set = Q, S.startOf = function(t) {
        switch (t = d(t)) {
          case "year":
            this.month(0);
          case "quarter":
          case "month":
            this.date(1);
          case "week":
          case "isoWeek":
          case "day":
            this.hours(0);
          case "hour":
            this.minutes(0);
          case "minute":
            this.seconds(0);
          case "second":
            this.milliseconds(0)
        }
        return "week" === t && this.weekday(0), "isoWeek" === t && this.isoWeekday(1), "quarter" === t && this.month(3 * Math.floor(this.month() / 3)), this
      }, S.subtract = Oe, S.toArray = function() {
        var t = this;
        return [t.year(), t.month(), t.date(), t.hour(), t.minute(), t.second(), t.millisecond()]
      }, S.toObject = function() {
        var t = this;
        return {
          years: t.year(),
          months: t.month(),
          date: t.date(),
          hours: t.hours(),
          minutes: t.minutes(),
          seconds: t.seconds(),
          milliseconds: t.milliseconds()
        }
      }, S.toDate = function() {
        return this._offset ? new Date(+this) : this._d
      }, S.toISOString = xt, S.toJSON = xt, S.toString = function() {
        return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")
      }, S.unix = function() {
        return Math.floor(+this / 1e3)
      }, S.valueOf = function() {
        return +this._d - 6e4 * (this._offset || 0)
      }, S.year = be, S.isLeapYear = function() {
        return ft(this.year())
      }, S.weekYear = function(t) {
        var e = h(this, this.localeData()._week.dow, this.localeData()._week.doy).year;
        return null == t ? e : this.add(t - e, "y")
      }, S.isoWeekYear = function(t) {
        var e = h(this, 1, 4).year;
        return null == t ? e : this.add(t - e, "y")
      }, S.quarter = S.quarters = function(t) {
        return null == t ? Math.ceil((this.month() + 1) / 3) : this.month(3 * (t - 1) + this.month() % 3)
      }, S.month = st, S.daysInMonth = function() {
        return ot(this.year(), this.month())
      }, S.week = S.weeks = function(t) {
        var e = this.localeData().week(this);
        return null == t ? e : this.add(7 * (t - e), "d")
      }, S.isoWeek = S.isoWeeks = function(t) {
        var e = h(this, 1, 4).week;
        return null == t ? e : this.add(7 * (t - e), "d")
      }, S.weeksInYear = function() {
        var t = this.localeData()._week;
        return Wt(this.year(), t.dow, t.doy)
      }, S.isoWeeksInYear = function() {
        return Wt(this.year(), 1, 4)
      }, S.date = se, S.day = S.days = function(t) {
        var e, n, i = this._isUTC ? this._d.getUTCDay() : this._d.getDay();
        return null != t ? (e = t, n = this.localeData(), t = "string" != typeof e ? e : isNaN(e) ? "number" == typeof(e = n.weekdaysParse(e)) ? e : null : parseInt(e, 10), this.add(t - i, "d")) : i
      }, S.weekday = function(t) {
        var e = (this.day() + 7 - this.localeData()._week.dow) % 7;
        return null == t ? e : this.add(t - e, "d")
      }, S.isoWeekday = function(t) {
        return null == t ? this.day() || 7 : this.day(this.day() % 7 ? t : t - 7)
      }, S.dayOfYear = function(t) {
        var e = Math.round((this.clone().startOf("day") - this.clone().startOf("year")) / 864e5) + 1;
        return null == t ? e : this.add(t - e, "d")
      }, S.hour = S.hours = O, S.minute = S.minutes = Ye, S.second = S.seconds = Ee, S.millisecond = S.milliseconds = ne, S.utcOffset = function(t, e) {
        var n, i = this._offset || 0;
        return null != t ? ("string" == typeof t && (t = kt(t)), Math.abs(t) < 16 && (t *= 60), !this._isUTC && e && (n = Dt(this)), this._offset = t, this._isUTC = !0, null != n && this.add(n, "m"), i !== t && (!e || this._changeInProgress ? Et(this, g(t - i, "m"), 1, !1) : this._changeInProgress || (this._changeInProgress = !0, f.updateOffset(this, !0), this._changeInProgress = null)), this) : this._isUTC ? i : Dt(this)
      }, S.utc = function(t) {
        return this.utcOffset(0, t)
      }, S.local = function(t) {
        return this._isUTC && (this.utcOffset(0, t), this._isUTC = !1, t && this.subtract(Dt(this), "m")), this
      }, S.parseZone = function() {
        return this._tzm ? this.utcOffset(this._tzm) : "string" == typeof this._i && this.utcOffset(kt(this._i)), this
      }, S.hasAlignedHourOffset = function(t) {
        return t = t ? v(t).utcOffset() : 0, (this.utcOffset() - t) % 60 == 0
      }, S.isDST = function() {
        return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset()
      }, S.isDSTShifted = function() {
        if (void 0 !== this._isDSTShifted) return this._isDSTShifted;
        var t, e = {};
        return H(e, this), (e = gt(e))._a ? (t = (e._isUTC ? B : v)(e._a), this._isDSTShifted = this.isValid() && 0 < F(e._a, t.toArray())) : this._isDSTShifted = !1, this._isDSTShifted
      }, S.isLocal = function() {
        return !this._isUTC
      }, S.isUtcOffset = function() {
        return this._isUTC
      }, S.isUtc = Ot, S.isUTC = Ot, S.zoneAbbr = function() {
        return this._isUTC ? "UTC" : ""
      }, S.zoneName = function() {
        return this._isUTC ? "Coordinated Universal Time" : ""
      }, S.dates = o("dates accessor is deprecated. Use date instead.", se), S.months = o("months accessor is deprecated. Use month instead", st), S.years = o("years accessor is deprecated. Use year instead", be), S.zone = o("moment().zone is deprecated, use moment().utcOffset instead. https://github.com/moment/moment/issues/1779", function(t, e) {
        return null != t ? (this.utcOffset(t = "string" != typeof t ? -t : t, e), this) : -this.utcOffset()
      }), S),
      k = U.prototype,
      W = (k._calendar = {
        sameDay: "[Today at] LT",
        nextDay: "[Tomorrow at] LT",
        nextWeek: "dddd [at] LT",
        lastDay: "[Yesterday at] LT",
        lastWeek: "[Last] dddd [at] LT",
        sameElse: "L"
      }, k.calendar = function(t, e, n) {
        return "function" == typeof(t = this._calendar[t]) ? t.call(e, n) : t
      }, k._longDateFormat = {
        LTS: "h:mm:ss A",
        LT: "h:mm A",
        L: "MM/DD/YYYY",
        LL: "MMMM D, YYYY",
        LLL: "MMMM D, YYYY h:mm A",
        LLLL: "dddd, MMMM D, YYYY h:mm A"
      }, k.longDateFormat = function(t) {
        var e = this._longDateFormat[t],
          n = this._longDateFormat[t.toUpperCase()];
        return e || !n ? e : (this._longDateFormat[t] = n.replace(/MMMM|MM|DD|dddd/g, function(t) {
          return t.slice(1)
        }), this._longDateFormat[t])
      }, k._invalidDate = "Invalid date", k.invalidDate = function() {
        return this._invalidDate
      }, k._ordinal = "%d", k.ordinal = function(t) {
        return this._ordinal.replace("%d", t)
      }, k._ordinalParse = /\d{1,2}/, k.preparse = Pt, k.postformat = Pt, k._relativeTime = {
        future: "in %s",
        past: "%s ago",
        s: "a few seconds",
        m: "a minute",
        mm: "%d minutes",
        h: "an hour",
        hh: "%d hours",
        d: "a day",
        dd: "%d days",
        M: "a month",
        MM: "%d months",
        y: "a year",
        yy: "%d years"
      }, k.relativeTime = function(t, e, n, i) {
        var o = this._relativeTime[n];
        return "function" == typeof o ? o(t, e, n, i) : o.replace(/%d/i, t)
      }, k.pastFuture = function(t, e) {
        return "function" == typeof(t = this._relativeTime[0 < t ? "future" : "past"]) ? t(e) : t.replace(/%s/i, e)
      }, k.set = function(t) {
        var e, n;
        for (n in t) e = t[n], "function" == typeof e ? this[n] = e : this["_" + n] = e;
        this._ordinalParseLenient = new RegExp(this._ordinalParse.source + "|" + /\d{1,2}/.source)
      }, k.months = function(t) {
        return this._months[t.month()]
      }, k._months = he, k.monthsShort = function(t) {
        return this._monthsShort[t.month()]
      }, k._monthsShort = fe, k.monthsParse = function(t, e, n) {
        var i, o;
        for (this._monthsParse || (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = []), i = 0; i < 12; i++) {
          if (o = B([2e3, i]), n && !this._longMonthsParse[i] && (this._longMonthsParse[i] = new RegExp("^" + this.months(o, "").replace(".", "") + "$", "i"), this._shortMonthsParse[i] = new RegExp("^" + this.monthsShort(o, "").replace(".", "") + "$", "i")), n || this._monthsParse[i] || (o = "^" + this.months(o, "") + "|^" + this.monthsShort(o, ""), this._monthsParse[i] = new RegExp(o.replace(".", ""), "i")), n && "MMMM" === e && this._longMonthsParse[i].test(t)) return i;
          if (n && "MMM" === e && this._shortMonthsParse[i].test(t)) return i;
          if (!n && this._monthsParse[i].test(t)) return i
        }
      }, k.week = function(t) {
        return h(t, this._week.dow, this._week.doy).week
      }, k._week = {
        dow: 0,
        doy: 6
      }, k.firstDayOfYear = function() {
        return this._week.doy
      }, k.firstDayOfWeek = function() {
        return this._week.dow
      }, k.weekdays = function(t) {
        return this._weekdays[t.day()]
      }, k._weekdays = ie, k.weekdaysMin = function(t) {
        return this._weekdaysMin[t.day()]
      }, k._weekdaysMin = oe, k.weekdaysShort = function(t) {
        return this._weekdaysShort[t.day()]
      }, k._weekdaysShort = D, k.weekdaysParse = function(t) {
        var e, n;
        for (this._weekdaysParse = this._weekdaysParse || [], e = 0; e < 7; e++)
          if (this._weekdaysParse[e] || (n = v([2e3, 1]).day(e), n = "^" + this.weekdays(n, "") + "|^" + this.weekdaysShort(n, "") + "|^" + this.weekdaysMin(n, ""), this._weekdaysParse[e] = new RegExp(n.replace(".", ""), "i")), this._weekdaysParse[e].test(t)) return e
      }, k.isPM = function(t) {
        return "p" === (t + "").toLowerCase().charAt(0)
      }, k._meridiemParse = /[ap]\.?m?\.?/i, k.meridiem = function(t, e, n) {
        return 11 < t ? n ? "pm" : "PM" : n ? "am" : "AM"
      }, z("en", {
        ordinalParse: /\d{1,2}(th|st|nd|rd)/,
        ordinal: function(t) {
          var e = t % 10;
          return t + (1 === a(t % 100 / 10) ? "th" : 1 == e ? "st" : 2 == e ? "nd" : 3 == e ? "rd" : "th")
        }
      }), f.lang = o("moment.lang is deprecated. Use moment.locale instead.", z), f.langData = o("moment.langData is deprecated. Use moment.localeData instead.", u), Math.abs),
      De = y("ms"),
      _e = y("s"),
      we = y("m"),
      Oe = y("h"),
      O = y("d"),
      Ye = y("w"),
      Ee = y("M"),
      ne = y("y"),
      se = b("milliseconds"),
      be = b("seconds"),
      S = b("minutes"),
      he = b("hours"),
      fe = b("days"),
      ie = b("months"),
      oe = b("years"),
      xe = Math.round,
      A = {
        s: 45,
        m: 45,
        h: 22,
        d: 26,
        M: 11
      },
      Ce = Math.abs,
      D = wt.prototype;
    return D.abs = function() {
      var t = this._data;
      return this._milliseconds = W(this._milliseconds), this._days = W(this._days), this._months = W(this._months), t.milliseconds = W(t.milliseconds), t.seconds = W(t.seconds), t.minutes = W(t.minutes), t.hours = W(t.hours), t.months = W(t.months), t.years = W(t.years), this
    }, D.add = function(t, e) {
      return Xt(this, t, e, 1)
    }, D.subtract = function(t, e) {
      return Xt(this, t, e, -1)
    }, D.as = function(t) {
      var e, n, i = this._milliseconds;
      if ("month" === (t = d(t)) || "year" === t) return e = this._days + i / 864e5, n = this._months + qt(e), "month" === t ? n : n / 12;
      switch (e = this._days + Math.round(Ft(this._months)), t) {
        case "week":
          return e / 7 + i / 6048e5;
        case "day":
          return e + i / 864e5;
        case "hour":
          return 24 * e + i / 36e5;
        case "minute":
          return 1440 * e + i / 6e4;
        case "second":
          return 86400 * e + i / 1e3;
        case "millisecond":
          return Math.floor(864e5 * e) + i;
        default:
          throw new Error("Unknown unit " + t)
      }
    }, D.asMilliseconds = De, D.asSeconds = _e, D.asMinutes = we, D.asHours = Oe, D.asDays = O, D.asWeeks = Ye, D.asMonths = Ee, D.asYears = ne, D.valueOf = function() {
      return this._milliseconds + 864e5 * this._days + this._months % 12 * 2592e6 + 31536e6 * a(this._months / 12)
    }, D._bubble = function() {
      var t = this._milliseconds,
        e = this._days,
        n = this._months,
        i = this._data;
      return 0 <= t && 0 <= e && 0 <= n || t <= 0 && e <= 0 && n <= 0 || (t += 864e5 * Ht(Ft(n) + e), n = e = 0), i.milliseconds = t % 1e3, t = c(t / 1e3), i.seconds = t % 60, t = c(t / 60), i.minutes = t % 60, t = c(t / 60), i.hours = t % 24, e += c(t / 24), n += t = c(qt(e)), e -= Ht(Ft(t)), t = c(n / 12), n %= 12, i.days = e, i.months = n, i.years = t, this
    }, D.get = function(t) {
      return this[(t = d(t)) + "s"]()
    }, D.milliseconds = se, D.seconds = be, D.minutes = S, D.hours = he, D.days = fe, D.weeks = function() {
      return c(this.days() / 7)
    }, D.months = ie, D.years = oe, D.humanize = function(t) {
      var e = this.localeData(),
        n = Ut(this, !t, e);
      return t && (n = e.pastFuture(+this, n)), e.postformat(n)
    }, D.toISOString = Nt, D.toString = Nt, D.toJSON = Nt, D.locale = Ct, D.localeData = $t, D.toIsoString = o("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", Nt), D.lang = Te, i("X", 0, 0, "unix"), i("x", 0, 0, "valueOf"), n("x", le), n("X", /[+-]?\d+(\.\d{1,3})?/), s("X", function(t, e, n) {
      n._d = new Date(1e3 * parseFloat(t, 10))
    }), s("x", function(t, e, n) {
      n._d = new Date(a(t))
    }), f.version = "2.10.6", Gt = v, f.fn = re, f.min = function() {
      return bt("isBefore", [].slice.call(arguments, 0))
    }, f.max = function() {
      return bt("isAfter", [].slice.call(arguments, 0))
    }, f.utc = B, f.unix = function(t) {
      return v(1e3 * t)
    }, f.months = function(t, e) {
      return Rt(t, e, "months", 12, "month")
    }, f.isDate = j, f.locale = z, f.invalid = X, f.duration = g, f.isMoment = r, f.weekdays = function(t, e) {
      return Rt(t, e, "weekdays", 7, "day")
    }, f.parseZone = function() {
      return v.apply(null, arguments).parseZone()
    }, f.localeData = u, f.isDuration = _t, f.monthsShort = function(t, e) {
      return Rt(t, e, "monthsShort", 12, "month")
    }, f.weekdaysMin = function(t, e) {
      return Rt(t, e, "weekdaysMin", 7, "day")
    }, f.defineLocale = V, f.weekdaysShort = function(t, e) {
      return Rt(t, e, "weekdaysShort", 7, "day")
    }, f.normalizeUnits = d, f.relativeTimeThreshold = function(t, e) {
      return void 0 !== A[t] && (void 0 === e ? A[t] : (A[t] = e, !0))
    }, f
  }),
  function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? e(require("../moment")) : "function" == typeof define && define.amd ? define(["moment"], e) : e(t.moment)
  }(this, function(t) {
    "use strict";
    return t.defineLocale("pt-br", {
      months: "Janeiro_Fevereiro_Março_Abril_Maio_Junho_Julho_Agosto_Setembro_Outubro_Novembro_Dezembro".split("_"),
      monthsShort: "Jan_Fev_Mar_Abr_Mai_Jun_Jul_Ago_Set_Out_Nov_Dez".split("_"),
      weekdays: "Domingo_Segunda-Feira_Terça-Feira_Quarta-Feira_Quinta-Feira_Sexta-Feira_Sábado".split("_"),
      weekdaysShort: "Dom_Seg_Ter_Qua_Qui_Sex_Sáb".split("_"),
      weekdaysMin: "Dom_2ª_3ª_4ª_5ª_6ª_Sáb".split("_"),
      longDateFormat: {
        LT: "HH:mm",
        LTS: "HH:mm:ss",
        L: "DD/MM/YYYY",
        LL: "D [de] MMMM [de] YYYY",
        LLL: "D [de] MMMM [de] YYYY [às] HH:mm",
        LLLL: "dddd, D [de] MMMM [de] YYYY [às] HH:mm"
      },
      calendar: {
        sameDay: "[Hoje às] LT",
        nextDay: "[Amanhã às] LT",
        nextWeek: "dddd [às] LT",
        lastDay: "[Ontem às] LT",
        lastWeek: function() {
          return 0 === this.day() || 6 === this.day() ? "[Último] dddd [às] LT" : "[Última] dddd [às] LT"
        },
        sameElse: "L"
      },
      relativeTime: {
        future: "em %s",
        past: "%s atrás",
        s: "poucos segundos",
        m: "um minuto",
        mm: "%d minutos",
        h: "uma hora",
        hh: "%d horas",
        d: "um dia",
        dd: "%d dias",
        M: "um mês",
        MM: "%d meses",
        y: "um ano",
        yy: "%d anos"
      },
      ordinalParse: /\d{1,2}º/,
      ordinal: "%dº"
    })
  }),
  function(t) {
    "function" == typeof define && define.amd ? define(["jquery", "moment"], t) : "object" == typeof exports ? t(require("jquery"), require("moment")) : t(jQuery, moment)
  }(function(h, f) {
    function e(t, e) {
      this.element = t, this.options = h.extend(!0, {}, n, e), this.options.moment && (f = this.options.moment), this.options.events.length && (this.options.multiDayEvents ? this.options.events = this.addMultiDayMomentObjectsToEvents(this.options.events) : this.options.events = this.addMomentObjectToEvents(this.options.events)), this.options.lengthOfTime.months || this.options.lengthOfTime.days ? this.options.lengthOfTime.months ? (this.options.lengthOfTime.days = null, this.options.lengthOfTime.startDate ? this.intervalStart = f(this.options.lengthOfTime.startDate).startOf("month") : this.options.startWithMonth ? this.intervalStart = f(this.options.startWithMonth).startOf("month") : this.intervalStart = f().startOf("month"), this.intervalEnd = f(this.intervalStart).add(this.options.lengthOfTime.months, "months").subtract(1, "days"), this.month = this.intervalStart.clone()) : this.options.lengthOfTime.days && (this.options.lengthOfTime.startDate ? this.intervalStart = f(this.options.lengthOfTime.startDate).startOf("day") : this.intervalStart = f().weekday(0).startOf("day"), this.intervalEnd = f(this.intervalStart).add(this.options.lengthOfTime.days - 1, "days").endOf("day"), this.month = this.intervalStart.clone()) : (this.month = f().startOf("month"), this.intervalStart = f(this.month), this.intervalEnd = f(this.month).endOf("month")), this.options.startWithMonth && (this.month = f(this.options.startWithMonth).startOf("month"), this.intervalStart = f(this.month), this.intervalEnd = f(this.month).endOf("month")), this.options.constraints && (this.options.constraints.startDate && (t = f(this.options.constraints.startDate), this.intervalStart.isBefore(t, "month") && (this.intervalStart.set("month", t.month()).set("year", t.year()), this.month.set("month", t.month()).set("year", t.year()))), this.options.constraints.endDate && (e = f(this.options.constraints.endDate), this.intervalEnd.isAfter(e, "month") && (this.intervalEnd.set("month", e.month()).set("year", e.year()), this.month.set("month", e.month()).set("year", e.year())))), this._defaults = n, this._name = "clndr", this.init()
    }
    var n = {
      template: "<div class='clndr-controls'><div class='clndr-control-button'><span class='clndr-previous-button'>previous</span></div><div class='month'><%= month %> <%= year %></div><div class='clndr-control-button rightalign'><span class='clndr-next-button'>next</span></div></div><table class='clndr-table' border='0' cellspacing='0' cellpadding='0'><thead><tr class='header-days'><% for(var i = 0; i < daysOfTheWeek.length; i++) { %><td class='header-day'><%= daysOfTheWeek[i] %></td><% } %></tr></thead><tbody><% for(var i = 0; i < numberOfRows; i++){ %><tr><% for(var j = 0; j < 7; j++){ %><% var d = j + i * 7; %><td class='<%= days[d].classes %>'><div class='day-contents'><%= days[d].day %></div></td><% } %></tr><% } %></tbody></table>",
      weekOffset: 0,
      startWithMonth: null,
      clickEvents: {
        click: null,
        nextMonth: null,
        previousMonth: null,
        nextYear: null,
        previousYear: null,
        today: null,
        onMonthChange: null,
        onYearChange: null
      },
      targets: {
        nextButton: "clndr-next-button",
        previousButton: "clndr-previous-button",
        nextYearButton: "clndr-next-year-button",
        previousYearButton: "clndr-previous-year-button",
        todayButton: "clndr-today-button",
        day: "day",
        empty: "empty"
      },
      classes: {
        today: "today",
        event: "event",
        past: "past",
        lastMonth: "last-month",
        nextMonth: "next-month",
        adjacentMonth: "adjacent-month",
        inactive: "inactive",
        selected: "selected"
      },
      events: [],
      extras: null,
      dateParameter: "date",
      multiDayEvents: null,
      doneRendering: null,
      render: null,
      daysOfTheWeek: null,
      showAdjacentMonths: !0,
      adjacentDaysChangeMonth: !1,
      ready: null,
      constraints: null,
      forceSixRows: null,
      trackSelectedDate: !1,
      selectedDate: null,
      ignoreInactiveDaysInSelection: null,
      lengthOfTime: {
        months: null,
        days: null,
        interval: 1
      },
      moment: null
    };
    e.prototype.init = function() {
      if (this.daysOfTheWeek = this.options.daysOfTheWeek || [], !this.options.daysOfTheWeek) {
        this.daysOfTheWeek = [];
        for (var t = 0; t < 7; t++) this.daysOfTheWeek.push(f().weekday(t).format("dd").charAt(0))
      }
      if (this.options.weekOffset && (this.daysOfTheWeek = this.shiftWeekdayLabels(this.options.weekOffset)), !h.isFunction(this.options.render)) {
        if (this.options.render = null, "undefined" == typeof _) throw new Error("Underscore was not found. Please include underscore.js OR provide a custom render function.");
        this.compiledClndrTemplate = _.template(this.options.template)
      }
      h(this.element).html("<div class='clndr'></div>"), this.calendarContainer = h(".clndr", this.element), this.bindEvents(), this.render(), this.options.ready && this.options.ready.apply(this, [])
    }, e.prototype.shiftWeekdayLabels = function(t) {
      for (var e = this.daysOfTheWeek, n = 0; n < t; n++) e.push(e.shift());
      return e
    }, e.prototype.createDaysObject = function(t, e) {
      var n, i, o, r, s = [],
        a = t.clone();
      if (e.diff(t, "days"), this._currentIntervalStart = t.clone(), this.eventsLastMonth = [], this.eventsThisInterval = [], this.eventsNextMonth = [], this.options.events.length && (this.eventsThisInterval = h(this.options.events).filter(function() {
          return !this._clndrEndDateObject.isBefore(t) && !this._clndrStartDateObject.isAfter(e)
        }).toArray(), this.options.showAdjacentMonths) && (n = t.clone().subtract(1, "months").startOf("month"), i = n.clone().endOf("month"), o = e.clone().add(1, "months").startOf("month"), r = o.clone().endOf("month"), this.eventsLastMonth = h(this.options.events).filter(function() {
          return !this._clndrEndDateObject.isBefore(n) && !this._clndrStartDateObject.isAfter(i)
        }).toArray(), this.eventsNextMonth = h(this.options.events).filter(function() {
          return !this._clndrEndDateObject.isBefore(o) && !this._clndrStartDateObject.isAfter(r)
        }).toArray()), !this.options.lengthOfTime.days) {
        var l = a.weekday() - this.options.weekOffset;
        if (l < 0 && (l += 7), this.options.showAdjacentMonths)
          for (var c = 0; c < l; c++) {
            var u = f([t.year(), t.month(), c - l + 1]);
            s.push(this.createDayObject(u, this.eventsLastMonth))
          } else
            for (c = 0; c < l; c++) s.push(this.calendarDay({
              classes: this.options.targets.empty + " " + this.options.classes.lastMonth
            }))
      }
      for (var d = t.clone(); d.isBefore(e) || d.isSame(e, "day");) s.push(this.createDayObject(d.clone(), this.eventsThisInterval)), d.add(1, "days");
      if (!this.options.lengthOfTime.days)
        for (; s.length % 7 != 0;) this.options.showAdjacentMonths ? s.push(this.createDayObject(d.clone(), this.eventsNextMonth)) : s.push(this.calendarDay({
          classes: this.options.targets.empty + " " + this.options.classes.nextMonth
        })), d.add(1, "days");
      if (this.options.forceSixRows && 42 !== s.length)
        for (; s.length < 42;) this.options.showAdjacentMonths ? (s.push(this.createDayObject(d.clone(), this.eventsNextMonth)), d.add(1, "days")) : s.push(this.calendarDay({
          classes: this.options.targets.empty + " " + this.options.classes.nextMonth
        }));
      return s
    }, e.prototype.createDayObject = function(t, e) {
      for (var n = [], i = f(), o = (!t.isValid() && t.hasOwnProperty("_d") && null != t._d && (t = f(t._d)), 0), r = e.length; o < r; o++) {
        var s = e[o]._clndrStartDateObject,
          a = e[o]._clndrEndDateObject;
        (t.isSame(s, "day") || t.isAfter(s, "day")) && (t.isSame(a, "day") || t.isBefore(a, "day")) && n.push(e[o])
      }
      var l = {
          isInactive: !1,
          isAdjacentMonth: !1,
          isToday: !1
        },
        c = "";
      return i.format("YYYY-MM-DD") == t.format("YYYY-MM-DD") && (c += " " + this.options.classes.today, l.isToday = !0), t.isBefore(i, "day") && (c += " " + this.options.classes.past), n.length && (c += " " + this.options.classes.event), this.options.lengthOfTime.days || (this._currentIntervalStart.month() > t.month() ? (c += " " + this.options.classes.adjacentMonth, l.isAdjacentMonth = !0, c += this._currentIntervalStart.year() === t.year() ? " " + this.options.classes.lastMonth : " " + this.options.classes.nextMonth) : this._currentIntervalStart.month() < t.month() && (c += " " + this.options.classes.adjacentMonth, l.isAdjacentMonth = !0, c += this._currentIntervalStart.year() === t.year() ? " " + this.options.classes.nextMonth : " " + this.options.classes.lastMonth)), this.options.constraints && (this.options.constraints.startDate && t.isBefore(f(this.options.constraints.startDate)) && (c += " " + this.options.classes.inactive, l.isInactive = !0), this.options.constraints.endDate && t.isAfter(f(this.options.constraints.endDate)) && (c += " " + this.options.classes.inactive, l.isInactive = !0)), !t.isValid() && t.hasOwnProperty("_d") && null != t._d && (t = f(t._d)), this.options.selectedDate && t.isSame(f(this.options.selectedDate), "day") && (c += " " + this.options.classes.selected), c = (c += " calendar-day-" + t.format("YYYY-MM-DD")) + (" calendar-dow-" + t.weekday()), this.calendarDay({
        day: t.date(),
        classes: this.options.targets.day + c,
        events: n,
        date: t,
        properties: l
      })
    }, e.prototype.render = function() {
      this.calendarContainer.empty();
      var t = {};
      if (this.options.lengthOfTime.days) {
        var e = this.createDaysObject(this.intervalStart.clone(), this.intervalEnd.clone());
        t = {
          daysOfTheWeek: this.daysOfTheWeek,
          numberOfRows: Math.ceil(e.length / 7),
          months: [],
          days: e,
          month: null,
          year: null,
          intervalStart: this.intervalStart.clone(),
          intervalEnd: this.intervalEnd.clone(),
          eventsThisInterval: this.eventsThisInterval,
          eventsLastMonth: [],
          eventsNextMonth: [],
          extras: this.options.extras
        }
      } else if (this.options.lengthOfTime.months) {
        var n = [],
          o = [];
        for (i = 0; i < this.options.lengthOfTime.months; i++) {
          var r = this.intervalStart.clone().add(i, "months"),
            s = r.clone().endOf("month"),
            e = this.createDaysObject(r, s);
          o.push(this.eventsThisInterval), n.push({
            month: r,
            days: e
          })
        }
        t = {
          daysOfTheWeek: this.daysOfTheWeek,
          numberOfRows: _.reduce(n, function(t, e) {
            return t + Math.ceil(e.days.length / 7)
          }, 0),
          months: n,
          days: [],
          month: null,
          year: null,
          intervalStart: this.intervalStart,
          intervalEnd: this.intervalEnd,
          eventsThisInterval: o,
          eventsLastMonth: this.eventsLastMonth,
          eventsNextMonth: this.eventsNextMonth,
          extras: this.options.extras
        }
      } else e = this.createDaysObject(this.month.clone().startOf("month"), this.month.clone().endOf("month")), t = (this.month, {
        daysOfTheWeek: this.daysOfTheWeek,
        numberOfRows: Math.ceil(e.length / 7),
        months: [],
        days: e,
        month: this.month.format("MMMM"),
        year: this.month.year(),
        eventsThisMonth: this.eventsThisInterval,
        eventsLastMonth: this.eventsLastMonth,
        eventsNextMonth: this.eventsNextMonth,
        extras: this.options.extras
      });
      if (this.options.render ? this.calendarContainer.html(this.options.render.apply(this, [t])) : this.calendarContainer.html(this.compiledClndrTemplate(t)), this.options.constraints) {
        for (var a in this.options.targets) a != this.options.targets.day && this.element.find("." + this.options.targets[a]).toggleClass(this.options.classes.inactive, !1);
        var t = null,
          l = null;
        this.options.constraints.startDate && (t = f(this.options.constraints.startDate)), this.options.constraints.endDate && (l = f(this.options.constraints.endDate)), t && (t.isAfter(this.intervalStart) || t.isSame(this.intervalStart, "day")) && this.element.find("." + this.options.targets.previousButton).toggleClass(this.options.classes.inactive, !0), l && (l.isBefore(this.intervalEnd) || l.isSame(this.intervalEnd, "day")) && this.element.find("." + this.options.targets.nextButton).toggleClass(this.options.classes.inactive, !0), t && t.isAfter(this.intervalStart.clone().subtract(1, "years")) && this.element.find("." + this.options.targets.previousYearButton).toggleClass(this.options.classes.inactive, !0), l && l.isBefore(this.intervalEnd.clone().add(1, "years")) && this.element.find("." + this.options.targets.nextYearButton).toggleClass(this.options.classes.inactive, !0), (t && t.isAfter(f(), "month") || l && l.isBefore(f(), "month")) && this.element.find("." + this.options.targets.today).toggleClass(this.options.classes.inactive, !0)
      }
      this.options.doneRendering && this.options.doneRendering.apply(this, [])
    }, e.prototype.bindEvents = function() {
      var t = h(this.element),
        n = this,
        e = "click";
      !0 === n.options.useTouchEvents && (e = "touchstart"), t.off(e + ".clndr", "." + this.options.targets.day).off(e + ".clndr", "." + this.options.targets.empty).off(e + ".clndr", "." + this.options.targets.previousButton).off(e + ".clndr", "." + this.options.targets.nextButton).off(e + ".clndr", "." + this.options.targets.todayButton).off(e + ".clndr", "." + this.options.targets.nextYearButton).off(e + ".clndr", "." + this.options.targets.previousYearButton), t.on(e + ".clndr", "." + this.options.targets.day, function(t) {
        var e;
        n.options.clickEvents.click && (e = n.buildTargetObject(t.currentTarget, !0), n.options.clickEvents.click.apply(n, [e])), n.options.adjacentDaysChangeMonth && (h(t.currentTarget).is("." + n.options.classes.lastMonth) ? n.backActionWithContext(n) : h(t.currentTarget).is("." + n.options.classes.nextMonth) && n.forwardActionWithContext(n)), !n.options.trackSelectedDate || n.options.ignoreInactiveDaysInSelection && h(t.currentTarget).hasClass("inactive") || (n.options.selectedDate = n.getTargetDateString(t.currentTarget), h(t.currentTarget).siblings().removeClass(n.options.classes.selected).end().addClass(n.options.classes.selected))
      }), t.on(e + ".clndr", "." + this.options.targets.empty, function(t) {
        var e;
        n.options.clickEvents.click && (e = n.buildTargetObject(t.currentTarget, !1), n.options.clickEvents.click.apply(n, [e])), n.options.adjacentDaysChangeMonth && (h(t.currentTarget).is("." + n.options.classes.lastMonth) ? n.backActionWithContext(n) : h(t.currentTarget).is("." + n.options.classes.nextMonth) && n.forwardActionWithContext(n))
      }), t.on(e + ".clndr", "." + this.options.targets.previousButton, {
        context: this
      }, this.backAction).on(e + ".clndr", "." + this.options.targets.nextButton, {
        context: this
      }, this.forwardAction).on(e + ".clndr", "." + this.options.targets.todayButton, {
        context: this
      }, this.todayAction).on(e + ".clndr", "." + this.options.targets.nextYearButton, {
        context: this
      }, this.nextYearAction).on(e + ".clndr", "." + this.options.targets.previousYearButton, {
        context: this
      }, this.previousYearAction)
    }, e.prototype.buildTargetObject = function(t, e) {
      var n, i = {
        element: t,
        events: [],
        date: null
      };
      return e && (n = this.getTargetDateString(t), i.date = n ? f(n) : null, this.options.events && (this.options.multiDayEvents ? i.events = h.makeArray(h(this.options.events).filter(function() {
        return (i.date.isSame(this._clndrStartDateObject, "day") || i.date.isAfter(this._clndrStartDateObject, "day")) && (i.date.isSame(this._clndrEndDateObject, "day") || i.date.isBefore(this._clndrEndDateObject, "day"))
      })) : i.events = h.makeArray(h(this.options.events).filter(function() {
        return this._clndrStartDateObject.format("YYYY-MM-DD") == n
      })))), i
    }, e.prototype.getTargetDateString = function(t) {
      var e = t.className.indexOf("calendar-day-");
      return -1 !== e ? t.className.substring(e + 13, e + 23) : null
    }, e.prototype.forwardAction = function(t) {
      t = t.data.context;
      t.forwardActionWithContext(t)
    }, e.prototype.backAction = function(t) {
      t = t.data.context;
      t.backActionWithContext(t)
    }, e.prototype.backActionWithContext = function(t) {
      var e;
      t.element.find("." + t.options.targets.previousButton).hasClass("inactive") || (e = null, t.options.lengthOfTime.days ? (t.intervalStart.subtract(t.options.lengthOfTime.interval, "days").startOf("day"), t.intervalEnd = t.intervalStart.clone().add(t.options.lengthOfTime.days - 1, "days").endOf("day")) : (t.intervalStart.subtract(t.options.lengthOfTime.interval, "months").startOf("month"), t.intervalEnd = t.intervalStart.clone().add(t.options.lengthOfTime.months || t.options.lengthOfTime.interval, "months").subtract(1, "days").endOf("month"), t.options.lengthOfTime.months || (e = !t.month.isSame(f(t.month).subtract(1, "months"), "year"))), t.month = t.intervalStart.clone(), t.render(), t.options.lengthOfTime.days || t.options.lengthOfTime.months ? (t.options.clickEvents.previousInterval && t.options.clickEvents.previousInterval.apply(t, [f(t.intervalStart), f(t.intervalEnd)]), t.options.clickEvents.onIntervalChange && t.options.clickEvents.onIntervalChange.apply(t, [f(t.intervalStart), f(t.intervalEnd)])) : (t.options.clickEvents.previousMonth && t.options.clickEvents.previousMonth.apply(t, [f(t.month)]), t.options.clickEvents.onMonthChange && t.options.clickEvents.onMonthChange.apply(t, [f(t.month)]), e && t.options.clickEvents.onYearChange && t.options.clickEvents.onYearChange.apply(t, [f(t.month)])))
    }, e.prototype.forwardActionWithContext = function(t) {
      var e;
      t.element.find("." + t.options.targets.nextButton).hasClass("inactive") || (e = null, t.options.lengthOfTime.days ? (t.intervalStart.add(t.options.lengthOfTime.interval, "days").startOf("day"), t.intervalEnd = t.intervalStart.clone().add(t.options.lengthOfTime.days - 1, "days").endOf("day")) : (t.intervalStart.add(t.options.lengthOfTime.interval, "months").startOf("month"), t.intervalEnd = t.intervalStart.clone().add(t.options.lengthOfTime.months || t.options.lengthOfTime.interval, "months").subtract(1, "days").endOf("month"), t.options.lengthOfTime.months || (e = !t.month.isSame(f(t.month).add(1, "months"), "year"))), t.month = t.intervalStart.clone(), t.render(), t.options.lengthOfTime.days || t.options.lengthOfTime.months ? (t.options.clickEvents.nextInterval && t.options.clickEvents.nextInterval.apply(t, [f(t.intervalStart), f(t.intervalEnd)]), t.options.clickEvents.onIntervalChange && t.options.clickEvents.onIntervalChange.apply(t, [f(t.intervalStart), f(t.intervalEnd)])) : (t.options.clickEvents.nextMonth && t.options.clickEvents.nextMonth.apply(t, [f(t.month)]), t.options.clickEvents.onMonthChange && t.options.clickEvents.onMonthChange.apply(t, [f(t.month)]), e && t.options.clickEvents.onYearChange && t.options.clickEvents.onYearChange.apply(t, [f(t.month)])))
    }, e.prototype.todayAction = function(t) {
      var t = t.data.context,
        e = !t.month.isSame(f(), "month"),
        n = !t.month.isSame(f(), "year");
      t.month = f().startOf("month"), t.options.lengthOfTime.days ? (t.options.lengthOfTime.startDate ? t.intervalStart = f().weekday(t.options.lengthOfTime.startDate.weekday()).startOf("day") : t.intervalStart = f().weekday(0).startOf("day"), t.intervalEnd = t.intervalStart.clone().add(t.options.lengthOfTime.days - 1, "days").endOf("day")) : t.options.lengthOfTime.months ? (t.intervalStart = f().startOf("month"), t.intervalEnd = t.intervalStart.clone().add(t.options.lengthOfTime.months || t.options.lengthOfTime.interval, "months").subtract(1, "days").endOf("month")) : e && (t.intervalStart = f().startOf("month"), t.render(), t.options.clickEvents.today && t.options.clickEvents.today.apply(t, [f(t.month)]), t.options.clickEvents.onMonthChange && t.options.clickEvents.onMonthChange.apply(t, [f(t.month)]), n && t.options.clickEvents.onYearChange && t.options.clickEvents.onYearChange.apply(t, [f(t.month)])), (t.options.lengthOfTime.days || t.options.lengthOfTime.months) && (t.render(), t.options.clickEvents.today && t.options.clickEvents.today.apply(t, [f(t.month)]), t.options.clickEvents.onIntervalChange && t.options.clickEvents.onIntervalChange.apply(t, [f(t.intervalStart), f(t.intervalEnd)]))
    }, e.prototype.nextYearAction = function(t) {
      t = t.data.context;
      t.element.find("." + t.options.targets.nextYearButton).hasClass("inactive") || (t.month.add(1, "years"), t.intervalStart.add(1, "years"), t.intervalEnd.add(1, "years"), t.render(), t.options.clickEvents.nextYear && t.options.clickEvents.nextYear.apply(t, [f(t.month)]), t.options.lengthOfTime.days || t.options.lengthOfTime.months ? t.options.clickEvents.onIntervalChange && t.options.clickEvents.onIntervalChange.apply(t, [f(t.intervalStart), f(t.intervalEnd)]) : (t.options.clickEvents.onMonthChange && t.options.clickEvents.onMonthChange.apply(t, [f(t.month)]), t.options.clickEvents.onYearChange && t.options.clickEvents.onYearChange.apply(t, [f(t.month)])))
    }, e.prototype.previousYearAction = function(t) {
      t = t.data.context;
      t.element.find("." + t.options.targets.previousYearButton).hasClass("inactive") || (t.month.subtract(1, "years"), t.intervalStart.subtract(1, "years"), t.intervalEnd.subtract(1, "years"), t.render(), t.options.clickEvents.previousYear && t.options.clickEvents.previousYear.apply(t, [f(t.month)]), t.options.lengthOfTime.days || t.options.lengthOfTime.months ? t.options.clickEvents.onIntervalChange && t.options.clickEvents.onIntervalChange.apply(t, [f(t.intervalStart), f(t.intervalEnd)]) : (t.options.clickEvents.onMonthChange && t.options.clickEvents.onMonthChange.apply(t, [f(t.month)]), t.options.clickEvents.onYearChange && t.options.clickEvents.onYearChange.apply(t, [f(t.month)])))
    }, e.prototype.forward = function(t) {
      return this.options.lengthOfTime.days ? (this.intervalStart.add(this.options.lengthOfTime.interval, "days").startOf("day"), this.intervalEnd = this.intervalStart.clone().add(this.options.lengthOfTime.days - 1, "days").endOf("day")) : (this.intervalStart.add(this.options.lengthOfTime.interval, "months").startOf("month"), this.intervalEnd = this.intervalStart.clone().add(this.options.lengthOfTime.months || this.options.lengthOfTime.interval, "months").subtract(1, "days").endOf("month")), this.month = this.intervalStart.clone(), this.render(), t && t.withCallbacks && (this.options.lengthOfTime.days || this.options.lengthOfTime.months ? this.options.clickEvents.onIntervalChange && this.options.clickEvents.onIntervalChange.apply(this, [f(this.intervalStart), f(this.intervalEnd)]) : (this.options.clickEvents.onMonthChange && this.options.clickEvents.onMonthChange.apply(this, [f(this.month)]), 0 === this.month.month() && this.options.clickEvents.onYearChange && this.options.clickEvents.onYearChange.apply(this, [f(this.month)]))), this
    }, e.prototype.back = function(t) {
      return this.options.lengthOfTime.days ? (this.intervalStart.subtract(this.options.lengthOfTime.interval, "days").startOf("day"), this.intervalEnd = this.intervalStart.clone().add(this.options.lengthOfTime.days - 1, "days").endOf("day")) : (this.intervalStart.subtract(this.options.lengthOfTime.interval, "months").startOf("month"), this.intervalEnd = this.intervalStart.clone().add(this.options.lengthOfTime.months || this.options.lengthOfTime.interval, "months").subtract(1, "days").endOf("month")), this.month = this.intervalStart.clone(), this.render(), t && t.withCallbacks && (this.options.lengthOfTime.days || this.options.lengthOfTime.months ? this.options.clickEvents.onIntervalChange && this.options.clickEvents.onIntervalChange.apply(this, [f(this.intervalStart), f(this.intervalEnd)]) : (this.options.clickEvents.onMonthChange && this.options.clickEvents.onMonthChange.apply(this, [f(this.month)]), 11 === this.month.month() && this.options.clickEvents.onYearChange && this.options.clickEvents.onYearChange.apply(this, [f(this.month)]))), this
    }, e.prototype.next = function(t) {
      return this.forward(t), this
    }, e.prototype.previous = function(t) {
      return this.back(t), this
    }, e.prototype.setMonth = function(t, e) {
      return this.options.lengthOfTime.days || this.options.lengthOfTime.months ? console.log("You are using a custom date interval; use Clndr.setIntervalStart(startDate) instead.") : (this.month.month(t), this.intervalStart = this.month.clone().startOf("month"), this.intervalEnd = this.intervalStart.clone().endOf("month"), this.render(), e && e.withCallbacks && this.options.clickEvents.onMonthChange && this.options.clickEvents.onMonthChange.apply(this, [f(this.month)])), this
    }, e.prototype.setIntervalStart = function(t, e) {
      return this.options.lengthOfTime.days ? (this.intervalStart = f(t).startOf("day"), this.intervalEnd = this.intervalStart.clone().add(this.options.lengthOfTime.days - 1, "days").endOf("day")) : this.options.lengthOfTime.months && (this.intervalStart = f(t).startOf("month"), this.intervalEnd = this.intervalStart.clone().add(this.options.lengthOfTime.months || this.options.lengthOfTime.interval, "months").subtract(1, "days").endOf("month"), this.month = this.intervalStart.clone()), this.options.lengthOfTime.days || this.options.lengthOfTime.months ? (this.render(), e && e.withCallbacks && this.options.clickEvents.onIntervalChange && this.options.clickEvents.onIntervalChange.apply(this, [f(this.intervalStart), f(this.intervalEnd)])) : console.log("You are using a custom date interval; use Clndr.setIntervalStart(startDate) instead."), this
    }, e.prototype.nextYear = function(t) {
      return this.month.add(1, "year"), this.intervalStart.add(1, "year"), this.intervalEnd.add(1, "year"), this.render(), t && t.withCallbacks && (this.options.clickEvents.onYearChange && this.options.clickEvents.onYearChange.apply(this, [f(this.month)]), this.options.clickEvents.onIntervalChange && this.options.clickEvents.onIntervalChange.apply(this, [f(this.intervalStart), f(this.intervalEnd)])), this
    }, e.prototype.previousYear = function(t) {
      return this.month.subtract(1, "year"), this.intervalStart.subtract(1, "year"), this.intervalEnd.subtract(1, "year"), this.render(), t && t.withCallbacks && (this.options.clickEvents.onYearChange && this.options.clickEvents.onYearChange.apply(this, [f(this.month)]), this.options.clickEvents.onIntervalChange && this.options.clickEvents.onIntervalChange.apply(this, [f(this.intervalStart), f(this.intervalEnd)])), this
    }, e.prototype.setYear = function(t, e) {
      return this.month.year(t), this.intervalStart.year(t), this.intervalEnd.year(t), this.render(), e && e.withCallbacks && (this.options.clickEvents.onYearChange && this.options.clickEvents.onYearChange.apply(this, [f(this.month)]), this.options.clickEvents.onIntervalChange && this.options.clickEvents.onIntervalChange.apply(this, [f(this.intervalStart), f(this.intervalEnd)])), this
    }, e.prototype.setEvents = function(t) {
      return this.options.multiDayEvents ? this.options.events = this.addMultiDayMomentObjectsToEvents(t) : this.options.events = this.addMomentObjectToEvents(t), this.render(), this
    }, e.prototype.addEvents = function(t) {
      return this.options.multiDayEvents ? this.options.events = h.merge(this.options.events, this.addMultiDayMomentObjectsToEvents(t)) : this.options.events = h.merge(this.options.events, this.addMomentObjectToEvents(t)), this.render(), this
    }, e.prototype.removeEvents = function(t) {
      for (var e = this.options.events.length - 1; 0 <= e; e--) 1 == t(this.options.events[e]) && this.options.events.splice(e, 1);
      return this.render(), this
    }, e.prototype.addMomentObjectToEvents = function(t) {
      for (var e = 0, n = t.length; e < n; e++) t[e]._clndrStartDateObject = f(t[e][this.options.dateParameter]), t[e]._clndrEndDateObject = f(t[e][this.options.dateParameter]);
      return t
    }, e.prototype.addMultiDayMomentObjectsToEvents = function(t) {
      for (var e = this, n = 0, i = t.length; n < i; n++) t[n][e.options.multiDayEvents.endDate] || t[n][e.options.multiDayEvents.startDate] ? (t[n]._clndrEndDateObject = f(t[n][e.options.multiDayEvents.endDate] || t[n][e.options.multiDayEvents.startDate]), t[n]._clndrStartDateObject = f(t[n][e.options.multiDayEvents.startDate] || t[n][e.options.multiDayEvents.endDate])) : (t[n]._clndrEndDateObject = f(t[n][e.options.multiDayEvents.singleDay]), t[n]._clndrStartDateObject = f(t[n][e.options.multiDayEvents.singleDay]));
      return t
    }, e.prototype.calendarDay = function(t) {
      var e = {
        day: "",
        classes: this.options.targets.empty,
        events: [],
        date: null
      };
      return h.extend({}, e, t)
    }, e.prototype.destroy = function() {
      var t = h(this.calendarContainer);
      t.parent().data("plugin_clndr", null), this.options = n, t.empty().remove(), this.element = null
    }, h.fn.clndr = function(t) {
      if (1 === this.length) return this.data("plugin_clndr") ? this.data("plugin_clndr") : (t = new e(this, t), this.data("plugin_clndr", t), t);
      if (1 < this.length) throw new Error("CLNDR does not support multiple elements yet. Make sure your clndr selector returns only one element.")
    }
  }),
  function i(o, r, s) {
    function a(n, t) {
      if (!r[n]) {
        if (!o[n]) {
          var e = "function" == typeof require && require;
          if (!t && e) return e(n, !0);
          if (l) return l(n, !0);
          t = new Error("Cannot find module '" + n + "'");
          throw t.code = "MODULE_NOT_FOUND", t
        }
        e = r[n] = {
          exports: {}
        };
        o[n][0].call(e.exports, function(t) {
          var e = o[n][1][t];
          return a(e || t)
        }, e, e.exports, i, o, r, s)
      }
      return r[n].exports
    }
    for (var l = "function" == typeof require && require, t = 0; t < s.length; t++) a(s[t]);
    return a
  }({
    1: [function(t, e, n) {
      "use strict";

      function i(n) {
        n.fn.perfectScrollbar = function(e) {
          return this.each(function() {
            var t;
            return "object" == typeof e || void 0 === e ? (t = e, r.get(this) || o.initialize(this, t)) : "update" === (t = e) ? o.update(this) : "destroy" === t && o.destroy(this), n(this)
          })
        }
      }
      var o = t("../main"),
        r = t("../plugin/instances");
      "function" == typeof define && define.amd ? define(["jquery"], i) : void 0 !== (t = window.jQuery || window.$) && i(t), e.exports = i
    }, {
      "../main": 7,
      "../plugin/instances": 18
    }],
    2: [function(t, e, n) {
      "use strict";
      n.add = function(t, e) {
        var n;
        t.classList ? t.classList.add(e) : (e = e, (n = (t = t).className.split(" ")).indexOf(e) < 0 && n.push(e), t.className = n.join(" "))
      }, n.remove = function(t, e) {
        var n;
        t.classList ? t.classList.remove(e) : (e = e, n = (t = t).className.split(" "), 0 <= (e = n.indexOf(e)) && n.splice(e, 1), t.className = n.join(" "))
      }, n.list = function(t) {
        return t.classList ? Array.prototype.slice.apply(t.classList) : t.className.split(" ")
      }
    }, {}],
    3: [function(t, e, n) {
      "use strict";
      var i = {
        e: function(t, e) {
          t = document.createElement(t);
          return t.className = e, t
        },
        appendTo: function(t, e) {
          return e.appendChild(t), t
        }
      };
      i.css = function(t, e, n) {
        if ("object" != typeof e) return void 0 === n ? (r = e, window.getComputedStyle(t)[r]) : (r = t, o = e, "number" == typeof(n = n) && (n = n.toString() + "px"), r.style[o] = n, r);
        var i, o, r, s = t,
          a = e;
        for (i in a) {
          var l = a[i];
          "number" == typeof l && (l = l.toString() + "px"), s.style[i] = l
        }
        return s
      }, i.matches = function(t, e) {
        return void 0 !== t.matches ? t.matches(e) : void 0 !== t.matchesSelector ? t.matchesSelector(e) : void 0 !== t.webkitMatchesSelector ? t.webkitMatchesSelector(e) : void 0 !== t.mozMatchesSelector ? t.mozMatchesSelector(e) : void 0 !== t.msMatchesSelector ? t.msMatchesSelector(e) : void 0
      }, i.remove = function(t) {
        void 0 !== t.remove ? t.remove() : t.parentNode && t.parentNode.removeChild(t)
      }, i.queryChildren = function(t, e) {
        return Array.prototype.filter.call(t.childNodes, function(t) {
          return i.matches(t, e)
        })
      }, e.exports = i
    }, {}],
    4: [function(t, e, n) {
      "use strict";

      function i(t) {
        this.element = t, this.events = {}
      }

      function o() {
        this.eventElements = []
      }
      i.prototype.bind = function(t, e) {
        void 0 === this.events[t] && (this.events[t] = []), this.events[t].push(e), this.element.addEventListener(t, e, !1)
      }, i.prototype.unbind = function(e, n) {
        var i = void 0 !== n;
        this.events[e] = this.events[e].filter(function(t) {
          return i && t !== n || (this.element.removeEventListener(e, t, !1), !1)
        }, this)
      }, i.prototype.unbindAll = function() {
        for (var t in this.events) this.unbind(t)
      };
      o.prototype.eventElement = function(e) {
        var t = this.eventElements.filter(function(t) {
          return t.element === e
        })[0];
        return void 0 === t && (t = new i(e), this.eventElements.push(t)), t
      }, o.prototype.bind = function(t, e, n) {
        this.eventElement(t).bind(e, n)
      }, o.prototype.unbind = function(t, e, n) {
        this.eventElement(t).unbind(e, n)
      }, o.prototype.unbindAll = function() {
        for (var t = 0; t < this.eventElements.length; t++) this.eventElements[t].unbindAll()
      }, o.prototype.once = function(t, e, n) {
        var i = this.eventElement(t),
          o = function(t) {
            i.unbind(e, o), n(t)
          };
        i.bind(e, o)
      }, e.exports = o
    }, {}],
    5: [function(t, e, n) {
      "use strict";

      function i() {
        return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
      }
      e.exports = function() {
        return i() + i() + "-" + i() + "-" + i() + "-" + i() + "-" + i() + i() + i()
      }
    }, {}],
    6: [function(t, e, n) {
      "use strict";
      var o = t("./class"),
        i = t("./dom");
      n.toInt = function(t) {
        return parseInt(t, 10) || 0
      }, n.clone = function(t) {
        if (null === t) return null;
        if ("object" != typeof t) return t;
        var e, n = {};
        for (e in t) n[e] = this.clone(t[e]);
        return n
      }, n.extend = function(t, e) {
        var n, i = this.clone(t);
        for (n in e) i[n] = this.clone(e[n]);
        return i
      }, n.isEditable = function(t) {
        return i.matches(t, "input,[contenteditable]") || i.matches(t, "select,[contenteditable]") || i.matches(t, "textarea,[contenteditable]") || i.matches(t, "button,[contenteditable]")
      }, n.removePsClasses = function(t) {
        for (var e = o.list(t), n = 0; n < e.length; n++) {
          var i = e[n];
          0 === i.indexOf("ps-") && o.remove(t, i)
        }
      }, n.outerWidth = function(t) {
        return this.toInt(i.css(t, "width")) + this.toInt(i.css(t, "paddingLeft")) + this.toInt(i.css(t, "paddingRight")) + this.toInt(i.css(t, "borderLeftWidth")) + this.toInt(i.css(t, "borderRightWidth"))
      }, n.startScrolling = function(t, e) {
        o.add(t, "ps-in-scrolling"), void 0 !== e ? o.add(t, "ps-" + e) : (o.add(t, "ps-x"), o.add(t, "ps-y"))
      }, n.stopScrolling = function(t, e) {
        o.remove(t, "ps-in-scrolling"), void 0 !== e ? o.remove(t, "ps-" + e) : (o.remove(t, "ps-x"), o.remove(t, "ps-y"))
      }, n.env = {
        isWebKit: "WebkitAppearance" in document.documentElement.style,
        supportsTouch: "ontouchstart" in window || window.DocumentTouch && document instanceof window.DocumentTouch,
        supportsIePointer: null !== window.navigator.msMaxTouchPoints
      }
    }, {
      "./class": 2,
      "./dom": 3
    }],
    7: [function(t, e, n) {
      "use strict";
      var i = t("./plugin/destroy"),
        o = t("./plugin/initialize"),
        t = t("./plugin/update");
      e.exports = {
        initialize: o,
        update: t,
        destroy: i
      }
    }, {
      "./plugin/destroy": 9,
      "./plugin/initialize": 17,
      "./plugin/update": 21
    }],
    8: [function(t, e, n) {
      "use strict";
      e.exports = {
        maxScrollbarLength: null,
        minScrollbarLength: null,
        scrollXMarginOffset: 0,
        scrollYMarginOffset: 0,
        stopPropagationOnClick: !0,
        suppressScrollX: !1,
        suppressScrollY: !1,
        swipePropagation: !0,
        useBothWheelAxes: !1,
        useKeyboard: !0,
        useSelectionScroll: !1,
        wheelPropagation: !1,
        wheelSpeed: 1
      }
    }, {}],
    9: [function(t, e, n) {
      "use strict";
      var i = t("../lib/dom"),
        o = t("../lib/helper"),
        r = t("./instances");
      e.exports = function(t) {
        var e = r.get(t);
        e && (e.event.unbindAll(), i.remove(e.scrollbarX), i.remove(e.scrollbarY), i.remove(e.scrollbarXRail), i.remove(e.scrollbarYRail), o.removePsClasses(t), r.remove(t))
      }
    }, {
      "../lib/dom": 3,
      "../lib/helper": 6,
      "./instances": 18
    }],
    10: [function(t, e, n) {
      "use strict";
      var r = t("../../lib/helper"),
        s = t("../instances"),
        a = t("../update-geometry"),
        l = t("../update-scroll");
      e.exports = function(t) {
        var n, i, e = s.get(t);

        function o(t) {
          return t.getBoundingClientRect()
        }
        n = t, i = e, t = window.Event.prototype.stopPropagation.bind, i.settings.stopPropagationOnClick && i.event.bind(i.scrollbarY, "click", t), i.event.bind(i.scrollbarYRail, "click", function(t) {
          var e = r.toInt(i.scrollbarYHeight / 2),
            e = i.railYRatio * (t.pageY - window.scrollY - o(i.scrollbarYRail).top - e) / (i.railYRatio * (i.railYHeight - i.scrollbarYHeight));
          e < 0 ? e = 0 : 1 < e && (e = 1), l(n, "top", (i.contentHeight - i.containerHeight) * e), a(n), t.stopPropagation()
        }), i.settings.stopPropagationOnClick && i.event.bind(i.scrollbarX, "click", t), i.event.bind(i.scrollbarXRail, "click", function(t) {
          var e = r.toInt(i.scrollbarXWidth / 2),
            e = i.railXRatio * (t.pageX - window.scrollX - o(i.scrollbarXRail).left - e) / (i.railXRatio * (i.railXWidth - i.scrollbarXWidth));
          e < 0 ? e = 0 : 1 < e && (e = 1), l(n, "left", (i.contentWidth - i.containerWidth) * e - i.negativeScrollAdjustment), a(n), t.stopPropagation()
        })
      }
    }, {
      "../../lib/helper": 6,
      "../instances": 18,
      "../update-geometry": 19,
      "../update-scroll": 20
    }],
    11: [function(t, e, n) {
      "use strict";

      function i(i, o) {
        function e(t) {
          var e, n;
          e = t.pageX - r, e = s + e * o.railXRatio, n = o.scrollbarXRail.getBoundingClientRect().left + o.railXRatio * (o.railXWidth - o.scrollbarXWidth), o.scrollbarXLeft = e < 0 ? 0 : n < e ? n : e, n = l.toInt(o.scrollbarXLeft * (o.contentWidth - o.containerWidth) / (o.containerWidth - o.railXRatio * o.scrollbarXWidth)) - o.negativeScrollAdjustment, u(i, "left", n), c(i), t.stopPropagation(), t.preventDefault()
        }

        function n() {
          l.stopScrolling(i, "x"), o.event.unbind(o.ownerDocument, "mousemove", e)
        }
        var r, s = null;
        o.event.bind(o.scrollbarX, "mousedown", function(t) {
          r = t.pageX, s = l.toInt(a.css(o.scrollbarX, "left")) * o.railXRatio, l.startScrolling(i, "x"), o.event.bind(o.ownerDocument, "mousemove", e), o.event.once(o.ownerDocument, "mouseup", n), t.stopPropagation(), t.preventDefault()
        })
      }

      function o(i, o) {
        function e(t) {
          var e, n;
          e = t.pageY - r, e = s + e * o.railYRatio, n = o.scrollbarYRail.getBoundingClientRect().top + o.railYRatio * (o.railYHeight - o.scrollbarYHeight), o.scrollbarYTop = e < 0 ? 0 : n < e ? n : e, n = l.toInt(o.scrollbarYTop * (o.contentHeight - o.containerHeight) / (o.containerHeight - o.railYRatio * o.scrollbarYHeight)), u(i, "top", n), c(i), t.stopPropagation(), t.preventDefault()
        }

        function n() {
          l.stopScrolling(i, "y"), o.event.unbind(o.ownerDocument, "mousemove", e)
        }
        var r, s = null;
        o.event.bind(o.scrollbarY, "mousedown", function(t) {
          r = t.pageY, s = l.toInt(a.css(o.scrollbarY, "top")) * o.railYRatio, l.startScrolling(i, "y"), o.event.bind(o.ownerDocument, "mousemove", e), o.event.once(o.ownerDocument, "mouseup", n), t.stopPropagation(), t.preventDefault()
        })
      }
      var a = t("../../lib/dom"),
        l = t("../../lib/helper"),
        r = t("../instances"),
        c = t("../update-geometry"),
        u = t("../update-scroll");
      e.exports = function(t) {
        var e = r.get(t);
        i(t, e), o(t, e)
      }
    }, {
      "../../lib/dom": 3,
      "../../lib/helper": 6,
      "../instances": 18,
      "../update-geometry": 19,
      "../update-scroll": 20
    }],
    12: [function(t, e, n) {
      "use strict";

      function i(o, r) {
        var s = !1;
        r.event.bind(o, "mouseenter", function() {
          s = !0
        }), r.event.bind(o, "mouseleave", function() {
          s = !1
        });
        r.event.bind(r.ownerDocument, "keydown", function(t) {
          if ((!t.isDefaultPrevented || !t.isDefaultPrevented()) && s) {
            var e = document.activeElement || r.ownerDocument.activeElement;
            if (e) {
              for (; e.shadowRoot;) e = e.shadowRoot.activeElement;
              if (a.isEditable(e)) return
            }
            var n = 0,
              i = 0;
            switch (t.which) {
              case 37:
                n = -30;
                break;
              case 38:
                i = 30;
                break;
              case 39:
                n = 30;
                break;
              case 40:
                i = -30;
                break;
              case 33:
                i = 90;
                break;
              case 32:
                i = t.shiftKey ? 90 : -90;
                break;
              case 34:
                i = -90;
                break;
              case 35:
                i = t.ctrlKey ? -r.contentHeight : -r.containerHeight;
                break;
              case 36:
                i = t.ctrlKey ? o.scrollTop : r.containerHeight;
                break;
              default:
                return
            }
            c(o, "top", o.scrollTop - i), c(o, "left", o.scrollLeft + n), l(o),
              function(t, e) {
                var n = o.scrollTop;
                if (0 === t) {
                  if (!r.scrollbarYActive) return !1;
                  if (0 === n && 0 < e || n >= r.contentHeight - r.containerHeight && e < 0) return !r.settings.wheelPropagation
                }
                if (n = o.scrollLeft, 0 === e) {
                  if (!r.scrollbarXActive) return !1;
                  if (0 === n && t < 0 || n >= r.contentWidth - r.containerWidth && 0 < t) return !r.settings.wheelPropagation
                }
                return !0
              }(n, i) && t.preventDefault()
          }
        })
      }
      var a = t("../../lib/helper"),
        o = t("../instances"),
        l = t("../update-geometry"),
        c = t("../update-scroll");
      e.exports = function(t) {
        i(t, o.get(t))
      }
    }, {
      "../../lib/helper": 6,
      "../instances": 18,
      "../update-geometry": 19,
      "../update-scroll": 20
    }],
    13: [function(t, e, n) {
      "use strict";

      function i(o, r) {
        function t(t) {
          var e, n, i;
          !a.env.isWebKit && o.querySelector("select:focus") || (n = (e = t).deltaX, i = -1 * e.deltaY, void 0 !== n && void 0 !== i || (n = -1 * e.wheelDeltaX / 6, i = e.wheelDeltaY / 6), e.deltaMode && 1 === e.deltaMode && (n *= 10, i *= 10), n != n && i != i && (n = 0, i = e.wheelDelta), function(t, e) {
            var n = o.querySelector("textarea:hover");
            if (n) {
              var i = n.scrollHeight - n.clientHeight;
              if (0 < i && !(0 === n.scrollTop && 0 < e || n.scrollTop === i && e < 0)) return 1;
              i = n.scrollLeft - n.clientWidth;
              if (0 < i && !(0 === n.scrollLeft && t < 0 || n.scrollLeft === i && 0 < t)) return 1
            }
          }(n = (e = [n, i])[0], i = e[1]) || (s = !1, r.settings.useBothWheelAxes ? r.scrollbarYActive && !r.scrollbarXActive ? (c(o, "top", i ? o.scrollTop - i * r.settings.wheelSpeed : o.scrollTop + n * r.settings.wheelSpeed), s = !0) : r.scrollbarXActive && !r.scrollbarYActive && (c(o, "left", n ? o.scrollLeft + n * r.settings.wheelSpeed : o.scrollLeft - i * r.settings.wheelSpeed), s = !0) : (c(o, "top", o.scrollTop - i * r.settings.wheelSpeed), c(o, "left", o.scrollLeft + n * r.settings.wheelSpeed)), l(o), (s = s || function(t, e) {
            var n = o.scrollTop;
            if (0 === t) {
              if (!r.scrollbarYActive) return !1;
              if (0 === n && 0 < e || n >= r.contentHeight - r.containerHeight && e < 0) return !r.settings.wheelPropagation
            }
            if (n = o.scrollLeft, 0 === e) {
              if (!r.scrollbarXActive) return !1;
              if (0 === n && t < 0 || n >= r.contentWidth - r.containerWidth && 0 < t) return !r.settings.wheelPropagation
            }
            return !0
          }(n, i)) && (t.stopPropagation(), t.preventDefault())))
        }
        var s = !1;
        void 0 !== window.onwheel ? r.event.bind(o, "wheel", t) : void 0 !== window.onmousewheel && r.event.bind(o, "mousewheel", t)
      }
      var a = t("../../lib/helper"),
        o = t("../instances"),
        l = t("../update-geometry"),
        c = t("../update-scroll");
      e.exports = function(t) {
        i(t, o.get(t))
      }
    }, {
      "../../lib/helper": 6,
      "../instances": 18,
      "../update-geometry": 19,
      "../update-scroll": 20
    }],
    14: [function(t, e, n) {
      "use strict";
      var i = t("../instances"),
        o = t("../update-geometry");
      e.exports = function(t) {
        var e, n = i.get(t);
        e = t, n.event.bind(e, "scroll", function() {
          o(e)
        })
      }
    }, {
      "../instances": 18,
      "../update-geometry": 19
    }],
    15: [function(t, e, n) {
      "use strict";

      function i(s, t) {
        function a() {
          l && (clearInterval(l), l = null), d.stopScrolling(s)
        }
        var l = null,
          c = {
            top: 0,
            left: 0
          },
          u = !1;
        t.event.bind(t.ownerDocument, "selectionchange", function() {
          var t;
          s.contains(0 === (t = window.getSelection ? window.getSelection() : document.getSelection ? document.getSelection() : "").toString().length ? null : t.getRangeAt(0).commonAncestorContainer) ? u = !0 : (u = !1, a())
        }), t.event.bind(window, "mouseup", function() {
          u && (u = !1, a())
        }), t.event.bind(window, "mousemove", function(t) {
          var e, n, i, o, r;
          u && (e = t.pageX, t = t.pageY, n = s.offsetLeft, i = s.offsetLeft + s.offsetWidth, o = s.offsetTop, r = s.offsetTop + s.offsetHeight, e < n + 3 ? (c.left = -5, d.startScrolling(s, "x")) : i - 3 < e ? (c.left = 5, d.startScrolling(s, "x")) : c.left = 0, t < o + 3 ? (c.top = o + 3 - t < 5 ? -5 : -20, d.startScrolling(s, "y")) : r - 3 < t ? (c.top = t - r + 3 < 5 ? 5 : 20, d.startScrolling(s, "y")) : c.top = 0, 0 === c.top && 0 === c.left ? a() : l = l || setInterval(function() {
            return h.get(s) ? (p(s, "top", s.scrollTop + c.top), p(s, "left", s.scrollLeft + c.left), void f(s)) : void clearInterval(l)
          }, 50))
        })
      }
      var d = t("../../lib/helper"),
        h = t("../instances"),
        f = t("../update-geometry"),
        p = t("../update-scroll");
      e.exports = function(t) {
        i(t, h.get(t))
      }
    }, {
      "../../lib/helper": 6,
      "../instances": 18,
      "../update-geometry": 19,
      "../update-scroll": 20
    }],
    16: [function(t, e, n) {
      "use strict";

      function i(s, a, t, e) {
        function r(t, e) {
          w(s, "top", s.scrollTop - e), w(s, "left", s.scrollLeft - t), b(s)
        }

        function n() {
          v = !0
        }

        function i() {
          v = !1
        }

        function l(t) {
          return t.targetTouches ? t.targetTouches[0] : t
        }

        function c(t) {
          return t.targetTouches && 1 === t.targetTouches.length || !(!t.pointerType || "mouse" === t.pointerType || t.pointerType === t.MSPOINTER_TYPE_MOUSE)
        }

        function o(t) {
          var e;
          c(t) && (g = !0, e = l(t), h.pageX = e.pageX, h.pageY = e.pageY, f = (new Date).getTime(), null !== m && clearInterval(m), t.stopPropagation())
        }

        function u(t) {
          var e, n, i, o;
          !v && g && c(t) && (r(e = (i = {
            pageX: (i = l(t)).pageX,
            pageY: i.pageY
          }).pageX - h.pageX, n = i.pageY - h.pageY), h = i, 0 < (o = (i = (new Date).getTime()) - f) && (p.x = e / o, p.y = n / o, f = i), function(t, e) {
            var n = s.scrollTop,
              i = s.scrollLeft,
              o = Math.abs(t),
              r = Math.abs(e);
            if (o < r) {
              if (e < 0 && n === a.contentHeight - a.containerHeight || 0 < e && 0 === n) return !a.settings.swipePropagation
            } else if (r < o && (t < 0 && i === a.contentWidth - a.containerWidth || 0 < t && 0 === i)) return !a.settings.swipePropagation;
            return 1
          }(e, n) && (t.stopPropagation(), t.preventDefault()))
        }

        function d() {
          !v && g && (g = !1, clearInterval(m), m = setInterval(function() {
            return !y.get(s) || Math.abs(p.x) < .01 && Math.abs(p.y) < .01 ? void clearInterval(m) : (r(30 * p.x, 30 * p.y), p.x *= .8, void(p.y *= .8))
          }, 10))
        }
        var h = {},
          f = 0,
          p = {},
          m = null,
          v = !1,
          g = !1;
        t && (a.event.bind(window, "touchstart", n), a.event.bind(window, "touchend", i), a.event.bind(s, "touchstart", o), a.event.bind(s, "touchmove", u), a.event.bind(s, "touchend", d)), e && (window.PointerEvent ? (a.event.bind(window, "pointerdown", n), a.event.bind(window, "pointerup", i), a.event.bind(s, "pointerdown", o), a.event.bind(s, "pointermove", u), a.event.bind(s, "pointerup", d)) : window.MSPointerEvent && (a.event.bind(window, "MSPointerDown", n), a.event.bind(window, "MSPointerUp", i), a.event.bind(s, "MSPointerDown", o), a.event.bind(s, "MSPointerMove", u), a.event.bind(s, "MSPointerUp", d)))
      }
      var y = t("../instances"),
        b = t("../update-geometry"),
        w = t("../update-scroll");
      e.exports = function(t, e, n) {
        i(t, y.get(t), e, n)
      }
    }, {
      "../instances": 18,
      "../update-geometry": 19,
      "../update-scroll": 20
    }],
    17: [function(t, e, n) {
      "use strict";
      var i = t("../lib/class"),
        o = t("../lib/helper"),
        r = t("./instances"),
        s = t("./update-geometry"),
        a = t("./handler/click-rail"),
        l = t("./handler/drag-scrollbar"),
        c = t("./handler/keyboard"),
        u = t("./handler/mouse-wheel"),
        d = t("./handler/native-scroll"),
        h = t("./handler/selection"),
        f = t("./handler/touch");
      e.exports = function(t, e) {
        e = "object" == typeof e ? e : {}, i.add(t, "ps-container");
        var n = r.add(t);
        n.settings = o.extend(n.settings, e), a(t), l(t), u(t), d(t), n.settings.useSelectionScroll && h(t), (o.env.supportsTouch || o.env.supportsIePointer) && f(t, o.env.supportsTouch, o.env.supportsIePointer), n.settings.useKeyboard && c(t), s(t)
      }
    }, {
      "../lib/class": 2,
      "../lib/helper": 6,
      "./handler/click-rail": 10,
      "./handler/drag-scrollbar": 11,
      "./handler/keyboard": 12,
      "./handler/mouse-wheel": 13,
      "./handler/native-scroll": 14,
      "./handler/selection": 15,
      "./handler/touch": 16,
      "./instances": 18,
      "./update-geometry": 19
    }],
    18: [function(t, e, n) {
      "use strict";

      function o(t) {
        var e, n, i = this;
        i.settings = c.clone(s), i.containerWidth = null, i.containerHeight = null, i.contentWidth = null, i.contentHeight = null, i.isRtl = "rtl" === r.css(t, "direction"), i.isNegativeScroll = (n = t.scrollLeft, t.scrollLeft = -1, e = t.scrollLeft < 0, t.scrollLeft = n, e), i.negativeScrollAdjustment = i.isNegativeScroll ? t.scrollWidth - t.clientWidth : 0, i.event = new a, i.ownerDocument = t.ownerDocument || document, i.scrollbarXRail = r.appendTo(r.e("div", "ps-scrollbar-x-rail"), t), i.scrollbarX = r.appendTo(r.e("div", "ps-scrollbar-x"), i.scrollbarXRail), i.scrollbarXActive = null, i.scrollbarXWidth = null, i.scrollbarXLeft = null, i.scrollbarXBottom = c.toInt(r.css(i.scrollbarXRail, "bottom")), i.isScrollbarXUsingBottom = i.scrollbarXBottom == i.scrollbarXBottom, i.scrollbarXTop = i.isScrollbarXUsingBottom ? null : c.toInt(r.css(i.scrollbarXRail, "top")), i.railBorderXWidth = c.toInt(r.css(i.scrollbarXRail, "borderLeftWidth")) + c.toInt(r.css(i.scrollbarXRail, "borderRightWidth")), r.css(i.scrollbarXRail, "display", "block"), i.railXMarginWidth = c.toInt(r.css(i.scrollbarXRail, "marginLeft")) + c.toInt(r.css(i.scrollbarXRail, "marginRight")), r.css(i.scrollbarXRail, "display", ""), i.railXWidth = null, i.railXRatio = null, i.scrollbarYRail = r.appendTo(r.e("div", "ps-scrollbar-y-rail"), t), i.scrollbarY = r.appendTo(r.e("div", "ps-scrollbar-y"), i.scrollbarYRail), i.scrollbarYActive = null, i.scrollbarYHeight = null, i.scrollbarYTop = null, i.scrollbarYRight = c.toInt(r.css(i.scrollbarYRail, "right")), i.isScrollbarYUsingRight = i.scrollbarYRight == i.scrollbarYRight, i.scrollbarYLeft = i.isScrollbarYUsingRight ? null : c.toInt(r.css(i.scrollbarYRail, "left")), i.scrollbarYOuterWidth = i.isRtl ? c.outerWidth(i.scrollbarY) : null, i.railBorderYWidth = c.toInt(r.css(i.scrollbarYRail, "borderTopWidth")) + c.toInt(r.css(i.scrollbarYRail, "borderBottomWidth")), r.css(i.scrollbarYRail, "display", "block"), i.railYMarginHeight = c.toInt(r.css(i.scrollbarYRail, "marginTop")) + c.toInt(r.css(i.scrollbarYRail, "marginBottom")), r.css(i.scrollbarYRail, "display", ""), i.railYHeight = null, i.railYRatio = null
      }

      function i(t) {
        return void 0 === t.dataset ? t.getAttribute("data-ps-id") : t.dataset.psId
      }
      var r = t("../lib/dom"),
        s = t("./default-setting"),
        a = t("../lib/event-manager"),
        l = t("../lib/guid"),
        c = t("../lib/helper"),
        u = {};
      n.add = function(t) {
        var e, n, i = l();
        return n = i, void 0 === (e = t).dataset ? e.setAttribute("data-ps-id", n) : e.dataset.psId = n, u[i] = new o(t), u[i]
      }, n.remove = function(t) {
        delete u[i(t)], void 0 === (t = t).dataset ? t.removeAttribute("data-ps-id") : delete t.dataset.psId
      }, n.get = function(t) {
        return u[i(t)]
      }
    }, {
      "../lib/dom": 3,
      "../lib/event-manager": 4,
      "../lib/guid": 5,
      "../lib/helper": 6,
      "./default-setting": 8
    }],
    19: [function(t, e, n) {
      "use strict";

      function r(t, e) {
        return t.settings.minScrollbarLength && (e = Math.max(e, t.settings.minScrollbarLength)), e = t.settings.maxScrollbarLength ? Math.min(e, t.settings.maxScrollbarLength) : e
      }
      var s = t("../lib/class"),
        a = t("../lib/dom"),
        l = t("../lib/helper"),
        c = t("./instances"),
        u = t("./update-scroll");
      e.exports = function(t) {
        var e, n, i, o = c.get(t);
        o.containerWidth = t.clientWidth, o.containerHeight = t.clientHeight, o.contentWidth = t.scrollWidth, o.contentHeight = t.scrollHeight, t.contains(o.scrollbarXRail) || (0 < (e = a.queryChildren(t, ".ps-scrollbar-x-rail")).length && e.forEach(function(t) {
          a.remove(t)
        }), a.appendTo(o.scrollbarXRail, t)), t.contains(o.scrollbarYRail) || (0 < (e = a.queryChildren(t, ".ps-scrollbar-y-rail")).length && e.forEach(function(t) {
          a.remove(t)
        }), a.appendTo(o.scrollbarYRail, t)), !o.settings.suppressScrollX && o.containerWidth + o.settings.scrollXMarginOffset < o.contentWidth ? (o.scrollbarXActive = !0, o.railXWidth = o.containerWidth - o.railXMarginWidth, o.railXRatio = o.containerWidth / o.railXWidth, o.scrollbarXWidth = r(o, l.toInt(o.railXWidth * o.containerWidth / o.contentWidth)), o.scrollbarXLeft = l.toInt((o.negativeScrollAdjustment + t.scrollLeft) * (o.railXWidth - o.scrollbarXWidth) / (o.contentWidth - o.containerWidth))) : (o.scrollbarXActive = !1, o.scrollbarXWidth = 0, o.scrollbarXLeft = 0, t.scrollLeft = 0), !o.settings.suppressScrollY && o.containerHeight + o.settings.scrollYMarginOffset < o.contentHeight ? (o.scrollbarYActive = !0, o.railYHeight = o.containerHeight - o.railYMarginHeight, o.railYRatio = o.containerHeight / o.railYHeight, o.scrollbarYHeight = r(o, l.toInt(o.railYHeight * o.containerHeight / o.contentHeight)), o.scrollbarYTop = l.toInt(t.scrollTop * (o.railYHeight - o.scrollbarYHeight) / (o.contentHeight - o.containerHeight))) : (o.scrollbarYActive = !1, o.scrollbarYHeight = 0, o.scrollbarYTop = 0, u(t, "top", 0)), o.scrollbarXLeft >= o.railXWidth - o.scrollbarXWidth && (o.scrollbarXLeft = o.railXWidth - o.scrollbarXWidth), o.scrollbarYTop >= o.railYHeight - o.scrollbarYHeight && (o.scrollbarYTop = o.railYHeight - o.scrollbarYHeight), e = t, i = {
          width: (n = o).railXWidth
        }, n.isRtl ? i.left = n.negativeScrollAdjustment + e.scrollLeft + n.containerWidth - n.contentWidth : i.left = e.scrollLeft, n.isScrollbarXUsingBottom ? i.bottom = n.scrollbarXBottom - e.scrollTop : i.top = n.scrollbarXTop + e.scrollTop, a.css(n.scrollbarXRail, i), i = {
          top: e.scrollTop,
          height: n.railYHeight
        }, n.isScrollbarYUsingRight ? n.isRtl ? i.right = n.contentWidth - (n.negativeScrollAdjustment + e.scrollLeft) - n.scrollbarYRight - n.scrollbarYOuterWidth : i.right = n.scrollbarYRight - e.scrollLeft : n.isRtl ? i.left = n.negativeScrollAdjustment + e.scrollLeft + 2 * n.containerWidth - n.contentWidth - n.scrollbarYLeft - n.scrollbarYOuterWidth : i.left = n.scrollbarYLeft + e.scrollLeft, a.css(n.scrollbarYRail, i), a.css(n.scrollbarX, {
          left: n.scrollbarXLeft,
          width: n.scrollbarXWidth - n.railBorderXWidth
        }), a.css(n.scrollbarY, {
          top: n.scrollbarYTop,
          height: n.scrollbarYHeight - n.railBorderYWidth
        }), s[o.scrollbarXActive ? "add" : "remove"](t, "ps-active-x"), s[o.scrollbarYActive ? "add" : "remove"](t, "ps-active-y")
      }
    }, {
      "../lib/class": 2,
      "../lib/dom": 3,
      "../lib/helper": 6,
      "./instances": 18,
      "./update-scroll": 20
    }],
    20: [function(t, e, n) {
      "use strict";
      var o, r, s = t("./instances"),
        a = document.createEvent("Event"),
        l = document.createEvent("Event"),
        c = document.createEvent("Event"),
        u = document.createEvent("Event"),
        d = document.createEvent("Event"),
        h = document.createEvent("Event"),
        f = document.createEvent("Event"),
        p = document.createEvent("Event"),
        m = document.createEvent("Event"),
        v = document.createEvent("Event");
      a.initEvent("ps-scroll-up", !0, !0), l.initEvent("ps-scroll-down", !0, !0), c.initEvent("ps-scroll-left", !0, !0), u.initEvent("ps-scroll-right", !0, !0), d.initEvent("ps-scroll-y", !0, !0), h.initEvent("ps-scroll-x", !0, !0), f.initEvent("ps-x-reach-start", !0, !0), p.initEvent("ps-x-reach-end", !0, !0), m.initEvent("ps-y-reach-start", !0, !0), v.initEvent("ps-y-reach-end", !0, !0), e.exports = function(t, e, n) {
        if (void 0 === t) throw "You must provide an element to the update-scroll function";
        if (void 0 === e) throw "You must provide an axis to the update-scroll function";
        if (void 0 === n) throw "You must provide a value to the update-scroll function";
        if ("top" === e && n <= 0) return t.scrollTop = 0, void t.dispatchEvent(m);
        if ("left" === e && n <= 0) return t.scrollLeft = 0, void t.dispatchEvent(f);
        var i = s.get(t);
        return "top" === e && n > i.contentHeight - i.containerHeight ? (t.scrollTop = i.contentHeight - i.containerHeight, void t.dispatchEvent(v)) : "left" === e && n > i.contentWidth - i.containerWidth ? (t.scrollLeft = i.contentWidth - i.containerWidth, void t.dispatchEvent(p)) : (o = o || t.scrollTop, r = r || t.scrollLeft, "top" === e && n < o && t.dispatchEvent(a), "top" === e && o < n && t.dispatchEvent(l), "left" === e && n < r && t.dispatchEvent(c), "left" === e && r < n && t.dispatchEvent(u), "top" === e && (t.scrollTop = o = n, t.dispatchEvent(d)), void("left" === e && (t.scrollLeft = r = n, t.dispatchEvent(h))))
      }
    }, {
      "./instances": 18
    }],
    21: [function(t, e, n) {
      "use strict";
      var i = t("../lib/dom"),
        o = t("../lib/helper"),
        r = t("./instances"),
        s = t("./update-geometry");
      e.exports = function(t) {
        var e = r.get(t);
        e && (e.negativeScrollAdjustment = e.isNegativeScroll ? t.scrollWidth - t.clientWidth : 0, i.css(e.scrollbarXRail, "display", "block"), i.css(e.scrollbarYRail, "display", "block"), e.railXMarginWidth = o.toInt(i.css(e.scrollbarXRail, "marginLeft")) + o.toInt(i.css(e.scrollbarXRail, "marginRight")), e.railYMarginHeight = o.toInt(i.css(e.scrollbarYRail, "marginTop")) + o.toInt(i.css(e.scrollbarYRail, "marginBottom")), i.css(e.scrollbarXRail, "display", "none"), i.css(e.scrollbarYRail, "display", "none"), s(t), i.css(e.scrollbarXRail, "display", ""), i.css(e.scrollbarYRail, "display", ""))
      }
    }, {
      "../lib/dom": 3,
      "../lib/helper": 6,
      "./instances": 18,
      "./update-geometry": 19
    }]
  }, {}, [1]),
  function(t) {
    var e = ".select-custom",
      n = {};

    function i(t) {
      var e, n, i, t = $(t);
      t.data("isOpen") || (t.data("isOpen", !0), i = (_currentSelect = t).height(), e = t.data("list-height"), n = t.data("list-bgcolor"), i = i / 2 - e / 2, (t = t.find(".list-content")).css({
        left: 0,
        top: 0,
        height: 0,
        backgroundColor: n,
        opacity: 0
      }), t.show(), TweenLite.to(t, .5, {
        top: i,
        opacity: 1,
        height: e,
        ease: Expo.easeOut,
        onComplete: function() {
          $(window).bind("mousedown", a)
        }
      }))
    }

    function o(t) {
      var t = $(t),
        e = t.find(".list-content");
      t.data("disable-close") || (t.data("isOpen", !1), $(window).unbind("mousedown", a), e.hide())
    }

    function r(t) {
      t = $(t);
      t.css("pointer-events", "none"), t.addClass("disabled"), t.css({
        backgroundColor: "#fff"
      }), TweenLite.to(t, .5, {
        backgroundColor: "#fff",
        ease: Expo.easeOut
      })
    }

    function s(t) {
      i($(t.currentTarget).closest(e))
    }

    function a(t) {
      for (var e = $(t.target), n = !1;
        "BODY" != e.prop("tagName");) {
        if (e.hasClass("select-custom")) {
          n = !0;
          break
        }
        e = e.parent()
      }!n && _currentSelect && (o(_currentSelect), _currentSelect = null)
    }
    n.init = function(t) {
      var e = $(t);
      e.find("button").bind("click", s), e.hasClass("disabled") && r(t)
    }, n.getBySelector = function(t) {
      var n = $(t);
      return {
        open: function() {
          i(n)
        },
        close: function() {
          o(n)
        },
        showPreloader: function() {
          n.find(".label").text("Carregando")
        },
        enable: function() {
          var t = n;
          (t = $(t)).css("pointer-events", "auto"), t.removeClass("disabled"), TweenLite.to(t, .5, {
            backgroundColor: t.data("list-bgcolor"),
            ease: Expo.easeOut
          })
        },
        disable: function() {
          r(n)
        },
        getLabel: function() {
          return n.find(".selected").text()
        },
        setLabel: function(t) {
          n.find(".label").text(t)
        },
        bind: function(t, e) {
          return n.bind(t, e)
        }
      }
    }, n.apply = function() {
      $(document).find(e).each(function(t, e) {
        n.init(e)
      })
    }, window.BMS || (window.BMS = t), t.selectCustom = n
  }(window.BMS || {}),
  function(t) {
    var e, i, n = ".select-date",
      o = {};

    function r(t) {
      var t = $(t),
        e = (_currentSelect = t).find(".in-label"),
        n = t.find(".out-label"),
        i = t.find(".cal-in-container"),
        o = t.find(".cal-out-container");
      t.data("list-bgcolor");

      function r() {
        $(window).bind("mousedown", u)
      }
      e.show(), n.show(), i.show(), i.css({
        top: 0,
        height: 0,
        opacity: 0
      }), TweenLite.to(i, .5, {
        top: -207,
        opacity: 1,
        height: 207,
        ease: Expo.easeOut,
        onComplete: r
      }), o.show(), o.css({
        top: -200,
        height: 0,
        opacity: 0
      }), TweenLite.to(o, .5, {
        top: 98,
        opacity: 1,
        height: 207,
        ease: Expo.easeOut,
        onComplete: r
      })
    }

    function s(t) {
      var t = $(t),
        e = t.find(".in-label"),
        n = t.find(".out-label"),
        i = t.find(".cal-in-container"),
        t = t.find(".cal-out-container");
      e.hide(), n.hide(), i.hide(), t.hide(), $(window).unbind("mousedown", u)
    }

    function a(t) {
      e = t.date.format("DD/MM/YYYY"), $(t.element).closest(n).trigger("inSelect"), console.log("inSelect"), i && $(t.element).closest(n).trigger("complete")
    }

    function l(t) {
      i = t.date.format("DD/MM/YYYY"), e && $(t.element).closest(n).trigger("complete")
    }

    function c(t) {
      r($(t.currentTarget).closest(n))
    }

    function u(t) {
      for (var e = $(t.target), n = !1;
        "BODY" != e.prop("tagName");) {
        if (e.hasClass("select-date")) {
          n = !0;
          break
        }
        e = e.parent()
      }!n && _currentSelect && (s(_currentSelect), _currentSelect = null)
    }
    moment.locale("pt-br"), o.init = function(t) {
      $(t).find("button").bind("click", c);
      var t = {
          template: $("#clndr-template").html(),
          trackSelectedDate: !0,
          clickEvents: {
            click: a
          }
        },
        e = {
          template: $("#clndr-template").html(),
          trackSelectedDate: !0,
          clickEvents: {
            click: l
          }
        };
      $(".clndr-in").clndr(t), $(".clndr-out").clndr(e)
    }, o.getBySelector = function(t) {
      var n = $(t);
      return {
        open: function() {
          r(n)
        },
        close: function() {
          s(n)
        },
        showPreloader: function() {
          n.find(".label").text("Carregando")
        },
        enable: function() {
          n.removeClass("disabled"), TweenLite.to(n, .5, {
            backgroundColor: n.data("list-bgcolor"),
            ease: Expo.easeOut
          })
        },
        disable: function() {
          n.addClass("disabled"), n.css({
            backgroundColor: "#fff"
          }), TweenLite.to(n, .5, {
            backgroundColor: "#fff",
            ease: Expo.easeOut
          })
        },
        getStartDate: function() {
          return e
        },
        getEndDate: function() {
          return i
        },
        getIsthroughEurope: function() {
          return $(".europe_check").prop("checked")
        },
        getLabel: function() {
          return n.find(".selected").text()
        },
        setLabel: function(t) {
          n.find(".label").text(t)
        },
        bind: function(t, e) {
          return n.bind(t, e)
        }
      }
    }, o.apply = function() {
      $(document).find(n).each(function(t, e) {
        o.init(e)
      })
    }, window.BMS || (window.BMS = t), t.selectDate = o
  }(window.BMS || {}),
  function(t) {
    var s, a, i = ".select-list",
      l = null,
      c = "",
      u = 1500,
      n = {};

    function e(t) {
      l && (d(l), l = null);
      var e = $(t),
        n = (l = e).find(".list-container"),
        t = e.height(),
        i = e.data("list-height"),
        o = e.data("list-bgcolor"),
        r = e.find("div.label");
      a = r.text(), r.html('<input type="text" value="" style="background: none; border: none; padding-left: 30px; width: 190px" class="searchAuto" placeholder="Digite aqui..." />'), n.css({
        left: 0,
        top: 0,
        height: 0,
        backgroundColor: o,
        opacity: 0
      }), n.addClass("active").show(), TweenLite.to(n, .5, {
        top: t,
        opacity: 1,
        height: i,
        ease: Expo.easeOut,
        onComplete: function() {
          $(window).bind("mousedown", g), $(window).bind("keydown", y);
          var t = n.find(".list-wrapper").eq(0).prop("scrollHeight");
          console.log("scrollHeight", t), console.log("listHeight", i), console.log(i < t), i < t + 42 && n.find(".list-wrapper").perfectScrollbar();
          e.find("input").bind("keyup", m), $(".searchAuto").focus()
        }
      }), n.find(".list-wrapper").perfectScrollbar("destroy"), n.find(".list-wrapper")[0].scrollTop = 0
    }

    function d(t) {
      var t = $(t),
        e = t.find(".list-container");
      1 <= t.find("div.label").children().length && t.find("div.label").html(a), $(window).unbind("mousedown", g), $(window).unbind("keydown", y), e.removeClass("active").hide(), t.find(".list-wrapper li").each(function(t) {
        $(this).addClass("show").show()
      })
    }

    function r(t) {
      t = $(t);
      t.css("pointer-events", "none"), t.addClass("disabled"), t.css({
        backgroundColor: "#fff"
      }), TweenLite.to(t, .5, {
        backgroundColor: "#fff",
        ease: Expo.easeOut
      })
    }

    function h(t, e, n) {
      null == n && (n = !0);
      var i = $(t),
        o = (i.find(".selected").removeClass("selected"), $(e)),
        r = (o.addClass("selected"), o.data("disabled") || "Selecione" == o.data("value"));
      r || (i.find(".label").text(o.text()), d(t), n && !r && i.trigger("change", {
        selected: e,
        value: o.data("value"),
        label: o.text()
      }))
    }

    function f(t, e, n) {
      h(t, $(t).find("li")[e], n)
    }

    function p(t, e) {
      console.log("highlightItemAt", e);
      t = $(t), e = t.find("li")[e];
      t.find(".highlighted").removeClass("highlighted"), $(e).addClass("highlighted")
    }

    function m(t) {
      var e = $(t.currentTarget),
        t = $(t.currentTarget).closest(i),
        n = t.find(".list-wrapper li"),
        n = (console.log("press:", e.val().toLowerCase()), n.each(function(t) {
          -1 === $(this).text().toLowerCase().indexOf(e.val().toLowerCase()) ? $(this).removeClass("show").hide() : $(this).addClass("show").show()
        }), t.find(".ps-container"));
      n.scrollTop(0), n.perfectScrollbar("update")
    }

    function o(t) {
      e($(t.currentTarget).closest(i))
    }

    function v(t) {
      t = $(t.currentTarget);
      h(l, t)
    }

    function g(t) {
      for (var e = $(t.target), n = !1;
        "BODY" != e.prop("tagName");) {
        if (e.hasClass("select-list")) {
          n = !0;
          break
        }
        e = e.parent()
      }!n && l && (d(l), l = null)
    }

    function y(t) {
      console.log("key: ", t.originalEvent.keyCode);
      var e, n, i, o = t.originalEvent.keyCode;
      if (32 == o) return n = $(".searchAuto").val(), $(".searchAuto").val(n + " "), t.originalEvent.preventDefault(), m(t), !1;
      if (13 == o) return 1 == (n = $(".active .list-wrapper li.show")).length && h(l, n), !1;
      if (38 == o) return t.originalEvent.preventDefault(), n = l, 0 < (i = $(n).find(".highlighted").index()) && p(n, i - 1), !1;
      if (40 == o) return t.originalEvent.preventDefault(), i = l, e = (o = $(i)).find(".highlighted"), o = o.find(".list-wrapper li").length, console.log("num_items", e), (e = e.index()) < o - 2 && p(i, e + 1), !1;
      var r, o = String.fromCharCode(t.originalEvent.keyCode);
      c += o, clearTimeout(s), s = setTimeout(function() {
        c = "", clearTimeout(s)
      }, u), console.log("letter", c), l.find("li").each(function(t, e) {
        0 != $(e).text().toLowerCase().indexOf(c.toLowerCase()) || r || (r = $(e))
      }), r && (l.find(".list-wrapper")[0].scrollTop += r.position().top)
    }
    n.init = function(t) {
      var e = $(t);
      e.find("button").bind("click", o), e.find("li").bind("click", v), e.hasClass("disabled") && r(t)
    }, n.getBySelector = function(t) {
      var o = $(t);
      return {
        open: function() {
          e(o)
        },
        close: function() {
          d(o)
        },
        showPreloader: function() {
          o.find(".label").text("Carregando")
        },
        enable: function() {
          var t, e;
          t = o, (e = $(t)).css("pointer-events", "auto"), e.removeClass("disabled"), TweenLite.to(e, .5, {
            backgroundColor: e.data("list-bgcolor"),
            ease: Expo.easeOut
          }), 1 == e.find("li").length && f(t, 0, !0)
        },
        disable: function() {
          r(o)
        },
        getValue: function() {
          return o.find(".selected").data("value")
        },
        getLabel: function() {
          return o.find(".selected").text()
        },
        setLabel: function(t) {
          o.find(".label").text(t)
        },
        selectItemAt: function(t, e) {
          f(o, t, e = null == e ? !1 : e)
        },
        trigger: function(t) {
          o.trigger("change")
        },
        setData: function(t) {
          var e = o.find(".list-container ul");
          e.empty();
          for (var n = 0; n < t.length; n++) {
            var i = t[n];
            "Selecione" != i.Value && (i = "<li data-value='" + i.Value + "' data-disabled='" + i.Disabled + "'>" + i.Text + "</li>", e.append(i))
          }
          o.find("li").bind("click", v), o.find(".label").text("Selecione")
        },
        reset: function(t) {
          o.find(".list-container ul").empty(), o.find(".label").text(t)
        },
        bind: function(t, e) {
          return o.bind(t, e)
        }
      }
    }, $(document).find(i).each(function(t, e) {
      n.init(e)
    }), n.apply = function() {
      $(document).find(i).each(function(t, e) {
        n.init(e)
      })
    }, n.trigger = function(t) {
      l.trigger("change")
    }, window.BMS || (window.BMS = t), t.selectList = n
  }(window.BMS || {}),
  function(n) {
    var i, o, r, s, a, l, c, u, d, e, h = !1,
      f = window.top.location.href.match("/marisa"),
      p = ".quick-quotation-cellphone",
      m = !1;

    function v(t) {
      e = _invoiceDateSL.getStartDate(), y()
    }

    function g(t, e) {
      console.log("Load Brands"), o.showPreloader(), r.reset("Modelo"), r.disable(), _invoiceDateSL.disable(), null != e && "" != e ? $.getJSON("/seguro-eletronico/get-marcas?productCode=" + t + "&brand=" + e, function(t) {
        o.setData(t), o.enable()
      }) : $.post("/seguro-celular/nova-cotacao-rapida?isTheft=false&productCode=" + t, function(t) {
        console.log(t.PriceWithoutDiscount, "0,00" != t.PriceWithoutDiscount), "0,00" != t.PriceWithoutDiscount ? ($(".special-price").show(), $("#special-price-value").text("R$ " + t.PriceWithoutDiscount)) : $(".special-price").hide(), d = t.Price, qq.hidePreloader(), b(), s.prop("disabled", !1), $(".results-header .preloader").hide(), console.log("carregou"), $(".coverage .theft").show()
      })
    }

    function y() {
      var t = {
        ProductCode: a,
        gadgetMarcaNome: l,
        gadgetMarcaNomeTexto: l,
        ComboModelo: c,
        Modelo: c,
        Preco: u,
        NotaFiscal: e,
        UrlId: "Celular"
      };
      $("input[name='theft-only']").prop("checked") && (t.SomenteRoubo = "on"), qq.showPreloader(), s.prop("disabled", !0)
    }

    function b() {
      $(".price .value").html("R$ " + d), m = !0, TweenLite.to(".quick-quotation", .5, {
        height: 535,
        ease: Expo.easeOut
      }), TweenLite.to(".card", .5, {
        rotationX: 180,
        top: -84,
        ease: Expo.easeOut
      }), TweenLite.to(".card .products", .5, {
        alpha: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".quick-quotation-steps", .5, {
        top: 500,
        opacity: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".bg-green", .5, {
        opacity: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".results-content", .5, {
        top: 128,
        autoAlpha: 1,
        ease: Expo.easeOut
      });
      var t = $("<li style='width:100%' class='item'>Dispositivo: " + i.getLabel() + "</li>");
      $(".results-header .text").text("Seguro Celular:"), window.otherServices.isCurrentPartner("tim") && $(".results-header .text").text("TIM Protect Seguro Aparelho"), $(".results-header .icon-wrapper").empty(), $(".results-header .icon-wrapper").append('<span class="icon icon-cellphone-square"></span>'), $(".results-header").css("backface-visibility", "visible"), $(".results-content .specs").empty(), $(".results-content .specs").append(t), $(".btn-mosaic-purple").attr("href", "/seguro-celular/cotacao"), s.unbind("change", w), s.bind("change", w)
    }

    function w(t) {
      var e = $(".theft-only").prop("checked"),
        n = $(".selected").attr("data-value");
      console.log(t), $.post("/seguro-celular/nova-cotacao-rapida?isTheft=" + e + "&productCode=" + n, function(t) {
        "0,00" != t.PriceWithoutDiscount ? ($(".special-price").show(), $("#special-price-value").text("R$ " + t.PriceWithoutDiscount)) : $(".special-price").hide(), d = t.Price, qq.hidePreloader(), b(), s.prop("disabled", !1), $(".results-header .preloader").hide(), $(".coverage .theft").show(), e ? ($(".coverage .repairs").hide(), $(".coverage .liquid-spill").hide()) : ($(".coverage .repairs").show(), $(".coverage .liquid-spill").show())
      }), $(".results-header .preloader").show(), y()
    }

    function _() {
      m = !1, TweenLite.to(".quick-quotation", .5, {
        height: 355,
        ease: Expo.easeOut
      }), TweenLite.to(".card", .5, {
        rotationX: 0,
        top: -98,
        ease: Expo.easeOut
      }), TweenLite.to(".card .products", .5, {
        alpha: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".quick-quotation-steps", .5, {
        top: 200,
        opacity: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".bg-green", .5, {
        opacity: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".results-content", .5, {
        top: 300,
        autoAlpha: 0,
        ease: Expo.easeOut
      }), $(".results-header").css("backface-visibility", "hidden")
    }

    function S(t, e) {
      a = e.value, console.log(a), g(a)
    }

    function k(t, e) {
      var n;
      l = e.value, e = a, n = l, r.showPreloader(), $.getJSON("/seguro-eletronico/get-modelos?productCode=" + e + "&marca=" + n, function(t) {
        r.setData(t), r.enable()
      })
    }

    function M(t, e) {
      c = e.label, u = e.value, window.top.location.pathname.match("/webfones") ? _invoiceDateSL.enable() : y()
    }
    n.QQCellphone = {
      restart: function(t, e) {
        n.selectList.apply(), n.selectDate.apply(), $(document).find(p).each(function(t, e) {
          $(e), i = n.selectList.getBySelector(p + " .device-sl"), o = n.selectList.getBySelector(p + " .brand-sl"), r = n.selectList.getBySelector(p + " .model-sl"), _invoiceDateSL = n.selectDate.getBySelector(p + " .dates-sl"), s = $("input[name='theft-only']"), i.enable(), i.bind("change", S), o.bind("change", k), r.bind("change", M), _invoiceDateSL.bind("inSelect", v), $(".results-header button").bind("click", _), $(".carda").bind("click", function() {
            (m ? _ : b)()
          }), f && i.selectItemAt(1, !0)
        }), "" != t && (h = !0, a = t, "" != e && null != e && null != e ? g(a, l = e) : g(a))
      },
      reset: function() {
        h || (f && (o.reset("Marca"), r.reset("Modelo"), r.disable(), _invoiceDateSL.disable()), i.setLabel("Dispositivo"), o.reset("Marca"), o.disable(), r.reset("Modelo"), r.disable(), _invoiceDateSL.disable())
      }
    }, window.BMS = n
  }(window.BMS || {}),
  function(n) {
    var i, o, r, s, a, l, c, u, d = ".quick-quotation-electronics";

    function h() {
      $(".price .value").html("R$ " + u), TweenLite.to(".quick-quotation", .5, {
        height: 535,
        ease: Expo.easeOut
      }), TweenLite.to(".card", .5, {
        rotationX: 180,
        top: -84,
        ease: Expo.easeOut
      }), TweenLite.to(".card .products", .5, {
        alpha: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".quick-quotation-steps", .5, {
        top: 500,
        opacity: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".bg-green", .5, {
        opacity: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".results-content", .5, {
        top: 128,
        autoAlpha: 1,
        ease: Expo.easeOut
      });
      var t = $("<li style='width:100%' class='item'>Dispositivo: " + i.getLabel() + "</li>");
      $("<li class='item'>Marca: " + o.getLabel() + "</li>"), $("<li class='item'>Modelo: " + r.getLabel() + "</li>"), $(".results-header .text").text("Seguro para Eletrônicos:"), $(".results-header .icon-wrapper").empty(), $(".results-header .icon-wrapper").append('<span class="icon icon-electronic-square"></span>'), $(".results-content .specs").empty(), $(".results-content .specs").append(t), $(".btn-mosaic-purple").attr("href", "/seguro-eletronico/cotacao"); - 1 == ["Câmera Digital", "e-Reader", "Filmadora", "Fone de Ouvido", "GPS", "Lentes", "MP3 Player", "Notebook", "Tablet", "Smartwatches"].indexOf(i.getLabel()) && $(".coverage .theft").hide()
    }

    function f() {
      TweenLite.to(".quick-quotation", .5, {
        height: 355,
        ease: Expo.easeOut
      }), TweenLite.to(".card", .5, {
        rotationX: 0,
        top: -98,
        ease: Expo.easeOut
      }), TweenLite.to(".card .products", .5, {
        alpha: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".quick-quotation-steps", .5, {
        top: 200,
        opacity: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".bg-green", .5, {
        opacity: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".results-content", .5, {
        top: 300,
        autoAlpha: 0,
        ease: Expo.easeOut
      })
    }

    function p(t, e) {
      s = e.value, e = s, o.showPreloader(), r.reset("Modelo"), r.disable(), $.post("/seguro-eletronico/nova-cotacao-rapida?isTheft=false&productCode=" + e, function(t) {
        "0,00" != t.PriceWithoutDiscount ? ($(".special-price").show(), $("#special-price-value").text("R$ " + t.PriceWithoutDiscount)) : $(".special-price").hide(), u = t.Price, qq.hidePreloader(), h(), $(".results-header .preloader").hide(), $("#show-eletro").show()
      })
    }

    function m(t, e) {
      var n;
      a = e.value, e = s, n = a, r.showPreloader(), $.getJSON("/seguro-eletronico/get-modelos?productCode=" + e + "&marca=" + n, function(t) {
        r.setData(t), r.enable()
      })
    }

    function v(t, e) {
      l = e.label, c = e.value, e = {
        ProductCode: s,
        gadgetMarcaNome: a,
        gadgetMarcaNomeTexto: a,
        ComboModelo: l,
        Modelo: l,
        Preco: c,
        UrlId: "Eletronico"
      }, qq.showPreloader(), $.post("/seguro-eletronico/cotacao-rapida", e, function(t) {
        u = t, h(), qq.hidePreloader()
      })
    }
    n.QQElectronics = {
      restart: function() {
        n.selectList.apply(), $(document).find(d).each(function(t, e) {
          $(e), i = n.selectList.getBySelector(d + " .device-sl"), o = n.selectList.getBySelector(d + " .brand-sl"), r = n.selectList.getBySelector(d + " .model-sl"), i.enable(), i.bind("change", p), o.bind("change", m), r.bind("change", v), $(".results-header button").bind("click", f)
        })
      },
      reset: function() {
        i.setLabel("Dispositivo"), o.reset("Marca"), o.disable(), r.reset("Modelo"), r.disable()
      }
    }, window.BMS = n
  }(window.BMS || {}),
  function(n) {
    var i, o, r, s, a = ".quick-quotation-travel",
      l = !1;

    function c() {
      $(".price .value").html(_monthlyPrice.replace(".", ",")), l = !0, TweenLite.to(".quick-quotation", .5, {
        height: 535,
        ease: Expo.easeOut
      }), TweenLite.to(".card", .5, {
        rotationX: 180,
        top: -84,
        ease: Expo.easeOut
      }), TweenLite.to(".card .products", .5, {
        alpha: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".quick-quotation-steps", .5, {
        top: 500,
        opacity: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".bg-green", .5, {
        opacity: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".results-content", .5, {
        top: 128,
        autoAlpha: 1,
        ease: Expo.easeOut
      }), $(".results-header .text").text("Seguro Viagem:"), $(".results-header .icon-wrapper").empty(), $(".results-header .icon-wrapper").append('<span class="icon icon-travel-square"></span>');
      var t = $("<li class='item'>" + i.getLabel() + "</li>"),
        e = $("<li class='item'>" + o.getLabel() + "</li>"),
        n = $("<li class='item'>" + s.getStartDate() + " - " + s.getEndDate() + "</li>");
      $(".results-content .specs").empty(), $(".results-content .specs").append(t), $(".results-content .specs").append(e), $(".results-content .specs").append(n), $(".btn-mosaic-purple").attr("href", "/seguro-viagem/cotacao")
    }

    function u() {
      l = !1, TweenLite.to(".quick-quotation", .5, {
        height: 355,
        ease: Expo.easeOut
      }), TweenLite.to(".card", .5, {
        rotationX: 0,
        top: -98,
        ease: Expo.easeOut
      }), TweenLite.to(".card .products", .5, {
        alpha: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".quick-quotation-steps", .5, {
        top: 200,
        opacity: 1,
        ease: Expo.easeOut
      }), TweenLite.to(".bg-green", .5, {
        opacity: 0,
        ease: Expo.easeOut
      }), TweenLite.to(".results-content", .5, {
        top: 300,
        autoAlpha: 0,
        ease: Expo.easeOut
      })
    }

    function d(t, e) {
      o.enable()
    }

    function h(t, e) {
      r.enable()
    }

    function f(t) {
      s.enable()
    }

    function p(t) {
      var e;
      e = {
        OriginId: i.getValue(),
        DestinationId: o.getValue(),
        TravelersBetween0And12: $(".coverage-sl #age0-12").val(),
        TravelersBetween13And70: $(".coverage-sl #age13-70").val(),
        TravelersBetween71And85: $(".coverage-sl #age71-85").val(),
        StartDate: s.getStartDate(),
        EndDate: s.getEndDate(),
        IsEuropeanTrip: s.getIsthroughEurope()
      }, qq.showPreloader(), $.post("/seguro-viagem/cotacao-rapida", e, function(t) {
        if ("object" == typeof t) return Lightbox.show(t[0]), qq.hidePreloader(), !1;
        _monthlyPrice = t, c(), qq.hidePreloader()
      })
    }
    n.QQTravel = {
      restart: function() {
        n.selectList.apply(), n.selectCustom.apply(), n.selectDate.apply(), $(document).find(a).each(function(t, e) {
          $(e), i = n.selectList.getBySelector(a + " .origin-sl"), o = n.selectList.getBySelector(a + " .destination-sl"), r = n.selectCustom.getBySelector(a + " .coverage-sl"), s = n.selectDate.getBySelector(a + " .dates-sl"), i.enable(), i.bind("change", d), o.bind("change", h), s.bind("complete", p), $(".coverage-sl #age0-12").bind("change", f), $(".coverage-sl #age13-70").bind("change", f), $(".coverage-sl #age71-85").bind("change", f), $(".results-header button").bind("click", u), $(".carda").bind("click", function() {
            (l ? u : c)()
          })
        })
      },
      reset: function() {}
    }, window.BMS = n
  }(window.BMS || {});
