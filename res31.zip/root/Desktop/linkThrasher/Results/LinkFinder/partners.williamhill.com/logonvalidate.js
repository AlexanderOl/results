	function validRequired(formField,fieldLabel,Message) {
		var result = true;
		if (formField.value == "")
		{
			alert(Message);
			formField.focus();
			result = false;
		}
		return result;
	}
	
	
	//validate login
	
	function validRequired(formField,fieldLabel,Message)
	{
		var result = true;
		if (formField.value == "")
		{
			alert(Message);
			formField.focus();
			result = false;
		}
		return result;
	}

	function LogonValidate(theForm)
	{
		if (!validRequired(theForm.username,"username", "You need to enter your username"))
		return false;
		if (!validRequired(theForm.password,"password", "You must insert your password!"))
		return false;
		return true;
	}
	
	function CancelClick() {
		history.go(-1);
	}
	
	function setFocus() {
		document.forms[0].username.focus();
	}
	
//merchants application validation

function Validate()
{var test;
test = document.merchantapp.name.value;
	if (test == "")
	{
		alert("Please provide your Name");
		document.merchantapp.name.focus();
		return false;
	}
test = document.merchantapp.company.value;
	if (test == "")
	{
		alert("Please provide your Company");
		document.merchantapp.company.focus();
		return false;
	}
test = document.merchantapp.email.value;
	if (test == "")
	{
		alert("Please provide your email address");
		document.merchantapp.email.focus();
		return false;
	}
test = document.merchantapp.phone.value;
	if (test == "")
	{
		alert("Please provide your Phone number");
		document.merchantapp.phone.focus();
		return false;
	}
test = document.merchantapp.url.value;
	if (test == "")
	{
		alert("Please provide your Website address");
		document.merchantapp.url.focus();
		return false;
	}
test = document.merchantapp.product.value;
	if (test == "")
	{
		alert("Please provide your Product or Service");
		document.merchantapp.product.focus();
		return false;
	}
	return true;
}


