jQuery(document).ready(function ($) {
    //Resize registration form tabs based on widths and padding of each tab in the registration wizard
    if (jQuery(".steps").length) {
        var regSteps = jQuery("ul.steps li");
        var totalWidth = 0;

        regSteps.each(function (idx, li) {
            var item = $(li);
            totalWidth += item.width() + 75;
        });

        if (totalWidth < 700) { //less than 700, default wizard panel width to 800
            jQuery(".wizard-wrapper").width(800);
        } else {
            jQuery(".wizard-wrapper").width(totalWidth);
        }
    }
        jQuery.validator.setDefaults({
            rules: {
                username: {
                    required: true,
                    minlength: 2,
                    regex: /^[a-zA-Z0-9 ._@#*&,/-]*$/,
                    remote: "./includes/scripts/ajax_affdetails.asp"
                },
                emailaddress: {
                    minlength: 2,
                    regex: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-.]+(?:\.[a-zA-Z0-9]+)*$/,
                    remote: "./includes/scripts/ajax_affdetails.asp"
                },
                verificationimg: {
                    minlength: 1,
                    remote: "./includes/scripts/ajax_affdetails.asp"
                },
                password: {
                    required: true,
                    ispassword: true
                },
                passwordretype: {
                    required: true,
                    equalTo: "#password"
                }
            },
            errorClass: 'has-error control-label',
            validClass: 'has-success',
            highlight: function (element, errorClass, validClass) {
                if (element.type === "radio") {
                    this.findByName(element.name).addClass(errorClass).removeClass(validClass);
                } else {
                    jQuery(element).closest('.input-group').removeClass('has-success has-feedback').addClass('has-error has-feedback');
                    jQuery(element).closest('.input-group').find('i.fa').removeClass('fa-asterisk').removeClass('fa-check').addClass('fa-exclamation');
                }
            },
            unhighlight: function (element, errorClass, validClass) {
                if (element.type === "radio") {
                    this.findByName(element.name).removeClass(errorClass).addClass(validClass);
                } else {
                    jQuery(element).closest('.input-group').removeClass('has-error has-feedback').addClass('has-success has-feedback');
                    jQuery(element).closest('.input-group').find('i.fa').removeClass('fa-asterisk').removeClass('fa-exclamation').addClass('fa-check');
                }
            },
            errorPlacement: function (error, element) {
                if (jQuery(element).hasClass('groupedElement')) {
                    $newDiv = jQuery("<div class='input-group has-error'></div>");
                    element.closest('.form-group').append($newDiv);
                    $newDiv.append(error);
                } else {
                    error.insertAfter(element);
                }
            }
        });

        var errormessage = " ";
        jQuery.validator.addMethod(
            "regex",
            function (value, element, regexp) {
                errormessage = element.name == "emailaddress" ? "You have entered an invalid character. Please enter valid characters." : "Please check the username entered. (Allowed : a-zA-Z0-9 ._@#*&,/-)"
                if (regexp.constructor != RegExp)
                    regexp = new RegExp(regexp);
                else if (regexp.global)
                    regexp.lastIndex = 0;
                return this.optional(element) || regexp.test(value);
            }, function () { return errormessage }
        );

        var validator = jQuery('#registrationform').validate({
            debug: false
            , ignore: ':hidden'
            , onblur: false
        });

        jQuery('.next').on('click', function () {
            var current = jQuery(this).data('currentBlock');
            var next = jQuery(this).data('nextBlock');
            var valid;

            // only validate going forward. If current group is invalid, do not go further
            if (next > current)
                valid = true;

            var panelId = jQuery('#block' + current);

            //if (typeof window.console !== "undefined") {
                //console.log("currently checking panel:" + '#block' + current);
           // }

            jQuery(panelId).find(":input").each(function () {
                var input = jQuery(this);

                //if (typeof window.console !== "undefined") {
                //    console.log("error check : " + input.attr('id') + ":" + input.val() + ":");
                //    console.log("validator.element(this)" + validator.element(this));
                //    console.log("valid" + valid);
               // }

                if (validator.element(this) === false && valid) { // sometimes validator returns undefined this is not the same as false
                    valid = false;
                }
            });

            if (false === valid)
                return;

            // validation was ok. We can go on next step.
            jQuery('.block' + current).removeClass('show').addClass('hidden');
            jQuery('.block' + next).removeClass('hidden').addClass('show');

            jQuery('#progress-block' + current).removeClass('active');
            jQuery('#progress-block' + next).addClass('active');
        });

});



