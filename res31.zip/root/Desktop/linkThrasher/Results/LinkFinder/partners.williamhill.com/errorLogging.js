﻿window.addEventListener('error', function (e) {
    if (e.message != undefined) {

        var errorToLog = {};

        errorToLog.AppSource = "javascript";
        errorToLog.AppLocation = window.location;
        errorToLog.ExceptionType = "javascript";
        errorToLog.Message = e.message + "\r\n" + ErrorEvent.error;
        errorToLog.Stack = "File=" + ErrorEvent.filename + "\r\nLine=" + ErrorEvent.lineno + "\r\nCol=" + ErrorEvent.colno;

        var errorUrl = "/netapp/api/ErrorLog/LogError";

        var xhr = new XMLHttpRequest();
        xhr.open("POST", errorUrl,true);
        xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');

        // send the collected data as JSON
        xhr.send(JSON.stringify(errorToLog));
    }
}, true);