//---------------------------------------------------------------//
// Global Variables.............
//Images
	var uparrow = "../../clientincludes/images/UpArrow.gif";
	var downarrow = "../../clientincludes/images/dwnArrow.gif";
	var newimage = "../../clientincludes/images/shim.gif";
// Records
	var defaultrecsperpage = 35;
// Spreadsheet
	var Spreadsheeturl = "excel.asp"
	var spreadsheetwindow="excelresults"
	
	var currentgroupby ='memberid'
	var currentcolumn='memberid'
	var currentorder='descending'
	var recordsperpage=35
	if (typeof currencysymbol=='undefined') {currencysymbol = "$";}
	if (typeof merchcolumns=='undefined') {merchcolumns = "";}
//---------------------------------------------------------------//
function TransformXMLPages(page){
	
	groupby = currentgroupby ;
	column = currentcolumn;
	order = currentorder;
	currentrecordsperpage = recordsperpage
	
	recordsperpage = GetValue("recordsperpage");
	if (!recordsperpage){
		recordsperpage = currentrecordsperpage;
	}


	var parameterarray = new Array()
	parameterarray = ['sortKey', column,'sortOrder', order,'currentpage',page,'groupby',groupby,'recordsperpage',recordsperpage,'currencysymbol',currencysymbol,'merchcolumns',merchcolumns,'langid',langid]
	
	var moz = (typeof document.implementation != 'undefined') && (typeof document.implementation.createDocument != 'undefined');
	if(moz) { 
	 	// Mozilla!! 
	 	 TransformXML_Moz (parameterarray,'container',xslpath);
	} else { 
		 TransformXML_IE2 (parameterarray,'container',xslpath); 
	}
	
	currentgroupby=groupby
	currentcolumn=column
	currentorder=order
	recordsperpage=recordsperpage

}


function TransformXML(sortcolumn, groupby){
// set defaults for xsl parameters
var parameterarray = new Array();
var order="descending";
var newclass= "SortingGriddown"
//var recordsperpage=defaultrecsperpage;
///////////////////////////////////////////////////////////////
// ONly if the page has the paging container do this.........
	if (sortcolumn.length > 0){		
		//if (sortcolumn ==fieldvalue('currentcolumn')){
		if (sortcolumn ==currentcolumn){
			if (currentorder=="ascending"){
				order="descending"
				newimage = downarrow
			}
			else{
				order="ascending"
				newimage = uparrow
			}
		}
		else{
			order="ascending"
			newimage = uparrow
		}
	}
	else {		
		order="ascending"
		newimage = uparrow
	}
	if (!groupby){
		groupby = currentgroupby;
	}
	
	if (!recordsperpage){
		recordsperpage = defaultrecsperpage;
	}
	parameterarray = ['sortKey', sortcolumn,'sortOrder', order,'groupby',groupby,'recordsperpage',recordsperpage,'currencysymbol',currencysymbol,'merchcolumns',merchcolumns,'langid',langid]


///////////////////////////////////////////////////////////////
// load xml and xsl files	
	loadcontainer = 'container';
	//alert('sortKey'+sortcolumn+'sortOrder' + order +'groupby' +groupby +'recordsperpage' + recordsperpage)
	//alert(xslpath)
	var moz = (typeof document.implementation != 'undefined') && (typeof document.implementation.createDocument != 'undefined');
	if(moz) { 
	 	// Mozilla!! 
	 	 TransformXML_Moz (parameterarray,loadcontainer,xslpath);
	} else { 
		 TransformXML_IE2 (parameterarray,loadcontainer, xslpath); 
	}
	
	//Changeclass(sortcolumn,newclass);
	ChangeImage(sortcolumn,newimage)
	
///////////////////////////////////////////////////////////////
// remember current settings............
	currentgroupby=groupby
	currentcolumn=sortcolumn
	currentorder=order
	recordsperpage=recordsperpage
// Done!!!!!
}
//****************************************************************************************************
function TransformXMLExcel(xslpath){

	groupby = currentgroupby ;
	column = currentcolumn;
	order = currentorder;

	var parameterarray = new Array()
	parameterarray = ['sortKey', column,'sortOrder', order,'currentpage',1,'groupby',groupby,'recordsperpage',0,'excelformat','no','currencysymbol',currencysymbol,'merchcolumns',merchcolumns]

	
	var moz = (typeof document.implementation != 'undefined') && (typeof document.implementation.createDocument != 'undefined');
	if(moz) { 
	 	// Mozilla!! 
	 	newxmlstring =  TransformXML_Moz (parameterarray,'',"../xslstylesheets/" + xslpath);
	} else { 
		newxmlstring =  TransformXML_IE2 (parameterarray,'',"../xslstylesheets/" + xslpath); 
	}
	newwindow=window.open("../reporting/excel.asp");
	newdocument=newwindow.document;
	newdocument.write(newxmlstring);
	newdocument.close();

}

// create an instance of XSLTProcessor
function TransformXML_Moz (arguments, loadcontainer, xslurlpath){
	// GET Xml data
		xmlcontent = document.getElementById("xmlcontent");
		xmlstring = xmlcontent.innerHTML
		//alert(xmlstring);
		xmlDoc = (new DOMParser()).parseFromString(xmlstring, "text/xml");
	// Get XSL Data
		var xmlHttp = new XMLHttpRequest();
		xmlHttp.open("GET", xslurlpath, false);
		xmlHttp.send(null);
		xmlstring = xmlserializer(xmlHttp.responseXML);
		xmlstring = xmlHttp.responseXML;
	// load XSL
		var processor = new XSLTProcessor();	
		
		//XSLTProcessor.setParameter(null, "name", "descending");
		// configure the processor to use our stylesheet 
		processor.importStylesheet(xmlstring);
		for (var i=0; i<arguments.length; i++){	
				paramName=arguments[i];
				paramValue=arguments[i+1];
				i=i+1;
				//alert(paramName)
				//alert(paramValue)
				//alert(paramName + '='+paramValue)
				processor.setParameter(null, paramName, paramValue);
		}
		// transform and store the result as a new doc
		var resultDocument = processor.transformToDocument(xmlDoc);
		//var resultDocument = processor.transformToFragment(xmlDoc,document);
		// show transformation results
		transformedresults = xmlserializer(resultDocument);
		if (!loadcontainer){
			return transformedresults
		}
		else {
			if (document.getElementById)
			{
				//alert(transformedresults);
				x = document.getElementById(loadcontainer);
				x.innerHTML = transformedresults;
			}
			else if (document.all)
			{
				x = document.all[loadcontainer];
				x.innerHTML = transformedresults;
			}
			else if (document.layers)
			{
		
				document.writeln(transformedresults)
				}		
		}
		//document.write (transformedresults);
}

///////////////////////////////////////////////////////////////////////////////////////////////
function xmlserializer(theobject){
	return (new XMLSerializer()).serializeToString(theobject);
}
///////////////////////////////////////////////////////////////////////////////////////////////

function TransformXML_IE2 (arguments, loadcontainer,xslurlpath){

	// Load Xsl
	var xsl = new ActiveXObject("Microsoft.XMLDOM")
	xsl.async = false
	xsl.load(xslurlpath)
	
	var xslt = new ActiveXObject("Msxml2.XSLTemplate.3.0");
	var xsldoc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument.3.0");
	var xslproc;
	xsldoc.async = false;
	xsldoc.load(xsl);
	//alert(xslurlpath);
	if (xsldoc.parseError.errorCode != 0)
	{
   		var myErr = xsldoc.parseError;
   		alert("You have an XSLT parse error: " + myErr.reason);
	}
	else
	{


		xmlstring = xmlcontent.innerHTML
		
   		xslt.stylesheet = xsldoc;
   		var xmldoc = new ActiveXObject("Msxml2.DOMDocument.3.0");
		xmldoc.async = false;
		xmldoc.loadXML(xmlstring);
   		if (xmldoc.parseError.errorCode != 0)
   		{
      		var myErr = xmldoc.parseError;
      		alert("You have an XML parse error: " + myErr.reason);
   		}
   		else
   		{
      		xslproc = xslt.createProcessor();
      		xslproc.input = xmldoc;
			for (var i=0; i<arguments.length; i++){	
				paramName=arguments[i];
				paramValue=arguments[i+1];
				i=i+1;
				//alert(paramName + '='+paramValue)
				//alert(paramValue)
				xslproc.addParameter(paramName,paramValue);
			}
			//xslproc.addParameter("sortKey", column);
			//xslproc.addParameter("sortOrder", order);
      		xslproc.transform();
			//alert(xslproc.output);
			//document.getElementById("container").innerHTML = xslproc.output;
			if (!loadcontainer){
				return xslproc.output
				}
			else {
				document.getElementById(loadcontainer).innerHTML = xslproc.output;
      			//container.innerHTML = xslproc.output;
			}
   		}
	}

}
//********************************************************
function Changeclass(DocID,ClName){

	if(document.getElementById) {
    	e= document.getElementById(DocID);
		alert(e.type)
		if (e) 	e.className=ClName
	}
  else{
  	e= document.all(DocID);

	if (e) e.className=ClName
	}
}
//********************************************************
function ChangeImage(DocID,imagename){

	if(document.getElementById) {
    	e= document.getElementById(DocID);
		if (e) 	e.src=imagename
	}
  else{
  	e= document.all(DocID);

	if (e) e.src=imagename
	}
}
//********************************************************
function Getclass(DocID){

	if(document.getElementById) {
    	e= document.getElementById(DocID);
		if (e) 	return e.className;
	}
  else{
  	e= document.all(DocID);
	if (e) return e.className
}
}
//********************************************************
function GetValue(elementname){
		if (document.getElementById)
		{
			x = document.getElementById(elementname);
			return x.value ;
		}
		else if (document.all)
		{
			x = document.all[elementname];
			return x.value;
		}

}
//********************************************************
function SetValue(elementname,newvalue){
	if (document.getElementById)
		{
			x = document.getElementById(elementname);
			x.value= newvalue;
		}
		else if (document.all)
		{
			x = document.all[elementname];
			x.value=newvalue;
		}
}
//********************************************************
function fieldexists (fieldname) {	
	var result = false;
	if (document.layers)
	{
		fieldcheck = document.layers[fieldname];

	}
	else if (document.getElementById)
	{
		fieldcheck = document.getElementById(fieldname);

	}
	else if (document.all)
	{
		fieldcheck = document.all[fieldname];

	}
	
	if (fieldcheck!=null){ result = true;}
	return result;
	
}
//********************************************************
function fieldvalue (fieldname) {	
	var result = false;
	if (document.layers)
	{
		fieldcheck = document.layers[fieldname].value;

	}
	else if (document.getElementById)
	{
		fieldcheck = document.getElementById(fieldname).value;

	}
	else if (document.all)
	{
		fieldcheck = document.all[fieldname].value;

	}
	
	return fieldcheck;
	
}