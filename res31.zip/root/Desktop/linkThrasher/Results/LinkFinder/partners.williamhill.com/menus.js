jQuery(document).ready(function($){

	//$(document).ready(function(){/* smooth scrolling for scroll to top */
	jQuery('.scroll-top').click(function(){
	jQuery('body,html').animate({scrollTop:0},800);
})
/* smooth scrolling for scroll down */
jQuery('.scroll-down').click(function(){
  jQuery('body,html').animate({scrollTop:jQuery(window).scrollTop()+800},1000);
})

/* highlight the top nav as scrolling occurs */
jQuery('body').scrollspy({ target: '#navbar' })

});



