function createWindow(url,windowname,w,h,l,t,mb,sb,tb,rb) 
{
	if (!w){w=600;}//width
	if (!h){h=400;}//height
	if (!l){l=100;}//left
	if (!t){t=100;}//top
	if (!mb){mb=0;}//menubar
	if (!sb){sb=1;}//scrollbar
	if (!tb){tb=0;}//toolbar
	if (!rb){rb='yes';}//resizeable
    var features ='width=' + w+
        ',height='      + h +
        ',left=' + l +
        ',top='    + t +
        ',menubar='     + mb +
        ',scrollbars='  + sb +
        ',toolbar='     + tb +
        ',resizable='   + rb;
		newwindow = open (url, windowname, features);
		newwindow.focus();
	
}

function resizeWin()
{
	var winHeight =500;
	var winWidth = 800;

if(window.innerWidth >= screen.availWidth){return true;}
else{

if (document.getElementById('reportcriteria')){  
	winWidth = document.getElementById('reportcriteria').offsetWidth;
}else if (document.getElementById('body')){  
	winWidth = document.getElementById('body').offsetWidth;
}else if (window.innerWidth) {  
	winWidth = window.innerWidth;
}else if (document.all) {  
	winWidth = document.body.clientWidth;
}

if (window.innerHeight) {
	winHeight = window.innerHeight;

}else if (document.all) {
	winHeight = document.body.clientHeight;
}

winHeight =(winHeight>0 ? winHeight :500);
winWidth = (winWidth>0 ? winWidth : 800);

window.resizeTo(winWidth+50,winHeight+200);
}

}

function fnloadAffiliateGroups(){
if (fieldexists("merchantid")){
 	var selmerchantid = getObj("merchantid").options[getObj("merchantid").selectedIndex].value;
 	params ="list=affiliategroup&merchantid=" + selmerchantid;
	var mytypeAjax = new Ajax.Updater('RPaffgroups', '../../includes/scripts/ajax_selectlist.asp', { parameters: params} );
}
return true;
}
function fnloadPromoGroups(){
if (fieldexists("merchantid")){
 	var selmerchantid = getObj("merchantid").options[getObj("merchantid").selectedIndex].value;
 	params ="list=promogroup&merchantid=" + selmerchantid;
	var mytypeAjax = new Ajax.Updater('RPpromogroups', '../../includes/scripts/ajax_selectlist.asp', { parameters: params} );
}
return true;
}
function fnloadPromoGroupsALL(){
if (fieldexists("merchantid")){
 	var selmerchantid = getObj("merchantid").options[getObj("merchantid").selectedIndex].value;
 	params ="list=promogroup&allowall=true&merchantid=" + selmerchantid;
	var mytypeAjax = new Ajax.Updater('RPpromogroups', '../../includes/scripts/ajax_selectlist.asp', { parameters: params} );
}
return true;
}
function fnselrow(curclassname,classid){
	if (curclassname == 'reportrowsel'){ return 'reportrow'+ classid;}
	else {return 'reportrowsel';}
}
function toggletable(tableid,rowid){
	thistbl = document.getElementById(tableid);
	thistablewidth = thistbl.offsetWidth;
	thistbllnk= document.getElementById(tableid + "link");
	var trs = thistbl.getElementsByTagName("tr");
    for (var i = 1; i < trs.length; i++) {
	if (rowid == trs[i].id){	
		showMode = 	trs[i].style.display;
		if (showMode=="none") {thistbl.style.width=thistablewidth; trs[i].style.display = "";  thistbllnk.innerHTML ="[Less]";}
		else {thistbl.style.width=thistablewidth; trs[i].style.display = "none";  thistbllnk.innerHTML ="[More]";	}
	}
	}
	thistbl.style.width=thistablewidth;
}

function FNajaxload(loadfield, loadurl, params){
	new Ajax.Updater(loadfield, loadurl,  { parameters: params} );
}
function toggleEL(divid){
	thisel = document.getElementById(divid);
	thisellnk= document.getElementById(divid + "link");
	if (thisel){
		showMode = 	thisel.style.display;
		if (showMode=="none") {thisel.style.display = "";thisellnk.innerHTML ="[-]";}
		else {thisel.style.display = "none";thisellnk.innerHTML ="[+]";	}
	}
}
function fnloadImageFarmList(){
if (fieldexists("merchantid")){
 	var selmerchantid = getObj("merchantid").options[getObj("merchantid").selectedIndex].value;
 	params ="list=imagefarmlist&merchantid=" + selmerchantid;
	var mytypeAjax = new Ajax.Updater('RPimagelist', '../includes/scripts/ajax_selectlist.asp', { parameters: params} );
}
return true;
}

function PostLink(url, params) {
    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", url);
    form.setAttribute("target", "_blank");
    for (var i in params) {
        if (params.hasOwnProperty(i)) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = i;
            input.value = params[i];
            form.appendChild(input);
        }
    }
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}