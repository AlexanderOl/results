
jQuery(document).ready(function ($) {
    // observable for the current active language
    ko.language = ko.observable();
    /*
    * Initialize the translation. Initial language will be German, the fallback
    * language will be English. As a callback (after the translation resources
    * have been loaded) the active language is updated (and only then the
    * re-computation of any translations is triggered)
    */
    var langidactive = jQuery.cookie("aflang"); 
    var langisoactive = (jQuery.cookie("aflangiso") == undefined ? "en" : jQuery.cookie("aflangiso"));

    jQuery.i18n.init({
        useCookie: false,
        detectLngQS: false,
        lng: langisoactive,
        debug: false,
        fallbackLng: false,
        ns: { namespaces: [ 'common'] },
        resGetPath: "/clientincludes/languages/__lng__/translate__ns__.json"
    }, function () {
        ko.language(langisoactive);
    });

    /*
    * returns a computed value for a given key. As it is dependent on the current
    * active language the outcome will change when the language changes.
    */
    ko.i18n = function (key) {
        key = key.toLowerCase();
        return ko.computed(function () {
            if (ko.language() != null) {
                //console.log(key + ' -- ' + ko.language());
                return i18n.t(key, { lng: ko.language() });
            } else {
                return "";
            }
        }, key);
    };
    translate = ko.i18n;

    ko.applyBindings({ iatrans: ko.i18n })


    jQuery.urlParam = function (name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results == null) {
            return null;
        }
        else {
            return results[1] || 0;
        }
    }

    /* CHECK EXISTING LANGUAGE PREFERENCES
    * users can either link to the page with a param of &lang=1 - where 1 is a language id associated with the language 
    * - this matches the langid in the programs db - tbl_languages table and will also match the langid in config.xml files
    *  at the end of the checks  active  vars should now contain any preset language preferences  we will want to load languages on the page according to these settings
    */
    var self = this;
    // ALL clients always have an english translation - so if we cannot set anything else we will load english
    var langiddefault = 1;
    var langisodefault = "en";
    // did we get a lang id passed to the page that we should change to???
    var langidactive = (jQuery.urlParam('lang') == null ? "" : jQuery.urlParam('lang'));
    var langisoactive = "";
    // if no language was passed to the page then we will try to find a predefined preference in cookies
    if (langidactive == "") {
        langidactive = jQuery.cookie("aflang");
    }


    /* LOAD LANGUAGE SETTINGS FOR SITE
    * each client template contains a config.xml file that contains the permitted languages for the site
    * and what the default language is to load if no preference has been set for the client
    * this ajax call will load the xml and parse the results to set the active language preferences for the site
    */
  

    jQuery.getJSON("/clientincludes/templates/" + vartemplatename + "/config.json", function (data) {
        var langlist = "";
        var languageclass = "";
        // language drop down class - use this value to control what displays, flag, label or both
        if (typeof data.languagesettings.languageclass != 'undefined') {
            languageclass = data.languagesettings.languageclass;
        }
        if (languageclass.length == 0) languageclass = "lang-lbl";// default to label(language name) only if nothing is set in the config


        //LANGUAGE LOAD - LOOP through config  settings and if active guild language dropdown
        if (typeof data.languagesettings.language != 'undefined') { // test if we actually have a language list if not then do not display lang picker
			var langcount =0;
			
            jQuery.each(data.languagesettings.language, function (i, result) {

                //var id = $(this).attr('id');
                var isolangcode = result.isolangcode;
                var langid = result.langid;
                var defaultflag = result.default;
                //console.log("isolangcode=" + isolangcode);
                // change the defaults for the program if we find a default flag
                if (defaultflag == 1) {
                    langiddefault = langid;
                    langisodefault = isolangcode;
                }
                // if we find a match for the active language set the iso lang code
                if (langidactive == langid) {
                    langisoactive = isolangcode;
                }
                langlist += '<li><a href="#" class="' + languageclass + '" lang="' + isolangcode + '" langid="' + langid + '" ></a></li>';
				langcount += 1;
            })
            //----------------------------------------------
            // active language check - if we still have no active language set use the program defaults to set language to load
			//console.log (langcount);
            if (langidactive.length == 0) {
                langidactive = langiddefault;
                langisoactive = langisodefault;
            }
            // remember the active language
            jQuery.cookie("aflang", langidactive, { expires: 30000 });
            jQuery.cookie("aflangiso", langisoactive, { expires: 30000 });

            // load list of languages into #langpicker  div paceholder
			if (langcount>1) {
            jQuery('<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">'
                    + '<span class="' + languageclass + '" lang="' + langisoactive + '" langid="' + langidactive + '"></span> <span class="caret"></span> '
                    + '</a><ul id="langpickerDD" role="menu" class="dropdown-menu">'
                    + langlist
                    + '</ul>').appendTo('#langpicker');
			}
            // load any dynamic languages now
            jQuery.i18n.setLng(langisoactive, function () {
                if (ko.language() != langisoactive) {
                    ko.language(langisoactive);
                }
            });

            // bind the newly added language options to click
            jQuery('#langpicker ul.dropdown-menu li a').on("click", function (e) {

                var newLanguage = jQuery(this).attr("lang");
                var newLanguageid = jQuery(this).attr("langid");
                var $div = jQuery(this).parent().parent().parent();
                $div.find('span.' + languageclass + '').first().attr("lang", newLanguage);

                jQuery.cookie("aflang", newLanguageid, { expires: 30000 })
                jQuery.cookie("aflangiso", newLanguage, { expires: 30000 })
                jQuery("#langpickerDD").dropdown("toggle");

                var thispage = "";
                thispage = (document.location.pathname.match(/[^\/]+$/) ? document.location.pathname.match(/[^\/]+$/)[0] : "");
                if (thispage == "default.asp" || thispage == "") {
                    jQuery.i18n.setLng(newLanguage, function () {
                        if (ko.language() != newLanguage) {
                            ko.language(newLanguage);
                        }
                    });
                } else {
                    // while we still have some pages with asp language translations and others with javascript we need to reload 
                    // future releases we will be able to reload all in page
                    // document.location.href.match(/[^\/]+$/)[0]
                    window.location.href = '?lang=' + newLanguageid;
                    return false;
                }
            });
        }
    });
    
                


})




