﻿//Global variables
//------------------------------------------------------
getLogoapiUrl = "/netapp/Api/MerchantLogo/GetMerchantLogoCdn";
getAllLogosapiUrl = "/netapp/Api/MerchantLogo/GetAllMerchantsLogos";
uploadLogoapiUrl = "/netapp/Api/MerchantLogo/UploadMerchantLogo";
resetLogoapiUrl = "/netapp/Api/MerchantLogo/RemoveMerchantLogo/?merchantId=";
maxSize = 25 * 1024;//25KB maximum file size
fileSize = 0;
limitSizeExeeded = 1001; //This code will be retured by API if the file size exceeds 25KB
//-------------------------------------------------------

jQuery(document).ready(function () {

    //calling this funtion to initiate events for merchant/details.asp
    InitEvents();

    //loading logo for login and registration pages 
    const urlParams = new URLSearchParams(window.location.search);
    var mid = urlParams.get('mid');
    LoadLogo(mid, ".logo-merchant");

    //loading logo in merchant/details.asp page inside the logo field
    mid = jQuery('#pmerchantid').val();
    LoadLogo(mid, "#logocdn");

    //Loading all logos 
    LoadAllLogos();
    
})

//Loding all logos 
function LoadAllLogos() {
    if (jQuery('#alllogosflag').length>0 && jQuery('#alllogosflag').val() == "1") {
        jQuery.ajax({
            type: "GET",
            url: getAllLogosapiUrl,
            success: function (data) {
                CreateHtmlTag(data);
            }
        });
    }
}
//Loading logo 
function LoadLogo(mid, img) {
    if (mid) {
        jQuery.ajax({
            type: "GET",
            url: getLogoapiUrl,
            cache: false,
            data: { merchantId: mid },
            success: function (cdn) {
                jQuery(img).attr("src", cdn);
            }
        });
    }
   
}

function CreateHtmlTag(data) {

    var logosTag = jQuery('.all-merchant-logos');
    if (logosTag) {
        
        var injectedHtml = "";
        jQuery.each(data, function (i, record) {
            var htmlTag = "<div class='col-md-2 col-xs-2 col-sm-2' style='margin-left:8px;margin-top:8px;' ><a href=#url class='logo' target='_blank'><img class='logo' width='120' height='80' src=#src/></a></div>";
            htmlTag = htmlTag.replace("#url","'"+record.LogoURL+"'");
            htmlTag = htmlTag.replace("#src","'"+ record.LogoCDN+"'");
            injectedHtml += htmlTag;
        });
        //There is some injected tags
        if (injectedHtml.length > 0 && jQuery(logosTag).length>0) {
            jQuery(logosTag)[0].innerHTML  = injectedHtml;
        }
    }
}

//Initializing all events for merchant/details.asp page
function InitEvents() {
    jQuery('#uploadlogo').click(function () {
        jQuery('#choosefile').trigger('click');
    })

    jQuery("#choosefile").change(function () {
        ReadURL(this);
        
    });

    function ReadURL(input) {
        if (input.files && input.files[0]) {
            fileSize = input.files[0].size;
            if (fileSize <= maxSize) {
                var reader = new FileReader();
                reader.onload = function (e) {

                    jQuery('#logocdn').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
            else {
                alert("File size cannot be more than 25KB");
            }
        }
        
    }

    jQuery('#submitlogo').click(function () {
        
        var merchantLogoDTO = {
            MerchantLogosId: jQuery('#merchantlogoid').val(),
            ParentMerchantId: jQuery('#pmerchantid').val(),
            LogoCDN: jQuery('#logocdn').val(),
            LogoURL: jQuery('#logourl').val(),
            FileStream: jQuery('#logocdn').attr('src')
        };

        jQuery.ajax({
            url: uploadLogoapiUrl,
            type: 'POST',
            dataType: "application/json",
            cache: false,
            data: merchantLogoDTO,
            success: function (code) {
                if (code == limitSizeExeeded) {
                    alert("File size cannot be more than 25KB");
                }
            },
            error: function () {
                console.log('something wrong happens in UploadMerchantLogo API...');
            }
        });
    })

    jQuery('#resetlogo').click(function () {

        var url = resetLogoapiUrl + jQuery('#pmerchantid').val()

        if (confirm('Are you sure you want to remove the logo?')) {
            jQuery.ajax({
                url: url,
                type: 'POST',
                success: function () {
                    jQuery("#logocdn").attr("src", "");
                    jQuery("#logourl").val("");
                },
                error: function () {
                    console.log('something wrong happens in RemoveMerchantLogo API...');
                }
            });
        }
    })
}