﻿
$(window).load(function () {
    function scrollingText(time) {
        $('.marquee').marquee({
            duration: time,
            gap: 0,
            delayBeforeStart: 0,
            direction: 'left',
            duplicated: true,
            startVisible: true,
            pauseOnHover: true
        });
    }
    if ($(".marquee .list").length <= 4) {
        var $speedTime = 30000;
        scrollingText($speedTime)
    }

    else if ($(".marquee .list").length <= 6) {
        var $speedTime = 40000;
        scrollingText($speedTime)
    }

    else if ($(".marquee .list").length <= 8) {
        var $speedTime = 50000;
        scrollingText($speedTime)
    }

    else if ($(".marquee .list").length <= 10) {
        var $speedTime = 60000;
        scrollingText($speedTime)
    }

    else if ($(".marquee .list").length <= 12) {
        var $speedTime = 70000;
        scrollingText($speedTime)
    }

    else if ($(".marquee .list").length <= 14) {
        var $speedTime = 80000;
        scrollingText($speedTime)
    }

    else if ($(".marquee .list").length <= 16) {
        var $speedTime = 90000;
        scrollingText($speedTime)
    }

    else {
        var $speedTime =100000;
        scrollingText($speedTime);
    }


});