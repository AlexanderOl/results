﻿ var debug = true;

function debug(strMessage) {
    if (debug) {
        console.log(strMessage);
    }
}

var analytics = {
    init: function () {

        $('a').on('click', function () {
            var el = jQuery(this);
            var href = (typeof (el.attr('href')) != 'undefined') ? el.attr('href') : "";
            var filetypes = /\.(zip|exe|dmg|pdf|doc.*|xls.*|ppt.*|mp3|txt|rar|wma|mov|avi|jpg|png|wmv|flv|wav)$/i;
            var externalLinks = /^(http|https)\:/i;
            var track = true; var elEv = [];
            if (href.match(filetypes)) {

                var extension = (/[.]/.exec(href)) ? /[^.]+$/.exec(href) : undefined;
                elEv.category = "Download";
                elEv.action = "Click-" + extension[0];
                elEv.label = href.replace(/ /g, "-");
                elEv.loc = href;

            } else if (href.match(externalLinks)) {
                elEv.category = "External";
                elEv.action = "Click";
                elEv.label = href;
                elEv.loc = href;

            } else if (href.indexOf("mediadownload.ashx") > 0) {
                elEv.category = "Download";
                elEv.action = "Click-FileDownload";
                elEv.label = href.replace(/ /g, "-");
                elEv.loc = href;
            } else if (href.indexOf("ical.ashx") > 0) {
                elEv.category = "Download";
                elEv.action = "Click-IcalDownload";
                elEv.label = href.replace(/ /g, "-");
                elEv.loc = href;
            } else if (href.indexOf("videoiframe.ashx") > 0) {
                elEv.category = "Video";
                elEv.action = "Click-Open";
                elEv.label = href.replace(/ /g, "-");
                elEv.loc = href;
            } else if (href.match(/^mailto\:/i)) {
                elEv.category = "Email";
                elEv.action = "Click";
                elEv.label = href.replace(/^mailto\:/i, '');
                elEv.loc = href;
            } else if (href.match(/^tel\:/i)) {
                elEv.category = "Tel";
                elEv.action = "Click";
                elEv.label = href.replace(/^tel\:/i, '');
                elEv.loc = href;


            } else {
                track = false;
            }

            if (track) {
                analytics.postEventToAnalytics(elEv);
            }
        });


    },
    postEventToAnalytics: function (elEv) {
        //var elEv = [];
        //elEv.category = category;
        //elEv.action = action;
        //elEv.label = label;

        console.log(elEv)
        if (typeof ga === 'function') {
            ga('send', 'event', elEv.category, elEv.action, elEv.label);
        }
    }

};



/**** MAP ****/
var map =
{
    init: function () {
        $('.global-locator').click(function () {
            if ($(this).hasClass('show')) {
                $(this).removeClass('show');
                $(this).parentsUntil('.global-country-profile').find('.global-info').removeClass('show');
            }
            else {
                $('.global-locator').removeClass('show');
                $('.global-info').removeClass('show');
                $(this).addClass('show');
                $(this).parentsUntil('.global-country-profile').find('.global-info').addClass('show');
            }
        });
    }
    };

$(document).ready(function () {

    $(".convert-emoji").each(function () {
        var original = $(this).html();
        // use .shortnameToImage if only converting shortnames (for slightly better performance)
        var converted = emojione.toImage(original);
        $(this).html(converted);
    });

    $(".hamburger").click(function () {
        $('#main-nav').slideToggle()
        $(this).toggleClass("is-active");
    });


    $("#navleft-title, .nav-left-arrow").click(function (e) {
        $(".panel-body").slideToggle("slow");
        $(".nav-left-arrow").toggleClass("toggled")
        e.preventDefault();

    });


    $('#contact').click(function () {
        $('#contact-card').addClass('on');
    });

    $('span.close-card').click(function () {
        $('#contact-card').removeClass("on");
    });


    $('.btn-MobileNews').click(function () {
        $('.mobileWrapper').toggleClass('on');
    });
    $('#nav-icon1,#nav-icon2,#nav-icon3').click(function () {
        $(this).toggleClass('open');
    });

    analytics.init();
    map.init();
    $('[data-fancybox]').fancybox({
        afterLoad: function () {
            //console.log("afterLoad!!!!")
            //console.info(this)
            var elEv = [];
            
            elEv.category = "FancyBox";
            elEv.label = this.src;
            elEv.loc = this.src;
            if (this.type === "inline" && this.src.indexOf("hidden-content") > 0) {
                elEv.action = "Display-Video";
            } else {
                elEv.action = "Display-" + this.type;
            }
            analytics.postEventToAnalytics(elEv);
        },
        buttons: [
            'close',
            'thumbs'
        ],
      
        youtube: {
            controls : 0,
            showinfo : 0
        },
        vimeo : {
            color : 'f00'
        }
    });




    $('[data-fancybox="med-library"]').fancybox({
        idleTime: false,
        baseClass: 'fancybox-custom-layout',
        margin: 0,
        gutter: 0,
        infobar: false,
        thumbs: {
            hideOnClose: false,
            parentEl: '.fancybox-outer'
        },
        touch: {
            vertical: false
        },
        buttons: [
            'close',
            'thumbs'
        ],
        animationEffect: "fade",
        animationDuration: 300,
        onInit: function (instance) {
            //console.log(instance);
            // Create new wrapping element, it is useful for styling
            // and makes easier to position thumbnails
            instance.$refs.inner.wrap('<div class="fancybox-outer"></div>');
        },
        //caption: function (instance, item) {
        //    console.log(item)
        //    return '<h3>Collection #162 – <br /> The Histographer</h3><p>This collection of photos, curated by The Histographer, is a collection around the concept of \'Autumn is here\'.</p><p><a href="https://unsplash.com/collections/curated/162" target="_blank">unsplash.com</a></p>';
        //}
    });



    //var $ticker = $('[data-ticker="list"]'),
    //    tickerItem = '[data-ticker="item"]'
    //     itemCount = $(tickerItem).length,
    //    viewportWidth = 0;

    //function setupViewport() {
    //    $ticker.find(tickerItem).prependTo('[data-ticker="list"]');

    //    for (i = 0; i < itemCount; i++) {
    //        var itemWidth = $(tickerItem).eq(i).outerWidth();
    //        viewportWidth = viewportWidth + itemWidth;
    //    }

    //    console.log("item width : " + itemWidth + "viewport width : " + viewportWidth);
    //    $ticker.css('width',  viewportWidth);
    //}

    //function animateTicker() {
    //    $listNum = $(".ticker__list li").length;
    //    console.log("wtf : " + $listNum);
    //    $timeout = 10000;

    //    if ($listNum <= 5) {
    //        $timeout * 2
    //    } else ($listNum <= 10) {
    //        $timeout * 5
    //    }


    //    $ticker.animate({
    //        marginLeft: -viewportWidth
    //    }, 5000, "linear", function () {
    //        $ticker.css('margin-left', '0');
    //        animateTicker();
    //    });
    //}

    //function initializeTicker() {
    //    setupViewport();
    //    animateTicker();

    //    $ticker.on('mouseover', function () {
    //        $(this).stop(true);
    //    }).on('mouseout', function () {
    //        animateTicker();
    //    });

    //}


    //initializeTicker();

});

