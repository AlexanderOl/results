window.initCallback = function(){

	// Workaround to trigger Ext.js ResponsiveConfig adjustments. 
	var resizeEvent = document.createEvent('UIEvents');
	resizeEvent.initUIEvent('resize', true, false, window,0);
	window.dispatchEvent(resizeEvent);

	var sidePanel = Smc.System.GUI.getGuiObject("smc-main-sidebar-top");
	sidePanel.setHtml("<div id='sidebar-top-ct'>" +
		"<div id='sidebar-top-logo' class='sidebar-top-logo'></div> " +
		"<div id='sidebar-top-subtitle' class='sidebar-top-subtitle'></div> " +
		"</div>");


	/*
	 &lt;button id='smc-mobile-menu' class='menu-mobile'/&gt;
	 */
	var structDoc = Smc.System.getStructureDoc();
	var subTitleElem = Smc.DOM.getSingleNode(structDoc, "/*/*[local-name() = 'Subtitle']");

	if (subTitleElem) {
		var subTitle = "";
		for (var i = 0, len = subTitleElem.childNodes.length; i < len; i++) {
			subTitle += Smc.DOM.serialize(subTitleElem.childNodes[i]);
		}
		$("#sidebar-top-subtitle").html(subTitle);
	}
	var tabpanel = Smc.System.GUI.getGuiObject("smc-content-ct");
	var tabBar = tabpanel.getTabBar();
	tabBar.enableFocusableContainer = false;
	tabBar.setHeight(100);

	var tabletScreen = window.matchMedia("(max-width: 1023px) and (min-width: 701px)").matches;
	if(tabletScreen){
         tabBar.setHeight(200);
    }

    var mobileScreen = window.matchMedia("(max-width: 700px)").matches;
    if(mobileScreen){
         tabBar.setHeight(200);
	}

	window.addEventListener("resize", function () {
		this.setTimeout(function () {
			var tabBar = tabpanel.getTabBar();
			tabBar.enableFocusableContainer = false;
			tabBar.setHeight(100);

			var tabletScreen = window.matchMedia("(max-width: 1023px) and (min-width: 701px)").matches;
			if (tabletScreen) {
				tabBar.setHeight(200);
			}

			var mobileScreen = window.matchMedia("(max-width: 700px)").matches;
			if (mobileScreen) {
				tabBar.setHeight(200);
			}
		}, 500)
	})

	var tabletLogoHeader = document.createElement("img");
	tabletLogoHeader.setAttribute("id", "tablet-logo-header");
	tabletLogoHeader.setAttribute("src", "resources/images/logo.svg");

	var searchDiv = document.createElement("div");
	searchDiv.setAttribute("class","content-search");

	var inputDiv = document.createElement("div");
	inputDiv.setAttribute("class","smc-panel-search button-search");
	inputDiv.setAttribute("id","smc-search-button");

	var inputButton = document.createElement("input");
	inputButton.setAttribute("class","fuzzyComplete x-form-trigger-wrap-default");
	inputButton.setAttribute("id","smc-search-field");
	inputButton.setAttribute("type","text");
	inputButton.setAttribute("autocomplete","off");

	searchDiv.appendChild(inputDiv);
	searchDiv.appendChild(inputButton);

	var buttonMobile = document.createElement("button");
	buttonMobile.setAttribute("id", "mobile-menu");
	buttonMobile.classList.add("menu-mobile");

	$($(tabBar.body.dom).prepend(searchDiv));
	$($(tabBar.body.dom).prepend(tabletLogoHeader));
	$($(tabBar.body.dom).prepend(buttonMobile));

	//TOGGLE LOGO
	var panel = Smc.System.GUI.getGuiObject('smc-sidebar');
	//This removes the logo when it loads by adding the class that hides it.
	$(document).ready(function() {
			$(".smc-content-ct").addClass("smc-sidebar-shown");
	});

	panel.addListener("beforecollapse", function (){
		$(".smc-content-ct").removeClass("smc-sidebar-shown");
	})
	panel.addListener("beforeexpand", function (){
		$(".smc-content-ct").addClass("smc-sidebar-shown");
	})
}

$(function() {
	Smc.System.onSuccessPage = function(node, panel, title, response){
		var info = this.processResponseOpenPage(response);
		title = (title && title.length > 0) ? title : info["title"];
		var path = panel.currentPath;

		if(Ext.os.is.Phone) {
			panel.body.dom.innerHTML = info["body"];
		} else {
			panel.update(info["body"]);
		}
		panel.setTitle(title);

		if (path.indexOf("#") !== -1) {
			var anchorId = path.slice(path.indexOf("#"));
			var targetSection = $(anchorId);
			if(targetSection.length > 0) {
				setTimeout(function() {
					if(targetSection.get(0)) {
						targetSection.get(0).scrollIntoView();
					}
				}, 100);
			}
		}

		if (node.attributes) {

			if(node.attributes.path != null && node.attributes.path.indexOf("#") > -1){
				var anchor = node.attributes.path.split("#")[1];
				var elem = $("#"+anchor);
				setTimeout(function() {
					if(elem.get(0)) {
						elem.get(0).scrollIntoView();
					}
				}, 100);
			}

			if (node.attributes["searchField"]) {
				var doc = panel.body.dom.querySelector("div.x-autocontainer-innerCt");
				var phrase = node.attributes.searchField.replace(/^\s+|\s+$/g, "").replace(/\s+/g, "|");
				Smc.System.highlightInElement(doc, phrase);
			}
		}

		var params = Util.parseQueryString(window.location.search);
		if (params["scrollTo"]) {
			var scrollElem = $("#" + params["scrollTo"]);
			if(scrollElem.get(0)){
				scrollElem.get(0).scrollIntoView();
			}else{
				var url = window.location.href;
				var scrollParam = url.split('?')[1];
				if (window.location.protocol !== "file:") {
					history.pushState({}, null, './');
				}
				window.location.hash = scrollParam.split('#')[1];
			}
		} else {
			panel.body.dom.scrollTop = 0;
		}

		this.runQuery(panel.body.dom, "img[src^='../'],source[src^='../'],track[src^='../']", this.adapterRootImg, this);
		this.runQuery(panel.body.dom, "a[class*='link-file']", this.adapterRootLink, this);
		this.runQuery(panel.body.dom, "a[class*='link-xref']," +
			" a[class*='link-detail']," +
			" a[class*='link-element']," +
			" area[class*='link-xref']," +
			" div[class*='container-navButtons'] a:not([class*='smc-print'])," +
			" div[class*='index'] a", this.asignLinkEvent, this);
		this.runQuery(panel.body.dom, "div[class*='container-navButtons'] a[class*='smc-print']", this.asignPrintEvent, this, {path: path});
		this.runQuery(panel.body.dom, "a[class*='preview-image']", this.asignMediaPreviewEvent, this);

		this.runQuery(panel.body.dom, "video", this.asignVideoEvent, this);
		this.runQuery(panel.body.dom, "a[class*='actionButtonDetails']", this.buttonActionDetails, this);
		this.runQuery(panel.body.dom, "a[class*='actionButtonCopy']", this.buttonActionCopy, this);
		this.runQuery(panel.body.dom, "a[class*='actionButtonShow']", this.processPartlyNotices, this);
		this.runQuery(panel.body.dom, ".table-", this.processTables, this);


	}

	Smc.System.processPartlyNotices = function (showActive) {
		var divElement = showActive ? showActive.parentElement : null
		if (divElement) {
			var shortText = true;
			var tableNoticeElem = $(divElement).find(".table-notice");
			var contentNoticeElem = $(tableNoticeElem).find('.content-notice');
			var warningNoticeElem = $(contentNoticeElem).find('.warning-notice');
			var toggleButton =  $(tableNoticeElem).siblings(".actionButtonShow");
			var maxChars = parseInt($(contentNoticeElem).attr("character-limit"));
			$(toggleButton).addClass("more");

			var content = $(warningNoticeElem).text();

			if(content.length > maxChars) {
				var shortText = content.substring(0, maxChars);
				var shortDiv = document.createElement("div");

				var isCodeInsideNotice;
				var firstChild = $(warningNoticeElem).get(0).firstChild;
				if (firstChild && firstChild.nodeType !== 3) {
					isCodeInsideNotice = firstChild.getAttribute("class") === "code";
				}

				$(shortDiv).attr("class", isCodeInsideNotice ? "shortText code" : "shortText");
				$(shortDiv).text(shortText);

				$(warningNoticeElem).parent().prepend(shortDiv);
				$(warningNoticeElem).hide();

				toggleButton[0].addEventListener("click", function (e) {
					e.preventDefault();
					if(shortText){
						$(warningNoticeElem).show();
						$(shortDiv).hide();
						shortText = false;
						$(toggleButton).removeClass("more");
					}else{
						shortText = true;
						$(warningNoticeElem).hide();
						$(shortDiv).show();
						$(toggleButton).addClass("more");
					}

				}, this);

			}else{
				$(toggleButton).hide();
			}
		}
	}

	//This gives the standard tables (NOT NORMAL) a class that allows for better distinction
	//between tables that have a header element (Bold header/Bold header and column) from those which do not

	Smc.System.processTables= function (tableElement) {
		if (tableElement) {
			var thead = $(tableElement).find("thead")[0];
			if (thead){
				$(tableElement).addClass("table-has-header");
			}
		}
	}


	Smc.System.buttonActionDetails = function (link) {
		if (link) {
			var parent = link.parentElement;
			if(!$(parent).hasClass("details_button")) {
				$(parent).addClass("details_button");
			}
			link.addEventListener("click", function (e) {
				e.preventDefault();
				var tableNoticeElem = $(this).siblings('.table-notice');
				var contentNotice = $(tableNoticeElem).find('.content-notice').find('.warning-notice');
				if(contentNotice){
					contentNotice.toggleClass('show');
					$(this).toggleClass('show');
				}
			}, this);
		}
	}

	Smc.System.buttonActionCopy = function (link) {
		if (link) {
			link.addEventListener("click", function (e) {
				e.preventDefault();
				var tableNoticeElem = $(this).siblings('.table-notice');
				var contentNotice = $(tableNoticeElem).find('.content-notice').find('.warning-notice')[0];

				if (window.getSelection) {
					if (window.getSelection().empty) { // Chrome
						window.getSelection().empty();
					} else if (window.getSelection().removeAllRanges) { // Firefox
						window.getSelection().removeAllRanges();
					}
				} else if (document.selection) { // IE?
					document.selection.empty();
				}

				if (document.selection) {
					var range = document.body.createTextRange();
					if($(contentNotice).is(":visible")){
						range.moveToElementText(contentNotice);
						range.select().createTextRange();
						document.execCommand("copy");
					}else{
						$(contentNotice).show();
						range.moveToElementText(contentNotice);
						range.select().createTextRange();
						document.execCommand("copy");
						$(contentNotice).hide();
					}
				} else if (window.getSelection) {
					var range = document.createRange();
					if($(contentNotice).is(":visible")) {
						range.selectNode(contentNotice);
						window.getSelection().addRange(range);
						document.execCommand("copy");
					}else{
						$(contentNotice).show();
						range.selectNode(contentNotice);
						window.getSelection().addRange(range);
						document.execCommand("copy");
						$(contentNotice).hide();
					}
				}

				window.getSelection().removeAllRanges();
				Ext.toast({
					html: 'Text copied',
					title: '',
					align: 't',
					autoCloseDelay: 500
				});

			}, this);
		}
	}
});

Smc.System.doSearch = function() {
	var searchField = this.GUI.getGuiObject("smc-search-field");
	if (!searchField) {
		searchField = $("#smc-search-field")[0].value;
	} else {
		searchField = searchField.value;
	}

	var tabPanelBody = this.GUI.getGuiObject("smc-content-ct");

	var resultCt = Ext.getCmp("smc-tab-search-result");

	if(resultCt && resultCt !== this.getActiveTab()) {
		resultCt.close();
	}
	resultCt = tabPanelBody.add({
		closable: true,
		scrollable: true,
		id: "smc-tab-search-result"
	});

	var searchID = this.getTranslatorCtrl().t("smc.search");

	/* Sanitize Input */
	searchField = searchField
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#x27;')
		.replace(/\//g, '&#x2F;')
		.replace(/`/g, '&#x60;')
		.replace(/=/g, '&#x3D;');

	resultCt.setTitle(searchID + ": " + searchField);

	if (searchField)
	{
		switch( this.getOnlineHelpType() ){
			case "auto":
				if(window.location.protocol == "file:"){
					this.doLocalSearch(searchField, resultCt);
				}else{
					this.doLuceneSearch(searchField, resultCt);
				}
				break;
			case "jsonly":
				this.doLocalSearch(searchField, resultCt);
				break;
			case "lucene":
				this.doLuceneSearch(searchField, resultCt);
				break;
			case "lucene-php":
				this.doLuceneSearch(searchField, resultCt, "php");
				break;
			default:
				this.doLocalSearch(searchField, resultCt);
				break;

		}
	}

};

Smc.System.isViewMobile = function() {
	var width = window.screen.width;
	return width <= 825;
}

Smc.System.onTextEntriesLoad = function(entriesJSON){
	var context = this;
	$(document).ready(function () {
		$("#smc-search-field").attr("placeholder", 'Enter your text here');
		$("#smc-search-field").keyup(function (evt) {
			if (evt.keyCode == 40 || evt.keyCode == 38) {
				return;
			} else {
				if (context.timer) {
					clearTimeout(context.timer);
				}
				if (!this.run) {
					context.timer = setTimeout(function (scope) {
						scope.run = true;
						$(scope).keyup();
						scope.run = false;
					}, 400, this);

					evt.stopImmediatePropagation();
				}
			}
		});
		$("#smc-search-field").fuzzyComplete(entriesJSON.root);
		$("#smc-search-field").on('keydown', function (e) {
			if (e.keyCode == 13) {
				context.doSearch();
				if (context.timer) {
					clearTimeout(context.timer);
				}
				e.target.blur();
			}
		});
		$("#smc-search-button").append(
			$(document.createElement('button')).prop({
					type: 'button',
					innerHTML: 'Search',
					class: 'search-button'
				}

			)
		)
		$("#smc-search-button").on('click', function () {
			context.doSearch();
		});
		$(".fuzzyResults").on("click", ".selected", function () {
			context.doSearch();
			$("#smc-search-field").blur();
		});
	});
}

