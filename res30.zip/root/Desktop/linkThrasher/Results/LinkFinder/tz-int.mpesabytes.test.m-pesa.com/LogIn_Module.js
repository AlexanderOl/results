function onLoginFrm(form) {
	
	//var frmLg 			= document.loginFrm;
	var frmLg 			= form;
	var find_submit_el 	= 0
	var usrname 		= frmLg.usrname.value;
	var usrpassd 		= frmLg.usrpassd.value;

	var usrpassdEncoded 	= b64EncodeUnicode(usrpassd);
	//var usrpassdDecoded 	= b64DecodeUnicode(usrpassdEncoded);


	var usrpassdStr 		= usrpassdEncoded.split('=').join('##||'); 
	var usrpassdStr 		= usrpassdStr.split('/').join('###|||'); 

	/*console.log('usrpassd '+usrpassd);
	console.log('usrpassdEncoded '+usrpassdEncoded);
	console.log('usrpassdDecoded '+usrpassdDecoded);*/

	//return;

	if (usrname!='' && usrpassd!=''){
		if( typeof frmLg.login_captcha !== 'undefined'){
			var login_captcha 	= frmLg.login_captcha.value;

			if(login_captcha != ''){
				GoTo("thisPage?event=none.login(usrname="+usrname+";usrpassd="+usrpassdStr+";passwordIsEncoded=yes;login_captcha="+login_captcha+";idstempLogin="+idstempLogin+")");	
			}else{
				return false;
			}
			
		}else{
		GoTo("thisPage?event=none.login(usrname="+usrname+";usrpassd="+usrpassdStr+";passwordIsEncoded=yes;idstempLogin="+idstempLogin+")");	
		}
		

	} else {
		//alert (_fill_required_data);
		return false;
	}
}

function resetField(obj,str){
	if(obj.value.length==0){
		 obj.value=str;
		 return;
	}
	if(obj.value==str){
		obj.value="";
	}
 }
function b64EncodeUnicode(str) {
    // first we use encodeURIComponent to get percent-encoded UTF-8,
    // then we convert the percent encodings into raw bytes which
    // can be fed into btoa.
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
            return String.fromCharCode('0x' + p1);
    }));
}

function b64DecodeUnicode(str) {
    // Going backwards: from bytestream, to percent-encoding, to original string.
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

