function contact_clearAll(id_nem) 
{
  var form_name = "contact_form_name"+id_nem;
  var form      = document.getElementsByName(form_name)[0];

  var nr;
  nr = -1;
  for(var i=0; i<form.elements.length; i++) 
     {
      if ((form.elements[i].type == "text" || form.elements[i].type == "textarea") && !(form.elements[i].disabled == true))
         {
          if (nr == -1)
             {nr = i;}
             
          form.elements[i].value = "";
         }
      if ((form.elements[i].type == "select-one") && !(form.elements[i].disabled == true))
         {
          if (nr == -1)
             {nr = i;}

          nr_index = form.elements[i].options[0].value;
          form.elements[i].value = nr_index;
         }
     }
  form.elements[nr].focus();  
}

function feedback_send(idstemp, id_nem, EF_id, sourcetrg){
  //var form    = document.contact_form_name;
  var form_name = "enquiry_form_name_"+id_nem;
  var kol_val   = valid_value(form_name);
  if (kol_val == "")
     {}
  else
     {
      var id_buton_send = "contact_id_buton_send" + id_nem;
      if (document.getElementById(id_buton_send))
         {
          var buton_send      = document.getElementById(id_buton_send);
          buton_send.disabled = "disabled";
         }
      
      var user_name    = "";
      var id_user_name = "UserName_"+EF_id;
      if (document.getElementById(id_user_name))
         {
          user_name = document.getElementById(id_user_name).value;

          str_val1  = new Array(/;/ig, /;/ig);
          user_name = reg_exp_pik_presje(user_name, str_val1);
   
          str_val2  = new Array(/&/ig, /&/ig);
          user_name = reg_exp_and(user_name, str_val2);
         }

      var user_email    = "";
      var id_user_email = "UserEmail_"+EF_id;
      if (document.getElementById(id_user_email))
         {
          user_email = document.getElementById(id_user_email).value;

          str_val1   = new Array(/;/ig, /;/ig);
          user_email = reg_exp_pik_presje(user_email, str_val1);

          str_val2   = new Array(/&/ig, /&/ig);
          user_email = reg_exp_and(user_email, str_val2);
         }

      var capt_h = "";
      if (contactmodule_capt_h[idstemp])
         {
          capt_h = contactmodule_capt_h[idstemp];
         }
      var sourcetrgVal = typeof sourcetrg !== 'undefined' ? sourcetrg : '';
      GoTo('thisPage?event=none.enquiryFeedback(idstemp='+idstemp+';user_name='+user_name+';user_email='+user_email+';capt_h='+capt_h+';kol_val='+kol_val+';EF_id='+EF_id+';sourcetrg='+sourcetrgVal+')');
  }
}


// SKRIPTET PER NGARKIMIN E DOKUMENTIT ---------------------------------------------------------------------------------------------------
function contact_returnUTS() 
{
	var d = new Date();
	return d.getTime() + '' + Math.floor(1000 * Math.random());
}

function contact_upload(idstemp, id_nem)
{
  if (contact_title_window_mesg)
     {var title_window = contact_title_window_mesg;}
  else
     {var title_window = "Upload";}

  var wpath=APP_URL+'templates/NEModules/ContactModule/ContactModule_Upload.php?uni='+uni+'&idstemp='+idstemp+'&lang='+lang+'&u='+contact_returnUTS();
  win = new Window({className: 'alert', title: title_window,
                      width:470, height:150,
                      url: wpath})
  win.showCenter(true);
}

function modelessDialogShow(url,width,height) {
	var unique = contact_returnUTS();
	var url = url+'&u='+unique
	if(navigator.appName.indexOf('Microsoft')!=-1) { //explorer
		window.showModelessDialog(url,window,"dialogWidth:"+width+"px;dialogHeight:"+height+"px;edge:Raised;center:1;help:0;resizable:1;");
	} else { //moxilla
		var left = screen.availWidth/2 - width/2;
		var top = screen.availHeight/2 - height/2;
		window.open(url, "", "dependent=yes,width="+width+"px,height="+height+",left="+left+",top="+top);
	}
}
// ins_upload -----------------------------------------------------------------------------------


// CAPTCHA ---------------------------------------------------------------------------------------------------
function captcha_reload(uni, idstemp) 
{
 var tmspt              = contact_returnUTS();
 var captcha_reload_src = APP_URL+"enquiryFeedback_captcha.php?uni="+uni+"&idstemp="+idstemp+"&reload=R&t="+tmspt;


 var CaptchaReq = cap_getXmlHttpRequestObject();
 CaptchaReq.open("GET", captcha_reload_src, false);
 //CaptchaReq.open("GET", captcha_reload_src);
 CaptchaReq.send(null);

 var img_src = CaptchaReq.responseText;
 if (img_src != "")
    {
     var img_id = "cap_"+idstemp;
     var img_el = document.getElementById(img_id);
     img_el.setAttribute("src", img_src);
    }
}

//Gets the browser specific XmlHttpRequest Object
function cap_getXmlHttpRequestObject() 
{
	if (window.XMLHttpRequest) 
	   {
		return new XMLHttpRequest();
	   }
	else if(window.ActiveXObject) 
	   {
		return new ActiveXObject("Microsoft.XMLHTTP");
	   } 
	else 
	   {
	   
	   }
}
// CAPTCHA ---------------------------------------------------------------------------------------------------

