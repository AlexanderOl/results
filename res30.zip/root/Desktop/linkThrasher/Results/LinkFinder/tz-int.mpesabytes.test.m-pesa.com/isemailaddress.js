// isEmailAddress ------------------------------------------------------------------------
  function isEmailAddress(theElement, theElementName)
  {
    var s = theElement.value;
    var filter=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (s.length == 0 ) return true;
    if (filter.test(s))  
         return true;
    else  
      alert(alert_isemail_mesg);
      if (!(theElement.disabled == true))
      	{theElement.focus(); }
      return false;
  }
//----------------------------------------------------------------------------------------