// isNull ---------------------------------------------------------------------------------
function isNull( field , fieldName) {
    selected = 0;
    fieldIsNull = 0;
    if ( field.type == "file" ||
         field.type == "text" ||
         field.type == "hidden" ||
         field.type == "password" ||
         field.type == "textarea" ) {
      if ( field.value == "" )
        fieldIsNull = 1;
    } else if ( field.type == "select-one" ) {
        if ( field.options[field.selectedIndex].value == "")
          fieldIsNull = 1;
    } else if ( field.type == "select-multiple" ) {
        fieldIsNull = 1;
        for ( i = 0; i < field.length; i++ )
          if ( field.options[i].selected )
            fieldIsNull = 0;
    } else if ( field.type == "undefined" ||
                field.type == "checkbox"  ||
                field.type == "radio" ) {
        fieldIsNull = 1;
        for ( i = 0; i < field.length; i++ )
          if ( field[i].checked )
            fieldIsNull = 0;
    }
    if ( fieldIsNull ) {
        if ( isNull.arguments.length  == 1 )
           alert( alert_isnull_mesg );
        else
           alert( alert_isnull_mesg + ' ' + fieldName+ '' );
        if ( field.type == "file" ||
             field.type == "text" ||
             field.type == "textarea"  ||
             field.type == "password"  ||
             field.type == "select-one"  ||
             field.type == "select-multiple" )
          
        if (!(field.disabled == true))
      	{field.focus(); }
       return false;
    }
    return true;
  }
//----------------------------------------------------------------------------------------