/*
 * 23.10.2019
 * Copyright (c) 2019 Prevoir Solutions Informatiques Ltd. All Rights Reserved.
 */
/**
 * Configuration file
 */
window.env = {
  // Object containing details for ajax calls sent from the frontend
  ajaxConfig: {
    // baseURL defines the URL of the API of the portal backend
    baseURL: 'https://oat.openapiportal.m-pesa.com/api/',
    // Response type of all ajax calls
    responseType: 'json',
    // Static headers added to all ajax calls sent from the frontend
    headers: {
      'Content-Type': 'application/json',
      'Cache-control': 'no-cache, no-store',
      'Pragma': 'no-cache',
      'Expires': '0'
    }
  },
  // Inactivity timeout in seconds (time until 30 second warning is shown): Default 270
  inactivityTimeout: 270,
  // band page absolute URL
  banUrl: 'https://oat.openapiportal.m-pesa.com/banned.html',
  // URL of the support email address to display to the user if Contact Support does not work
  supportEmail: 'servicedesk@4cgroup.co.za',
  // Link to the help forum
  forumLink: 'https://uat.supportforum.m-pesa.com/',
  // The provider for the generated authentication key QR code used for the two-factor authentication login
  authKeyLabel: 'M-Pesa OpenAPI Portal OAT',
  // List of authentication types that are allowed to update login credentials.
  updatableCredentialsAuthTypes: [0],
  // Google API key for the ReCAPTCHA component
  captchaKey: '6LdK0VQlAAAAAGZWomIrVtxa3Wsg0zXsdT622Dg8',
  // Link to Terms & Conditions
  termsAndConditionsLink: 'https://business.m-pesa.com/terms-conditions-centre',
  prevoirLink: 'https://www.prevoir.mu/',
  // Theme customization options. See https://material-ui.com/customization/themes/
  geolocationAPI: 'https://api.ipgeolocation.io/ipgeo?apiKey=d098989d7b3e478eb67f3ec8590ec98d',
  theme: {
    palette: {
      type: 'light',
      fontFamily: 'Roboto, sans-serif',
      primary: {
        main: '#e60000'
      },
      secondary: {
        main: '#222222'
      },
      error: {
        main: '#e60000'
      },
      base: '#F8F8F8',
      footer: {
        onLogin: {
          font: 'black',
          background: 'transparent'
        },
        inApp: {
          font: 'black',
          background: 'transparent'
        }
      }
    },
    typography: {
      suppressDeprecationWarnings: true
    },
    graphColors: ['#0061b0', '#6b7b83', '#232683', '#4c76a5', '#131231', '#7a757a', '#73a9b0', '#6d5eb0', '#0600b0',
      '#3ab0b0', '#4565b0', '#1e1e21', '#075fb0', '#707379']
  }
};
