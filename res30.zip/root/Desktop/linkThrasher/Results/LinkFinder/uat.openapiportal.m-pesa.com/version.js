/*
 * 18.09.2019
 * Copyright (c) 2019 Prevoir Solutions Informatiques Ltd. All Rights Reserved.
 */
/**
 * Front-end version
 */
window.env.version = '1.15.0';
