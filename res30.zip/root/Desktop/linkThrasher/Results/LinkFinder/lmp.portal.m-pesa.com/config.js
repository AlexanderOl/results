/*
 * 23.10.2019
 * Copyright (c) 2019 Prevoir Solutions Informatiques Ltd. All Rights Reserved.
 */
/**
 * Configuration file
 */
window.env = {
  // Indicates which LMP portal instance this is. Must be either 'bank' or 'service_provider'
  instance: 'service_provider',
  // Object containing details for ajax calls sent from the frontend
  ajaxConfig: {
    // baseURL defines the URL of the API of the portal backend
    baseURL: 'https://lmp.portal.m-pesa.com/api/',
    // Response type of all ajax calls
    responseType: 'json',
    // Static headers added to all ajax calls sent from the frontend
    headers: {
      'Content-Type': 'application/json',
      'Cache-control': 'no-cache, no-store',
      'Pragma': 'no-cache',
      'Expires': '0'
    }
  },
  // Inactivity timeout in seconds (time until 30 second warning is shown): Default 270
  inactivityTimeout: 900,
  // band page absolute URL
  banUrl: 'https://lmp.portal.m-pesa.com/banned.html',
  // URL of the support email address to display to the user if Contact Support does not work
  supportEmail: 'servicedesk@4cgroup.co.za',
  // Link to the help documentation
  wikiLink: '',
  // The provider for the generated authentication key QR code used for the two-factor authentication login
  authKeyLabel: 'LMP SP Portal',
  // List of authentication types that are allowed to update login credentials.
  updatableCredentialsAuthTypes: [0],
  // Google API key for the ReCAPTCHA component
  captchaKey: '',
  prevoirLink: 'https://www.prevoir.mu/',
  // Theme customization options. See https://material-ui.com/customization/themes/
  theme: {
    palette: {
      type: 'light',
      fontFamily: 'Roboto, sans-serif',
      primary: {
        main: '#4A4D4E'
      },
      secondary: {
        main: '#e60000'
      },
      error: {
        main: '#e60000'
      },
      base: '#F8F8F8',
      footer: {
        onLogin: {
          font: 'black',
          background: 'transparent'
        },
        inApp: {
          font: 'black',
          background: 'transparent'
        }
      }
    },
    typography: {
      suppressDeprecationWarnings: true
    }
  }
};
