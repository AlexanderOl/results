define("autofill-with-linkedin",["linkedInUtils"],function(b){function a(c){return{locationFieldsContainer:$(".location-fields-ui"),getCountryFieldValue:function(){return $(".country-field-ui .select2-selection__rendered").text()
},linkedinData:{country:c.country.toUpperCase(),region:c.state,city:c.city,zipCode:c.zip},isAlphaCodeUse:true}
}window.addEventListener("message",function(g){try{var f=JSON.parse(g.data);
if(f.type==="formData"){var i=f.data;
var c=a(i);
var d=$(".geolocation-country").length>0;
if(d){return
}b.fillLocationFormFields(c)
}}catch(h){return
}})
});
define("linkedinModule",["analytics"],function(l){var n=document.querySelector("script[data-mode='BUTTON_DATA']");
var h=null;
var f=null;
if(n){localStorage.setItem("isAppliedWithLinkedin","false");
EPAM.pushLinkedinApplyGtmEvent=function(){h();
var q=l.getEvent(f);
q=q&&$.extend({},q,{eventAction:"Clicks on AWL"});
if(q){l.push(q)
}}
}function b(q){f=q
}function d(q,r){if(m()){if(!c()){j(q,r);
a()
}}}function m(){return JSON.parse(localStorage.getItem("isAppliedWithLinkedin"))
}function e(q){return document.querySelector("script[data-mode='"+q+"']")
}function j(r,s){var q=e(r);
q.setAttribute("data-mode",s)
}function a(){var r=document.querySelector("[name='widget-holder']");
var q=document.createElement("script");
q.src="https://www.linkedin.com/mjobs/awli/awliWidget";
r.appendChild(q)
}function p(){var q=window.location.href;
return q.indexOf("vacancyId")!==-1
}function c(){return !!document.querySelector(".form-component__self-id-link")
}function o(){localStorage.setItem("isAppliedWithLinkedin","false")
}function g(){$(".IN-Awli-widget").addClass("hidden")
}function i(){$(".IN-Awli-widget").removeClass("hidden")
}function k(q){h=q
}return{initLinkedin:d,resetApplyWithLinkedin:o,isTwoStepsForm:c,isSecondStep:p,changeLinkedinMode:j,triggerLinkedInScript:a,isAppliedWithLinkedin:m,getLinkedInConfigByType:e,hideLinkedinWidget:g,showLinkedinWidget:i,addCallbackForStartForm:k,addForm:b}
});
define("linkedInUtils",["constants"],function(j){function e(m,o,n){var l=null;
if(n){l=m.find('option[data-iso-code-alpha-2="'+o+'"]').val()
}else{l=m.find('option[data-geolocation-name="'+o+'"]').val()
}return l
}function b(m,l){if(m&&l){m.value=l
}}function f(n){var m=document.querySelector("[name='applicantFirstName']");
var p=document.querySelector("[name='applicantLastName']");
var l=document.querySelector("[name='applicantEmail']");
var o=document.querySelector("[name='applicantMessage']");
b(m,n.linkedinData.firstName);
b(p,n.linkedinData.lastName);
b(l,n.linkedinData.emailAddress);
b(o,n.linkedinData.publicProfileUrl)
}function h(l){l.locationFieldsContainer.one(j.Events.locationSelectZipCodeUpdate,function(){var m=i("zip-code");
m.val(l.linkedinData.zipCode).trigger("change")
})
}function g(l){l.locationFieldsContainer.one(j.Events.locationSelectCityUpdate,function(n,m){if(m.isEmpty===0){var p=i("city",true);
p.val(l.linkedinData.city)
}else{var o=i("city");
o.val(e(o,l.linkedinData.city)).trigger("change")
}})
}function a(l){l.locationFieldsContainer.one(j.Events.locationSelectRegionUpdate,function(){var m=i("region");
m.val(e(m,l.linkedinData.region,l.isAlphaCodeUse)).trigger("change")
})
}function d(m){var n=i("country");
var l=e(n,m.linkedinData.country,m.isAlphaCodeUse);
n.val(l).trigger("change")
}function c(m){var n=$(".country-filled").length>0;
if(!n){d(m);
var o=k(m.linkedinData.dataArray,"region",m.linkedinData.country,m);
if(o){m.linkedinData.region=o;
a(m)
}var p=k(m.linkedinData.dataArray,"city",m.linkedinData.country,m);
if(p){m.linkedinData.city=p;
g(m)
}var l=m.linkedinData.zipCode;
if(l){h(m)
}}}function k(o,m,n,l){if(l.isAlphaCodeUse){return l.linkedinData[m]
}if(n==="United States"||n==="Canada"||n==="US"){if(m==="region"){return o[o.length-2]
}if(m==="city"){return o[o.length-3]
}}if(m==="city"){if(o.length===3){return o[o.length-3]
}else{return o[o.length-2]
}}}function i(m,l){if(l){return $(".location-fields-ui ."+m+"-field-ui input")
}return $(".location-fields-ui ."+m+"-field-ui select")
}return{fillLocationFormFields:c,fillLocationCountryField:d,fillLocationRegionField:a,fillLocationCityFiled:g,fillCasualFormFields:f,fillLocationZipCodeField:h}
});
function onProfileData(b){if(!JSON.parse(localStorage.getItem("isAppliedWithLinkedin"))){EPAM.pushLinkedinApplyGtmEvent()
}localStorage.setItem("isAppliedWithLinkedin","true");
var a=$(".linkedin-summary-ui");
if(a.length){a.removeClass("hidden")
}require(["linkedInUtils"],function(d){$(window).trigger("linkedin.data.received",[{linkedinData:b}]);
var e=(function(){var g=b.location.locationName.split(", ");
var f={region:null,city:null,isAlphaCodeUse:false,firstName:b.firstName,lastName:b.lastName,emailAddress:b.emailAddress,publicProfileUrl:b.publicProfileUrl,country:g[g.length-1],dataArray:g};
return f
})();
var c={locationFieldsContainer:$(".location-fields-ui"),getCountryFieldValue:function(){return $(".country-field-ui .select2-selection__rendered").text()
},linkedinData:e};
d.fillCasualFormFields(c);
d.fillLocationFormFields(c)
})
}define("linkedInSummaryParser",[],function(){var d=typeof Symbol==="function"&&typeof Symbol.iterator==="symbol"?function(m){return typeof m
}:function(m){return m&&typeof Symbol==="function"&&m.constructor===Symbol?"symbol":typeof m
};
var f={headLine:"headline",firstName:"firstName",lastName:"lastName",emailAddress:"emailAddress",phoneNumber:"phoneNumber",summary:"summary",positions:"positions",title:"title",startDate:"startDate",month:"month",year:"year",endDate:"endDate",companyName:"companyName",educations:"educations",schoolName:"schoolName",degree:"degree",fieldOfStudy:"fieldOfStudy",headline:"headline",skills:"skills",isCurrent:"isCurrent"};
var j=function j(n,m){if(m){return"\n  "+n+": "+m
}return""
};
function h(m){if(m){return m[f.month]+" "+m[f.year]
}return""
}function k(m){var n="\n  "+j("Position",m[f.title])+"  "+j("Company",m[f.companyName])+"  "+j("Dates",h(m[f.startDate])+" - "+h(m[f.endDate]))+"  "+j("Description",m[f.summary])+"  ";
return n
}function e(n){var m="\n  "+j("University",n[f.schoolName])+"  "+j("Degree",n[f.degree])+"  "+j("Faculty",n[f.fieldOfStudy])+"  "+j("Dates",h(n[f.startDate])+" - "+h(n[f.endDate]))+"  ";
return m
}function b(m){return m.name
}function l(p,t,n,o){var m=p[t];
if(Array.isArray(m)){var s=[];
for(var q=0;
q<m.length;
q++){var v=m[q];
var u=n(v);
s.push(u)
}return s.join(o)
}else{var r=null;
if(n){r=n(p[t])
}else{r=p[t]
}return r
}}function g(q){var o=q[f.positions];
var n=[];
for(var p=0;
p<o.length;
p++){var m=o[p];
if(m[f.isCurrent]){n.push(m[f.title]+" at "+m[f.companyName])
}}return n.join(", ")
}var a={get:function c(n,o){if(n[o]===null){return""
}if(d(n[o])==="object"&&n[o]!==null&&o===f.startDate||o===f.endDate){return new Proxy(n[o],a)
}if(Array.isArray(n[o])&&n[o]!==null){for(var m=0;
m<n[o].length;
m++){n[o][m]=new Proxy(n[o][m],a)
}}if(o in n){return n[o]
}return""
}};
function i(n){var o=new Proxy(n,a);
var m="\n  "+o[f.firstName]+" "+o[f.lastName]+"\n  "+g(n)+"\n  -------------------------------------\n  Summary: "+l(o,f.summary)+"\n  --------------------------------------\n  Work history:  "+l(o,f.positions,k,"")+"\n  --------------------------------------\n  Education:  "+l(o,f.educations,e,"")+"\n  --------------------------------------\n  Skills:\n  "+l(o,f.skills,b,", ")+"\n  ";
return m
}return{formattingLinkedinSummary:i}
});
"use strict";
var _createClass=function(){function a(e,c){for(var b=0;
b<c.length;
b++){var d=c[b];
d.enumerable=d.enumerable||false;
d.configurable=true;
if("value" in d){d.writable=true
}Object.defineProperty(e,d.key,d)
}}return function(d,b,c){if(b){a(d.prototype,b)
}if(c){a(d,c)
}return d
}
}();
function _toConsumableArray(a){if(Array.isArray(a)){for(var c=0,b=Array(a.length);
c<a.length;
c++){b[c]=a[c]
}return b
}else{return Array.from(a)
}}function _classCallCheck(a,b){if(!(a instanceof b)){throw new TypeError("Cannot call a class as a function")
}}define("ColumnControl",[],function(){var b={COLUMN_CONTROL_COLUMN:"colctrl__col",TEXT_UI:"text-ui"};
var a=function(){function l(o){var q=this;
_classCallCheck(this,l);
this.el=o[0];
var p=this.el.getAttribute("data-is-list");
p&&window.addEventListener("DOMContentLoaded",function(){q.items=q.getInteractiveItems();
q.items.length&&q.init()
})
}_createClass(l,[{key:"getInteractiveItems",value:function m(){var o=this;
return Array.from(this.el.querySelectorAll("."+b.COLUMN_CONTROL_COLUMN)).map(function(q){var p=q.querySelectorAll("img, ."+b.TEXT_UI);
if(p.length===0){return q
}if(p.length===1){return p[0]
}return o.getClosestCommonParent(Array.from(p))
})
}},{key:"getClosestCommonParent",value:function d(o){var p=o[0];
while(p.parentNode){p=p.parentNode;
if(o.every(function(q){return p.contains(q)
})){return p
}}}},{key:"init",value:function n(){var o;
if(!window.accessibility){window.accessibility={startIndexes:[],items:[],indexOfCurrentItem:-1};
this.addEventListenerForNavigationOnPage();
this.addEventListenerForNavigationInList();
this.addEventListenerOnTabPress()
}this.createRefresherForIndexOfCurrentItem();
window.accessibility.startIndexes.push(window.accessibility.items.length);
(o=window.accessibility.items).push.apply(o,_toConsumableArray(this.items))
}},{key:"addEventListenerForNavigationOnPage",value:function h(){var o=this;
window.addEventListener("keydown",function(p){if(p.key.toLowerCase()==="l"){!p.shiftKey?o.changeIndexOfCurrentItem(o.findNextStartIndex()):o.changeIndexOfCurrentItem(o.findPreviousStartIndex())
}})
}},{key:"findNextStartIndex",value:function j(){for(var o=0;
o<window.accessibility.startIndexes.length;
o++){if(window.accessibility.startIndexes[o]>window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"findPreviousStartIndex",value:function e(){for(var o=window.accessibility.startIndexes.length-1;
o>=0;
o--){if(window.accessibility.startIndexes[o]<window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"changeIndexOfCurrentItem",value:function f(o){if(o>=0&&o<=window.accessibility.items.length-1){window.accessibility.indexOfCurrentItem=o;
this.setFocusToCurrentItem()
}}},{key:"setFocusToCurrentItem",value:function k(){var q=window.accessibility.items[window.accessibility.indexOfCurrentItem];
var p=q.getAttribute("tabindex")&&q.getAttribute("tabindex")!=="-1";
if(!p){q.setAttribute("tabindex",0);
q.addEventListener("focusout",function o(){q.setAttribute("tabindex",-1);
q.removeEventListener("focusout",o)
})
}q.focus()
}},{key:"addEventListenerForNavigationInList",value:function i(){var o=this;
window.addEventListener("keydown",function(p){if(p.key==="ArrowRight"||!p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem+1)
}else{if(p.key==="ArrowLeft"||p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem-1)
}}})
}},{key:"addEventListenerOnTabPress",value:function c(){window.addEventListener("keydown",function(o){if(o.key==="Tab"){setTimeout(function(){var p=window.accessibility.items.findIndex(function(q){return document.activeElement.compareDocumentPosition(q)!==Node.DOCUMENT_POSITION_PRECEDING
});
window.accessibility.indexOfCurrentItem=p===-1?window.accessibility.items.length-1:p
},0)
}})
}},{key:"createRefresherForIndexOfCurrentItem",value:function g(){this.items.forEach(function(o){o.addEventListener("focus",function(){window.accessibility.indexOfCurrentItem=window.accessibility.items.indexOf(o)
})
})
}}]);
return l
}();
a.moduleName="Column Control";
a.selector=".colctrl-ui";
return a
});
define("MultiStyleSliderConstants",function(){var c={common:{carousel:".owl-carousel",disabledArrow:"disable-nav-arrow",prevButton:".owl-prev",nextButton:".owl-next",navigationPanel:".owl-nav",isHasImagesSlide:".multi-style-slider-slide-type.slider--images",disableOwlSwipe:"disable-owl-swipe",activeSlide:".owl-item.active",hideTitle:"hide-title"},manual:{imageSlide:".slider--images",imagesTrack:".multi-style-slider-images-track",image:".multi-style-slider-image"}};
var b={stopAutoPlay:"stop.owl.autoplay",translated:"translated.owl.carousel",initialized:"initialized.owl.carousel",swipeEvents:"touchstart mousedown",slide:{nextSlide:"next.owl.carousel",prevSlide:"prev.owl.carousel"},swipe:{left:"swipeleft",right:"swiperight"},resumeAutoPlay:"play.owl.autoplay",mouse:{leave:"mouseleave",enter:"mouseenter"}};
var d=20;
var e='<svg class="navigation__arrow" width="35" height="15" viewBox="0 0 35 15" fill="none" xmlns="http://www.w3.org/2000/svg">\n<path d="M33.7337 8.18953C34.1242 7.799 34.1242 7.16584 33.7337 6.77532L27.3697 0.411354C26.9792 0.0208297 26.346 0.0208297 25.9555 0.411354C25.565 0.801878 25.565 1.43504 25.9555 1.82557L31.6124 7.48242L25.9555 13.1393C25.565 13.5298 25.565 14.163 25.9555 14.5535C26.346 14.944 26.9792 14.944 27.3697 14.5535L33.7337 8.18953ZM0 8.48242H33.0266V6.48242H0V8.48242Z" fill="#222222"/>\n</svg>';
var a={items:1,dots:false,loop:true,autoplay:false,nav:true,navText:[e,e]};
return{classes:c,defaultSliderOptions:a,events:b,RESPONSIVE_PADDING:d}
});
define("MultiStyleSlider",["MultiStyleSliderConstants","MultiStyleSliderHandlers","utils-env"],function(c,a,d){var b=function(){function l(n){_classCallCheck(this,l);
this._el=n[0];
this.isEditMode=d.isEditMode();
this.sliderSpeed=this._el.dataset.playSpeed;
this.slider=this._el.querySelector(c.classes.common.carousel);
this.isHasImagesSlide=this._el.querySelector(c.classes.common.isHasImagesSlide);
this._context={self:this};
this.init()
}_createClass(l,[{key:"init",value:function m(){this.initSliderEvents()
}},{key:"initSliderEvents",value:function k(){var n=this;
window.addEventListener("DOMContentLoaded",function(){if(!n.isEditMode){$(n.slider).one(c.events.initialized,a.carouselInitialized(n._context));
$(n.slider).one(c.events.translated,a.enableNavigationArrow(n._context));
$(n.slider).on(c.events.translated,a.removeTitleUnderImagesSlide(n._context));
a.initOwlCarousel(n._context);
n.initAdditionalSliderVariables();
n.unbindDefaultCarouselEvents();
n.initSliderNavigation();
n.initImagesSliderNavigation();
n.initSpecialEvents();
a.initCustomAutoPlay(n._context);
a.removeTitleUnderImagesSlide(n._context)()
}});
this.handleSliderStopAutoPlay()
}},{key:"handleSliderStopAutoPlay",value:function j(){if(this.sliderSpeed>0){this._el.addEventListener(c.events.mouse.enter,a.mouseEnterEventHandler(this._context));
this._el.addEventListener(c.events.mouse.leave,a.mouseLeaveEventHandler(this._context))
}}},{key:"initAdditionalSliderVariables",value:function i(){this.nextButton=this._el.querySelector(c.classes.common.nextButton);
this.prevButton=this._el.querySelector(c.classes.common.prevButton);
this.navigationPanel=this._el.querySelector(c.classes.common.navigationPanel)
}},{key:"unbindDefaultCarouselEvents",value:function e(){if(this.isHasImagesSlide){$(this.nextButton).unbind();
$(this.prevButton).unbind()
}}},{key:"initSliderNavigation",value:function h(){if(!this.isHasImagesSlide){var n={self:this};
this.nextButton.addEventListener("click",a.stopAutoPlay(n));
this.prevButton.addEventListener("click",a.stopAutoPlay(n))
}}},{key:"initImagesSliderNavigation",value:function f(){var n=this;
if(this.isHasImagesSlide){this.nextButton.addEventListener("click",function(){a.stopAutoPlay({self:n});
a.handleImagesNavigations({self:n,direction:"right"})()
});
this.prevButton.addEventListener("click",function(){a.stopAutoPlay({self:n});
a.handleImagesNavigations({self:n,direction:"left"})()
})
}}},{key:"initSpecialEvents",value:function g(){this.navigationPanel.addEventListener("click",a.enableNavigationArrow({self:this}),{once:true})
}}]);
return l
}();
b.selector=".multi-style-slider-ui";
b.moduleName="Multi Style Slider";
return b
});
define("MultiStyleSliderHandlers",["MultiStyleSliderConstants","MultiStyleSliderUtils"],function(m,l){var e=function e(r){var q=r.self;
var p=l.getSliderConfig({isHasImagesSlide:q.isHasImagesSlide,speed:q.sliderSpeed,self:q,callback:n});
$(q.slider).owlCarousel(p)
};
var n=function n(q){var p=q.self;
return function(){if(p.isHasImagesSlide){clearInterval(p.customTimerId)
}else{$(p.slider).trigger(m.events.stopAutoPlay)
}}
};
var a=function a(q){var p=q.self;
if(p.isHasImagesSlide){b({self:p})
}else{$(p.slider).trigger(m.events.resumeAutoPlay,[p.sliderSpeed*1000])
}};
var b=function b(q){var p=q.self;
if(p.isHasImagesSlide&&p.sliderSpeed>0){p.customTimerId=l.createInterval(function(){f({self:p,direction:"right"})()
},p.sliderSpeed)
}};
var i=function i(q){var p=q.self;
return function(){n({self:p})()
}
};
var g=function g(q){var p=q.self;
return function(){a({self:p})
}
};
var c=function c(p){return function(){p.self._el.classList.remove(m.classes.common.disabledArrow)
}
};
var h=function h(p){return function(){k(p);
d(p)
}
};
var k=function k(q){var p=q.self;
var r=$(p._el).find(m.classes.manual.imageSlide);
if(r.length>0){r.on(m.events.swipeEvents,function(s){s.stopPropagation()
})
}};
var d=function d(q){var p=q.self;
var r=$(p._el).find(m.classes.manual.imagesTrack);
if(r.length>0){r.on(m.events.swipe.left,function(s){o(p,s.currentTarget,"left")
});
r.on(m.events.swipe.right,function(s){o(p,s.currentTarget,"right")
})
}};
var o=function o(p,s,q){var r=l.isPossibleSlideToSwitch(s,q);
if(r&&r.event){$(p.slider).trigger(r.event)
}};
var f=function f(q){var p=q.self,r=q.direction;
return function(){var u=l.getActiveSlide(p);
var t=u.querySelector(m.classes.manual.imagesTrack);
if(r==="right"){if(t){var v=l.getScrollMoveDistance(t,"right");
if(v>0){l.moveScrollToPosition(t,v+10)
}if(v<0){$(p.slider).trigger(m.events.slide.nextSlide)
}}else{$(p.slider).trigger(m.events.slide.nextSlide)
}}if(r==="left"){if(t){var s=l.getScrollMoveDistance(t,"left");
if(s>=0){$(p.slider).trigger(m.events.slide.prevSlide)
}if(s<0){l.moveScrollToPosition(t,s)
}}else{$(p.slider).trigger(m.events.slide.prevSlide)
}}}
};
var j=function j(q){var p=q.self;
return function(){var r=l.getActiveSlide(p);
var s=r.querySelector(m.classes.manual.imageSlide);
if(s){p._el.classList.add(m.classes.common.hideTitle)
}else{p._el.classList.remove(m.classes.common.hideTitle)
}}
};
return{initOwlCarousel:e,enableNavigationArrow:c,stopAutoPlay:n,carouselInitialized:h,handleImagesNavigations:f,removeTitleUnderImagesSlide:j,mouseEnterEventHandler:i,mouseLeaveEventHandler:g,initCustomAutoPlay:b}
});
define("MultiStyleSliderUtils",["MultiStyleSliderConstants"],function(j){var h=function h(q){var p=q.isHasImagesSlide,r=q.speed,n=q.self,t=q.callback;
var s=r*1000;
var m=j.defaultSliderOptions;
var o=null;
if(s>0){o={autoplayTimeout:s,autoplay:!p,onDragged:t({self:n})}
}return o?Object.assign({},m,o):m
};
var g=function g(o,n){var m=o.offsetWidth+o.scrollLeft;
if(n==="right"&&o.scrollLeft===0){return{event:j.events.slide.prevSlide}
}if(n==="left"&&m>=o.scrollWidth){return{event:j.events.slide.nextSlide}
}return null
};
var k=function k(n){var m=n.offsetWidth+n.scrollLeft;
return n.scrollWidth-m
};
var d=function d(p){var m=p.getBoundingClientRect(),o=m.left,n=m.right;
return{left:o,right:n}
};
var e=function e(m,u){var p=arguments.length>2&&arguments[2]!==undefined?arguments[2]:false;
var s=d(m),v=s.left,t=s.right;
var w={currentImage:null,nextImage:null,fullyDisplayedImage:null,prevImage:null};
for(var r=0;
r<u.length;
r++){var o=d(u[r]),q=o.left,n=o.right;
if(v<q&&t>n){w.fullyDisplayedImage=u[r];
w.nextImage=u[r+1]||u[r];
w.prevImage=u[r-1]||u[r]
}if(v>q&&q<t&&n>v){w.currentImage=u[r];
w.nextImage=u[r+1]||u[r]
}if(p&&(w.currentImage||w.fullyDisplayedImage)){return w
}}return w
};
var b=function b(p,n){var t=e(p,n);
var r=t.nextImage;
var o=d(p),q=o.left;
if(r){var m=d(r),s=m.left;
return s-q
}return -1
};
var i=function i(n,r){var q=e(n,r,true);
var o=q.currentImage,w=q.fullyDisplayedImage,m=q.prevImage;
var x=d(n),u=x.left;
if(w){var v=d(m),p=v.left;
return p-u
}else{if(o){var t=d(o),s=t.left;
return s-u
}}return 0
};
var f=function f(n,r){var m=n.querySelectorAll(j.classes.manual.image);
if(r==="right"){var o=b(n,m);
var q=k(n);
if(q<=1){return -1
}return o-j.RESPONSIVE_PADDING
}if(r==="left"){var p=i(n,m);
return p-j.RESPONSIVE_PADDING
}};
var c=function c(m,n){m.scrollBy({left:n,behavior:"smooth"})
};
var a=function a(n,m){if(m>0){return setInterval(function(){n()
},m*1000)
}};
var l=function l(m){return m._el.querySelector(j.classes.common.activeSlide)
};
return{getSliderConfig:h,isPossibleSlideToSwitch:g,moveScrollToPosition:c,getScrollMoveDistance:f,createInterval:a,getActiveSlide:l}
});
define("PaddingComponent",["utils"],function(a){var d={DATA_DESKTOP_HEIGHT:"data-desktopHeight",DATA_RESPONSIVE_HEIGHT:"data-responsiveHeight",DATA_RESPONSIVE_BREAKPOINTS:"data-responsiveBreakpoints",TABLET:"tablet",MOBILE:"mobile"};
var c={mobile:"(max-width: 767px)",tablet:"(min-width: 768px) and (max-width: 991px)"};
var b=function(){function e(h){_classCallCheck(this,e);
this._el=h[0];
this.desktopHeight=this._el.getAttribute(d.DATA_DESKTOP_HEIGHT);
this.responsiveHeight=this._el.getAttribute(d.DATA_RESPONSIVE_HEIGHT)||this.desktopHeight;
this.breakPoint=this._el.getAttribute(d.DATA_RESPONSIVE_BREAKPOINTS);
this.isTabletBreakPoint=this.breakPoint===d.TABLET;
this.isMobileBreakPoint=this.breakPoint===d.MOBILE;
this.init()
}_createClass(e,[{key:"init",value:function g(){this.resizeEventHandler();
window.addEventListener("resize",a.debounce(this.resizeEventHandler.bind(this),300))
}},{key:"resizeEventHandler",value:function f(){var i=window.matchMedia(c.tablet).matches;
var h=window.matchMedia(c.mobile).matches;
if(this.isTabletBreakPoint&&(h||i)){this._el.style.height=this.responsiveHeight+"px"
}else{if(this.isMobileBreakPoint&&h){this._el.style.height=this.responsiveHeight+"px"
}else{this._el.style.height=this.desktopHeight+"px"
}}}}]);
return e
}();
b.moduleName="Padding Component";
b.selector=".padding-component-ui";
return b
});
define("RolloverBlocks",[],function(){var b={BLOCK:"rollover-blocks__block",FOCUSED_BLOCK:"rollover-blocks__block--focused",BLOCK_CONTENT:"rollover-blocks__content",ROLLOVER_BLOCK:"rollover-blocks__description-rollover",LINK_A11Y:"rollover-blocks__link-holder--a11y",LINK_LEARN_MORE:"rollover-blocks__link",RTE_LINKS:"rollover-blocks__text a"};
var a=function(){function d(h){_classCallCheck(this,d);
this.el=h[0];
this.blocks=this.el.querySelectorAll("."+b.BLOCK);
this.addEventListenersToBlocks()
}_createClass(d,[{key:"addEventListenersToBlocks",value:function g(){var h=this;
this.blocks.forEach(function(p,n){var m=p.querySelector("."+b.BLOCK_CONTENT);
var j=p.querySelector("."+b.LINK_A11Y);
var l=p.querySelector("."+b.ROLLOVER_BLOCK);
var i=p.querySelector("."+b.LINK_LEARN_MORE);
var o=p.querySelectorAll("."+b.RTE_LINKS);
var k=[i].concat(_toConsumableArray(o));
if(n===0){h.showForAccessibility(m)
}m.addEventListener("click",function(){if(i){i.click()
}else{if(o[0]){o[0].click()
}}});
h.hideForAccessibility.apply(h,_toConsumableArray(o));
h.addEventListenerToRolloverBlock(p,l,k);
j.addEventListener("click",function(){h.showForAccessibility.apply(h,[l].concat(_toConsumableArray(k)));
l.focus({preventScroll:true})
})
})
}},{key:"addEventListenerToRolloverBlock",value:function c(k,j,i){var h=this;
j.addEventListener("focus",function(){setTimeout(function(){k.classList.add(b.FOCUSED_BLOCK);
h.showForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
},5)
});
j.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
h.hideForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
});
i.forEach(function(l){if(l){l.addEventListener("focus",function(){k.classList.add(b.FOCUSED_BLOCK);
h.showForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
});
l.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
h.hideForAccessibility.apply(h,[j].concat(_toConsumableArray(i)))
})
}})
}},{key:"showForAccessibility",value:function e(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",0);
k.removeAttribute("aria-hidden")
}})
}},{key:"hideForAccessibility",value:function f(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",-1);
k.setAttribute("aria-hidden",true)
}})
}}]);
return d
}();
a.selector=".rollover-blocks-ui";
a.moduleName="Rollover Blocks";
return a
});
define("TileList",[],function(){var b={TILE:"tile-list__item",TILE_ACTIVE:"tile-list__item--active",TILE_LINK:"tile-list__link",TILE_LINK_EXTERNAL:"tile-list__external-link",LINK_A11Y:"tile-list__link--a11y",LINK_A11Y_HOLDER:"tile-list__link-holder--a11y",TILE_CONTENT:"tile-list__content",TABS_UI:"tabs-ui",TABS_ITEM:"tabs__item"};
var a=function(){function k(m){_classCallCheck(this,k);
this.el=m[0];
this.tiles=this.el.querySelectorAll("."+b.TILE);
this.addEventListeners();
this.disableTabsFocus()
}_createClass(k,[{key:"addEventListeners",value:function g(){var m=this;
this.tiles.forEach(function(s,q){var p=s.querySelector("."+b.LINK_A11Y);
var r=s.querySelector("."+b.LINK_A11Y_HOLDER);
var o=s.querySelector("."+b.TILE_LINK);
var n=s.querySelector("."+b.TILE_CONTENT);
var u=s.querySelector("."+b.TILE_LINK_EXTERNAL);
var t=[o,u];
if(q===0){m.showA11yForTile(n,s)
}m.hideA11yForTile(n);
m.addEventListenersToTileContent(s,n,t);
m.addEventListenersToA11yLink(s,n,p,r,t);
m.addEventListenerToTile(s,r,t);
m.addEventListenersToLinks(s,n,t)
})
}},{key:"addEventListenersToLinks",value:function l(n,m,o){var p=this;
o.forEach(function(q){if(q){q.addEventListener("focus",function(){n.classList.add(b.TILE_ACTIVE);
p.showA11yForTile.apply(p,[m].concat(_toConsumableArray(o)))
});
q.addEventListener("focusout",function(){n.classList.remove(b.TILE_ACTIVE);
p.hideA11yForTile.apply(p,[m].concat(_toConsumableArray(o)))
})
}})
}},{key:"addEventListenerToTile",value:function j(n,m,p){var o=this;
n.addEventListener("focus",function(){m.setAttribute("aria-hidden",true)
});
n.addEventListener("click",function(){o.simulateClickOnTileLinks(p)
})
}},{key:"addEventListenersToA11yLink",value:function i(q,m,n,o,r){var p=this;
n.addEventListener("focus",function(){o.setAttribute("aria-hidden",false)
});
n.addEventListener("click",function(s){s.stopPropagation();
q.classList.add(b.TILE_ACTIVE);
p.showA11yForTile.apply(p,[m].concat(_toConsumableArray(r)));
setTimeout(function(){m.focus()
},5)
})
}},{key:"addEventListenersToTileContent",value:function c(o,m,p){var n=this;
m.addEventListener("focus",function(){setTimeout(function(){o.classList.add(b.TILE_ACTIVE);
n.showA11yForTile.apply(n,[m].concat(_toConsumableArray(p)))
},5)
});
m.addEventListener("focusout",function(){o.classList.remove(b.TILE_ACTIVE);
n.hideA11yForTile.apply(n,[m].concat(_toConsumableArray(p)))
});
m.addEventListener("click",function(q){q.stopPropagation();
n.simulateClickOnTileLinks(p)
})
}},{key:"simulateClickOnTileLinks",value:function h(m){m.forEach(function(n){if(n){n.click()
}})
}},{key:"showA11yForTile",value:function d(){for(var o=arguments.length,m=Array(o),n=0;
n<o;
n++){m[n]=arguments[n]
}m.forEach(function(p){if(p){p.setAttribute("tabindex",0);
p.removeAttribute("aria-hidden")
}})
}},{key:"hideA11yForTile",value:function f(){for(var o=arguments.length,m=Array(o),n=0;
n<o;
n++){m[n]=arguments[n]
}m.forEach(function(p){if(p){p.setAttribute("tabindex",-1);
p.setAttribute("aria-hidden",true)
}})
}},{key:"disableTabsFocus",value:function e(){var m=this.el.closest("."+b.TABS_UI);
if(m){m.querySelectorAll("."+b.TABS_ITEM).forEach(function(n){n.setAttribute("tabindex",-1)
})
}}}]);
return k
}();
a.moduleName="Tile List";
a.selector=".tile-list-ui";
return a
});
define("ObserversAPI",[],function(){var b={root:null,rootMargin:"0px",threshold:1};
var a=function a(f,d){var c=arguments.length>2&&arguments[2]!==undefined?arguments[2]:b;
var e=new IntersectionObserver(f,c);
e.observe(d)
};
return{intersectionObserver:a}
});
define("RequestAnimationFrame",[],function(){var e=60;
var g=[];
var d=0;
function f(i,h){i.fps=h?h:e;
i.then=Date.now();
i.fpsInterval=1000/i.fps;
g.push(i);
b()
}function b(){if(d!==0){return
}a()
}function a(){d=Date.now();
c()
}function c(){if(g.length===0){d=0;
return
}requestAnimationFrame(c);
var j=Date.now();
for(var k=0;
k<g.length;
k++){var h=j-g[k].then;
if(h>g[k].fpsInterval){g[k].then=j-h%g[k].fpsInterval;
g[k].func();
if(g[k].isEnd()){g.splice(k,1)
}}}}return{increaseAnimationQueue:f}
});
define(["utils","RequestAnimationFrame"],function(o,g){var d=window.innerHeight/100*80;
var e=2;
var h=9*e;
var b=[];
var j=function j(){var r=this.el.getBoundingClientRect();
if(r.top<=d){this.startValue+=this.step;
if(this.startValue===this.string||this.startValue>this.string){this.el.innerHTML=this.originalString;
this.finish=true;
return
}this.el.innerHTML=c.call(this,this.startValue.toString())
}};
var a=function a(){if(this.finish){return true
}};
function c(s){var r=this.signCount>1?m.call(this,s):i.call(this,s);
return this.sign===-1?Math.ceil(r):r
}var q=function q(s,r){var t=s/r;
if(this.signCount>1){return Math.ceil(t)
}if(t>0.1){return +parseFloat(t).toFixed(this.precise)
}return +parseFloat(t).toFixed(2)
};
function p(){if(this.originalString.indexOf(",")!==-1){this.sign=","
}else{if(this.originalString.indexOf(".")!==-1){this.sign="."
}}}function n(){var r=this.originalString.lastIndexOf(this.sign);
if(r!==-1){this.precise=this.originalString.length-1-r;
return
}if(this.string<h){this.precise=1
}}function l(r){if(this.sign&&this.sign===","){return r.replaceAll(".",",")
}return r
}function i(r){if(this.precise!==0){return l.call(this,parseFloat(r).toFixed(this.precise))
}else{return l.call(this,r)
}}function m(v){var s=v;
var u=s.length;
var r=Math.floor(u/this.precise);
var t=u-this.precise*r;
while(t<=u){if(t===0){t+=this.precise
}else{s=s.slice(0,t)+this.sign+s.slice(t);
t+=this.precise+1
}}return s
}function f(t){var r=arguments.length>1&&arguments[1]!==undefined?arguments[1]:1;
if(this.sign!==-1){var s=t.indexOf(this.sign,r);
if(s!==-1){this.signCount+=1;
f.call(this,t,s+1)
}}}var k=function k(r){Array.prototype.forEach.call(r,function(t){var s={signCount:0,startValue:0,finish:false,sign:-1,precise:0};
s.originalString=t.innerHTML;
p.call(s);
f.call(s,s.originalString);
if(s.signCount>1){s.string=parseFloat(s.originalString.replaceAll(s.sign,""))
}else{s.string=parseFloat(s.originalString.replaceAll(",","."))
}if(!isNaN(s.string)){n.call(s);
s.step=q.call(s,s.string,h);
s.el=t;
t.innerHTML=0;
b.push({func:j.bind(s),endFunc:a.bind(s)})
}})
};
document.addEventListener("DOMContentLoaded",function(){var r=document.querySelectorAll(".rte-number-animation");
k(r);
Array.prototype.forEach.call(b,function(s){g.increaseAnimationQueue({func:s.func,isEnd:s.endFunc},10)
})
})
});
define("animation-tools",["utils"],function(l){var n=window.innerHeight;
var b=n/2;
var d={multipleBlock:"multiple-topics-list__block-image-wrapper",multipleParallaxSection:"multiple-topics-list__animation-placeholder-wrapper",parallaxSection:"parallax-section",featureParallaxBlock:"featured-content-card__parallax-block",featureSection:"featured-content-card__image-wrapper"};
var f=10;
var e=function e(){return window.scrollY
};
var c=function c(o){var p=o.getBoundingClientRect();
return{top:p.top+e(),rawTop:p.top,bottom:p.bottom+e(),rawBottom:p.bottom,height:o.offsetHeight}
};
var g=function g(s,r,p,o){var q=c(s);
var u=Math.ceil(q.height/100*o);
var t=u/100*r*p;
s.style.transform="translateY("+t+"px)"
};
var h=function h(p){var r=c(p);
var q=0;
var o=0;
if(r.rawTop<b){q=100-r.rawTop/b*100;
o=1
}else{q=r.rawTop/b*100-100;
o=-1
}return{percent:q,translateDirection:o}
};
function k(q){if(l.isElementInViewport(q)){var r=h(q),p=r.percent,o=r.translateDirection;
g(this,p,o,f)
}}var j=function j(o){var p=void 0;
if(o.classList.contains(d.multipleBlock)){p=o.closest("."+d.multipleParallaxSection)
}else{if(o.classList.contains(d.featureParallaxBlock)){p=o.closest("."+d.featureSection)
}else{p=o.closest(".section")
}}p.classList.add(d.parallaxSection);
return p
};
var a={applyParallax:function i(o){var p=j(o);
return k.bind(o,p)
},parallaxStopCondition:function m(){return false
}};
return{Parallax:a,getElRect:c}
});
define(["utils","RequestAnimationFrame"],function(a,b){document.addEventListener("DOMContentLoaded",function(){var d=document.querySelectorAll(".rte-text-animation");
var e=Array.prototype.slice.call(d);
function c(){for(var g=0;
g<e.length;
g++){if(a.isElementInViewport(e[g])){e[g].classList.add("live-text");
e.splice(g,1)
}}}function f(){return e.length===0
}if(e.length!==0){b.increaseAnimationQueue({func:c,isEnd:f})
}})
});
define(["RequestAnimationFrame","animation-tools","constants"],function(e,d,b){var a="applied-parallax";
var c=function c(){var f=document.querySelectorAll(".parallax-wrapper:not(."+a+")");
f.forEach(function(g){g.classList.add(a);
e.increaseAnimationQueue({func:d.Parallax.applyParallax(g),isEnd:d.Parallax.parallaxStopCondition})
})
};
document.addEventListener(b.Events.featureGridAddedNewItems,function(){c()
});
document.addEventListener("DOMContentLoaded",function(){c()
})
});
define("SolutionsHubReferrer",[],function(){var d={referrerKey:"SolutionsHubReferrer",referrerField:'.hidden-field-ui[name="source"]'};
var a=function a(){var e=sessionStorage.getItem(d.referrerKey);
if(e===null){sessionStorage.setItem(d.referrerKey,JSON.stringify({referrer:document.referrer,isPaidTraffic:b()}))
}};
var c=function c(e){var f=e.querySelector(d.referrerField);
if(f){f.value=sessionStorage.getItem(d.referrerKey)
}};
var b=function b(){var e=/gclid|gclsrc|compaignSource|utm_source/gi;
var f=document.location.search;
return e.test(f)
};
a();
return{setReferrerHiddenField:c}
});
define("sticky-scroll",[],function(){var o='[data-sticky-scroll="true"]';
var j=[];
window.addEventListener("load",l);
function l(){var u=document.querySelectorAll(o);
var t=u.length>0;
if(!t){return
}r();
s();
b();
c();
g()
}function g(){var u=document.documentElement.scrollTop;
var t=j.find(function(w){var x=w.start,v=w.end;
return u>=x&&u<=v
});
if(t){p(u,t)
}else{q(u)
}}function r(){var u=document.createElement("div");
u.classList.add("pin-spacer");
u.style.width="100%";
u.style.position="relative";
var t=document.querySelector("body");
while(t.firstChild){u.appendChild(t.firstChild)
}t.appendChild(u)
}function n(w,v,x){var u=document.querySelector(".pin-spacer");
var t=w?{position:"fixed",top:"-"+v+"px"}:{position:"relative",top:v+"px"};
Object.assign(u.style,t);
Array.from(document.querySelectorAll(o)).forEach(function(z){var A=h(z),B=A.start,y=A.end;
z.dataset.stickyScrollStarted=B<=x;
z.dataset.stickyScrollEnded=y<=x;
if(x>y){f(z,y-B);
return
}if(x<B){f(z,0);
return
}f(z,x-B)
})
}function c(){window.addEventListener("scroll",d);
window.addEventListener("resize",i)
}function i(){s();
b();
g()
}function a(v){var u=0;
var t=v;
var w=document.querySelector(".pin-spacer");
while(t.offsetParent){if(t!==w&&!isNaN(t.offsetTop)){u+=t.offsetTop
}t=t.offsetParent
}return u
}function e(t){return t.dataset.stickyScrollVertical==="true"
}function h(u){var w=u.offsetHeight,E=u.scrollHeight,C=u.offsetWidth,z=u.scrollWidth;
var v=a(u);
var t=v+w;
var A=document.documentElement.clientHeight;
var x=j.filter(function(F){return F.offsetTop<v
}).reduce(function(H,G){var I=G.start,F=G.end;
return H+F-I
},0);
var y=t-A<0?x:t-A+x;
var D=e(u)?E-w:z-C;
var B=y+D;
return{start:y,end:B,offsetTop:v}
}function s(){j=[];
document.querySelectorAll(o).forEach(function(t){j.push(h(t))
})
}function b(){var u=document.querySelector("body");
var x=document.querySelector(".pin-spacer");
var t=x.offsetHeight;
var w=j.reduce(function(A,z){var B=z.start,y=z.end;
return A+y-B
},0);
var v=t+w;
u.style.height=v+"px"
}function m(u,w){var v=u.start,t=u.end;
return w>=v&&w<=t
}function k(t){Array.from(document.querySelectorAll(o)).some(function(u){var v=h(u);
if(!m(v,t)){return null
}f(u,t-v.start);
return true
})
}function f(t,u){if(e(t)){t.style.transform="translate3d(0px, -"+u+"px, 0px)"
}else{t.style.transform="translate3d(-"+u+"px, 0px, 0px)"
}}function p(w,v){var u=v.start;
var t=j.filter(function(x){return x.start<u
}).reduce(function(x,y){return x-y.end+y.start
},u);
n(true,t,w)
}function q(u){var t=j.filter(function(w){var v=w.end;
return u>v
}).reduce(function(x,v){var y=v.start,w=v.end;
return x+w-y
},0);
n(false,t,u)
}function d(){var v=document.documentElement.scrollTop;
var u=j.find(function(y){var x=y.start,w=y.end;
return v>=x&&v<=w
});
var t=document.querySelector(".pin-spacer").style.position==="fixed";
if(u&&!t){p(v,u)
}if(!u&&t){q(v)
}if(t){k(v)
}}});
define("VkFeed",["media","utils-env"],function(c,b){function a(d){this.$el=d;
this.containerId=this.$el.data("containerId");
this.params={id:this.$el.data("group-id"),mode:this.$el.data("widget-type"),heights:this.$el.data("height")};
this.update();
!b.isEditMode()&&$(window).on("resize",this.update.bind(this))
}a.prototype.update=function(){var d=c.currentMode();
if(d.isNot(this.currentState.mode)){this.currentState.height=this.params.heights[d.name];
this.currentState.mode=c.currentMode()
}this.initWidget()
};
a.prototype.clearElement=function(){this.$el.html('<div id="'+this.containerId+'"/>')
};
a.prototype.initWidget=function(){this.clearElement();
VK.Widgets.Group(this.containerId,{wide:0,mode:this.params.mode,width:"auto",height:this.currentState.height,color1:this.colors.background,color2:this.colors.text,color3:this.colors.buttons},this.params.id)
};
a.prototype.colors={background:"FFFFFF",text:"231F20",buttons:"76CDD7"};
a.prototype.currentState={};
a.moduleName="VK Feed";
a.selector=".vk-feed-ui";
return a
});
define("VideoShowcaseA11y",[],function(){var i={container:"a11y-container",navigationPanel:"a11y-navigation-panel"};
var j=0;
function l(n){this.$optionsA11=n;
this.$elA11=$(this.$el).find("."+i.container);
this.$navigationPanelA11=this.$elA11.find("."+i.navigationPanel);
this.$navigationItemsA11=this.$navigationPanelA11.find("."+this.$optionsA11["list-item"]);
this.$navigationItemsLengthA11=this.$navigationItemsA11.length;
d.call(this);
f.call(this)
}function d(o){this.$navigationPanelA11.attr("role","tablist");
var n=o?o:j;
$.each(this.$navigationItemsA11,function(p,q){if(p===n){$(q).attr("aria-selected","true").attr("role","tab").attr("tabindex","0");
return
}$(q).attr("aria-selected","false").attr("role","tab").attr("tabindex","-1")
})
}function b(){$.each(m.call(this),function(n,o){$(o).attr("aria-selected","false").attr("tabindex","-1")
})
}function m(){return this.$navigationPanelA11.find('[aria-selected="true"]')
}function h(){var n=m.call(this).next("."+this.$optionsA11["list-item"]);
return n.length!==0?n:$(this.$navigationItemsA11[0])
}function e(){var n=m.call(this).prev("."+this.$optionsA11["list-item"]);
return n.length!==0?n:$(this.$navigationItemsA11[this.$navigationItemsLengthA11-1])
}function c(o){var n=o();
b.call(this);
n.attr("aria-selected","true").attr("tabindex","0").focus()
}function g(){c.call(this,h.bind(this))
}function k(){c.call(this,e.bind(this))
}function a(o){var n=o.keyCode;
if(n===39||n===40){g.call(this);
this.$optionsA11["move-forward-callback"]&&this.$optionsA11["move-forward-callback"].call(this)
}if(n===37||n===38){k.call(this);
this.$optionsA11["move-downward-callback"]&&this.$optionsA11["move-downward-callback"].call(this)
}if(n===35||n===36){}if(n===13||n===32){this.$optionsA11["enter-action"]&&this.$optionsA11["enter-action"].call(null,o.target)
}}function f(){this.$navigationPanelA11.on("keydown",a.bind(this))
}return{init:l,setSpecialAttribute:d}
});
define("UtilityMenu",["utils-share"],function(b){function a(c){this.$el=c;
this.$share=this.$el.find("."+this.classes.share);
this.$share.on("click",this.share.bind(this))
}a.prototype.share=function(c){b.openPopup(b.getLink($(c.currentTarget).data()));
return false
};
a.prototype.classes={share:"utility-menu__share-button"};
a.moduleName="Utility Menu";
a.selector=".utility-menu-ui";
return a
});
define("UnsubscribeButton",["utils"],function(a){function b(c){this.$el=c;
this.$errorMessage=this.$el.find("."+this.classes.error);
this.$successMessage=this.$el.find("."+this.classes.success);
this.$validationMessage=this.$el.find("."+this.classes.validation);
this.$unsubscribeButton=this.$el.find("."+this.classes.button);
this.$disclaimer=this.$el.find("."+this.classes.disclaimer);
this.$unsubscribeButton.on("click",this.sendRequest.bind(this))
}b.prototype.hideAll=function(){this.$errorMessage.addClass(constants.Classes.hidden);
this.$unsubscribeButton.addClass(constants.Classes.hidden);
this.$validationMessage.addClass(constants.Classes.hidden);
this.$disclaimer.addClass(constants.Classes.hidden);
this.$successMessage.addClass(constants.Classes.hidden)
};
b.prototype.showValidation=function(){this.hideAll();
this.$validationMessage.removeClass(constants.Classes.hidden)
};
b.prototype.showError=function(){this.hideAll();
this.$errorMessage.removeClass(constants.Classes.hidden)
};
b.prototype.showSuccess=function(){this.hideAll();
this.$successMessage.removeClass(constants.Classes.hidden)
};
b.prototype.sendRequest=function(){var c=window.location.href,d=a.getQueryParameters(c);
if(!d.id||!d.type){this.showValidation();
return
}$.ajax({type:"POST",url:"/services/interaction/subscription/unsubscribe",data:{id:d.id,type:d.type},beforeSend:function(){this.$unsubscribeButton.attr("disabled","disabled")
}.bind(this),error:function(e){e.status===400?this.showValidation():this.showError()
}.bind(this),success:this.showSuccess.bind(this)})
};
b.prototype.classes={error:"unsubscribe-button--error",success:"unsubscribe-button--success",validation:"unsubscribe-button--validation",button:"unsubscribe-button__button",disclaimer:"unsubscribe-button__disclaimer"};
b.moduleName="Unsubscribe Button";
b.selector=".unsubscribe-button-ui";
return b
});
define("TwitterFeed",["media","constants"],function(c,b){function a(e){this.$el=e;
this.$tweets=this.$el.find(this.classes.tweet);
this.locale=this.$el.data("locale");
this.isCarouselView=this.$el.hasClass(this.classes.carousel);
moment.locale(this.locale);
var d=$.extend({},b.CarouselDefaultConfig,{dots:false});
this.$tweets.each(function(h,i){var g=$(i),k=g.find(this.classes.date),f=g.data("dateFormat"),j=moment(+g.data("created"));
k.text(j.format(b.DateFormats[f]))
}.bind(this));
this.isCarouselView&&this.$el.find(this.classes.tweets).owlCarousel(d)
}a.prototype.classes={date:".twitter-feed__date",tweet:".twitter-feed__tweet",tweets:".twitter-feed__tweets",carousel:"twitter-feed--carousel"};
a.moduleName="Twitter Feed";
a.selector=".twitter-feed-ui";
return a
});
define("TrainingSearch",["RecruitingSearch"],function(a){function b(c){a.call(this,c)
}b.prototype=Object.create(a.prototype);
b.prototype.getSubmitContext=function(){return{query:this.$autocomplete.val(),country:this.getCountry(),city:this.getCity()}
};
b.prototype.getResultsContext=function(c){return{list:c,spritePath:EPAM.spritePath}
};
b.prototype.getResultMessageWithQuery=function(e,d){var c='"'+e+'"';
return d===1?CQ.I18n.getMessage("component.training-search.results-label.single_result",[c]):CQ.I18n.getMessage("component.training-search.results-label.several_results",[c,d])
};
b.prototype.getResultMessage=function(c){return c===1?CQ.I18n.getMessage("component.training-search.results-label.single_result_without_query"):CQ.I18n.getMessage("component.training-search.results-label.several_results_without_query",[c])
};
b.prototype.config={autocompletePath:"/services/search/smart-search.training.json",searchUrl:"/services/search/training"};
b.moduleName="Training Search";
b.selector=".training-search-ui";
return b
});
define("TimelineSlider",["TabsUtil","utils-a11y","constants","utils-env"],function(f,b,j,h){var d=$(document),e=$("html"),a=$(window),g=$("body");
var c={item:".timeline-slider__slide",historyImage:".timeline-slider__view-more",historyGallery:".timeline-slider__carousel",active:"timeline-slider--active",close:"timeline-slider--close",popup:".timeline-slider__popup",closePopupButton:".timeline-slider__popup-close",carouselItem:".timeline-slider__carousel-item",switcherCarousel:".timeline-slider__switcher-carousel",switcherButton:".timeline-slider__switcher-button",preloader:".timeline-slider__preloader",allyActive:"ally-active",popupPrint:"popup-print",printImage:"print-image"};
function i(k){this.$el=k;
this.$historyImage=this.$el.find(c.historyImage);
this.$historyGallery=this.$el.find(c.historyGallery);
this.$closePopupButton=this.$el.find(c.closePopupButton);
this.$switcherCarousel=this.$el.find(c.switcherCarousel);
this.$switcherButtons=this.$el.find(c.switcherButton);
this.$preloader=this.$el.find(c.preloader);
this.$historyImage.on("click",this.onButtonClick.bind(this));
this.$closePopupButton.on("click",this.closePopup.bind(this));
a.on("tab.changed",this.onTabChanged.bind(this));
a.on("beforeprint",this.beforeprintHandler.bind(this));
d.on("keyup",this.keyupHandler.bind(this));
this.$switcherCarousel.on("changed.owl.carousel",function(l){this.onSwitcherItemChanged(l)
}.bind(this));
this.$historyGallery.on("load.owl.lazy",this.showPreloader.bind(this));
this.$historyGallery.on("loaded.owl.lazy",this.hidePreloader.bind(this));
this.$switcherCarousel.owlCarousel(this.switcherDefaultConfig);
f.call(this,k,{items:k.find(c.item),verticalNavigation:true});
this.$el.on("tab.loaded tab.change",function(){this.$items.eq(this.activeItem).addClass(c.allyActive)
}.bind(this));
this.$items.on(j.Events.transitionEnd,function(){this.$items.not("."+this.classes.active).removeClass(c.allyActive)
}.bind(this))
}i.prototype=Object.create(f.prototype);
i.prototype.wcmModeChange=function(k){k==="preview"&&this.setColorClass()
};
i.prototype.onButtonClick=function(k){k.preventDefault();
!this.$el.hasClass(c.active)&&this.$el.scrollToSelector({duration:1000});
this.openPopup(k)
};
i.prototype.keyupHandler=function(k){if(k.key===j.Keys.esc){this.closePopup()
}};
i.prototype.openPopup=function(k){var m=$(k.currentTarget).parent(c.popup),l=m.find(c.closePopupButton);
this.$currentHistoryImage=m.find(c.historyImage);
this.$currentGallery=m.find(c.historyGallery);
this.$el.addClass(c.active);
g.addClass(c.popupPrint);
g.addClass(j.Classes.pinnedFilter);
e.addClass(j.Classes.noscroll);
this.$historyImage.attr("tabindex",-1);
this.carouselItemLength=m.find(c.carouselItem).length;
l.focus();
this.initGallery();
b.handlePopupFocus(m)
};
i.prototype.closePopup=function(){if(!this.$el.hasClass(c.active)){return
}this.$el.removeClass(c.active).addClass(c.close);
this.$historyImage.removeAttr("tabindex");
setTimeout(function(){g.removeClass(c.popupPrint);
g.removeClass(j.Classes.pinnedFilter);
e.removeClass(j.Classes.noscroll);
!this.$el.hasClass(c.active)&&this.$el.scrollToSelector({duration:300,reservedSpace:100});
this.refreshGallery();
this.$el.removeClass(c.close);
this.$currentHistoryImage.focus()
}.bind(this),100)
};
i.prototype.initGallery=function(){var k=this.carouselItemLength>1?this.mainDefaultConfig:$.extend({},this.mainDefaultConfig,{mouseDrag:false,touchDrag:false,nav:false,dots:false});
if(this.$currentGallery.hasClass("owl-loaded")){this.$currentGallery.trigger("refresh.owl.carousel")
}else{this.$currentGallery.owlCarousel(k)
}};
i.prototype.refreshGallery=function(){this.$currentGallery.trigger("to.owl.carousel",[0,20])
};
i.prototype.onTabChanged=function(){if(h.isEditMode()){return
}var k=this.$switcherButtons.filter("."+this.classes.active).data("item");
this.$switcherCarousel.trigger("to.owl.carousel",[k,20]);
this.activeBgColor=this.getBgColorClass(this.$items.eq(this.activeItem));
this.setColorClass()
};
i.prototype.onSwitcherItemChanged=function(k){var l=k.item.index;
this.$el.trigger("tab.change",{tab:l,skipFocus:true})
};
i.prototype.setColorClass=function(){var k=this.getBgColorClass(this.$el);
this.$el.removeClass(k).addClass(this.activeBgColor)
};
i.prototype.getBgColorClass=function(l){if(!l){return
}var k=l.attr("class").match(/bg-color[\w-]*\b/);
return k&&k.join(" ")
};
i.prototype.showPreloader=function(){this.$preloader.removeClass(j.Classes.hidden)
};
i.prototype.hidePreloader=function(){this.$preloader.addClass(j.Classes.hidden)
};
i.prototype.beforeprintHandler=function(){if(!this.$el.hasClass(c.active)){this.$currentGallery.owlCarousel("destroy")
}if(this.$el.hasClass(c.active)){this.addPrintImage()
}};
i.prototype.addPrintImage=function(){var k=$("."+c.printImage),l=this.$items.eq(this.activeItem).find(".owl-item.active .timeline-slider__carousel-image--desktop").attr("src");
if(!k.length){k=$('<img class="'+c.printImage+'" />').attr("src",l);
g.append(k);
return
}k.attr("src",l)
};
i.prototype.mainDefaultConfig={nav:true,center:true,items:1,lazyLoad:true,lazyLoadEager:0};
i.prototype.switcherDefaultConfig={center:true,items:1,dots:false,nav:true};
i.moduleName="Timeline Slider";
i.selector=".timeline-slider-ui";
return i
});
define("Timeline",["utils","RequestAnimationFrame","Timeline-A11y"],function(g,e,a){var d=156;
var f=160;
var h=768;
var c=3;
var b={events:"timeline-event",tempTimelineGraph:"temp-timeline-graph",topEventGraph:"timeline-graph-top",bottomEventGraph:"timeline-graph-bottom",eventLine:"timeline-event-line",progressLine:"timeline-event-line-progress",activeEvent:"timeline-active"};
function i(j){this.$el=j;
this.$tempTimelineGraph=this.$el.find("."+b.tempTimelineGraph);
this.$tempEvents=this.$el.find("."+b.events);
this.$eventCount=this.$tempEvents.length-1;
this.$topEventGraph=this.$el.find("."+b.topEventGraph);
this.$bottomEventGraph=this.$el.find("."+b.bottomEventGraph);
this.$progressLine=this.$el.find("."+b.progressLine);
this.$eventLine=this.$el.find("."+b.eventLine);
this.isAnimationRun=false;
this.isAnimationOn=this.$el.hasClass("timeline-animation");
this.color=this.$el.data().color;
this.documentWidth=$(document).width();
this.init()
}i.prototype.init=function(){this.events();
a.addKeydownEventHandler.call(this);
this.createEventsGraphs();
this.defineEventProgressStep();
this.isInsideSection();
this.createTimeline();
this.fixTimelineMobileHeight();
this.isAnimationOn&&this.runAnimation();
$.onFontLoad(this.setInfiniteLinePos.bind(this))
};
i.prototype.createEventsGraphs=function(){var k=[];
var j=[];
$.each(this.$tempEvents,function(l,m){m.setAttribute("data-index",l);
this.markFirstBoldItem(m);
a.applyAriaAttrOnItem(l,m);
if(l%2){j.push(m);
return
}k.push(m)
}.bind(this));
this.$topEventGraph.append(k);
this.$bottomEventGraph.append(j);
j.length===1&&this.$bottomEventGraph.addClass("timeline-single-event");
this.$bottomEventsCount=j.length;
this.$tempTimelineGraph.addClass("hidden");
a.applyAriaAttrOnContainer([this.$topEventGraph[0],this.$bottomEventGraph[0]])
};
i.prototype.markFirstBoldItem=function(j){var k=$(j).find('.timeline__mobile-event-text [class*="font-size-"]');
if(k.length!==0){$(k[0]).closest(".timeline__mobile-event-text").addClass($(k[0]).attr("class"))
}};
i.prototype.defineEventProgressStep=function(){if($(window).width()<h){this.step=f/2;
return
}var k=this.$el.width()-d;
var j=Math.round(k/this.$eventCount);
this.step=j*2<d?d/2:j
};
i.prototype.createTimeline=function(){if(!this.isAnimationOn){this.drawEventLine();
this.drawEvents()
}this.initSwiperSectionEvent();
this.fixTimelineMobileHeight()
};
i.prototype.isInsideSection=function(){var j=this.$el.closest(".section__wrapper");
if(j.length!==0){this.$section=j;
this.calcTimelineTranslate(j);
if(this.timelineTranslate!==0){this.$section.addClass("timeline-section-wrapper")
}this.$sectionParent=this.$section.closest(".section-ui").append('<div class="timeline-infinite-line"></div>');
this.infiniteLine=this.$sectionParent.find(".timeline-infinite-line");
this.infiniteLine.mouseover(this.mouseoverHandler.bind(this)).addClass(this.color)
}};
i.prototype.drawEvents=function(){if(this.isAnimationOn){if($(window).width()>=h){this.drawAnimationEvent("left","width");
this.initSwiperSectionEvent()
}else{this.drawAnimationEvent("top","height")
}}else{if($(window).width()>=h){this.drawSimpleEvent("left","width");
this.initSwiperSectionEvent()
}else{this.drawSimpleEvent("top","height")
}}};
i.prototype.drawSimpleEvent=function(k,j){$.each(this.$tempEvents,function(l){this.calcStyleForTheNextItem(l,k,j)
}.bind(this))
};
i.prototype.drawAnimationEvent=function(l,k){var j=Math.round(c/this.$eventCount*1000);
$.each(this.$tempEvents,function(m,n){this.calcStyleForTheNextItem(m,l,k);
setTimeout(function(o){o.addClass(b.activeEvent)
}.bind(this,$(n)),m*j)
}.bind(this))
};
i.prototype.calcTimelineTranslate=function(n){var k=n?n:this.$el.closest(".section__wrapper");
if(k.length!==0){var j=this.$el.width();
var l=this.$el[0].scrollWidth;
var m=d*this.$bottomEventsCount+this.step;
l=m>l?m:l;
this.timelineTranslate=Math.round(j-l)
}};
i.prototype.calcStyleForTheNextItem=function(m,j){var k=this.step;
var l=k*m;
var r=$(this.$tempEvents[m]);
var o=Math.round(r.offset()[j]);
var n=this.$el.offset()[j];
var q=n+l;
var p=q-o;
r.css(j,p+"px")
};
i.prototype.drawEventLine=function(){var j=this.step*this.$eventCount;
this.$progressLine.removeAttr("style").removeClass("timeline-animate");
setTimeout(function(){if(this.isAnimationOn){this.$progressLine.addClass("timeline-animate")
}if($(window).width()<h){this.$progressLine.css("height",j+f+"px")
}}.bind(this),100)
};
i.prototype.setInfiniteLinePos=function(){if(this.$section){if($(window).width()>=h){var j=this.$eventLine.offset().top-this.$section.offset().top;
this.infiniteLine.css("top",j+"px");
this.infiniteLine.css("left",this.$section.offset().left);
if(!this.isAnimationOn){this.infiniteLine.addClass("timeline-infinite-static")
}}}};
i.prototype.clearEventsStyle=function(){var j=this.$el.find("."+b.events);
$.each(j,function(k,l){$(l).removeClass(b.activeEvent).removeAttr("style")
})
};
i.prototype.events=function(){$(window).resize(g.debounceExtend(function(){if(this.documentWidth!==$(document).width()){this.documentWidth=$(document).width();
this.clearEventsStyle();
this.defineEventProgressStep();
this.createTimeline();
this.setInfiniteLinePos();
if($(window).width()>=h){this.calcTimelineTranslate()
}if(this.isAnimationOn){this.isAnimationRun=false;
this.runAnimation()
}}}.bind(this),500))
};
i.prototype.initSwiperSectionEvent=function(){this.$el.removeAttr("style");
this.$section&&this.$section.off("swipeleft").off("swiperight").off("mouseover").off("mouseleave");
if($(window).width()>=h){this.$section&&this.$section.on("swipeleft",this.mouseoverHandler.bind(this)).on("swiperight",this.mouseleaveHandler.bind(this)).mouseover(this.mouseoverHandler.bind(this)).mouseleave(this.mouseleaveHandler.bind(this))
}};
i.prototype.mouseoverHandler=function(){this.$el.css("transform","translate("+this.timelineTranslate+"px)").addClass("timeline-transition-active")
};
i.prototype.mouseleaveHandler=function(){this.$el.removeAttr("style").removeClass("timeline-transition-active")
};
i.prototype.runAnimation=function(){e.increaseAnimationQueue({func:function(){if(!this.isAnimationRun&&g.isElementInViewport(this.$el[0])){this.drawEventLine();
this.drawEvents();
this.isAnimationRun=true;
this.animateInfiniteLine()
}}.bind(this),isEnd:function(){return this.isAnimationRun
}.bind(this)})
};
i.prototype.animateInfiniteLine=function(){if(this.$section&&$(window).width()>=h){this.infiniteLine.addClass("timeline-infinite-animate")
}};
i.prototype.fixTimelineMobileHeight=function(){this.$el.removeAttr("style");
if(this.isAnimationOn&&$(window).width()<h){var j=this.$eventCount*this.step+f;
this.$el.css("height",j+"px")
}};
i.moduleName="Timeline";
i.selector=".timeline-ui";
return i
});
define("Timeline-A11y",[],function(){function c(j,k){k.setAttribute("role","tab");
if(j===0){k.setAttribute("tabindex",0);
k.setAttribute("aria-selected",true);
return
}k.setAttribute("tabindex",-1);
k.setAttribute("aria-selected",false)
}function f(j){Array.prototype.forEach.call(j,function(k){k.setAttribute("role","tablist");
k.setAttribute("aria-label","Timeline")
})
}function a(){this.ariaSelected=this.$el.find('.timeline-event[aria-selected="true"]');
this.ariaSelectedActiveIndex=parseInt(this.ariaSelected.attr("data-index"))
}function b(){this.ariaSelected.attr("aria-selected",false);
this.ariaSelected.attr("tabindex",-1)
}function g(k){var j=this.$el.find('.timeline-event[data-index="'+k+'"]');
if(j.length!==0){b.call(this);
j.attr("tabindex",0);
j.attr("aria-selected",true);
j.focus()
}}function d(){a.call(this);
g.call(this,this.ariaSelectedActiveIndex-1)
}function i(){a.call(this);
g.call(this,this.ariaSelectedActiveIndex+1)
}function h(j){switch(j.keyCode){case 38:d.call(this);
j.preventDefault();
break;
case 40:i.call(this);
j.preventDefault();
break;
default:}}function e(){this.$el.keydown(function(j){h.call(this,j)
}.bind(this))
}return{applyAriaAttrOnItem:c,applyAriaAttrOnContainer:f,addKeydownEventHandler:e}
});
define("ScalableImage",["utils","RequestAnimationFrame"],function(a,e){var c={scalableText:"scalable-image__text",scalableTextWrapper:"scalable-image-text-wrapper",animationContainer:"scalable-image-animation-container"};
var d={noLine:{path:"noLine"},girlAnimatedLine:{path:"/etc/designs/epam-com/json-animations/gradient.json",className:"girl-animated-line"},phoneAnimatedLine:{path:"/etc/designs/epam-com/json-animations/OurVision(PhoneOnAngle).json",className:"phone-animated-line"}};
function b(f){this.$el=f;
this.$scalableText=this.$el.find("."+c.scalableText);
this.$scalableTextWrapper=this.$el.find("."+c.scalableTextWrapper);
this.$animationContainer=this.$el.find("."+c.animationContainer);
this.picture=this.$el.find("picture");
this.animLineName=this.$el.data().animation;
this.scaletext=this.$el.data().textscale;
this.isFontLoad=false;
this.isAnimationRun=false;
this.init()
}b.prototype.init=function(){this.initEvents();
$.onFontLoad(function(){this.isFontLoad=true
}.bind(this));
if(d[this.animLineName].path!=="noLine"){this.loadAnimation()
}};
b.prototype.loadAnimation=function(){this.animation=a.loadLottieFile({container:this.$animationContainer[0],renderer:"svg",loop:false,autoplay:false,path:d[this.animLineName].path,rendererSettings:{viewBoxOnly:true,className:d[this.animLineName].className}});
this.animation.addEventListener("DOMLoaded",this.runAnimation.bind(this))
};
b.prototype.runAnimation=function(){e.increaseAnimationQueue({func:this.triggerAnimation.bind(this),isEnd:this.finishAnimation.bind(this)})
};
b.prototype.triggerAnimation=function(){if(this.isAnimationRun){return
}if(a.isElementInViewport(this.$el[0])){this.isAnimationRun=true;
this.animation.goToAndPlay(0)
}};
b.prototype.finishAnimation=function(){return this.isAnimationRun
};
b.prototype.getScalableTextRect=function(){return this.$scalableText[0].getBoundingClientRect()
};
b.prototype.getScalableTextWrapperRect=function(){return this.$scalableTextWrapper[0].getBoundingClientRect()
};
b.prototype.scaleText=function(){var h=this.getScalableTextRect();
var g=this.getScalableTextWrapperRect();
var f=Math.ceil(g.bottom-h.bottom);
if(f<=0){this.calculateTextScale(h,g)
}};
b.prototype.calculateTextScale=function(g,i){var k=Math.ceil((i.height/g.height)*100)-1;
var j=k/100;
var h=Math.ceil(g.width*(k/100));
var f=(g.width-h)/-2;
this.$scalableText.css({transform:"scale("+j+")",left:f+"px"})
};
b.prototype.wait=function(g,f){setTimeout(g.bind(this),f)
};
b.prototype.waitImageLoading=function(){var f=this.picture[0].getBoundingClientRect().height;
if(f===0||this.isFontLoad===false){this.wait(this.waitImageLoading,2000);
return
}if(this.scaletext){this.$scalableText.removeAttr("style");
this.scaleText()
}};
b.prototype.documentReadyCallback=function(){this.waitImageLoading()
};
b.prototype.initEvents=function(){$(document).ready(function(){this.documentReadyCallback()
}.bind(this));
$(window).on("resize",a.debounceExtend(this.waitImageLoading.bind(this),300))
};
b.moduleName="Scalable Image";
b.selector=".scalable-image-ui";
return b
});
define("RelatedContent",["media","utils","constants"],function(e,a,d){var f=$(window),c=$.extend({},d.CarouselDefaultConfig,{margin:0,loop:true,dots:false,responsive:{}});
function b(g){this.$el=g;
this.config=$.extend({},c,{onTranslated:this.toggleArrowColor.bind(this)});
this.$grid=this.$el.find("."+this.classes.grid);
this.toggleSlider();
f.on("resize",this.toggleSlider.bind(this))
}b.prototype.toggleArrowColor=function(){var g=!!this.$grid.find(this.classes.activeItem).find("."+this.classes.whiteBlock).length;
this.$el.toggleClass(this.classes.invertedArrows,g)
};
b.prototype.makeSliderAccessible=function(m){var l=this.$el.find(".owl-item a"),i=this.$el.find(".owl-item.active a");
l.attr("tabindex","-1");
i.attr("tabindex","");
if(m){var j=1,k=m.relatedTarget.clones().length/2,h=this.$el.find(".owl-item.active");
if(h.hasClass("cloned")){var g=h.index()>k?h.index()-k*2:h.index();
j=g>=k?g-k+1:g+k+1
}else{j=m.item.index+1-k
}}this.$el.find(".owl-counter span").text(j)
};
b.prototype.toggleSlider=function(){if(e.currentMode().lessThan(e.modes.Tablet)){this.$grid.owlCarousel(this.config);
this.carouselData=this.$grid.data("owl.carousel");
this.makeSliderAccessible();
this.$grid.on("translated.owl.carousel",function(g){this.makeSliderAccessible(g)
}.bind(this));
return
}if(!this.carouselData){return
}this.carouselData.destroy();
this.$el.removeClass(this.classes.invertedArrows);
this.carouselData=null
};
b.prototype.classes={grid:"related-content__grid",activeItem:".owl-item.active",whiteBlock:"related-content__block-text--white",invertedArrows:"related-content--inverted-arrows"};
b.moduleName="Related Content";
b.selector=".related-content-ui";
return b
});
define("RecruitingSearch",["constants","geolocation","utils-env","utils"],function(l,f,e,g){var a=$(window),j={formOnly:"searchForm",formWithResults:"searchFormAndResults"};
var i="";
var d=new Intl.Collator();
var b={form:".recruiting-search__form",autocomplete:".js-autocomplete",fakeAutoComplete:".recruiting-search__fake-input",select:".recruiting-search__select",selectOption:"select2-results__option",selectOptions:"select2-results__options",selectOptionGroup:'select2-results__option[role="list"]',selectGroup:"select2-results__group",selectRendered:"select2-selection__rendered",selectBoxContainer:".select2-container",formComponentField:"form-component__field",location:".recruiting-search__location",searchFilter:".recruiting-search__filter",checkbox:".recruiting-search__checkbox",resultList:".search-result__list",resultContainer:".search-result",resultHeader:".search-result__heading",sortingMenu:".search-result__sorting-menu",sortingItem:".search-result__sorting-item",sortingRadio:".search-result__sorting-radio",hiddenDividerItem:"search-result__sorting-item--no-divider",itemName:".search-result__item-name",viewMore:".search-result__view-more",errorMessage:".search-result__error-message"};
function c(r,p){if($.trim(r.term)===""){return p
}if(typeof p.children==="undefined"){return null
}var m=i=r.term.toUpperCase();
var q="(^|.*\\s)("+m+")";
if(p.text.trim().toUpperCase().match(q)!==null){return p
}var n=[];
$.each(p.children,function(s,t){if(s>0){if(t.text.trim().toUpperCase().match(q)!==null){n.push(t)
}}});
if(n.length){var o=$.extend({},p,{text:"",hasChild:true},true);
o.children=n;
return o
}return null
}function k(n){function r(t,s){return d.compare(t.text,s.text)
}function p(t,s){$.each(t.children,function(u,v){s.push(v)
})
}function o(t,s){if(t.children.length!==0){$.each(t.children,function(u,v){if(u>0&&v.text.trim().toUpperCase().indexOf(i)===0&&v.text.trim().toUpperCase().indexOf(t.text.trim().toUpperCase())!==0){s.push(v)
}})
}}function m(){var s=this.$el.find(".dropdown-cities");
var t=s.find(".select2-results__options--nested");
if(s.length!==0&&t.length!==0){s.removeClass("dropdown-cities");
t.removeClass("open")
}}if(this.$el.find(".select2-search__field").val().trim().length!==0){var q=[];
$.each(n,function(s,t){if(t.hasChild){p(t,q)
}else{o(t,q);
q.push(t)
}});
if(q.length>1){setTimeout(m.bind(this),0)
}return q.sort(r)
}return n
}function h(m){this.$el=m;
this.$form=m.find(b.form);
this.$autocomplete=this.$form.find(b.autocomplete);
this.$fakeAutoComplete=$(".job-search-ui").find(b.fakeAutoComplete);
this.$select=this.$form.find(b.select);
this.$location=this.$form.find(b.location);
this.$results=this.$el.find(b.resultList);
this.isAuthor=e.isAuthor();
this.viewType=this.$el.data("view");
this.resultsUrl=this.$el.data("resultsUrl");
this.recruitingUrl=this.$el.data("recruitingUrl");
this.defaultSearchParameters={locale:CQ.I18n.getLocale(),limit:20,recruitingUrl:this.recruitingUrl};
this.init&&this.init();
this.initAutocomplete();
this.initSelect();
this.$el.data("useGeolocation")&&f.onGeolocationUpdate(this.fillWithGeolocation.bind(this));
this.$form.on("submit",this.submit.bind(this));
if(!this.isFormOnly()){this.initSearchResult()
}}h.prototype.init=null;
h.prototype.initAutocomplete=function(){this.$fakeAutoComplete.autocomplete($.extend({},this.getAutocompleteConfig(),{appendTo:this.$fakeAutoComplete.parent(),onSelect:function(m){this.submit(m,"fake")
}.bind(this)})).on("keyup",this.onEnter.bind(this));
this.$autocomplete.autocomplete($.extend({},this.getAutocompleteConfig(),{onSelect:function(m){this.submit(m,"real")
}.bind(this)})).on("keyup",this.onEnter.bind(this))
};
h.prototype.onEnter=function(m){m.key===l.Keys.enter&&this.submit()
};
h.prototype.getAutocompleteConfig=function(){return{serviceUrl:this.config.autocompletePath,triggerSelectOnValidInput:false,deferRequestBy:500,appendTo:this.$autocomplete.parent(),params:{locale:this.defaultSearchParameters.locale},transformResult:function(m){return{suggestions:JSON.parse(m)}
},onSelect:this.submit.bind(this),width:"100%",zIndex:10}
};
h.prototype.submit=function(n,m){n&&n.preventDefault&&n.preventDefault();
this.$form.trigger(l.Events.autocompleteSelected,[{initialInput:m}]);
if(!this.isFormOnly()){this.updateUrlAndLoadResults();
return
}window.location=this.toUrl(this.resultsUrl,this.getSubmitContext(),this.isAuthor)
};
h.prototype.getSubmitContext=null;
h.prototype.initSelect=function(){this.$select.selectWoo(this.getSelectConfig());
this.$selectBoxContainer=this.$el.find(b.selectBoxContainer);
this.$selectBoxContainer.addClass(b.formComponentField);
this.$location.on("click",this.openSelection.bind(this)).on("click","."+b.selectOption,this.toggleSelectItem.bind(this)).on("click","."+b.selectOptionGroup,this.toggleCities.bind(this))
};
h.prototype.openSelection=function(q,o){var p,n;
if(o){p=o.parents("."+b.selectOptionGroup)
}else{n=this.$location.find('[aria-selected="true"]')
}if(n&&n.length){p=n.parents("."+b.selectOptionGroup);
n.parents("."+b.selectOptions).addClass("open")
}if(p&&p.hasClass("dropdown-cities")){var r=p.offset().top-p.offsetParent().offset().top;
var m=this.$location.find("."+b.selectOptions+":first");
m.animate({scrollTop:m.scrollTop()+r+"px"},300)
}};
h.prototype.toggleSelectItem=function(p){var m=$(p.target),n=m.hasClass(b.selectGroup),o=n?m.siblings("."+b.selectOptions):m.children("."+b.selectOptions);
if(!o.length){return
}o.toggleClass("open")
};
h.prototype.toggleCities=function(n){var m=$(n.target);
if(m.hasClass(b.selectRendered)){return
}if(m.hasClass(b.selectGroup)){m.parent().toggleClass("dropdown-cities")
}else{m.toggleClass("dropdown-cities")
}this.openSelection(null,m);
return false
};
h.prototype.getSelectConfig=function(){return{dropdownParent:this.$location,placeholderOption:"first",matcher:c,width:"off",sorter:k.bind(this)}
};
h.prototype.fillWithGeolocation=function(m){var o={name:m.country},n={name:m.city};
if(!o.name){return
}o.$item=this.$select.find('[data-geolocation-name="'+o.name+'"]');
o.value=o.$item.length&&"all_"+o.$item.data("name");
if(n.name){n.$item=o.$item.find('[data-geolocation-name="'+n.name+'"]');
n.value=n.$item.val()
}if(o.value||n.value){this.$select.val(n.value||o.value).trigger("change")
}};
h.prototype.isFormOnly=function(){return this.viewType===j.formOnly
};
h.prototype.initSearchResult=function(){this.$resultContainer=this.$el.find(b.resultContainer);
this.$resultHeader=this.$resultContainer.find(b.resultHeader);
this.$sortingMenu=this.$resultContainer.find(b.sortingMenu);
this.$sortingItem=this.$resultContainer.find(b.sortingItem);
this.$sortingRadio=this.$resultContainer.find(b.sortingRadio);
this.$preloader=this.$resultContainer.find("."+l.Classes.preloader).toggle(false);
this.$viewMore=this.$resultContainer.find(b.viewMore).toggle(false);
this.$errorMessage=this.$resultContainer.find(b.errorMessage).toggle(false);
this.$sortingRadio.on("change",this.updateUrlAndLoadResults.bind(this));
this.$select.on("change",this.updateUrlAndLoadResults.bind(this));
this.$viewMore.on("click",this.loadMoreResults.bind(this));
a.on("scroll",this.loadResultsOnScroll.bind(this));
this.beforeLoadResults&&this.beforeLoadResults();
this.loadResults(this.collectSearchParameters(0,true))
};
h.prototype.beforeLoadResults=null;
h.prototype.loadMoreResults=function(m){var o=this.$results.children().length,n=this.collectSearchParameters(o);
this.loadResults(n);
m&&m.preventDefault()
};
h.prototype.loadResultsOnScroll=function(){if(this.loading||!this.loadOnScroll||this.$viewMore.is(":visible")){return
}var o=a.height(),n=a.scrollTop(),m=this.$results.children().last().offset().top;
if(o+n>m){this.loadMoreResults()
}};
h.prototype.collectSearchParameters=function(n,o){var m={query:this.$autocomplete.val(),country:this.getCountry(),city:this.getCity(),sort:this.getSorting(),offset:n||0,buildSchemaOrgMarkup:o};
return $.extend({},this.defaultSearchParameters,m)
};
h.prototype.getCountry=function(){return this.$select.find(":selected").parent().data("name")
};
h.prototype.getCity=function(){if(!this.$select.find(":selected").is(":first-child")){return this.$select.val()
}};
h.prototype.getSorting=function(){return this.$sortingMenu?this.$sortingMenu.find(":checked").val():null
};
h.prototype.updateUrlAndLoadResults=function(m){m&&m.stopPropagation();
var o=this.collectSearchParameters(),n=this.updateUrl(o);
this.loadResults(o,n)
};
h.prototype.updateUrl=function(o){var r=$.extend({},o,{locale:null,limit:null,offset:null}),n=window.location.href,q=this.toUrl(window.location.pathname,r),m=n.length-q.length;
if(m<0||n.indexOf(q,m)!==m){window.history.pushState({},"",q);
if(window.initWechat){var p=window.location.href.split("#")[0];
initWechat(p)
}return true
}return false
};
h.prototype.toUrl=function(o,n,q){var m=o+(q?".html":""),p={};
Object.keys(n).forEach(function(s){var t=n[s],r=t&&(!$.isArray(t)||t.length);
if(r){p[s]=t
}});
return Object.keys(p).length?m+"?"+$.param(p):m
};
h.prototype.loadResults=function(m,n){$.ajax({url:this.config.searchUrl,data:m,cache:false,beforeSend:this.toggleLoadingState.bind(this,true),complete:this.toggleLoadingState.bind(this,false),success:this.updateSearchResults.bind(this,m),error:this.showErrorMessage.bind(this,n)})
};
h.prototype.updateSearchResults=function(w,o){var x=o.result,v=o.schemaOrgMarkup,t=o.total,m=this.getResultsContext(x),p=w.limit,q=w.offset,u=!x.length,s=q===0,n=t>q+p,r=!!w.buildSchemaOrgMarkup;
this.loadOnScroll=s&&n;
if(u||s){this.$results.empty()
}require("utils-dust").append("recruiting-search-result",m,this.$results);
this.showResultMessage(w.query,t);
this.$sortingMenu.toggleClass(l.Classes.hidden,u);
this.$resultHeader.toggle(!u);
this.$errorMessage.toggle(u);
this.$viewMore.toggle(!s&&n);
!s&&this.$results.find(b.itemName).eq(q).focus();
g.checkDividers(this.$sortingItem,b.hiddenDividerItem);
r&&!!v&&this.addSchemaOrgMarkup(v)
};
h.prototype.addSchemaOrgMarkup=function(m){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(m)+"<\/script>")
};
h.prototype.getResultsContext=null;
h.prototype.showErrorMessage=function(n){var m=CQ.I18n.getMessage("component.general.ajax-error-message")+" "+CQ.I18n.getMessage("component.general.ajax-error-try-again");
this.$errorMessage.text(m).show();
this.$sortingMenu.addClass(l.Classes.hidden);
if(n){this.$results.empty();
this.$resultHeader.hide();
this.$viewMore.hide()
}else{if(this.$results.children().length>=this.defaultSearchParameters.limit){this.$viewMore.show()
}}};
h.prototype.toggleLoadingState=function(m){this.$preloader.toggle(m);
this.loading=m
};
h.prototype.showResultMessage=function(o,n){if(!n){this.$errorMessage.text(CQ.I18n.getMessage("component.general.search-empty-result-for-combination"));
return
}var m=o?this.getResultMessageWithQuery(o,n):this.getResultMessage(n);
this.$resultHeader.text(m)
};
h.prototype.getResultMessageWithQuery=null;
h.prototype.getResultMessage=null;
h.prototype.classes=b;
return h
});
define("PersonInfo",["utils","media","imager"],function(b,d,a){var e=$(window);
function c(f){this.desktopImageLoaded=false;
this.mobileImageLoaded=false;
this.$el=f;
this.$mobilePlaceholder=this.$el.find("."+this.classes.mobilePlaceholder);
this.$desktopPlaceholder=this.$el.find("."+this.classes.desktopPlaceholder);
this.render();
e.on("resize",b.debounce(this.render.bind(this),100))
}c.prototype.isDesktop=function(){return d.currentMode().greaterThan(d.modes.Tablet)
};
c.prototype.render=function(){if(this.isDesktop()){if(!this.desktopImageLoaded){a.create(this.$desktopPlaceholder);
this.desktopImageLoaded=true
}}else{if(!this.mobileImageLoaded){a.create(this.$mobilePlaceholder);
this.mobileImageLoaded=true
}}};
c.prototype.classes={desktopPlaceholder:"person-info__desktop-placeholder",mobilePlaceholder:"person-info__mobile-placeholder"};
c.moduleName="Person Info";
c.selector=".person-info-ui";
return c
});
define("NewsFilter",["require","media","constants","NewsFilterA11YLayer","utils-share","utils-env","utils-dust","jquery-plugins"],function(c,g,d,a){var h=$(window),f=$("body");
var e=c("utils-share");
function b(i){this.$el=i;
this.$newsList=this.$el.find("."+this.classes.newsList);
this.$preloader=this.$el.find("."+d.Classes.preloader);
this.$viewMore=this.$el.find("."+this.classes.viewMore);
this.$errorMessage=this.$el.find("."+this.classes.errorMessage);
this.$badRequestMessage=this.$el.find("."+this.classes.badRequestMessage);
this.$emptyResultMessage=this.$el.find("."+this.classes.emptyResultMessage);
this.defaultParameters={paths:this.$el.data("paths"),dateFormat:this.$el.data("dateFormat"),limit:this.constants.LIMIT,offset:0,locale:CQ.I18n.getLocale()};
this.defaulContext=this.createDefaultContext();
this.isTouch=Modernizr.touchevents;
this.initFilters();
this.$newsFilterA11YLayer=new a(i,this,e);
this.$newsList.on(this.isTouch?"click":"mouseover","."+this.classes.share,this.toggleShare.bind(this));
this.$newsList.on("click","."+this.classes.socialLink,this.openPopup.bind(this));
this.$viewMore.on("click",this.loadMoreNewsPages.bind(this));
this.collectParametersAndLoad(true);
this.$el.pinFilterTop()
}b.prototype.createDefaultContext=function(){var i=this.$el.data("socialIcons")||"";
return{socialIcons:i.split(","),spritePath:EPAM.spritePath,origin:window.location.origin,isAuthor:c("utils-env").isAuthor()}
};
b.prototype.initFilters=function(){var j=this.$el.find("."+this.classes.newsFilter),i=this.$el.data("hasNewsFilter");
this.$year=j.filter("."+this.classes.year);
this.initSelect(this.$year);
this.collectParameters=this.collectYearParameters;
if(i){this.$newsType=j.filter("."+this.classes.newsType);
this.initSelect(this.$newsType);
this.collectParameters=this.collectNewsTypeParameters
}j.on("change",function(){this.collectParametersAndLoad();
this.scrollResultsToTop()
}.bind(this))
};
b.prototype.initSelect=function(i){i.selectWoo({width:"off",dropdownParent:i.parent("."+this.classes.input)});
this.$selectBoxContainer=this.$el.find(this.classes.selectBoxContainer);
this.$selectBoxContainer.addClass(this.classes.formComponentField)
};
b.prototype.collectNewsTypeParameters=function(){return $.extend(this.collectYearParameters(),{newsType:this.getFilterValue(this.$newsType)})
};
b.prototype.collectYearParameters=function(){return $.extend({},this.defaultParameters,{year:this.getFilterValue(this.$year)})
};
b.prototype.getFilterValue=function(i){var j=i.val();
if(j){return j
}};
b.prototype.toggleShare=function(m){var l=$(m.currentTarget),j=g.currentMode().greaterThan(g.modes.WideMobile),i=$(m.target),k=this.classes.shareOpened;
function n(){l.removeClass(k)
}if(!j&&!i.parents().hasClass(this.classes.shareMobile)){return
}else{l.addClass(k);
if(this.isTouch){m.stopPropagation();
h.one("click",n)
}else{l.one("mouseout",n)
}}};
b.prototype.openPopup=function(j){var i=this.getLinkData(j.currentTarget);
e.openPopup(i);
return false
};
b.prototype.getLinkData=function(i){return e.getLink($(i).data())
};
b.prototype.loadMoreNewsPages=function(){var j=this.$newsList.children().length,i=$.extend(this.collectParameters(),{offset:j});
this.loadNewsPages(i)
};
b.prototype.collectParametersAndLoad=function(i){this.loadNewsPages($.extend(this.collectParameters(),{buildSchemaOrgMarkup:i}))
};
b.prototype.loadNewsPages=function(i){$.ajax({url:this.constants.URL,data:i,beforeSend:this.toggleLoadingState.bind(this,true),success:this.updateNewsPages.bind(this,i),error:this.showErrorMessage.bind(this),complete:this.toggleLoadingState.bind(this,false),cache:false})
};
b.prototype.toggleLoadingState=function(i){this.$preloader.toggleClass(d.Classes.hidden,!i);
i&&this.$errorMessage.addClass(d.Classes.hidden)
};
b.prototype.updateNewsPages=function(p,l){var q=l.result,o=l.schemaOrgMarkup,k=p.offset,n=!q.length,j=l.total>k+p.limit,m=!!p.buildSchemaOrgMarkup;
var i=this.$newsList.find(this.classes.lastNews);
(n||!k)&&this.$newsList.empty();
this.$emptyResultMessage.toggleClass(d.Classes.hidden,!n);
this.$viewMore.toggleClass(d.Classes.hidden,!j);
this.renderNewsPages(q);
this.$newsFilterA11YLayer.focusFirstItemAfterLoadNewItems(i);
m&&!!o&&this.addSchemaOrgMarkup(o)
};
b.prototype.renderNewsPages=function(i){var j=$.extend({pages:i},this.defaulContext);
c("utils-dust").append(this.constants.TEMPLATE,j,this.$newsList)
};
b.prototype.addSchemaOrgMarkup=function(i){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(i)+"<\/script>")
};
b.prototype.showErrorMessage=function(){this.$badRequestMessage.removeClass(d.Classes.hidden)
};
b.prototype.scrollResultsToTop=function(){if(f.hasClass(d.Classes.pinnedFilter)){this.$el.scrollToSelector({duration:500})
}};
b.prototype.constants={URL:"/services/search/news-pages",TEMPLATE:"news-list",LIMIT:12};
b.prototype.classes={selectBoxContainer:".select2-container",formComponentField:"form-component__field",input:"news-filter__input",newsFilter:"news-filter__select",newsType:"news-filter__select--newstype",year:"news-filter__select--year",share:"news-filter__item",shareMobile:"news-filter__share",shareOpened:"news-filter__share--opened",shareButton:"news-filter__share-button",socialLink:"news-filter__social-link",newsList:"news-filter__results",viewMore:"news-filter__view-more",errorMessage:"news-filter__error-message",badRequestMessage:"news-filter--bad-request",emptyResultMessage:"news-filter--empty-result",lastNews:">li:last-child",newsItemIcon:"news-filter__icon-item"};
b.moduleName="News Filter";
b.selector=".news-filter-ui";
return b
});
define("NewsFilterA11YLayer",[],function(){var a=$("html");
var c={shareButton:".news-filter__share-button",newsFilterItem:".news-filter__item",newsFilterShareOpened:"news-filter__share--opened",newsFilterIconsListFirstChild:".news-filter__icons-list > li:first-child",newFilterTitle:".news-filter__title",newsFilterTitleLink:".news-filter__title a"};
function b(f,e,d){this._el=f;
this._self=e;
this._shareLib=d;
this.init()
}b.prototype.init=function(){this.initEvents()
};
b.prototype.onShareButtonClickHandler=function(e){var d=$(e.target).parents(c.newsFilterItem);
if(d.length){d.addClass(c.newsFilterShareOpened);
d.find(c.newsFilterIconsListFirstChild).focus()
}};
b.prototype.onFocusinHandler=function(){if(a.hasClass("key-used")){var d=this._el.find("."+c.newsFilterShareOpened);
if(d.length){d.removeClass(c.newsFilterShareOpened)
}}};
b.prototype.focusFirstItemAfterLoadNewItems=function(d){if(d.length){d.next().find(c.newsFilterTitleLink).focus()
}};
b.prototype.onKeydownHandler=function(e){if(e.key==="Enter"){var d=this._shareLib.getLink($(e.currentTarget).children("a").data());
this._shareLib.openPopup(d);
return false
}};
b.prototype.onClickHandler=function(e){var f=e.target.firstChild;
var d=this._self.getLinkData(f);
this._shareLib.openPopup(d);
return false
};
b.prototype.initEvents=function(){this._el.on("click",c.shareButton,this.onShareButtonClickHandler.bind(this));
this._el.on("focusin",c.newFilterTitle,this.onFocusinHandler.bind(this));
this._self.$newsList.on("keydown","."+this._self.classes.newsItemIcon,this.onKeydownHandler.bind(this));
this._self.$newsList.on("click","."+this._self.classes.newsItemIcon,this.onClickHandler.bind(this))
};
return b
});
define("MultiStyleSection",["media"],function(b){var c={MAC:"mac",IMAGE_IN_TOP_RIGHT:"image-in-top-right",COLUMN_CONTROL:"colctrl-ui"};
function a(e){this.$el=e;
if(window.navigator.userAgent.indexOf("Macintosh")!==-1){this.$el.addClass(c.MAC)
}var d=!!this.$el.find("."+c.IMAGE_IN_TOP_RIGHT).length;
if(d&&b.currentMode().is(b.modes.Tablet)){this.moveRightColumnUp()
}}a.prototype.moveRightColumnUp=function(){var d=this.$el.find("."+c.COLUMN_CONTROL).children()[1];
if(d){d=$(d);
var g=d.find("p").first();
var e=g.outerHeight();
var f=parseInt(g.css("margin-bottom"),10);
d.css("transform","translateY(-"+(e+f)+"px)")
}};
a.moduleName="Multistyle Section";
a.selector=".multi-style-section";
return a
});
define("MixedVacancyBlock",["constants","utm-utils"],function(d,e){var a=$("html");
var c={placeOfWork:".mixed-vacancy-block__place-of-work",buttonWrapper:".mixed-vacancy-block__button-wrapper",buttonDisabled:"mixed-vacancy-block__button-wrapper--disabled"};
var f={office:"office",home:"home"};
function b(g){this.$el=g;
this.$placeOfWork=this.$el.find(c.placeOfWork);
this.$buttonWrapper=this.$el.find(c.buttonWrapper);
this.$vacancyButton=this.$buttonWrapper.find("button");
this.$vacancyLink=this.$buttonWrapper.find("a");
this.$vacancyButton.on("click",this.handleButtonClick.bind(this));
this.$vacancyLink.on("click",this.handleLinkClick.bind(this));
this.$placeOfWork.on("change","input",this.handleRadioButtonChange.bind(this))
}b.prototype.handleRadioButtonChange=function(g){var h=$(g.target).val();
this.$buttonWrapper.removeClass(c.buttonDisabled);
if(h===f.office){this.$vacancyLink.addClass(d.Classes.hidden);
this.$vacancyButton.removeClass(d.Classes.hidden)
}else{if(h===f.home){this.$vacancyLink.removeClass(d.Classes.hidden);
this.$vacancyButton.addClass(d.Classes.hidden)
}}};
b.prototype.handleButtonClick=function(){a.trigger(d.Events.showVacancyForm);
this.$el.addClass(d.Classes.hidden)
};
b.prototype.handleLinkClick=function(){var g=e.buildAnywhereUrl(this.$vacancyLink.data("href"));
this.$vacancyLink.attr("href",g)
};
b.moduleName="Mixed Vacancy Block";
b.selector=".mixed-vacancy-block-ui";
return b
});
define("LocationsViewer",["media","utils","SocialIcons","jquery-plugins"],function(b,h,d){var a=$(window),f=60,c=194,g=100;
var e={carousel:".locations-viewer__carousel",country:"locations-viewer__country",countryButton:".locations-viewer__country-btn",countryList:".locations-viewer__country-list",active:"active",owlLoaded:"owl-loaded",carouselButtons:".owl-nav button"};
function i(k){this.$el=k;
this.$carousel=this.$el.find(e.carousel);
this.$countryList=this.$el.find(e.countryList);
this.countryCount=this.$countryList.children().length;
this.$countryButton=this.$el.find(e.countryButton);
this.windowWidth=a.width();
var l={};
l[b.modes.WideMobile.start]={items:this.countryCount>2?2:this.countryCount};
l[b.modes.Desktop.start]={items:this.countryCount>3?3:this.countryCount};
l[b.modes.Broad.start]={items:this.countryCount>4?4:this.countryCount};
var j=$.extend({},this.config,{dots:false,lazyLoadEager:0,responsive:l,onInitialized:this.carouselInitialized.bind(this),navElement:'button type="button"',navText:["Previous card","Next card"]});
this.$el.attr("data-item-count",this.countryCount);
this.$parentTabItem=this.$carousel.parents(".js-tabs-item");
if(!this.$parentTabItem.length){this.$carousel.owlCarousel(j)
}a.on("tab.loaded tab.changed tab.change",function(){this.$parentTabItem.removeAttr("tabindex");
if(this.$carousel.parents(".js-tabs-item.active").length&&!this.$carousel.hasClass(e.owlLoaded)){this.$carousel.owlCarousel(j);
this.$carouselButtons=this.$carousel.find(e.carouselButtons);
this.addEventListenersToCarouselButtons()
}}.bind(this));
this.$actualElements=this.$carousel.find(".owl-item:not(.cloned)");
this.$countries=this.$carousel.find("."+e.country);
this.$carousel.on("click","."+e.country,this.toggleExpand.bind(this)).on("refreshed.owl.carousel",this.updateSelectors.bind(this)).on("translated.owl.carousel",this.onTranslated.bind(this));
a.on("resize orientationchange",function(){if(a.width()!==this.windowWidth){h.debounce(this.recalculateHeight(),g);
this.reInitCarousel(j).done(this.focusOnActive.bind(this))
}}.bind(this));
this.socialIcons=new d(this.$el);
h.addExtensionToPhoneNumber(this.$el);
this.isUrlContainsHash(j);
this.addEventListenersToCountryButtons(this.countryCount)
}i.prototype.isUrlContainsHash=function(l){var k=window.location.href;
var m=new RegExp("(/?#.{1,})","i");
var j=m.test(k);
if(j){this.reInitCarousel(l).done(this.focusOnActive.bind(this))
}};
i.prototype.carouselInitialized=function(){this.$carouselButtons=this.$carousel.find(e.carouselButtons)
};
i.prototype.reInitCarousel=function(j){var k=$.Deferred();
setTimeout(function(){this.$carousel.owlCarousel("destroy");
this.$carousel.owlCarousel(j);
k.resolve()
}.bind(this),g);
return k.promise()
};
i.prototype.recalculateHeight=function(){if(!this.$countryList.hasClass(e.active)){return
}setTimeout(function(){this.$countryList.height(this.$opened.outerHeight()+100)
}.bind(this),0)
};
i.prototype.scrollToList=function(k){var j=window.innerWidth>window.innerHeight&&b.currentMode().lessThan(b.modes.Tablet);
if(j&&k.hasClass(e.active)){return
}var l=j?-c:f;
this.$carousel.scrollToSelector({reservedSpace:l,duration:400})
};
i.prototype.updateSelectors=function(){this.$countries=this.$carousel.find("."+e.country)
};
i.prototype.clearState=function(){this.$countries.removeClass(e.active);
this.$countryList.children().removeClass(e.active).attr("aria-hidden",true);
if(this.$carouselButtons){this.$carouselButtons.removeAttr("tabindex")
}};
i.prototype.updateHeight=function(){var j=this.$opened.outerHeight();
this.$countryList.toggleClass(e.active,!!j).height(j?j+100:0)
};
i.prototype.onTranslated=function(){if(!this.currentActiveCountry){return
}this.$countries.filter('[data-country="'+this.currentActiveCountry+'"]').removeClass("active");
this.$el.find(".owl-item.active").find('[data-country="'+this.currentActiveCountry+'"]').addClass("active")
};
i.prototype.toggleExpand=function(l){var j=$(l.currentTarget),m=j.data("country");
this.$opened=this.$countryList.find('[data-country="'+m+'"]');
var k=this.$opened.hasClass(e.active);
this.currentActiveCountry=k?null:m;
this.toggleBlock(k,m,j);
this.updateHeight();
this.scrollToList(j)
};
i.prototype.toggleBlock=function(n,p,o){this.clearState();
var j=this.$countries.filter('[data-country="'+p+'"]'),l=this.$carousel.find(".owl-item.active").find(e.countryButton),m=o.find("button"),k=this.$carousel.find(e.countryButton);
j.toggleClass(e.active,!n);
this.$opened.toggleClass(e.active,!n);
if(!n){this.$opened.removeAttr("aria-hidden");
if(this.$carouselButtons){this.$carouselButtons.attr("tabindex","-1")
}k.attr("tabindex","-1");
k.attr("aria-expanded",true);
m.attr("tabindex","0")
}else{this.$opened.attr("aria-hidden",true);
k.attr("aria-expanded",false);
l.attr("tabindex","0")
}};
i.prototype.focusOnActive=function(){if(!this.currentActiveCountry){return
}this.$actualElements=this.$carousel.find(".owl-item:not(.cloned)");
var j=this.$actualElements.has("."+e.country+'[data-country="'+this.currentActiveCountry+'"]');
this.$carousel.trigger("to.owl.carousel",this.$actualElements.index(j))
};
i.prototype.config={loop:true,callbacks:true,items:1,autoWidth:true,responsive:{},lazyLoad:true,nav:true};
i.prototype.addEventListenersToCountryButtons=function(j){this.$countryButton.each(function(n){var q=$(this);
var o=q.attr("data-country-title");
var p=q.attr("data-cities-count");
var k=p>1?" locations":" location";
var m="Card "+(n+1)+" of "+j+" "+o;
q.attr("aria-label",m);
function l(){return q.attr("aria-expanded")!=="false"
}q.on("unfocus",function(){!l()&&q.attr("aria-label",m)
});
q.on("click",function(){l()?q.attr("aria-label",m):q.attr("aria-label",o+" button "+p+k)
})
})
};
i.prototype.addEventListenersToCarouselButtons=function(){var j=this;
this.$carouselButtons.on("focus",function(){var l=this.closest(".section__wrapper");
var k=l.getBoundingClientRect().top;
if(k<0){var m=$(l).offset().top;
$("html, body").animate({scrollTop:m},0)
}});
this.$carouselButtons.on("click",function(){j.refreshActiveCardsCounts();
var k=j.createCarouselButtonAriaLabelText();
$(this).attr("aria-label",k)
});
this.$carouselButtons.on("blur",function(){$(this).removeAttr("aria-label")
})
};
i.prototype.refreshActiveCardsCounts=function(){var j=this.$carousel.find(".owl-item.active .locations-viewer__country");
this.activeCardsCounts=j.map(function(){return $(this).attr("data-count")
})
};
i.prototype.createCarouselButtonAriaLabelText=function(){var n=this.activeCardsCounts.length;
for(var m=0;
m<this.activeCardsCounts.length-1;
m++){if(this.activeCardsCounts[m]>this.activeCardsCounts[m+1]){n=m+1
}}var o=[];
var l=this.activeCardsCounts.slice(0,n);
var k=this.activeCardsCounts.slice(n);
var p=this.createRange(l);
var j=this.createRange(k);
p&&o.push(p);
j&&o.push(j);
return"Cards "+o.join(", ")+" out of "+this.countryCount+" are shown"
};
i.prototype.createRange=function(j){if(j.length===0){return""
}if(j.length===1){return j[0]
}return j[0]+" - "+j[j.length-1]
};
i.moduleName="Locations Viewer";
i.selector=".locations-viewer-ui";
return i
});
define("LcaListing",["utils-dust"],function(a){function b(p){var f="/services/search/lca-listing",n="lca-listing-table-items",g=0,j=5;
var m=p,i=m.find(".ajax-error-message"),l=m.data("lca-path"),c=m.find(".gray-table"),e=m.find(".lca-listing-table"),o=m.find(".lca-listing-empty-message"),d=m.find(".lca-listing-disclaimer"),h=m.find(".preloader");
if(!l){return
}$.ajax({url:f,data:{lcaPath:l},cache:false,beforeSend:function(){i.hide();
o.hide();
h.addClass("preloader-blue")
},success:k,error:function(){console.error("During the search, a server error occurred.");
i.show()
},complete:function(){h.remove()
}});
function k(q){if(q.length===0){o.show();
c.hide();
d.hide();
return
}a.append(n,{items:q},e);
e.tablesorter({sortRestart:true,sortList:[[j,g]],headers:{7:{sorter:false}}})
}}b.moduleName="LCA Listing";
b.selector=".lca-listing-ui";
return b
});
define("JobSearch",["RecruitingSearch","analytics","utils-share","constants","media","jquery-plugins"],function(l,g,j,k,b){var a=$(window);
var d=$("body");
var c=$.extend({},l.prototype.classes,{multiselect:".js-multi-select",searchSelect:".recruiting-search__select",searchCheckbox:".recruiting-search__checkbox",initializedMultiSelect:".multi-select-filter",departments:"job-search__departments",resultItem:".search-result__item",shareButton:"button.search-result__share-button",referLink:"a.search-result__share-button",shareOpened:"search-result__share--opened",socialLink:".search-result__social-link",submitButton:".recruiting-search__submit",header:".header-ui",preserveHeader:"job-search-preserve-header",keywordLabel:".recruiting-search__keyword-label",wrapperMobile:".recruiting-search__wrapper-mobile",filterButton:".recruiting-search__filter-button",filterButtonClose:"recruiting-search__filter-button-close",fakePinnedInput:"recruiting-search__fake-input",searchInput:"recruiting-search__input:not(.recruiting-search__fake-input)",jobSearchOpenButton:".recruiting-search__job-search",pinnedPanelCloseButton:".recruiting-search__close-button"});
var f={experience:'[name="experience"]',relocation:'[name="relocation"]',remote:'[name="remote"]',office:'[name="office"]'};
function h(m){return function(n){return m[n]
}
}function e(n,m){n[m]={type:m,title:CQ.I18n.getMessage("component.general.social-icon.icon-"+m)};
return n
}function i(m){l.call(this,m);
this.$departmentsSelect=$('select[name="department"]');
this.$jobSearchDepartments=m.find(".job-search__departments");
this.$isShouldUpdate=true;
var n=this.$el.data("socialIcons");
if(!n){return
}this.titles=["fb","tw","li","vk"].reduce(e,{});
this.socialIcons=this.getSocialIconsFromData(this.$el.data("socialIcons")).map(h(this.titles));
this.$fetchOptions={beforeSend:function(){this.$departmentsSelect.trigger(k.Events.multiSelectBeforeUpdate)
}.bind(this),successCallback:function(p){try{var o=JSON.parse(p);
this.handleSuccessSkillsFetch(o)
}catch(q){console.warn(q)
}}.bind(this)};
this.$jobSearchDepartments.on("dropdown:open",function(){if(this.$isShouldUpdate){this.$fetchOptions.url=this.createSkillsFetchRequest();
this.fetch(this.$fetchOptions)
}}.bind(this));
this.firstDepartmentUpdate()
}i.prototype=Object.create(l.prototype);
i.prototype.init=function(){var o=this.$el.hasClass("dark-style");
this.$isApplyOverlay=this.$el.hasClass("apply-overlay");
this.$mobileWrapper=this.$el.find(c.wrapperMobile);
this.$pinnedPanelCloseButton=this.$el.find(c.pinnedPanelCloseButton);
if(o){var m=this.$el.find(c.jobSearchOpenButton);
m.on("click",this.toggleShowForm.bind(this))
}this.$filterButton=this.$el.find(c.filterButton);
this.$fakeSearchInput=this.$el.find("."+c.fakePinnedInput);
this.$realSearchInput=this.$el.find("."+c.searchInput);
this.$filterButton.removeClass(c.filterButtonClose);
this.$filterButton.on("click",this.toggleShowForm.bind(this));
this.$pinnedPanelCloseButton.on("click",this.toggleShowForm.bind(this));
this.$form.on("submit",function(){if(this.$form.hasClass("show")){this.$form.toggleClass("show");
this.$filterButton.toggleClass(c.filterButtonClose)
}}.bind(this));
this.$el.attr("data-location",this.getCountry());
this.$isPinned=this.$el.data("is-pinned");
this.$multiSelect=this.$el.find(c.multiselect);
this.$searchFilters=this.$form.find(c.searchFilter);
this.$checkbox=this.$searchFilters.find(c.checkbox);
this.$header=d.find(c.header);
this.$searchCheckbox=this.$el.find(c.searchCheckbox);
if(this.$multiSelect.length){this.$multiSelect.multiSelectFilter({showTags:true,className:c.departments});
this.$multiSelectEl=this.$el.find(c.initializedMultiSelect)
}this.$location.on("select2:open",function(){this.$multiSelectEl.trigger("dropdown:close")
}.bind(this));
this.$location.on("select2:select",function(){this.setDataLocation();
this.$isShouldUpdate=true
}.bind(this));
this.$results.on("click",c.shareButton,this.toggleShare.bind(this));
this.$results.on("click",c.referLink,this.pushGtmEvent);
var n=this.$realSearchInput.val()||this.$fakeSearchInput.val();
this.$realSearchInput.val(n);
this.$fakeSearchInput.val(n);
this.$fakeSearchInput.on("input keydown",this.fakeSearchInputChangeHandler.bind(this));
this.$realSearchInput.on("input keydown",this.searchInputChangeHandler.bind(this));
this.$fakeSearchInput.keypress(this.fakeSearchInputKeypressHandler.bind(this));
this.$searchCheckbox.on("change",this.handlerCheckBoxSelect.bind(this));
if(this.$isPinned){this.$searchSelect=this.$el.find(c.searchSelect);
this.$submitButton=this.$el.find(c.submitButton);
this.$el.pinFilterTop(true,{value:50,getSpacerHeight:function(){if(b.currentMode().lessThan(b.modes.Desktop)){return 650
}return 250
},getPanelTopOffset:this.getPanelTopOffset.bind(this)});
this.$multiSelect.on("change",this.scrollToTop.bind(this));
this.$searchSelect.on("change",this.scrollToTop.bind(this));
this.$searchCheckbox.on("change",this.scrollToTop.bind(this));
this.$submitButton.on("click",this.scrollToTop.bind(this));
this.$header.addClass(c.preserveHeader);
$(window).trigger("scroll");
this.$form.on(k.Events.autocompleteSelected,this.autoCompleteSelectWasSelected.bind(this))
}};
i.prototype.getPanelTopOffset=function(){return this.$isApplyOverlay?this.$el.offset().top-200:this.$el.offset().top
};
i.prototype.toggleShowForm=function(){this.$form.toggleClass("show");
this.$mobileWrapper.toggleClass("expanded");
this.$filterButton.toggleClass(c.filterButtonClose)
};
i.prototype.firstDepartmentUpdate=function(){this.$departments=null;
var o=window.location.search;
var m=new URLSearchParams(o);
this.$departments=m.getAll("department");
if(this.$departments.length>0){var n={url:this.createSkillsFetchRequest(),successCallback:function(p){try{this.handleFirstSuccessSkillsFetch(JSON.parse(p))
}catch(q){console.warn(q)
}}.bind(this)};
this.fetch(n)
}};
i.prototype.handlerCheckBoxSelect=function(){this.$isShouldUpdate=true
};
i.prototype.autoCompleteSelectWasSelected=function(m,n){if(n.initialInput==="fake"){this.fakeSearchInputChangeHandler()
}else{this.searchInputChangeHandler()
}};
i.prototype.fakeSearchInputChangeHandler=function(){this.$realSearchInput.val(this.$fakeSearchInput.val());
this.$isShouldUpdate=true
};
i.prototype.searchInputChangeHandler=function(){this.$fakeSearchInput.val(this.$realSearchInput.val());
this.$isShouldUpdate=true
};
i.prototype.fakeSearchInputKeypressHandler=function(m){if(m.keyCode===13){this.$submitButton.trigger("click")
}};
i.prototype.scrollToTop=function(){if(b.currentMode().greaterThan(b.modes.Tablet)){this.scrollResultsToTop()
}};
i.prototype.getSocialIconsFromData=function(m){return m&&m.split(",")
};
i.prototype.beforeLoadResults=function(){this.$multiSelect.on("change",this.updateUrlAndLoadResults.bind(this));
this.$checkbox.on("change",this.updateUrlAndLoadResults.bind(this));
this.$results.on("click",c.socialLink,this.openPopup.bind(this))
};
i.prototype.collectSearchParameters=function(n){var m={query:this.$autocomplete.val(),country:this.getCountry(),city:this.getCity(),sort:this.getSorting(),department:this.$multiSelect.val()||[],experience:this.getExperience(),relocation:this.isRelocation(),remote:this.isRemote(),office:this.isOffice(),offset:n||0,searchType:this.$el.data("searchtype")||""};
return $.extend({},this.defaultSearchParameters,m)
};
i.prototype.getExperience=function(){return this.$checkbox.filter(f.experience+":checked").map(function(){return $(this).val()
}).get()
};
i.prototype.isRelocation=function(){return this.$checkbox.filter(f.relocation+":checked").val()
};
i.prototype.isRemote=function(){return this.$checkbox.filter(f.remote+":checked").val()
};
i.prototype.isOffice=function(){return this.$checkbox.filter(f.office+":checked").val()
};
i.prototype.getSubmitContext=function(){return{query:this.$autocomplete.val(),country:this.getCountry(),city:this.getCity(),department:this.$multiSelect.val(),relocation:this.isRelocation(),office:this.isOffice(),remote:this.isRemote()}
};
i.prototype.getResultsContext=function(m){return{list:m,spritePath:EPAM.spritePath,socialIcons:this.socialIcons,gtmLabel:this.$el.data("referGtmLabel"),showFooter:true}
};
i.prototype.getResultMessageWithQuery=function(o,n){var m='"'+o+'"';
return n===1?CQ.I18n.getMessage("component.job-search.result_header.one_result",[m]):CQ.I18n.getMessage("component.job-search.result_header",[m,n])
};
i.prototype.getResultMessage=function(m){return m===1?CQ.I18n.getMessage("component.job-search.result_header.no_query.one_result"):CQ.I18n.getMessage("component.job-search.result_header.no_query",[m])
};
i.prototype.toggleShare=function(n){var o=$(n.currentTarget),m=o.closest(c.resultItem);
function p(q){return function(){q.removeClass(c.shareOpened)
}
}m.addClass(c.shareOpened);
setTimeout(function(){m.find(c.socialLink).first().focus()
});
a.one("click",function(){a.one("click",p(m))
})
};
i.prototype.pushGtmEvent=function(m){var n=$(m.currentTarget);
var o=g.getEvent(n);
g.push(o)
};
i.prototype.openPopup=function(n){var m=j.getLink($(n.currentTarget).data());
j.openPopup(m);
return false
};
i.prototype.setDataLocation=function(){var m=this.getCountry();
this.$el.attr("data-location",m?m:"")
};
i.prototype.scrollResultsToTop=function(){if(d.hasClass(k.Classes.pinnedFilter)){this.$el.scrollToSelector({duration:500,reservedSpace:400})
}};
i.prototype.fetch=function(m){$.ajax(m.url,{beforeSend:m.beforeSend,success:m.successCallback,error:function(o,p,n){this.$departmentsSelect.trigger(k.Events.multiSelectErrorUpdate);
console.warn(n)
}})
};
i.prototype.handleSuccessSkillsFetch=function(m){this.$isShouldUpdate=false;
var n=[];
for(var o=0;
o<m.length;
o++){n.push(new Option(m[o],m[o],false,false))
}this.$departmentsSelect.empty();
this.$departmentsSelect.append(n);
this.$departmentsSelect.trigger(k.Events.multiSelectUpdate)
};
i.prototype.handleFirstSuccessSkillsFetch=function(m){this.$isShouldUpdate=false;
var o=[];
for(var p=0;
p<m.length;
p++){var n=this.$departments.includes(m[p]);
o.push(new Option(m[p],m[p],n,n))
}this.$departmentsSelect.empty();
this.$departmentsSelect.append(o);
this.$departmentsSelect.trigger(k.Events.multiSelectFirstUpdate);
this.$form.trigger("submit")
};
i.prototype.createSkillsFetchRequest=function(){var m=this.collectSearchParameters();
delete m.department;
return this.toUrl("/services/department/search",m)
};
i.prototype.config={autocompletePath:"/services/search/smart-search.vacancy.json",searchUrl:"/services/vacancy/search"};
i.moduleName="Job Search";
i.selector=".job-search-ui";
return i
});
define("InteractiveMap",["utils"],function(O){var K={};
var g={};
var e={};
var I=$(window);
var i=0;
var N=0;
var H=1.7;
var o=0.9;
var d=6;
var y=540;
var n=0;
var b=4;
var u=5;
var q=0.1;
var C=false;
var v={x:0,y:0,width:0,height:0};
var J={x:0,y:0};
var z={x:0,y:0};
function h(Q){this.$el=Q;
this.dataUrl=Q.attr("data-component-path");
this.title=Q.find("."+this.classes.title);
this.items=Q.find("."+this.classes.items);
this.popup=Q.find("."+this.classes.popup);
this.popupTitle=Q.find("."+this.classes.popupTitle);
this.popupBulletPoints=Q.find("."+this.classes.popupBulletPoints);
this.mapWrapper=Q.find("."+this.classes.worldMapWrapper);
this.popupArrow=Q.find("."+this.classes.popupArrow);
this.closePopupButton=Q.find("."+this.classes.closePopupButton);
this.buttonZoonIn=Q.find("."+this.classes.zoomIn);
this.buttonZoonOut=Q.find("."+this.classes.zoomOut);
this.mapLogo=Q.find("."+this.classes.mapLogo);
this.divider=Q.find("."+this.classes.divider);
this.getData("/etc/designs/epam-com/images/interactive-map/interactive-map.svg",this.initSvgMap.bind(this),"html",this.message.svgError)
}h.prototype.getData=function(R,T,Q,S){$.ajax({url:R,dataType:Q}).then(function(U){T(U)
},function(U){throw Error(S+U)
})
};
h.prototype.initSvgMap=function(Q){$(this.mapWrapper).html(Q);
this.map=this.$el.find("."+this.classes.worldMap);
var R=this.map.prop("viewBox").baseVal;
v.width=R.width;
v.height=R.height;
this.getData(this.dataUrl,this.init.bind(this),"json",this.message.dataLoadError)
};
h.prototype.getPopupCoords=function(){var Q=this.popup[0].getBoundingClientRect();
return{height:Q.height,width:Q.width,x:Q.left,y:Q.top}
};
h.prototype.getMapWrapperCoords=function(){var Q=this.mapWrapper[0].getBoundingClientRect();
return{x1:Q.left,y1:Q.top,x2:Q.left+Q.width,y2:Q.top+Q.height,width:Q.width,height:Q.height}
};
h.prototype.getPopupArrowCoords=function(){var Q=this.popupArrow[0].getBoundingClientRect();
return{height:Q.height,width:Q.width,x:Q.left,y:Q.top}
};
h.prototype.getRegionCenterCoords=function(R){var Q=e[R].getBoundingClientRect();
return{x:Q.left,y:Q.top,width:Q.width,height:Q.height}
};
h.prototype.adjustMapCenter=function(){G.call(this,this.map[0]);
if(Modernizr.mq(this.mediaQuery.smallTablet)){this.adjustMapHeight();
r.call(this,this.mapWrapper[0],this.map[0]);
l(this.mapWrapper[0],this.map[0])
}else{this.mapWrapper.removeAttr("style")
}};
function G(Q){if(Modernizr.mq(this.mediaQuery.oldMobile)){Q.style.transform="scale(.45)"
}else{if(Modernizr.mq(this.mediaQuery.mobile)){Q.style.transform="scale(.5)"
}else{if(Modernizr.mq(this.mediaQuery.smallTablet)){Q.style.transform="scale(.8)"
}else{if(Modernizr.mq(this.mediaQuery.tablet)){Q.style.transform="scale(1)"
}else{if(Modernizr.mq(this.mediaQuery.desktop)){Q.style.transform="scale(1)"
}}}}}}h.prototype.adjustMapHeight=function(){var Q=this.map[0].getBoundingClientRect().height;
this.mapWrapper.css("height",Q+"px")
};
function r(T,R){var U=Math.floor(E(T).left+E(T).width);
var Q=parseInt(E(this.$el.find("#AU_Center")[0]).left);
var S=parseInt(R.style.left);
if(isNaN(S)){S=0
}if(U>Q){S=Math.abs(U-Q-25)+S;
R.style.left=S+"px"
}else{if(U<Q){S=Math.abs(U-Q+S-25);
R.style.left="-"+S+"px"
}}}function l(S,R){var T=Math.floor(E(S).top+E(S).height);
var U=Math.floor(E(R).top+E(R).height);
var Q=parseInt(R.style.top);
if(isNaN(Q)){Q=0
}if(T>U){Q=Math.abs(T-U)+Q;
R.style.top=Q+"px"
}if(T<U){Q=Math.abs(T-U+Q);
R.style.top="-"+Q+"px"
}}h.prototype.initEvents=function(){this.popup.on("mouseleave",this.closePopup.bind(this));
this.closePopupButton.on("click",this.closePopup.bind(this));
this.buttonZoonIn.on("click",t.bind(this));
this.buttonZoonOut.on("click",k.bind(this));
this.map.on("mousedown",function(Q){C=true;
x.call(this,Q)
}.bind(this));
this.map.on("mousemove",function(Q){if(C){D.call(this,Q)
}}.bind(this));
this.map.on("mouseup",function(){C=false;
a()
});
this.map.on("mouseleave",function(){C=false
});
this.map.on("touchstart",x.bind(this));
this.map.on("touchend",a);
this.map.on("touchmove",D.bind(this));
I.on("resize",O.debounceExtend(w.bind(this),100));
I.on("scroll",function(){if(Modernizr.mq(this.mediaQuery.desktop)){this.closePopup()
}}.bind(this))
};
h.prototype.initPartsOfMap=function(){this.initHeaderTitle(K.title);
this.initHeaderItems(K.items,K.numberOfItems);
this.initActiveRegions(K.regions);
this.initLogo()
};
h.prototype.initHeaderTitle=function(Q){this.title.empty();
if(Q===null){return false
}this.title.html(Q)
};
h.prototype.initHeaderItems=function(S,R){if(S.length===0){return
}var T=0;
var V=[];
var W=function(ab,aa){var Z=[];
for(var Y=0;
Y<aa;
Y++){var X=document.createElement(ab);
Z.push(X)
}return Z
};
var Q=W("p",S.length);
for(var U=0;
U<S.length;
U++){$(Q[U]).html(S[U])
}this.items.addClass(this.classes.column+" "+this.classes.staticColumn);
if(Modernizr.mq(this.mediaQuery.extraSmallMobile)){this.items.removeClass(this.classes.staticColumn+" "+this.classes.twoColumn+" "+this.classes.thirdColumn).addClass(this.classes.singleColumn);
V=W("div",1)
}else{if(Modernizr.mq(this.mediaQuery.mobile)){this.items.addClass(this.classes.twoColumn).removeClass(this.classes.singleColumn+" "+this.classes.thirdColumn+" "+this.classes.staticColumn);
V=W("div",2)
}else{if(Modernizr.mq(this.mediaQuery.tablet)){this.items.removeClass(this.classes.twoColumn+" "+this.classes.singleColumn+" "+this.classes.staticColumn).addClass(this.classes.thirdColumn);
V=W("div",3)
}else{this.items.removeClass(this.classes.twoColumn+" "+this.classes.singleColumn+" "+this.classes.thirdColumn).addClass(this.classes.staticColumn);
V=W("div",R)
}}}for(U=0;
U<Q.length;
U++){V[T].appendChild(Q[U]);
if(T>=V.length-1){T=0
}else{T++
}}this.items.empty();
this.items.append(V)
};
h.prototype.initActiveRegions=function(R){if(R===null){return
}for(var Q=0;
Q<R.length;
Q++){g[Q]=R[Q]
}$.each(g,function(S,V){var U="#"+V.countries.join(", #");
var T=this.$el.find(U);
V.countriesPath=T;
$.each(T,function(X,Y){var Z=$(Y).attr("data-id");
var W=$("#"+Z+"_Center")[0];
e[Z]=W;
$(Y).attr("data-union",S);
$(Y).addClass(this.classes.activePath);
$(Y).on("mouseout",function(aa){F.call(this,aa,S)
}.bind(this));
$(Y).on("mouseover",function(aa){c.call(this,aa,S)
}.bind(this))
}.bind(this))
}.bind(this))
};
h.prototype.initLogo=function(){if(K.title===null&&K.items.length===0){this.mapLogo.addClass(this.classes.hideEl);
this.divider.addClass(this.classes.hideEl)
}};
h.prototype.showPopup=function(){this.$el.addClass(this.classes.activePopup);
this.addScroll()
};
h.prototype.addScroll=function(){var R=parseInt(this.popupBulletPoints[0].getBoundingClientRect().height);
var S=this.$el.find(".bullet-list")[0];
if(S===undefined){return
}var Q=parseInt(S.getBoundingClientRect().height);
if(Q>R&&Modernizr.mq(this.mediaQuery.smallTablet)){this.popupBulletPoints.addClass("scroll");
this.popupBulletPoints.scrollTop(0)
}};
h.prototype.removeScroll=function(){this.popupBulletPoints.removeClass("scroll")
};
h.prototype.closePopup=function(){var R=this;
var Q=function(){$.each(g[i].countriesPath,function(S,T){$(T).removeClass(R.classes.pathHover)
})
};
if(!this.$el.hasClass(this.classes.activePopup)){Q();
return
}Q();
this.popup.removeAttr("style");
this.popupArrow.removeAttr("style");
this.removeScroll();
this.$el.removeClass(this.classes.activePopup)
};
function E(Q){return Q.getBoundingClientRect()
}function L(R){var Q={x:0,y:0};
Q.x=R.clientX;
Q.y=R.clientY;
if(Q.x===undefined){Q.x=R.originalEvent.touches[0].pageX;
Q.y=R.originalEvent.touches[0].pageY
}return Q
}function f(R){var S=L(R);
var Q=this.getPopupCoords();
var T=this.getPopupArrowCoords();
if(S.x>Q.x&&S.x<Q.x+Q.width&&S.y>Q.y&&S.y<Q.y+Q.height){return true
}if(S.x>T.x&&S.x<T.x+T.width&&S.y>T.y&&S.y<T.y+T.height){return true
}return false
}function F(Q){if(Modernizr.mq(this.mediaQuery.tablet)){return
}if(f.call(this,Q)){return
}this.closePopup()
}function c(T,S){var R=this;
var Q=P.call(this,S);
var U=s.call(this,S);
i=S;
$.each(g[S].countriesPath,function(W,X){$(X).addClass(R.classes.pathHover)
});
if(!Q&&!U){return
}var V=$(T.target).attr("data-id");
if(!Modernizr.mq(this.mediaQuery.tablet)){B.call(this,V)
}this.showPopup()
}function B(V){var W=this.getPopupCoords();
var R=this.getMapWrapperCoords();
var Y=this.getPopupArrowCoords();
var U=this.getRegionCenterCoords(V);
var S=function(Z,aa,ab){Z.addClass(aa);
Z.removeClass(ab)
};
var T=U.x-W.width/2;
var X=U.y-W.height-20;
if(T<R.x1){T=T+(R.x1-T);
var Q=U.x-T-20;
if(Q<Y.width/2){Q=Y.width/2
}this.popupArrow[0].style.left=Q+"px";
this.popupArrow[0].style.margin="unset";
S(this.popup,"normal","reverse")
}else{if(T+W.width>R.x2){T=T-(T+W.width-R.x2);
Q=T+W.width-U.x-20;
if(Q<Y.width/2){Q=Y.width/2
}this.popupArrow[0].style.right=Q+"px";
this.popupArrow[0].style.left="auto";
this.popupArrow[0].style.margin="unset";
S(this.popup,"normal","reverse")
}}if(X<R.y1){X=U.y+20;
S(this.popup,"reverse","normal")
}else{S(this.popup,"normal","reverse")
}this.popup[0].style.top=X+"px";
this.popup[0].style.left=T+"px"
}function P(Q){var R=g[Q].title;
this.popupTitle.empty();
if(R===null){return false
}this.popupTitle.html(g[Q].title);
return true
}function s(Q){this.popup.removeClass(this.classes.twoColumn).addClass(this.classes.singleColumn);
var R=g[Q].description;
this.popupBulletPoints.empty();
if(R===null){return false
}p.call(this,R);
return true
}function p(W){var T=$(window).width();
var V=$(W).attr("class");
var X=document.createElement("ul");
var S=$(W).children();
var R=document.createElement("div");
$(X).append(S);
$(R).addClass(V);
$(R).append(X);
this.popupBulletPoints.append(R);
var Y=parseFloat($(R).css("line-height"));
var U=function(){return Math.floor(R.getBoundingClientRect().height/Y)
};
var Q=function(){var aa=10;
var Z=Math.floor(T*aa/100)*2;
return T-Z
};
if(U()>d&&Q()>y){this.popup.addClass(this.classes.twoColumn).removeClass(this.classes.singleColumn);
j.call(this,S,R)
}}function j(ac,R){var aa=document.createElement("ul");
var Y=document.createElement("ul");
var ab=0;
var X=0;
ab=X=Math.floor(ac.length/2);
if(ac.length%2>0){ab+=1
}var W=function(ae,ai,ag){var af=ae;
var ah=ai;
while(ah>0){$(ag).append(ac[af]);
af++;
ah--
}};
var Z=0;
var Q=ab;
W(Z,Q,aa);
Z=ab;
Q=X;
W(Z,Q,Y);
$(R).empty();
$(R).append(aa);
$(R).append(Y);
if(Q===1){return
}var ad=aa.getBoundingClientRect().height;
var V=Y.getBoundingClientRect().height;
if(ad<V){while(ad<=V){var U=$(Y).children()[0];
$(aa).append(U);
ad=aa.getBoundingClientRect().height;
V=Y.getBoundingClientRect().height
}}if(V<ad){while(ad>V){var T=$(aa).children();
var S=T.length;
U=$(aa).children()[S-1];
$(Y).prepend(U);
ad=aa.getBoundingClientRect().height;
V=Y.getBoundingClientRect().height
}if(ad<V){$(aa).append($(Y).children()[0])
}}}function m(){var Q=M.call(this);
var S=Q[b];
var R=Q[u];
var T="transform: translate("+S+"px,"+R+"px) scale("+N+")";
this.map.removeAttr("style");
this.map.attr("style",T)
}function t(){var Q=M.call(this);
N=parseFloat(Q[n]);
if(N>H){return
}N=parseFloat((N+q).toFixed(2));
m.call(this)
}function k(){var Q=M.call(this);
N=parseFloat(Q[n]);
if(N<o){return
}N=parseFloat((N-q).toFixed(2));
m.call(this)
}function M(){var Q=this.map.css("transform");
var R=/\(([^)]+)\)/;
var S=R.exec(Q)[1].split(",");
return S
}function A(){return v.width/this.map[0].getBoundingClientRect().width
}function x(R){var Q=L(R);
J.x=Q.x;
J.y=Q.y
}function a(){v.x=z.x;
v.y=z.y
}function D(S){S.preventDefault();
var Q=A.call(this);
var R=L(S);
z.x=v.x-(R.x-J.x)*Q;
z.y=v.y-(R.y-J.y)*Q;
this.map[0].setAttribute("viewBox",z.x+" "+z.y+" "+v.width+" "+v.height)
}function w(){this.initHeaderItems(K.items,K.numberOfItems);
this.adjustMapCenter()
}h.prototype.init=function(Q){K=Q;
this.initPartsOfMap();
this.initEvents();
this.adjustMapCenter()
};
h.prototype.classes={activePath:"interactive-map__active-path",pathHover:"interactive-map__active-path--hover",title:"interactive-map__info-section-title",items:"interactive-map__items",itemsDesktop:"interactive-map__items--descktop",mapComponent:"interactive-map",activePopup:"interactive-map__popup--active",worldMap:"interactive-map__img",worldMapWrapper:"interactive-map__map-wrapper",popup:"interactive-map__popup",popupTitle:"interactive-map__popup-title",popupBulletPoints:"interactive-map__popup-bullet-points",popupArrow:"interactive-map__popup-arrow",closePopupButton:"interactive-map__close-popup",regionCenter:"_Center",zoomIn:"interactive-map__zoom-in",zoomOut:"interactive-map__zoom-out",mapLogo:"interactive-map__logo",divider:"interactive-map__divider",bulletList:"bullet-list",hideEl:"interactive-map__hide-element",staticColumn:"static-column",twoColumn:"two-column",thirdColumn:"third-column",singleColumn:"single-column",column:"column"};
h.prototype.mediaQuery={tablet:"(max-width: 991px)",smallTablet:"(max-width: 767px)",mobile:"(max-width: 556px)",smallMobile:"(max-width: 420px)",extraSmallMobile:"(max-width: 411px)",oldMobile:"(max-width: 320px)",desktop:"(min-width: 992px)",wideDesktop:"(mix-width: 1200)"};
h.prototype.message={svgError:"Interaction map SVG did not load successfully: ",dataLoadError:"Interaction map data JSON did not load successfully: "};
h.moduleName="Interactive Map";
h.selector=".interactive-map-ui";
return h
});
define("InstagramFeed",["media","constants"],function(c,b){function a(e){this.$el=e;
this.$dates=this.$el.find("."+this.classes.date);
this.locale=this.$el.data("locale");
moment.locale(this.locale);
var d=$.extend({},b.CarouselDefaultConfig,{dots:false});
this.$dates.each(function(i,h){var f=$(h),g=+f.data("createdTime");
f.text(moment(g).format(b.DateFormats.ALPHABETIC_SHORT_MONTH_SHORT_DAY))
});
this.$el.owlCarousel(d);
this.posts=this.$el.find("."+this.classes.posts);
this.navigationButtons=this.$el.find("."+this.classes.owlNavigation).children();
this.$previousCardButton=$(this.navigationButtons[0]);
this.$nextCardButton=$(this.navigationButtons[1]);
this.setA11yForPosts();
this.setA11yForNavigationButtons();
this.initEvents()
}a.prototype.setA11yForPosts=function(){var d=this.posts.length;
$.each(this.posts,function(e,f){$(f).attr("aria-label","card "+(e+1)+" of "+d)
})
};
a.prototype.setA11yForNavigationButtons=function(){this.$nextCardButton.attr("aria-label","next card");
this.$previousCardButton.attr("aria-label","previous card");
this.$nextCardButton.removeAttr("role");
this.$previousCardButton.removeAttr("role")
};
a.prototype.initEvents=function(){this.$previousCardButton.on("click",this.setA11yForPreviousCardButton.bind(this));
this.$nextCardButton.on("click",this.setA11yForNextCardButton.bind(this))
};
a.prototype.setA11yForNextCardButton=function(){var f=this.getNumbersOfVisiblePosts();
var e=f[0];
var d=f[f.length-1];
this.$nextCardButton.attr("aria-label","cards "+e+"-"+d+" out of "+this.posts.length+" are shown");
this.$previousCardButton.attr("aria-label","previous card")
};
a.prototype.setA11yForPreviousCardButton=function(){var f=this.getNumbersOfVisiblePosts();
var e=f[0];
var d=f[f.length-1];
this.$nextCardButton.attr("aria-label","next card");
this.$previousCardButton.attr("aria-label","cards "+e+"-"+d+" out of "+this.posts.length+" are shown")
};
a.prototype.getNumbersOfVisiblePosts=function(){var d=[];
$.each(this.posts,function(e,f){var g=$(f).parent().is(".active");
if(g){d.push(e+1)
}});
return d
};
a.prototype.classes={date:"instagram-feed__date",posts:"instagram-feed__item",owlNavigation:"owl-nav"};
a.moduleName="Instagram Feed";
a.selector=".instagram-feed-ui";
return a
});
define("GeneralVacancyBlock",["constants"],function(d){var a=$("html");
var c={vacancyForm:".general-vacancy-form-holder"};
function b(e){this.$vacancyForm=e.find(c.vacancyForm);
a.on(d.Events.showVacancyForm,this.showVacancyForm.bind(this));
$(document).ready(this.resizeVideos)
}b.prototype.showVacancyForm=function(){this.$vacancyForm.removeClass(d.Classes.hidden)
};
b.prototype.resizeVideos=function(){var e=$(document).find(".vacancy_content iframe");
e.each(function(){var i=$(this).attr("width");
var f=$(this).width();
if(f<i){var h=$(this).attr("height");
var g=i/h;
$(this).height(f/g)
}})
};
b.moduleName="General Vacancy Block";
b.selector=".general-vacancy-block-ui";
return b
});
define("FloatingMenu",["utils","utils-env","utils-share","media"],function(h,g,j,c){var b=$(window),f=$("body"),e=51;
var a={fb:"facebook",tw:"twitter",li:"linkedin",vk:"vkontakte"};
var d={floatingMenuUI:".floating-menu-ui",container:".floating-menu__container",iconsList:".floating-menu__icons-list",pinned:"floating-menu--pinned",link:".floating-menu__link",print:".js-print",email:".js-email-share",unpinnedSelector:[".utility-menu-ui",'.section-ui[class*="bg-color-"]:not(.bg-color-white)',".section-ui[data-src]",'.double-section-ui [class*="bg-color-"]:not(.bg-color-white)',".double-section__part--has-bg-image"].join(", "),footerContainer:".footer-container",focusableElements:'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'};
function i(l){this.$el=l;
this.$container=this.$el.find(d.container);
this.$unpinnedElement=$(d.unpinnedSelector).first();
this.$parent=this.$el.parent();
this.$links=this.$el.find(d.link);
this.pinToTop();
b.scroll(this.pinToTop.bind(this));
b.resize(h.debounce(this.pinToTop.bind(this),300));
this.shortUrl=location.href.match(/[^http(s)?://www.].+[\.$]/gi)[0];
var m=this.findContainerWithLastFocusableElementBeforeFooter();
if(!g.isEditMode()&&m!==null&&m.length){this.createClonedElement();
var k=this;
b.on("load",function(){k.styleClonedElement();
m.append(k.$cloned);
k.$parent.addClass("invisible");
k.$links=k.$cloned.find(d.link);
b.on("resize orientationchange",h.debounce(k.styleClonedElement.bind(k),50));
k.setSocialLinks();
k.setPrintButton();
k.setEmailButton()
})
}else{this.setSocialLinks();
this.setPrintButton();
this.setEmailButton()
}}i.prototype.pinToTop=function(){var o=b.scrollTop(),k=this.$el.offset().top,m=this.$container.outerHeight(),l=95,p=o>k-l&&c.currentMode().is(c.modes.Broad);
f.toggleClass(d.pinned,p);
if(this.$unpinnedElement.length){var n=this.$unpinnedElement.offset().top;
if(o+l+m>n){f.removeClass(d.pinned)
}}};
i.prototype.findContainerWithLastFocusableElementBeforeFooter=function(){var l=f.find(d.footerContainer);
var k=l.prev();
var m=k.find(d.focusableElements).last();
if(m.closest(d.floatingMenuUI).is(this.$el)){return null
}return m.closest(".section, .parsys")
};
i.prototype.createClonedElement=function(){this.$container.attr("aria-label","Share page list with "+this.$links.length+" items");
this.$cloned=this.$parent.clone().addClass("cloned")
};
i.prototype.styleClonedElement=function(){if(!this.$parent){return
}var m=this.$parent[0].getBoundingClientRect().top+b.scrollTop()-e;
var l=this.$container[0].getBoundingClientRect().left+b.scrollLeft();
var k=c.currentMode().lessThan(c.modes.Broad)?this.$parent.width():"";
this.$cloned.css("top",m).css("left",l).css("width",k)
};
i.prototype.setSocialLinks=function(){var k=this.$links.not(d.print).not(d.email);
k.on("click",this.share);
k.each(function(){var l=$(this).attr("data-type");
var n=a[l];
n&&$(this).attr("aria-label",n);
var m=j.getLink($(this).data());
m&&$(this).attr("href",m)
})
};
i.prototype.share=function(k){k.preventDefault();
j.go($(this).data())
};
i.prototype.setPrintButton=function(){this.$printButton=this.$links.filter(d.print);
this.$printButton.attr("href",this.getButtonHref("print"));
this.$printButton.on("click",function(k){k.preventDefault();
this.printPage()
}.bind(this))
};
i.prototype.getButtonHref=function(l){var m=JSON.parse(localStorage.getItem(l+"edPagesUrls"))||[];
var k=m.indexOf(this.shortUrl)!==-1;
return location.href+(k?"":"-"+l)
};
i.prototype.printPage=function(){window.print();
this.$printButton.attr("href",location.href);
this.addToUrls("print")
};
i.prototype.addToUrls=function(l){var k=JSON.parse(localStorage.getItem(l+"edPagesUrls"))||[];
if(k.indexOf(this.shortUrl)===-1){k.push(this.shortUrl)
}localStorage.setItem(l+"edPagesUrls",JSON.stringify(k))
};
i.prototype.setEmailButton=function(){this.$emailButton=this.$links.filter(d.email);
this.$emailButton.attr("href",this.getButtonHref("email"));
this.$emailButton.click(function(k){k.preventDefault();
$("<a />").attr("href",this.emailSharingLink()).get(0).click();
this.$emailButton.attr("href",location.href);
this.addToUrls("email")
}.bind(this))
};
i.prototype.emailSharingLink=function(){var l=encodeURIComponent(this.$emailButton.data("subject")),k=encodeURIComponent(location.href);
return"mailto:?subject="+l+"&body="+k
};
i.moduleName="Floating Menu";
i.selector=".floating-menu-ui";
return i
});
define("FeaturedContentGrid",["constants","utils-browser"],function(d,b){var e=b.isInternetExplorer();
var c={gridList:".featured-content-grid__list",viewMore:".featured-content-grid__view-more",errorMessage:".featured-content-grid__error-message",gridInfo:".featured-content-grid__info"};
function a(f){this.$gridList=f.find(c.gridList);
this.constants={URL:this.$gridList.data("content-path"),GRID_LENGTH:this.$gridList.data("content-rest"),LOAD_SIZE:12};
this.$gridInfo=f.find(c.gridInfo);
this.$preloader=f.find("."+d.Classes.preloader);
this.$viewMore=f.find(c.viewMore);
this.$errorMessage=f.find(c.errorMessage);
this.currentSize=this.$gridList.data("current-size");
this.firstLoad=this.currentSize<this.constants.LOAD_SIZE;
this.offset=this.firstLoad?0:this.constants.LOAD_SIZE;
this.gridListClasses=this.$gridList.attr("class");
this.$viewMore.on("click",this.loadGrid.bind(this))
}a.prototype.loadGrid=function(){$.ajax({url:this.constants.URL,data:{offset:this.offset},beforeSend:this.toggleLoadingState.bind(this,true),success:this.updateGrid.bind(this),error:this.showErrorMessage.bind(this),complete:this.toggleLoadingState.bind(this,false),cache:false})
};
a.prototype.updateGrid=function(i){this.offset+=this.constants.LOAD_SIZE;
var f=$.parseHTML(i),j=this.offset>=this.constants.GRID_LENGTH||this.constants.GRID_LENGTH+this.currentSize<=this.constants.LOAD_SIZE;
if(e===11){var g=$("<ul />",{"class":this.gridListClasses});
g.html(f);
this.firstLoad?this.$gridList.html(f):g.insertBefore(this.$gridInfo)
}else{this.firstLoad?this.$gridList.html(f):this.$gridList.append(f)
}j&&this.$viewMore.addClass(d.Classes.hidden);
this.firstLoad=false;
var h=new Event(d.Events.featureGridAddedNewItems);
document.dispatchEvent(h)
};
a.prototype.toggleLoadingState=function(f){this.$preloader.toggleClass(d.Classes.hidden,!f);
f&&this.$errorMessage.addClass(d.Classes.hidden)
};
a.prototype.showErrorMessage=function(){this.$errorMessage.removeClass(d.Classes.hidden)
};
a.moduleName="Featured Content Grid";
a.selector=".featured-content-grid-ui";
return a
});
define("EventsViewer",["utils-dust","utils-env"],function(e,d){function c(f){this.$el=f;
this.$list=this.$el.find("."+this.classes.list);
this.$viewMore=this.$el.find("."+this.classes.viewMore);
this.$errorMessage=this.$el.find("."+this.classes.ajaxError);
this.path=this.$el.data("path");
this.isAuthor=d.isAuthor();
this.category=this.$el.data("category");
this.language=CQ.I18n.getLocale();
this.dateFormat=this.$el.data("dateFormat");
this.getEvents();
this.$viewMore.on("click",this.getEvents.bind(this))
}c.prototype.getEvents=function(){var g=this.$list.children().length,f={method:"GET",url:this.config.eventUrl,data:{path:this.path,category:this.category,language:this.language,limit:this.constants.LIMIT,offset:g,dateFormat:this.dateFormat,buildSchemaOrgMarkup:g===0},success:this.renderEvents.bind(this),error:this.showErrorMessage.bind(this)};
$.ajax(f)
};
var a,b=false;
c.prototype.fillEventsListMarkup=function(g){if(a!==null&&a!==undefined){for(var f=0;
f<g.itemListElement.length;
f++){g.itemListElement[f].position=a.itemListElement.length+f+1
}a.itemListElement=Object.values(a.itemListElement).concat(Object.values(g.itemListElement))
}else{a=g
}};
c.prototype.renderEvents=function(g){var f=g.schemaOrgMarkup;
if(b){if(f){this.fillEventsListMarkup(f)
}if(a!==null&&a!==undefined){this.addSchemaOrgMarkup(a)
}}else{a=f
}b=true;
var h=this.$list.children().length;
e.append("events-viewer-items",{content:g.result,isAuthor:this.isAuthor,category:this.category},this.$list);
if(h+g.result.length>=g.total){return this.$viewMore.addClass(this.classes.buttonDisabled)
}};
c.prototype.addSchemaOrgMarkup=function(f){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(f)+"<\/script>")
};
c.prototype.showErrorMessage=function(){var f=this.classes.active;
this.$errorMessage.addClass(f)
};
c.prototype.classes={list:"events-viewer__list",ajaxError:"events-viewer__ajax-error-message",buttonDisabled:"button-ui--disabled",viewMore:"events-viewer__view-more",active:"active"};
c.prototype.config={eventUrl:"/services/search/events/viewer"};
c.prototype.constants={LIMIT:8};
c.moduleName="Events Viewer";
c.selector=".events-viewer-ui";
return c
});
define("DetailPagesFilter",["utils-dust","utils-env","constants","jquery-plugins"],function(f,e,d){var g=$("body");
var c={multiSelect:".detail-pages-filter__select",industries:".detail-pages-filter__select--industries",contentTypes:".detail-pages-filter__select--content-types",topics:".detail-pages-filter__select--topics",detailPagesMainList:".detail-pages-list--main",detailPagesSecondaryList:".detail-pages-list--secondary",detailPagesList:" .detail-pages-list__holder",detailPagesListNotEmpty:"detail-pages-list__holder--not-empty",viewMore:".detail-pages-filter__view-more",viewMoreLink:".detail-pages-filter__view-more-link",lastRowItem:"detail-pages-list__item-last-row",message:".detail-pages-filter__error-message",topPanel:".detail-pages-filter__top-panel",detailPagesLink:".detail-pages-list__link"};
var b={URL:"/services/search/detail-pages.json",DEFAULT_URL:"/services/search/detail-pages.default.json",TEMPLATE:"detail-pages-list",DEFAULT_IMAGE:"/etc/designs/epam-com/images/detail-page/default-filter-image.jpg",ROW_LENGTH:3,LIMIT:9,LIMIT_INDUSTRY_TAGS:2,TOPICS_COUNT:"component.detail-pages-filter.topics-count"};
var h={ajaxErrorMessage:"component.general.ajax-error-message",ajaxErrorTryAgain:"component.general.ajax-error-try-again",searchNoResults:"component.detail-pages-filter.search-no-results",searchEmptyResult:"component.general.search-empty-result-for-"};
function a(i){this.$el=i;
this.$detailPagesMainList=this.$el.find(c.detailPagesMainList+c.detailPagesList);
this.$detailPagesSecondaryList=this.$el.find(c.detailPagesSecondaryList+c.detailPagesList);
this.$viewMore=this.$el.find(c.viewMore);
this.$viewMoreLink=this.$viewMore.find(c.viewMoreLink);
this.$preloader=this.$el.find("."+d.Classes.preloader);
this.$message=this.$el.find(c.message);
this.$messageText=this.$message.find("p");
this.$topPanel=this.$el.find(c.topPanel);
this.industriesLimit=!!this.$el.data("limited-industries")&&b.LIMIT_INDUSTRY_TAGS;
this.contentReferenceLabelsView=this.$el.data("content-reference-labels-view");
this.sortByPreferredPages=!!this.$el.data("sort-by-preferred-pages");
this.$multiSelect=this.$el.find(c.multiSelect);
this.viewType=this.$el.data("viewType");
this.isAuthor=e.isAuthor();
this.paths=this.$el.data("paths")||"";
this.defaultParameters={paths:this.paths.split(","),limit:b.LIMIT,offset:0,viewType:this.viewType};
this.initViewType[this.viewType].call(this);
this.$multiSelect.on("change",function(){this.scrollResultsToTop()
}.bind(this));
this.$viewMoreLink.on("click",this.loadMoreDetailPages.bind(this));
this.focusOnFirstLoadedItem.bind(this);
if(this.viewType!=="filter"||this.viewType!=="careers-blog"){this.collectParametersAndLoad(true)
}this.$el.pinFilterTop()
}a.prototype.initViewType={filter:function(){this.$industries=this.$multiSelect.filter(c.industries);
this.$contentTypes=this.$multiSelect.filter(c.contentTypes);
this.$el.on("change","select",function(){this.collectParametersAndLoad()
}.bind(this));
this.collectParameters=this.collectFilterParameters;
window.addEventListener("load",function(){var j=this.$industries.val();
var i=this.$contentTypes.val();
this.collectParametersAndLoad(true,j,i).done(function(){this.initMultiselect(this.$industries,this.$el.data("filter-one-text")+":");
this.initMultiselect(this.$contentTypes,this.$el.data("filter-two-text")+":")
}.bind(this))
}.bind(this))
},"careers-blog":function(){this.$topics=this.$multiSelect.filter(c.topics);
window.addEventListener("load",function(){var i=this.$topics.val();
this.collectParametersAndLoad(true,i).done(function(){this.initMultiselect(this.$topics,b.TOPICS_COUNT)
}.bind(this))
}.bind(this));
this.$topics.on("change",function(){this.collectParametersAndLoad()
}.bind(this));
this.collectParameters=this.collectCareersBlogParameters
},allContentTypes:function(){var i=this.$el.data("industries")||"";
this.defaultParameters.industries=i.split(",");
this.collectParameters=this.collectDefaultParameters
}};
a.prototype.initMultiselect=function(i,j){i.multiSelectFilter({selectedCount:j,columns:1,showTags:true})
};
a.prototype.collectDefaultParameters=function(){return $.extend({},this.defaultParameters)
};
a.prototype.collectFilterParameters=function(){return $.extend({},this.defaultParameters,{contentTypes:this.$contentTypes.val()||[],industries:this.$industries.val()||[]})
};
a.prototype.collectCareersBlogParameters=function(){return $.extend({},this.defaultParameters,{topics:this.$topics.val()||[]})
};
a.prototype.loadMoreDetailPages=function(j){var k=this.$detailPagesMainList.children().length,i=$.extend(this.collectParameters(),{offset:k});
if(this.industriesLimit){i.industriesLimit=this.industriesLimit
}if(this.sortByPreferredPages){i.sortByPreferredPages=this.sortByPreferredPages
}this.loadDetailPages(i);
j.preventDefault()
};
a.prototype.collectParametersAndLoad=function(m,j,i,l){var k=this.collectParameters();
if(this.industriesLimit){k.industriesLimit=this.industriesLimit
}if(this.sortByPreferredPages){k.sortByPreferredPages=this.sortByPreferredPages
}if(m){k.buildSchemaOrgMarkup=m
}if(j){k.industries=j
}if(i){k.contentTypes=i
}if(l){k.topics=k
}return this.loadDetailPages(k)
};
a.prototype.loadDetailPages=function(i){return $.ajax({url:this.defaultLoad?b.DEFAULT_URL:b.URL,data:i,cache:false,beforeSend:this.toggleLoadingState.bind(this,true),success:this.loadDetailPagesAdapter.bind(this,i),complete:this.toggleLoadingState.bind(this,false),error:this.showErrorMessage.bind(this)})
};
a.prototype.loadDetailPagesAdapter=function(j,k){if(this.viewType!=="filter"){this.updateDetailPages(j,k);
return
}var i=k;
this.defaultLoad=!k.result.length;
if(this.secondLoad){i.defaultResult=k.result;
k.result=[];
this.secondLoad=false;
this.defaultLoad=false;
this.updateDetailPages(j,i);
return
}if(this.defaultLoad){this.collectParametersAndLoad();
this.secondLoad=true;
this.defaultLoad=false;
return
}this.updateDetailPages(j,i)
};
a.prototype.toggleLoadingState=function(i){this.$preloader.toggleClass(d.Classes.hidden,!i);
i&&this.$message.addClass(d.Classes.hidden)
};
a.prototype.updateDetailPages=function(u,o){var v=o.result,t=o.schemaOrgMarkup,k=o.defaultResult||[],r=o.total,m=u.limit,n=u.offset,j=!v.length,i=!k.length,s=j&&i,l=r>n+m,q=u.buildSchemaOrgMarkup,p=this.$el.data("viewType")==="careers-blog"?"query":"combination";
if(j||!n){this.$detailPagesMainList.empty();
this.$detailPagesSecondaryList.empty()
}!i&&this.updateErrorMessage([h.searchNoResults]);
s&&this.updateErrorMessage([h.searchEmptyResult+p]);
this.$message.toggleClass(d.Classes.hidden,i&&!s);
this.$viewMore.toggleClass(d.Classes.hidden,!l);
if(this.$topPanel.length){this.$detailPagesMainList.toggleClass(c.detailPagesListNotEmpty,!j)
}this.renderDetailPages(k,n,this.$detailPagesSecondaryList);
this.renderDetailPages(v,n,this.$detailPagesMainList);
q&&!!t&&this.addSchemaOrgMarkup(t)
};
a.prototype.renderDetailPages=function(i,l,k){var j={pages:i,lastRowIdx:this.calculateLastRowIndex(i.length),defaultImage:b.DEFAULT_IMAGE,isAuthor:this.isAuthor,contentReferenceLabelsView:this.contentReferenceLabelsView,viewType:this.viewType};
l&&k.children().removeClass(c.lastRowItem);
f.append(b.TEMPLATE,j,k);
this.focusOnFirstLoadedItem(l)
};
a.prototype.focusOnFirstLoadedItem=function(j){var i=this.$detailPagesMainList.children();
if(i.length>b.LIMIT){i.eq(j).find(c.detailPagesLink).focus()
}};
a.prototype.calculateLastRowIndex=function(i){var j=Math.ceil(i/b.ROW_LENGTH);
return(j-1)*b.ROW_LENGTH
};
a.prototype.addSchemaOrgMarkup=function(i){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(i)+"<\/script>")
};
a.prototype.showErrorMessage=function(){this.updateErrorMessage([h.ajaxErrorMessage,h.ajaxErrorTryAgain]);
this.$message.removeClass(d.Classes.hidden)
};
a.prototype.updateErrorMessage=function(i){var j=i.length>1?i.map(function(k){return CQ.I18n.getMessage(k)
}).join(" "):CQ.I18n.getMessage(i[0]);
this.$messageText.html(j)
};
a.prototype.scrollResultsToTop=function(){if(g.hasClass(d.Classes.pinnedFilter)){this.$el.scrollToSelector({duration:500})
}};
a.moduleName="Detail Pages Filter";
a.selector=".detail-pages-filter-ui";
return a
});
define("DemoAnimation",["utils-dust"],function(b){var c={"fortnite-growth":"fortnite-growth","epam-team":"epam-team","where-we-are-now":"where-we-are-now"};
function a(d){this.$el=d;
this.$data=this.$el.data().id;
this.textAnimTimer=0;
this.init()
}a.prototype.init=function(){b.append(c[this.$data],{},this.$el);
if(c[this.$data]===c["fortnite-growth"]){this.setTimer()
}if(c[this.$data]===c["where-we-are-now"]){this.resize()
}};
a.prototype.repeatAnimation=function(g,e){var d=this.$el.find("."+e);
var f=this.$el.find("."+g);
var h=d.clone(true);
d.remove();
f.append(h)
};
a.prototype.setTimer=function(){setInterval(function(){this.repeatAnimation("container","remove-block")
}.bind(this),3000)
};
a.prototype.resize=function(){var d=window.matchMedia("(min-width: 992px)");
if(d.matches){clearInterval(this.textAnimTimer);
this.textAnimTimer=setInterval(function(){this.repeatAnimation("where-we-are-now__animate-text","where-we-are-now__remove-block")
}.bind(this),12000)
}else{clearInterval(this.textAnimTimer)
}};
a.moduleName="Demo Animation";
a.selector=".demo-animation-ui";
return a
});
define("CookieDisclaimer",["utils"],function(h){var e="epam:cookiesAccepted";
var d=182;
var a=6;
var b=4;
var f=100;
var c=56;
var g="data-cookies-consent";
function i(j){this.$el=j;
this.$html=$("html");
this.$isCookieConsent=$(j).attr(g);
this.$description=$(j).find("."+this.classes.description);
if($.cookie(e)==="true"||!this.isCookieEnable()){this.destroy();
return
}this.$el.on("click","."+this.classes.button,this.cookiesAccepted.bind(this)).on("click",this.toggleExpand.bind(this));
$(window).on("resize",h.debounceExtend(this.hideExtraContent.bind(this),f));
if(this.$isCookieConsent==="true"){$(window).unload(this.clearAllCookies.bind(this))
}this.$el.removeClass("hidden");
$(window).bind("load",function(){this.hideExtraContent();
this.$el.removeClass(this.classes.invisible)
}.bind(this))
}i.prototype.cookiesAccepted=function(){$.cookie(e,"true",{expires:d,path:"/"});
this.destroy();
return false
};
i.prototype.destroy=function(){this.$el.remove()
};
i.prototype.toggleExpand=function(){this.$el.toggleClass(this.classes.expanded);
this.addScroll();
this.scrollToTop(this.$description[0])
};
i.prototype.hideExtraContent=function(){$(this.$el).removeClass(this.classes.shortView);
$(this.$el).addClass(this.classes.longView);
var j=Modernizr.mq(this.mediaMode.mobile)?b:a;
if(this.getAmountOfLine()>j){$(this.$el).addClass(this.classes.longView);
$(this.$el).removeClass(this.classes.shortView);
return
}$(this.$el).addClass(this.classes.shortView);
$(this.$el).removeClass(this.classes.longView)
};
i.prototype.descriptionHeight=function(){var j=0;
var l=this.$description.children();
for(var k=0;
k<l.length;
k++){j+=l[k].getBoundingClientRect().height
}return j
};
i.prototype.descriptionMaxHeight=function(){return Math.ceil($(window).height()*c/100)
};
i.prototype.descriptionLineHeight=function(){return parseInt($(this.$description).css(this.properties.lineHeight))
};
i.prototype.getAmountOfLine=function(){return Math.round(this.descriptionHeight()/this.descriptionLineHeight())
};
i.prototype.clearAllCookies=function(){if($.cookie(e)!=="true"){var k=document.cookie.split(";");
for(var j=0;
j<k.length;
j++){document.cookie=k[j]+"; path=/"
}}};
i.prototype.isCookieEnable=function(){return navigator&&navigator.cookieEnabled
};
i.prototype.scrollToTop=function(j){j.scrollTop=0
};
i.prototype.addScroll=function(){if(this.descriptionHeight()>this.descriptionMaxHeight()&&$(this.$el).hasClass(this.classes.expanded)){$(this.$description).addClass(this.classes.descriptionScroll)
}else{$(this.$description).removeClass(this.classes.descriptionScroll)
}};
i.prototype.classes={button:"cookie-disclaimer__button",expanded:"cookie-disclaimer--expanded",description:"cookie-disclaimer__description",descriptionScroll:"cookie-disclaimer__description--scroll",descriptionWrapper:"cookie-disclaimer-description-wrapper",readMoreButton:"cookie-disclaimer__read-more",shortView:"cookie-disclaimer--short-view",longView:"cookie-disclaimer--long-view",invisible:"invisible"};
i.prototype.properties={lineHeight:"line-height",height:"height"};
i.prototype.mediaMode={mobile:"(max-width: 767px)"};
i.moduleName="Cookie Disclaimer";
i.selector=".cookie-disclaimer-ui";
return i
});
define("ContactDetailsReference",["utils"],function(a){function b(c){a.addExtensionToPhoneNumber(c)
}b.moduleName="Contact Details Reference";
b.selector=".contact-details-reference-ui";
return b
});
define("AnywhereVacancyBlock",["utm-utils"],function(c){var b={button:".anywhere-vacancy-block__button",link:".anywhere-vacancy-block__link"};
function a(d){this.$button=d.find(b.button);
this.$link=d.find(b.link);
this.handleButtonClick();
this.handleLinkClick()
}a.prototype.handleButtonClick=function(){var d=c.buildAnywhereUrl(this.$button.data("href"));
this.$button.attr("href",d)
};
a.prototype.handleLinkClick=function(){var e=this.$link.data("href");
if(e!==undefined&&e.indexOf("anywhere")>=0){var d=c.buildAnywhereUrl(e);
this.$link.attr("href",d)
}};
a.moduleName="Anywhere Vacancy Block";
a.selector=".anywhere-vacancy-block-ui";
return a
});
"use strict";
var _createClass=function(){function a(e,c){for(var b=0;
b<c.length;
b++){var d=c[b];
d.enumerable=d.enumerable||false;
d.configurable=true;
if("value" in d){d.writable=true
}Object.defineProperty(e,d.key,d)
}}return function(d,b,c){if(b){a(d.prototype,b)
}if(c){a(d,c)
}return d
}
}();
function _defineProperty(c,a,b){if(a in c){Object.defineProperty(c,a,{value:b,enumerable:true,configurable:true,writable:true})
}else{c[a]=b
}return c
}function _toConsumableArray(a){if(Array.isArray(a)){for(var c=0,b=Array(a.length);
c<a.length;
c++){b[c]=a[c]
}return b
}else{return Array.from(a)
}}function _classCallCheck(a,b){if(!(a instanceof b)){throw new TypeError("Cannot call a class as a function")
}}define("Animation",["utils"],function(a){var d={ANIMATION_IMAGE_CONTAINER:"animation__image-container"};
var c=100;
var b=function(){function h(l){_classCallCheck(this,h);
this.$el=l[0];
this.$imageContainer=this.$el.querySelector("."+d.ANIMATION_IMAGE_CONTAINER);
this.imageName=l.attr("data-image-name");
this.isActive=true;
this.isEditMode=l.is("[is-edit-mode]");
this.delayAnimation=this.loadAnimationPicture();
this.init();
this.initEvents()
}_createClass(h,[{key:"init",value:function j(){this.onScrollChange()
}},{key:"initEvents",value:function g(){window.addEventListener("scroll",a.debounce(this.onScrollChange.bind(this),300));
this.delayAnimation.addEventListener("data_ready",this.onAnimationLoaded.bind(this))
}},{key:"onScrollChange",value:function k(){if(this.isActive&&this.isOnScreen(c)){this.delayAnimation.play();
this.isActive=false
}}},{key:"isOnScreen",value:function f(n){var m=window.innerHeight*(n/100)+window.scrollY;
var o=window.scrollY+this.$imageContainer.getBoundingClientRect().top;
var l=o+this.$imageContainer.offsetHeight/2;
return l<=m
}},{key:"loadAnimationPicture",value:function e(){return bodymovin.loadAnimation({container:this.$imageContainer,renderer:"svg",loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/"+this.imageName+".json",rendererSettings:{className:"animation__svg",viewBoxOnly:true}})
}},{key:"onAnimationLoaded",value:function i(){if(this.isEditMode){this.delayAnimation.goToAndPlay(this.delayAnimation.totalFrames,true);
this.isActive=false
}}}]);
return h
}();
b.moduleName="Animation";
b.selector=".animation-ui";
return b
});
define("AnimationLogos",["utils-env","utils-browser"],function(c,b){var d={item:".animated-logos__wrapper-item",wrapperItems:".animated-logos__wrapper-items",image:".animated-logos__image"};
var a=function(){function f(m){_classCallCheck(this,f);
this.$el=m[0];
this.$item=this.$el.querySelectorAll(d.item);
this.$wrapperItems=this.$el.querySelector(d.wrapperItems);
this.bindedAnimateIfInViewPort=this.animateIfInViewPort.bind(this);
this.init();
if(c.isEditMode()){var l=[];
for(var k=0;
k<this.$item.length;
k++){l.push(this.$item[k])
}l.forEach(function(n){n.classList.add("animated")
})
}}_createClass(f,[{key:"init",value:function i(){window.addEventListener("scroll",this.bindedAnimateIfInViewPort);
var k=this;
window.addEventListener("load",function(){k.animateIfInViewPort()
});
if(b.isInternetExplorer()){k.setSizes()
}}},{key:"animateIfInViewPort",value:function e(){if(!this.$wrapperItems){return
}var t=this.$wrapperItems.getBoundingClientRect().top;
var l=window.scrollY||document.documentElement.scrollTop;
var p=l+t;
var q=p+this.$wrapperItems.offsetHeight;
var n=l+window.innerHeight;
var s=l;
var r=this.$wrapperItems;
var m=r.offsetHeight;
var o=n-p;
var k=q-s;
if(o>=m/2||k<=m/2){this.animationLogos();
window.removeEventListener("scroll",this.bindedAnimateIfInViewPort)
}}},{key:"animationLogos",value:function j(){var l=[];
for(var k=0;
k<this.$item.length;
k++){l.push(this.$item[k])
}l.forEach(function(n,m){setTimeout(function(){n.classList.add("animated")
},150*m)
})
}},{key:"calcWrapperItemsWidth",value:function g(){var k=function k(l){return l/10
};
return k($(this.$wrapperItems).width())
}},{key:"setSizes",value:function h(){for(var m=0;
m<this.$item.length;
m++){var n=parseInt($(this.$item[m]).css("width"),10);
var k=parseInt($(this.$item[m]).css("padding-bottom"),10);
var l=n/k;
var p=$(this.$item[m]).find(d.image);
var o=p[0].naturalWidth/p[0].naturalHeight;
l>o?p.css("width","auto"):p.css("height","auto")
}}}]);
return f
}();
a.moduleName="Animation Logos";
a.selector=".animated-logos-ui";
return a
});
define("BlocksTabs",["utils"],function(e){var g={TABS_LINK:".blocks-tabs__tab",TAB_WRAPPER:".blocks-tabs-tab-wrapper",CONTENT_ITEM:".blocks-tabs__content-item",ACTIVE_CONTENT_ITEM:".blocks-tabs__content-item.active",ACTIVE_TAB:".blocks-tabs-tab-wrapper.active",TABS_WRAPPER:".blocks-tabs-tabs-wrapper",SCROLL_TO_CONTENT:"scroll-to-content",TABS_CONTENT_SECTION:".blocks-tabs-content-section",TABS_TITLE_SECTION:".blocks-tabs-title-section",OWL_STAGE:".owl-stage",SECTION_WRAPPER:".section__wrapper",SECTION_WRAPPERS_IN_TABS_CONTENT:".blocks-tabs__content-item .section__wrapper"};
var f={nextSlide:"blocks.tabs.next",prevSlide:"blocks.tabs.prev",owl:{to:"to.owl.carousel",destroy:"destroy.owl.carousel",refresh:"refresh.owl.carousel",initialized:"initialized.owl.carousel",translated:"translated.owl.carousel"}};
var c=52;
var h=1000;
var b=40;
var d="(min-width: 992px)";
var a=[];
var i=function(){function A(N){_classCallCheck(this,A);
this.$el=N;
this._el=N[0];
this._owl=$(".owl-carousel");
this._owlSingleInst=$(this._el.querySelector(".owl-carousel"));
this.$activeTabColor=this._el.dataset.activeTabColor;
this.$tabs=this._el.querySelectorAll(g.TAB_WRAPPER);
this.$tabsLinks=this._el.querySelectorAll(g.TABS_LINK);
this.$items=$(g.CONTENT_ITEM,this._el);
this.$tabsWrapper=this._el.querySelector(g.TABS_WRAPPER);
this.$tabsContentSection=this._el.querySelector(g.TABS_CONTENT_SECTION);
this.$tabsTitleSection=this._el.querySelector(g.TABS_TITLE_SECTION);
this.$isScrollToContent=this._el.classList.contains(g.SCROLL_TO_CONTENT);
this.$isOwlInit=false;
this.$isOwlDestroy=false;
this.$isDesktop=true;
this.$fisrtOwlRefresh=false;
this.$delayOwlEvent=null;
this.init();
a.push(this)
}_createClass(A,[{key:"init",value:function F(){this.editModeEvents();
this.initEvents();
this.checkDevice();
this.setDefaultActiveTab();
this.initOwlCarousel();
this.resizeEventHandler();
this.initKeysHandler();
this.addSpanWidthSpaceInTabsContent()
}},{key:"addSpanWidthSpaceInTabsContent",value:function K(){var O=function N(Q){if(Q.firstElementChild){N(Q.firstElementChild);
return
}else{if(Q.closest("a")){var R=document.createElement("span");
var P=Q.closest(g.SECTION_WRAPPER);
R.innerHTML="&nbsp;";
P.insertBefore(R,P.children[0])
}if(Q.tagName==="SPAN"&&!Q.innerText){Q.innerHTML="&nbsp;"
}return
}};
this.$tabsContentSection.querySelectorAll(g.SECTION_WRAPPERS_IN_TABS_CONTENT).forEach(function(P){O(P)
})
}},{key:"getNextItem",value:function u(O){var N=Array.prototype.indexOf.call(this.$tabs,O);
if(N===this.$tabs.length-1){return this.$tabs[0].getAttribute("tab-id")
}return this.$tabs[N+1].getAttribute("tab-id")
}},{key:"getPrevItem",value:function G(O){var N=Array.prototype.indexOf.call(this.$tabs,O);
if(N===0){return this.$tabs[this.$tabs.length-1].getAttribute("tab-id")
}return this.$tabs[N-1].getAttribute("tab-id")
}},{key:"changeActiveTab",value:function k(N){this.setActiveTab(N);
this.setActiveTabsContent(N);
var O=this._el.querySelector(g.TAB_WRAPPER+"[tab-id="+N+"]");
O.focus()
}},{key:"horizontalKeyHandlerCallback",value:function s(O){var Q=O.keyCode;
var R=O.target.closest(g.TAB_WRAPPER);
if(Q===39||Q===37||Q===35||Q===36){O.preventDefault()
}if(Q===39){var N=this.getNextItem(R);
this.changeActiveTab(N)
}if(Q===37){var P=this.getPrevItem(R);
this.changeActiveTab(P)
}if(Q===35){this.changeActiveTab(this.$tabs[this.$tabs.length-1].getAttribute("tab-id"))
}if(Q===36){this.changeActiveTab(this.$tabs[0].getAttribute("tab-id"))
}}},{key:"shiftTabHandlerCallback",value:function z(N){if(N.shiftKey&&N.keyCode===9){this.blocksTabsScroll(this.$tabsTitleSection)
}}},{key:"initKeysHandler",value:function D(){var N=this;
this.$tabsWrapper.addEventListener("keydown",function(O){N.horizontalKeyHandlerCallback(O)
});
this.$tabsContentSection.addEventListener("keydown",function(O){N.shiftTabHandlerCallback(O)
})
}},{key:"tabsClickHandler",value:function H(R){var T=e.isElementInViewport(this.$tabsContentSection,100);
var S=R.target;
if(!this.$fisrtOwlRefresh){this._owl.trigger(f.owl.refresh)
}if(S.classList.contains("blocks-tabs__tab")){S=S.parentNode
}var P=S.getAttribute("tab-id");
var Q=this.getTabIndex(P);
var O=this.setActiveTab(P),N=O.activeTabId;
this.setActiveTabsContent(P);
if(N!==P){this.moveToSelectedTab(Q)
}if(!T||this.$isScrollToContent){this.scrollToNode()
}$(window).trigger("tab.changed");
return false
}},{key:"scrollToNode",value:function I(){if(!this.$isScrollToContent){this.blocksTabsScroll(this.$tabsWrapper)
}else{this.blocksTabsScroll(this.$tabsContentSection)
}}},{key:"getTabIndex",value:function q(P){for(var O=0;
O<this.$tabs.length;
O++){var N=this.$tabs[O].getAttribute("tab-id");
if(N===P){return O
}}return -1
}},{key:"getTabIdByAnchor",value:function M(N){for(var O=0;
O<this.$tabsLinks.length;
O++){var P=this.$tabsLinks[O].getAttribute("href");
if(P===N){return this.$tabs[O].getAttribute("tab-id")
}}return null
}},{key:"moveToSelectedTab",value:function n(N){if(N!==-1){this._owlSingleInst.trigger(f.owl.to,[N,h])
}}},{key:"initEvents",value:function v(){var N=this;
window.onresize=e.debounceExtend(function(){return N.resizeEventHandler()
},200);
this.handleTabsClickEvent();
this.imitateHoverEventForTabs()
}},{key:"imitateHoverEventForTabs",value:function B(){var Q=this;
var O=function O(R,S){if(R.classList.contains("active")){return
}S()
};
for(var N=0;
N<this.$tabs.length;
N++){var P=this.$tabs[N];
P.addEventListener("mouseleave",function(R){var S=R.target;
O(S,function(){S.classList.remove(Q.$activeTabColor);
S.classList.remove("hover")
})
});
P.addEventListener("mouseenter",function(S){var R=S.target;
O(R,function(){R.classList.add(Q.$activeTabColor);
R.classList.add("hover")
})
})
}}},{key:"handleTabsClickEvent",value:function E(){for(var N=0;
N<this.$tabsLinks.length;
N++){this.$tabsLinks[N].addEventListener("click",this.tabsClickHandler.bind(this))
}}},{key:"resizeEventHandler",value:function o(){this.checkDevice();
this.initOwlCarousel()
}},{key:"checkDevice",value:function w(){var N=window.matchMedia(d).matches;
if(N){this.$isDesktop=true;
if(!this.$isOwlDestroy){this.$isOwlDestroy=true;
this.$isOwlInit=false;
this._owl.trigger(f.owl.destroy);
this._owl.off(f.owl.translated)
}}else{this.$isDesktop=false
}}},{key:"initOwlCarousel",value:function t(){var O=this;
if(!this.$isOwlInit&&!this.$isDesktop){this.$isOwlInit=true;
this.$isOwlDestroy=false;
this._owl.on(f.owl.initialized,function(){if(O.$delayOwlEvent&&O.$delayOwlEvent.event===f.owl.to){var R=O.getTabIndex(O.$delayOwlEvent.activeTabId);
setTimeout(function(){O.moveToSelectedTab(R)
},1000);
O.$delayOwlEvent=null
}});
this._owl.owlCarousel({autoWidth:true,dots:false});
this._owl.on(f.owl.refresh,function(){O.$fisrtOwlRefresh=true
});
var Q=this.$el.find(g.OWL_STAGE);
var P=Q.width();
var N=this.updateStagePosition(Q,this.$el);
this._owl.on(f.owl.translated,N.bind(this,P))
}}},{key:"setDefaultActiveTab",value:function p(){var P=this.checkURLAnchor();
if(P){var O=this.getTabIdByAnchor(P);
if(O){this.setActiveTab(O);
this.setActiveTabsContent(O);
this.scrollToNode();
if(!this.$isDesktop){this.$delayOwlEvent={event:f.owl.to,activeTabId:O}
}return
}}var N=this.$tabs[0].getAttribute("tab-id");
this.setActiveTab(N);
this.setActiveTabsContent(N)
}},{key:"checkURLAnchor",value:function m(){var N=window.location.hash.slice(0);
return N.length>1?N:null
}},{key:"setActiveTab",value:function y(P){var O=this._el.querySelector(g.ACTIVE_TAB);
var N=null;
if(O){O.classList.remove("active");
O.classList.remove("hover");
O.classList.remove(this.$activeTabColor);
O.setAttribute("aria-selected",false);
O.tabIndex=-1;
N=O.getAttribute("tab-id")
}var Q=this._el.querySelector(g.TAB_WRAPPER+"[tab-id="+P+"]");
if(Q){Q.classList.add("active");
Q.classList.add(this.$activeTabColor);
Q.setAttribute("aria-selected",true);
Q.tabIndex=0
}return{activeTabId:N}
}},{key:"blocksTabsScroll",value:function x(N){var O=N.getBoundingClientRect().top+window.scrollY-c;
window.scroll({top:O,left:0,behavior:"smooth"})
}},{key:"setActiveTabsContent",value:function l(N){var P=this._el.querySelector(g.ACTIVE_CONTENT_ITEM);
if(P){P.classList.remove("active");
P.classList.add("hidden");
P.tabIndex=-1
}var O=this._el.querySelector(g.CONTENT_ITEM+"[content-id="+N+"]");
O.classList.remove("hidden");
O.classList.add("active");
O.tabIndex=0
}},{key:"navigationArrowHandler",value:function J(O){var N=this.$tabs[O].getAttribute("tab-id");
this.setActiveTab(N);
this.setActiveTabsContent(N)
}},{key:"goToNextTab",value:function C(O,P){var N=P.tab;
this.navigationArrowHandler(N)
}},{key:"goToPrevTab",value:function r(P,O){var N=O.tab;
this.navigationArrowHandler(N)
}},{key:"editModeEvents",value:function L(){$(this._el).on(f.nextSlide,this.goToNextTab.bind(this));
$(this._el).on(f.prevSlide,this.goToPrevTab.bind(this))
}},{key:"updateStagePosition",value:function j(O,N){return function(T){var Q=parseInt(O.css("transform").split(",")[4]),R=N.width()-b,P=T-R,S=-Q>P;
S&&O.css("transform","translateX(-"+P+"px)")
}
}}]);
return A
}();
i.events=f;
i.activatedComponents=a;
i.moduleName="Blocks Tabs";
i.selector=".blocks-tabs-ui";
return i
});
define("CategoriesSwitcher",["utils","utils-env"],function(b,d){var g={TILE:"categories-switcher__tile-title",LEFT_SECTION:"categories-switcher-left-part",ACTIVE:"active",ACTIVE_TILE:".categories-switcher__tile-title.active",ACTIVE_CONTENT:".categories-switcher__content-item.active",ACTIVE_CONTENT_MOB:".categories-switcher__content-item-mob.active",CONTENT_ITEM:"categories-switcher__content-item",CONTENT_ITEM_MOBILE:"categories-switcher__content-item-mob",COLOR_PANEL:"categories-switcher-background",HIDE:"hidden",RESPONSIVE_IMAGE:"responsive-image-ui",TITLES_SECTION:"categories-switcher-tiles-section"};
var f={RESPONSIVE_HEADER_HEIGHT:52};
var a={nextSlide:"cat.switcher.next",prevSlide:"cat.switcher.prev"};
var e=[];
var c=function(){function r(C){_classCallCheck(this,r);
this.$el=C;
this.$modernEl=C[0];
this.$tiles=$("."+g.TILE,this.$modernEl);
this.$items=$("."+g.CONTENT_ITEM,this.$modernEl);
this.$itemsMobile=$("."+g.CONTENT_ITEM_MOBILE,this.$modernEl);
this.$tilesSection=this.$modernEl.querySelector("."+g.TITLES_SECTION);
this.itemsLength=this.$items.length;
this.init();
e.push(this)
}_createClass(r,[{key:"init",value:function z(){if(d.isEditMode()){this.editModeEvents();
return
}this.resizeEventHandler(this);
this.initDefaultSwitcherView();
this.addEventHandler();
this.setTitleIndex();
this.initEvents()
}},{key:"setTitleIndex",value:function y(){$.each(this.$tiles,function(C,D){D.setAttribute("item-index",C)
})
}},{key:"nextSlide",value:function l(){var D=this.$items.index(this.getActiveSlide());
var C=D<this.itemsLength-1?D+1:0;
this.switchSlide(this.$items[C])
}},{key:"prevSlide",value:function i(){var D=this.$items.index(this.getActiveSlide());
var C=D>0?D-1:this.itemsLength-1;
this.switchSlide(this.$items[C])
}},{key:"switchSlide",value:function o(C){this.reset();
C.classList.remove(g.HIDE);
C.classList.add(g.ACTIVE);
this.renderResponsiveImg(C)
}},{key:"getActiveSlide",value:function u(){return this.$modernEl.querySelector(g.ACTIVE_CONTENT)
}},{key:"getActiveTitle",value:function t(){return this.$modernEl.querySelector(g.ACTIVE_TILE)
}},{key:"reset",value:function A(){for(var C=0;
C<this.$tiles.length;
C++){this.$tiles[C].classList.remove(g.ACTIVE)
}for(var D=0;
D<this.itemsLength;
D++){this.$items[D].classList.remove(g.ACTIVE);
this.$items[D].classList.add(g.HIDE)
}if(this.$itemsMobile.length>0){for(var E=0;
E<this.itemsLength;
E++){this.$itemsMobile[E].classList.remove(g.ACTIVE);
this.$itemsMobile[E].style.maxHeight=null
}}}},{key:"initDefaultSwitcherView",value:function n(){this.reset();
if(this.device==="desktop"){this.$tiles[0].classList.add(g.ACTIVE);
this.$tiles[0].setAttribute("tabindex",0);
this.$items[0].classList.add(g.ACTIVE);
this.$items[0].classList.remove(g.HIDE)
}}},{key:"addEventHandler",value:function h(){var D=this;
var C=Array.prototype.slice.call(this.$tiles);
C.forEach(function(E){E.addEventListener("click",function(F){D.tileClickHandler(F.currentTarget,D)
})
})
}},{key:"mobileClickHandler",value:function x(D,C){var F=this.$modernEl.querySelector(g.ACTIVE_TILE);
if(!!F&&!F.isEqualNode(D)){this.reset()
}var E=D.nextElementSibling;
D.classList.toggle(g.ACTIVE);
E.classList.toggle("active");
C.activeTile=D;
C.activeContent=E;
if(E.style.maxHeight){E.style.maxHeight=null
}else{E.style.maxHeight=E.scrollHeight+"px"
}}},{key:"moveContentToTop",value:function v(C){if(C.activeTile!==undefined&&C.activeTile.classList.contains(g.ACTIVE)){var D=document.body.getBoundingClientRect();
var E=C.activeContent.getBoundingClientRect();
$("html, body").animate({scrollTop:E.top-D.top-f.RESPONSIVE_HEADER_HEIGHT},500)
}}},{key:"desktopClickHandler",value:function m(D){this.reset();
var E=D.getAttribute("tile-id");
var C=this.$modernEl.querySelector('[content-id="'+E+'"]');
D.classList.add(g.ACTIVE);
C.classList.add(g.ACTIVE);
C.classList.remove(g.HIDE);
this.renderResponsiveImg(C)
}},{key:"renderResponsiveImg",value:function s(C){var D=C.querySelectorAll("."+g.RESPONSIVE_IMAGE);
if(D.length>0){$(window).trigger("resize")
}}},{key:"tileClickHandler",value:function q(D,C){if(this.device==="desktop"){this.desktopClickHandler(D,C)
}else{this.mobileClickHandler(D,C)
}}},{key:"resizeEventHandler",value:function k(){if(window.matchMedia("(min-width: 768px)").matches){this.device="desktop"
}else{this.device="mobile"
}}},{key:"getTitleItem",value:function j(C){if(C<0){return this.$tiles[this.itemsLength-1]
}if(C>this.itemsLength-1){return this.$tiles[0]
}return this.$tiles[C]
}},{key:"arrowClickHandler",value:function w(G){var C=this;
var D=function D(H,J){J.preventDefault();
C.$modernEl.querySelector('[tabindex="0"]').removeAttribute("tabindex");
var I=C.getTitleItem(H);
I.setAttribute("tabindex",0);
I.focus();
C.desktopClickHandler(I)
};
if(G.keyCode===36){D(0,G)
}if(G.keyCode===35){D(this.itemsLength-1,G)
}if(G.keyCode===38||G.keyCode===37){var E=this.getActiveTitle().getAttribute("item-index");
D(Number(E)-1,G)
}if(G.keyCode===40||G.keyCode===39){var F=this.getActiveTitle().getAttribute("item-index");
D(Number(F)+1,G)
}}},{key:"initEvents",value:function p(){var C=this;
window.addEventListener("resize",b.debounceExtend(function(){C.resizeEventHandler(C);
if(!C.currentDevice){C.currentDevice=C.device;
return
}if(C.currentDevice!==C.device){C.initDefaultSwitcherView();
C.currentDevice=C.device
}},300));
this.$modernEl.addEventListener("transitionend",b.debounceExtend(function(){C.moveContentToTop(C)
},100));
this.$tilesSection.addEventListener("keydown",this.arrowClickHandler.bind(this))
}},{key:"editModeEvents",value:function B(){var C=this;
this.switchSlide(this.$items[0]);
this.$el.on(a.prevSlide,function(){C.prevSlide()
});
this.$el.on(a.nextSlide,function(){C.nextSlide()
})
}}]);
return r
}();
c.moduleName="Categories Switcher";
c.activatedComponents=e;
c.events=a;
c.selector=".categories-switcher-ui";
return c
});
define("ClientLogicPopUp",["utils","utils-env","ClientLogicPopUpService"],function(b,e,a){var f={POP_UP_CONTENT:".pop-up__content",POP_UP_SUCCESS_REQUEST_MESSAGE:".pop-up__request-message-success",POP_UP_ERROR_REQUEST_MESSAGE:".pop-up__request-message-error",POP_UP_CLOSE_BUTTON:".pop-up__button-close",POP_UP_BACKDROP:".pop-up__backdrop",POP_UP_WRAPPER:".pop-up__wrapper",POP_UP_FORM:".pop-up__form",POP_UP_TRY_AGAIN_LINK:".pop-up__request-message-error__link",POP_UP_EMAIL_INPUT:".pop-up__email-input",POP_UP_HELP_SECTION:".pop-up__help",TEXT_FIELD_UI:".text-field-ui",VALIDATION_TOOLTIP:".validation-tooltip",VALIDATION_TEXT:".validation-text",SUBMIT_BUTTON:".button-ui",BUTTON_SUBMIT_LOADING_GIF:".button-submit__loading-gif",REMEMBER_ME:".remember-me",POP_UP_HELP_LINK:".pop-up__help-link",HAMBURGER_MENU_BUTTON:".hamburger-menu__button",POP_UP_HELP_LOADING_GIF:".pop-up__help-loading-gif"};
var d="(max-width: 1129px)";
var c=function(){function s(A){_classCallCheck(this,s);
this._el=A[0];
this.$rememberMe=this._el.querySelector(f.REMEMBER_ME);
this.$popUpHelpLink=this._el.querySelector(f.POP_UP_HELP_LINK);
this.$popUpContent=this._el.querySelector(f.POP_UP_CONTENT);
this.$successMessage=this._el.querySelector(f.POP_UP_SUCCESS_REQUEST_MESSAGE);
this.$errorMessage=this._el.querySelector(f.POP_UP_ERROR_REQUEST_MESSAGE);
this.$popUpCloseButton=this._el.querySelector(f.POP_UP_CLOSE_BUTTON);
this.$popUpBackDrop=this._el.querySelector(f.POP_UP_BACKDROP);
this.$popUpWrapper=this._el.querySelector(f.POP_UP_WRAPPER);
this.$popUpForm=this._el.querySelector(f.POP_UP_FORM);
this.$popUpTryAgainLink=this._el.querySelector(f.POP_UP_TRY_AGAIN_LINK);
this.$popUpEmailInput=this._el.querySelector(f.POP_UP_EMAIL_INPUT);
this.$textFieldUI=this._el.querySelector(f.TEXT_FIELD_UI);
this.$popUpValidationTooltip=this._el.querySelector(f.VALIDATION_TOOLTIP);
this.$popUpValidationText=this._el.querySelector(f.VALIDATION_TEXT);
this.$popUpHelpSection=this._el.querySelector(f.POP_UP_HELP_SECTION);
this.$submitButton=this._el.querySelector(f.SUBMIT_BUTTON);
this.$buttonSubmitLoadingGif=this._el.querySelector(f.BUTTON_SUBMIT_LOADING_GIF);
this.$popUpHelpLoadingGif=this._el.querySelector(f.POP_UP_HELP_LOADING_GIF);
this.$hamburgerMenuButton=document.body.querySelector(f.HAMBURGER_MENU_BUTTON);
this.isAuthor=e.isAuthor();
this.setCurrentClientLoginButtonAndEvent();
this.initEvents();
new a(this)
}_createClass(s,[{key:"validateEmail",value:function u(A){var B=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
return B.test(A)
}},{key:"setCurrentClientLoginButtonAndEvent",value:function k(){var A=window.matchMedia(d).matches;
if(A){this.isAuthor?this.$clientLoginButton=document.body.querySelector('.hamburger-menu__link[href="/content/infongen/en/client-login.html"]'):this.$clientLoginButton=document.body.querySelector('.hamburger-menu__link[href="/client-login"]')
}else{this.isAuthor?this.$clientLoginButton=document.body.querySelector('.top-navigation__item-link[href="/content/infongen/en/client-login.html"]'):this.$clientLoginButton=document.body.querySelector('.top-navigation__item-link[href="/client-login"]')
}}},{key:"initEvents",value:function m(){this.$clientLoginButton.addEventListener("click",this.openPopUp.bind(this));
window.addEventListener("resize",b.debounce(this.setCurrentClientLoginButtonAndEvent.bind(this),300));
this.$popUpCloseButton.addEventListener("click",this.closePopUp.bind(this));
this.$popUpTryAgainLink.addEventListener("click",this.resetPopUpWithNeedHelpSection.bind(this));
this.$popUpBackDrop.addEventListener("mousedown",this.closePopUp.bind(this));
this.$popUpWrapper.addEventListener("mousedown",function(A){return A.stopPropagation()
});
this.$popUpEmailInput.addEventListener("change",this.isEmailValid.bind(this))
}},{key:"isEmailValid",value:function r(){var B=this.$popUpEmailInput.value;
var A=this.validateEmail(B);
if(A){this.$textFieldUI.classList.remove("validation-field")
}else{this.$textFieldUI.classList.add("validation-field");
!B.length?this.$popUpValidationText.textContent="This is required field":this.$popUpValidationText.textContent="Incorrect email format";
this.$popUpEmailInput.focus()
}return A
}},{key:"resetPopUpWithNeedHelpSection",value:function t(){var A=arguments.length>0&&arguments[0]!==undefined?arguments[0]:true;
this.$errorMessage.classList.remove("active");
this.$errorMessage.classList.add("hidden");
this.$successMessage.classList.remove("active");
this.$successMessage.classList.add("hidden");
this.$popUpContent.classList.remove("hidden");
this.$popUpContent.classList.add("active");
this._el.classList.remove("show-unknown-email-error");
if(A){this.showHelpSection()
}else{this.hideHelpSection()
}}},{key:"showHelpSection",value:function x(){this.$popUpHelpSection.classList.remove("hidden");
this.$popUpHelpSection.classList.add("active")
}},{key:"hideHelpSection",value:function g(){this.$popUpHelpSection.classList.add("hidden");
this.$popUpHelpSection.classList.remove("active")
}},{key:"closePopUp",value:function v(){this.$clientLoginButton.classList.remove("active");
this._el.classList.add("hidden");
this._el.classList.remove("active");
this.resetPopUpWithNeedHelpSection(false);
this.hideSpinner()
}},{key:"closeHamburgerMenu",value:function o(){var A=document.querySelector("html").classList.contains("hamburger-menu--expanded");
A&&this.$hamburgerMenuButton.click()
}},{key:"remembermeProxy",value:function p(B,A){var C=this.getCookieByName("rememberme");
if(C==="true"){B&&B()
}else{A&&A()
}}},{key:"openPopUp",value:function w(A){var B=this;
A.preventDefault();
this.remembermeProxy(function(){B.$submitButton.click()
},function(){B.showPopupWindow()
})
}},{key:"showPopupWindow",value:function z(){this.closeHamburgerMenu();
this.$clientLoginButton.classList.add("active");
this._el.classList.remove("hidden");
this._el.classList.add("active")
}},{key:"getCookieByName",value:function n(B){var A=document.cookie.match(new RegExp("(?:^|; )"+B.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,"\\$1")+"=([^;]*)"));
return A?decodeURIComponent(A[1]):undefined
}},{key:"showSpinner",value:function j(){this.$submitButton.textContent="";
this.$submitButton.setAttribute("disabled",true);
this.$buttonSubmitLoadingGif.classList.remove("hidden");
this.$buttonSubmitLoadingGif.classList.add("active")
}},{key:"hideSpinner",value:function l(){this.$submitButton.textContent="Continue";
this.$submitButton.removeAttribute("disabled");
this.$buttonSubmitLoadingGif.classList.remove("active");
this.$buttonSubmitLoadingGif.classList.add("hidden")
}},{key:"showHelpSectionSpinner",value:function h(){this.$popUpHelpLoadingGif.classList.remove("hidden");
this.$popUpHelpLoadingGif.classList.add("active");
this.$popUpHelpLink.classList.remove("active");
this.$popUpHelpLink.classList.add("hidden")
}},{key:"hideHelpSectionSpinner",value:function i(){this.$popUpHelpLoadingGif.classList.add("hidden");
this.$popUpHelpLoadingGif.classList.remove("active");
this.$popUpHelpLink.classList.add("active");
this.$popUpHelpLink.classList.remove("hidden")
}},{key:"showMessage",value:function q(A){this.$popUpContent.classList.remove("active");
this.$popUpContent.classList.add("hidden");
this._el.classList.remove("show-unknown-email-error");
if(A==="error"){this.$errorMessage.classList.remove("hidden");
this.$errorMessage.classList.add("active")
}else{this.$successMessage.classList.remove("hidden");
this.$successMessage.classList.add("active")
}}},{key:"showUnknownEmailError",value:function y(){this._el.classList.add("show-unknown-email-error")
}}]);
return s
}();
c.moduleName="Client Logic Pop Up";
c.selector=".client-logic-pop-up-ui";
return c
});
define("ClientLogicFetchService",[],function(){var b=function b(d,c){if(!d.ok){c&&c();
throw Error(d.statusText)
}return d
};
var a=function a(f){var e=f.url,g=f.data,c=f.successCallback,d=f.errorCallback;
fetch(e,g).then(function(h){return b(h,d)
}).then(function(h){c(h)
})
};
return{sendRequest:a}
});
define("ClientLogicPopUpService",["ClientLogicFetchService"],function(d){var f={popup:".client-logic-pop-up-ui script",recaptcha:".recaptcha-ui.g-recaptcha"};
var a={popupLoaded:"recaptcha.event.loaded",fetchSend:"fetched.send"};
var b={captchaValidation:"/services/recaptcha/validation",infongenContentPath:"/content/infongen/en",supportEmailUrl:"/services/notify/infongen-support-team?userEmail="};
var e={method:"GET",headers:{Referer:"https://www.infongen.com/"}};
var c=function(){function q(E){_classCallCheck(this,q);
this._popupComponent=E;
this.$recaptchaOnloadScript=document.querySelector(f.popup);
this.$isRecaptchaLaoded=false;
this.init()
}_createClass(q,[{key:"init",value:function y(){this.initEvents()
}},{key:"initEvents",value:function i(){var E=this;
this._popupComponent.$popUpForm.addEventListener("submit",function(F){return E.handlePopupFormSubmit(F)
});
this._popupComponent._el.addEventListener(a.popupLoaded,function(F){return E.handleRecaptchaScriptLoaded(F)
});
this._popupComponent.$popUpHelpLink.addEventListener("click",function(){return E.sendEmailToSupport()
})
}},{key:"handleRecaptchaScriptLoaded",value:function D(){this.renderRecaptchaForm();
grecaptcha.execute(this.$recaptchaId)
}},{key:"sendRecaptcha",value:function g(){this._popupComponent.showSpinner();
this.loadRecaptcha()
}},{key:"loadRecaptcha",value:function t(){if(!this.$isRecaptchaLaoded){this.createAndAddReCaptchaScript()
}else{grecaptcha.execute(this.$recaptchaId)
}}},{key:"handlePopupFormSubmit",value:function k(E){var F=this;
E.preventDefault();
this._popupComponent.remembermeProxy(function(){F.sendRecaptcha()
},function(){if(!F._popupComponent.isEmailValid()){return
}F.sendRecaptcha()
})
}},{key:"createAndAddReCaptchaScript",value:function w(){var E=document.createElement("script");
E.setAttribute("src","https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit");
E.defer=true;
E.async=true;
this._popupComponent._el.insertBefore(E,this.$recaptchaOnloadScript);
this.$isRecaptchaLaoded=true
}},{key:"renderRecaptchaForm",value:function m(){var E=document.querySelector("#popup-recaptcha-container").dataset.sitekey;
this.$recaptchaId=grecaptcha.render("popup-recaptcha-container",{sitekey:E,callback:this.recaptchaOnExecuteHandler.bind(this),size:"invisible"})
}},{key:"getPagePath",value:function B(){var E=/\.[^.]*$/;
var F=window.location.pathname.replace(E,"");
return F.includes(b.infongenContentPath)?F:b.infongenContentPath+F
}},{key:"recaptchaErrorCallback",value:function s(){grecaptcha.reset(this.$recaptchaId);
this.showErrorMessage();
this._popupComponent.hideSpinner();
this.saveToCookie("rememberme","false")
}},{key:"recaptchaOnExecuteHandler",value:function j(H){var G=this;
d.sendRequest({url:b.captchaValidation+"?currentPage="+this.getPagePath()+"&g-recaptcha-response="+H,body:{headers:{Accept:"application/json","Content-Type":"application/json"}},successCallback:function E(I){return G.handleRecaptchaSuccessfulResponse(I)
},errorCallback:function F(){return G.recaptchaErrorCallback()
}})
}},{key:"handleRecaptchaSuccessfulResponse",value:function h(E){var F=this;
E.json().then(function(G){if(G){F.sendEmailToInfongen()
}else{F.recaptchaErrorCallback()
}})
}},{key:"getUserEmail",value:function z(){var E=this;
var F=null;
this._popupComponent.remembermeProxy(function(){F=E._popupComponent.getCookieByName("client-login-user-email")
},function(){F=E._popupComponent.$popUpEmailInput.value
});
return this.escapeUserLogin(F)
}},{key:"sendEmailToInfongen",value:function u(){var H=this;
var F=document.querySelector(".client-logic-pop-up-ui").dataset.endPoint;
d.sendRequest({url:""+F+this.getUserEmail(),data:e,successCallback:function E(I){H.infongenFinalActions();
H.handleInfongenSuccessResponse(I)
},errorCallback:function G(){H.infongenFinalActions();
H.showErrorMessage();
H.saveToCookie("rememberme","false")
}})
}},{key:"handleInfongenSuccessResponse",value:function l(F){var E=this;
F.text().then(function(G){var H=G.length===0;
if(H){E._popupComponent.showPopupWindow();
E._popupComponent.resetPopUpWithNeedHelpSection();
E._popupComponent.showUnknownEmailError();
E.setPreviousEmail()
}else{if(E._popupComponent.$rememberMe.checked){E.saveToCookie("rememberme","true");
E.saveToCookie("client-login-user-email",E._popupComponent.$popUpEmailInput.value)
}window.location.href=G
}})
}},{key:"infongenFinalActions",value:function r(){this._popupComponent.hideSpinner();
grecaptcha.reset(this.$recaptchaId)
}},{key:"setPreviousEmail",value:function v(){var E=this;
this._popupComponent.remembermeProxy(function(){var F=E._popupComponent.getCookieByName("client-login-user-email");
E._popupComponent.$popUpEmailInput.value=F
})
}},{key:"saveToCookie",value:function C(E,F){if(F.trim().length!==0){document.cookie=E+"="+F
}}},{key:"escapeUserLogin",value:function x(E){return encodeURI(E)
}},{key:"showErrorMessage",value:function n(){this._popupComponent.showPopupWindow();
this._popupComponent.showMessage("error");
this.saveToCookie("rememberme","false")
}},{key:"showSuccessMessage",value:function p(){this._popupComponent.showPopupWindow();
this._popupComponent.showMessage();
this.saveToCookie("rememberme","false")
}},{key:"hidePopUpHelpAndSpinner",value:function A(){this._popupComponent.hideHelpSectionSpinner();
this._popupComponent.hideHelpSection()
}},{key:"sendEmailToSupport",value:function o(){var F=this;
if(!this._popupComponent.isEmailValid()){return
}this._popupComponent.showHelpSectionSpinner();
d.sendRequest({url:""+b.supportEmailUrl+this.getUserEmail(),data:e,successCallback:function E(){F.hidePopUpHelpAndSpinner();
F.showSuccessMessage()
},errorCallback:function G(){F.hidePopUpHelpAndSpinner();
F.showErrorMessage()
}})
}}]);
return q
}();
c.moduleName="Client Logic Pop Up";
return c
});
define("a11y-tools",[],function(){var f=function f(h,i){return(" "+h.className+" ").indexOf(" "+i+" ")>-1
};
var a=function a(j,h){if(h.$tiles.length===0){return
}var i=Array.prototype.slice.call(h.$tiles);
Array.prototype.forEach.call(i,function(l,k){if(f(l,"active")){l.setAttribute("tabindex","0");
l.setAttribute("aria-selected",true);
h.$tilesContent[k].setAttribute("tabindex",0)
}else{l.setAttribute("tabindex","-1");
l.setAttribute("aria-selected",false)
}l.classList.add("a11y-focus")
})
};
var d=function d(h,j){var i=Array.prototype.indexOf.call(h,j);
if(i===h.length-1){return{item:h[0],index:0}
}return{item:h[i+1],index:i+1}
};
var e=function e(h,j){var i=Array.prototype.indexOf.call(h,j);
if(i===0){return{item:h[h.length-1],index:h.length-1}
}return{item:h[i-1],index:i-1}
};
var b=function b(i,k){var h=k.$tilesSection.querySelector(".feature-blocks__active");
var j=Array.prototype.indexOf.call(k.$tiles,h);
k.activeTile(i.item);
k.activeTileContent(i.index);
k.$tilesContent[i.index].setAttribute("tabindex",0);
k.$tilesContent[j].removeAttribute("tabindex");
h.setAttribute("tabindex","-1");
h.setAttribute("aria-selected",false);
i.item.setAttribute("tabindex","0");
i.item.setAttribute("aria-selected",true);
i.item.focus()
};
var g=function g(k,j){var l=k.keyCode;
var m=k.target;
if(l===39||l===37||l===35||l===36){k.preventDefault()
}if(l===39){var h=d(j.$tiles,m);
b(h,j)
}if(l===37){var i=e(j.$tiles,m);
b(i,j)
}if(l===35){b({item:j.$tiles[j.$tiles.length-1],index:j.$tiles.length-1},j)
}if(l===36){b({item:j.$tiles[0],index:0},j)
}};
var c=function c(i,h){h.$tilesSection.addEventListener("keydown",function(j){g(j,h)
})
};
return{initFocusAndTabindex:a,initKeysHandler:c}
});
define("FeatureBlocks",["a11y-tools"],function(b){var d={FEATURE_BLOCKS_NAV_TILE:"feature-blocks__nav-tile",ACTIVE_TILE:"feature-blocks__active",ACTIVE_TILE_CONTENT:"feature-blocks__content-active",TILE_CONTENT_SECTION:"feature-blocks__tile-content-section",TILE_TEXT_WRAPPER:"feature-blocks__tile-text-wrapper",SINGLE_IMG:"feature-blocks__single-image",NAVIGATION_SECTION:"feature-blocks__nav-section",INSIDE_INACTIVE_MULTI_LEVEL_TAB:".multi-level-tab__accordion-item:not(.active)",ACTIVE:"active"};
var c=0;
var a=function(){function g(m){_classCallCheck(this,g);
this.$el=m[0];
this.$tiles=this.$el.querySelectorAll("."+d.FEATURE_BLOCKS_NAV_TILE);
this.$tilesContent=this.$el.querySelectorAll("."+d.TILE_CONTENT_SECTION);
this.$tilesL=this.$tiles.length;
this.$tilesSection=this.$el.querySelector("."+d.NAVIGATION_SECTION);
this.init()
}_createClass(g,[{key:"init",value:function l(){this.setDefaultTile();
this.initEventHandler();
this.resizeHandler();
window.addEventListener("resize",this.resizeHandler.bind(this));
b.initFocusAndTabindex(this.$el,this);
b.initKeysHandler(this.$el,this)
}},{key:"initEventHandler",value:function k(){var n=this;
var m=Array.prototype.slice.call(this.$tiles);
Array.prototype.forEach.call(m,function(p,o){var q=p.querySelector("."+d.TILE_TEXT_WRAPPER);
if(q===null){p.classList.add(d.SINGLE_IMG)
}p.addEventListener("click",n.tileClickHandler.bind(n,o,p))
})
}},{key:"tileClickHandler",value:function e(n,m){this.activeTile(m);
this.activeTileContent(n)
}},{key:"activeTile",value:function j(m){var n=this.$el.querySelector("."+d.ACTIVE_TILE);
if(n!==null){n.classList.remove(d.ACTIVE_TILE)
}m.classList.add(d.ACTIVE_TILE)
}},{key:"activeTileContent",value:function f(m){var n=this.$el.querySelector("."+d.ACTIVE_TILE_CONTENT);
if(n!==null){n.classList.remove(d.ACTIVE_TILE_CONTENT,d.ACTIVE);
n.classList.remove(d.ACTIVE)
}this.$tilesContent[m].classList.add(d.ACTIVE_TILE_CONTENT);
this.$tilesContent[m].classList.add(d.ACTIVE)
}},{key:"setDefaultTile",value:function i(){var n=this;
var m=function m(o){n.$tiles[o].classList.add(d.ACTIVE_TILE);
n.$tiles[o].classList.add(d.ACTIVE);
n.$tilesContent[o].classList.add(d.ACTIVE_TILE_CONTENT)
};
m(0)
}},{key:"resizeHandler",value:function h(){if(this.$el.closest(d.INSIDE_INACTIVE_MULTI_LEVEL_TAB)){return
}var p=this.$tiles[0].offsetWidth;
var n=this.$tiles[0].offsetHeight;
var m=Array.prototype.slice.call(this.$tiles);
var o=function o(){m.forEach(function(q){q.setAttribute("style","height:"+p+"px")
})
};
if(c===0){c=p
}if(this.$tilesL===3){o()
}else{if(p<n||c<=p){o();
c=p
}}}}]);
return g
}();
a.moduleName="Feature Blocks";
a.selector=".feature-blocks-ui";
return a
});
define("LogoCarousel",["utils","utils-browser"],function(a,c){var d={tilesContainer:"logo-carousel__tiles-container",tilePreview:"logo-carousel__tile-preview",tilesTrack:"logo-carousel__tiles-track",tileContainer:"logo-carousel__tile-hide-container",tile:"logo-carousel__tile-container",next:"logo-carousel__next",prev:"logo-carousel__prev",clone:"clone",pagination:"logo-carousel__pagination",paginationDot:"logo-carousel__pagination-dot",paginationDotActive:"logo-carousel__pagination-dot--active",navigarionWrapper:"logo-carousel__navigation-wrapper",mediumTile:"medium-tile",mLeft:"m-left",mRight:"m-right",sLeft:"s-left",sRight:"s-right",center:"center",resize:"resize",objectFit:"object-fit"};
var b=function(){function u(N){_classCallCheck(this,u);
this.$settings={items:2,step:1,speed:300,start:0,centerItem:2,shift:0};
this.$xDown=null;
this.$yDown=null;
this.$itemWidth=0;
this.$trackWidth=0;
this.$trackPosition=0;
this.$startPosition=0;
this.$endPosition=0;
this.$isActive=false;
this.$isEnd=false;
this.$isStart=false;
this.$tileIndex=0;
this.$moveDirection=null;
this.$steps=0;
this.$resizeTile=false;
this.$el=N[0];
this.$items=[];
this.$tilesContainer=this.$el.querySelector(".".concat(d.tileContainer));
this.$tilePreview=this.$el.querySelector(".".concat(d.tilePreview));
this.$tilesTrack=this.$el.querySelector(".".concat(d.tilesTrack));
this.$tileContainer=this.$el.querySelector(".".concat(d.tileContainer));
this.$next=this.$el.querySelector(".".concat(d.next));
this.$prev=this.$el.querySelector(".".concat(d.prev));
this.$pagination=this.$el.querySelector(".".concat(d.pagination));
this.$originItems=Array.prototype.slice.call(this.$el.querySelectorAll(".".concat(d.tileContainer)));
this.$naviagationWrapper=this.$el.querySelector(".".concat(d.navigarionWrapper));
this.nextButClickHandler=this.nextButClickHandler.bind(this);
this.prevButClickHandler=this.prevButClickHandler.bind(this);
this.transitionEndEventHandler=this.transitionEndEventHandler.bind(this);
this.resizeEventHandler=this.resizeEventHandler.bind(this);
this.tileClickHandler=this.tileClickHandler.bind(this);
this.keysNavigation=this.keysNavigation.bind(this);
this.paginationKeyHanler=this.paginationKeyHanler.bind(this);
this.handleTouchMove=this.handleTouchMove.bind(this);
this.handleTouchStart=this.handleTouchStart.bind(this);
this.detectIE();
this.init()
}_createClass(u,[{key:"detectIE",value:function E(){var O=c.isInternetExplorer();
if(O){var N=this.$el.querySelectorAll("img");
var P=Array.from(N);
P.forEach(function(R){var S=R.src;
var Q=R.parentNode;
var T=document.createElement("div");
if(S){T.style.backgroundImage="url(".concat(S,")");
T.classList.add(d.objectFit);
Q.removeChild(R);
Q.appendChild(T)
}})
}}},{key:"appendChild",value:function s(N,O){O.forEach(function(P){N.appendChild(P)
})
}},{key:"initUI",value:function J(){var P=document.createElement("div");
var N=Array.from(this.$originItems);
if(this.$settings.items===3){var Q=N[N.length-1];
N.splice(N.length-1,1);
N.unshift(Q)
}else{if(this.$settings.items===5){var O=N.slice(N.length-2,N.length);
N.splice(N.length-2,N.length);
N.unshift.apply(N,_toConsumableArray(O))
}}var S=N.slice(N.length-this.$settings.items,N.length).map(function(T){var U=T.cloneNode(true);
U.classList.add(d.clone);
return U
});
var R=N.slice(0,this.$settings.items).map(function(T){var U=T.cloneNode(true);
U.classList.add(d.clone);
return U
});
this.$items=Array.prototype.concat.call(S,N,R);
if(this.$resizeTile){this.$el.classList.add(d.resize)
}else{if(this.$items[0].classList.contains(d.resize)){this.$el.classList.remove(d.resize)
}}this.$tilePreview.removeChild(this.$tilesTrack);
this.$tilesTrack=P;
this.$tilesTrack.classList.add(d.tilesTrack);
this.appendChild(this.$tilesTrack,this.$items);
this.$tilePreview.appendChild(this.$tilesTrack)
}},{key:"initItemWidth",value:function p(){this.$itemWidth=Math.floor(this.$tilePreview.offsetWidth/this.$settings.items)
}},{key:"initTrackWidth",value:function j(){this.$trackWidth=this.$itemWidth*this.$items.length;
this.$tilesTrack.style.width=this.$trackWidth+"px"
}},{key:"next",value:function x(){if(this.$items.length===1){return
}this.$trackPosition-=this.$itemWidth*this.$settings.step;
this.move();
this.animateTile("next")
}},{key:"prev",value:function w(){if(this.$items.length===1){return
}this.$trackPosition+=this.$itemWidth*this.$settings.step;
this.move();
this.animateTile("prev")
}},{key:"move",value:function y(){this.$tilesTrack.style.transition="transform ".concat(this.$settings.speed,"ms ease");
this.$tilesTrack.style.transform="translate3d(".concat(this.$trackPosition,"px,0,0)");
this.updatePagination()
}},{key:"nextButClickHandler",value:function i(){if(this.$isActive){return
}this.$isActive=true;
this.next()
}},{key:"prevButClickHandler",value:function e(){if(this.$isActive){return
}this.$isActive=true;
this.prev()
}},{key:"setTrackPosition",value:function r(){this.$tilesTrack.style.transitionProperty="none";
this.$tilesTrack.style.transform="translate3d(".concat(this.$trackPosition,"px,0,0)")
}},{key:"setTrackStartPosition",value:function g(){if(this.$items.length===1){this.$trackPosition=0
}else{this.$startPosition=(this.$settings.start+this.$settings.items)*this.$itemWidth;
this.$trackPosition=this.$startPosition*-1
}this.setTrackPosition()
}},{key:"setTrackEndPosition",value:function B(){this.$endPosition=Math.abs(this.$trackPosition)-this.$itemWidth*(this.$items.length-this.$settings.items*2);
this.$trackPosition=this.$endPosition;
this.setTrackPosition()
}},{key:"transitionEndEventHandler",value:function F(N){var O=this;
if(!N.target.classList.contains(d.tilesTrack)){return
}if(this.$items.length!==1){this.$isEnd=Math.abs(this.$trackPosition)===this.$trackWidth-this.$itemWidth*this.$settings.items;
if(this.$isEnd){this.setTrackStartPosition()
}this.$isStart=Math.abs(this.$trackPosition)===0;
if(this.$isStart){this.setTrackEndPosition()
}}this.$isActive=false;
setTimeout(function(){O.tileMove()
},0)
}},{key:"goTo",value:function L(N){this.$trackPosition=-(N*this.$itemWidth);
this.$tileIndex=N;
this.move();
this.animateTile()
}},{key:"updatePagination",value:function l(){var N=0;
N=Math.abs(this.$trackPosition)/this.$itemWidth-this.$settings.items;
if(N===this.$items.length-this.$settings.items*2){N=0
}else{if(N<0){N=this.$items.length-this.$settings.items*2+N
}}var P=this.$el.querySelectorAll(".".concat(d.paginationDot));
var O=Array.from(P);
O.forEach(function(Q){return Q.classList.remove(d.paginationDotActive)
});
O[N].classList.add(d.paginationDotActive)
}},{key:"createPagination",value:function G(){var R=this;
var P=document.createElement("div");
var O=null;
var Q=[];
for(var N=0;
N<this.$originItems.length;
N++){O=document.createElement("div");
O.classList.add(d.paginationDot);
O.tabIndex=0;
Q.push(O)
}Q.forEach(function(U,S){var T=S+R.$settings.items;
U.addEventListener("click",function(){return R.goTo(T)
})
});
this.appendChild(P,Q);
this.$pagination.innerHTML="";
this.$pagination.appendChild(P)
}},{key:"resizeEventHandler",value:function f(){this.init()
}},{key:"animateTile",value:function h(P){this.$items.forEach(function(Q){Q.firstElementChild.style.transform="";
Q.classList.remove(d.center,d.mLeft,d.mRight,d.sLeft,d.sRight)
});
var N=Math.abs(this.$trackPosition)===this.$trackWidth-this.$itemWidth*this.$settings.items;
var O=Math.abs(this.$trackPosition)===0;
if(O||N){this.$tileIndex=O?this.$tileIndex-1:this.$tileIndex+1;
this.applyTileStyle();
this.changeTileIndex(P);
this.applyTileStyle()
}else{this.changeTileIndex(P);
this.applyTileStyle()
}}},{key:"applyTileStyle",value:function k(){var O=this;
var Q=function Q(R,U,S,T){O.$items[R].firstElementChild.style.transform=U;
O.$items[R].firstElementChild.style.transition=S;
O.$items[R].setAttribute("data-index",T);
O.$items[R].classList.add(T)
};
if(this.$settings.items===2){this.$items[this.$tileIndex].setAttribute("data-index",d.mLeft);
this.$items[this.$tileIndex+1].setAttribute("data-index",d.mRight);
return
}else{if(this.$settings.items===3||this.$settings.items===5){var P=this.$settings.items===5?28:0;
var N="transform ".concat(this.$settings.speed,"ms ease 0ms");
Q(this.$tileIndex+this.$settings.centerItem-1,"scale(1.18, 1.2) translateX(-"+P+"px)",N,d.mLeft);
Q(this.$tileIndex+this.$settings.centerItem,"scale(1.555, 1.6)",N,d.center);
Q(this.$tileIndex+this.$settings.centerItem+1,"scale(1.18, 1.2) translateX("+P+"px)",N,d.mRight);
if(this.$settings.items===5){Q(this.checkNextTileIndex(this.$tileIndex+this.$settings.centerItem-2),"translateX(-18px)",N,d.sLeft);
Q(this.checkNextTileIndex(this.$tileIndex+this.$settings.centerItem+2),"translateX(20px)",N,d.sRight)
}}}}},{key:"checkNextTileIndex",value:function z(N){if(N>=this.$items.length){return 0+this.$settings.items
}if(N<=0){return this.$items.length-this.$settings.items*2
}return N
}},{key:"changeTileIndex",value:function M(N){if(N==="next"){this.incTileIndex()
}else{if(N==="prev"){this.decTileIndex()
}}}},{key:"incTileIndex",value:function o(){if(this.$tileIndex>=this.$items.length-this.$settings.items-1){this.$tileIndex=this.$settings.items;
return
}this.$tileIndex=this.$tileIndex+1
}},{key:"decTileIndex",value:function K(){this.$tileIndex=this.$tileIndex-1;
if(this.$tileIndex<=0){this.$tileIndex=this.$items.length-this.$settings.items*2
}}},{key:"initEventsListener",value:function v(){this.$next.addEventListener("click",this.nextButClickHandler);
this.$prev.addEventListener("click",this.prevButClickHandler);
this.$tilesTrack.addEventListener("transitionend",this.transitionEndEventHandler);
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler,300));
this.$naviagationWrapper.addEventListener("click",this.tileClickHandler);
this.$tilePreview.addEventListener("keydown",this.keysNavigation);
this.$pagination.addEventListener("keydown",this.paginationKeyHanler);
this.$el.addEventListener("touchstart",this.handleTouchStart,{passive:true});
this.$el.addEventListener("touchmove",this.handleTouchMove,{passive:true})
}},{key:"getTouches",value:function D(N){return N.touches||N.originalEvent.touches
}},{key:"handleTouchStart",value:function n(N){var O=this.getTouches(N)[0];
this.$xDown=O.clientX;
this.$yDown=O.clientY
}},{key:"handleTouchMove",value:function q(N){if(!this.$xDown||!this.$yDown){return
}var Q=N.touches[0].clientX;
var O=N.touches[0].clientY;
var R=this.$xDown-Q;
var P=this.$yDown-O;
if(Math.abs(R)>Math.abs(P)){if(R>0){this.nextButClickHandler()
}else{this.prevButClickHandler()
}}this.$xDown=null;
this.$yDown=null
}},{key:"paginationKeyHanler",value:function I(N){var P=N.keyCode,O=N.target;
if(P===13){O.click()
}}},{key:"tileClickHandler",value:function m(R){var O=R.target;
var P=O.tagName;
var N=null;
var T=P.localeCompare("IMG");
var S=O.classList.contains(d.tile);
var Q=null;
if(T===0){Q=O.parentNode.parentNode;
N=Q.getAttribute("data-index")
}else{if(S){Q=O.parentNode;
N=Q.getAttribute("data-index")
}}switch(N){case d.sLeft:this.$moveDirection="prev";
this.$steps=2;
break;
case d.mLeft:this.$moveDirection="prev";
this.$steps=1;
break;
case d.sRight:this.$moveDirection="next";
this.$steps=2;
break;
case d.mRight:this.$moveDirection="next";
this.$steps=1;
break;
default:this.$moveDirection=null;
this.$steps=0;
return
}this.tileMove()
}},{key:"tileMove",value:function t(){if(this.$steps===0||this.$moveDirection===null){return
}this.$steps--;
if(this.$moveDirection==="next"){this.nextButClickHandler()
}else{if(this.$moveDirection==="prev"){this.prevButClickHandler()
}}}},{key:"keysNavigation",value:function H(N){var O=N.keyCode;
if(O===39){this.nextButClickHandler()
}if(O===37){this.prevButClickHandler()
}}},{key:"setItemsCount",value:function A(){this.$tilePreview.style.width="";
var N=this.$tilePreview.offsetWidth;
this.$resizeTile=false;
if(N===222){this.$settings.items=1;
this.$tileIndex=1
}else{if(N===444){this.$settings.items=2;
this.$tileIndex=2
}else{if(N===788){this.$settings.items=3;
this.$tileIndex=3;
this.$settings.centerItem=1
}else{if(this.$originItems.length>=5){this.$settings.items=5;
this.$tileIndex=5;
this.$settings.centerItem=2
}else{this.$settings.items=3;
this.$tileIndex=3;
this.$settings.centerItem=1;
this.$tilePreview.style.width=788+"px";
this.$resizeTile=true
}}}}}},{key:"init",value:function C(){this.setItemsCount();
this.initUI();
this.createPagination();
this.initItemWidth();
this.initTrackWidth();
this.setTrackStartPosition();
this.updatePagination();
this.animateTile();
this.initEventsListener()
}}]);
return u
}();
b.moduleName="Logo Carousel";
b.selector=".logo-carousel-ui";
return b
});
define("MultipleTopicsList",["utils","utils-env","RequestAnimationFrame"],function(a,d,e){var c={title:".multiple-topics-list__title-item",content:".multiple-topics-list__content",blockContent:".multiple-topics-list__block-content",contentWrapper:".multiple-topics-list__content-wrapper",hidden:"hidden",active:"active",dropdown:".multiple-topics-list__dropdown",dropdownButton:".multiple-topics-list__dropdown-button",dropdownButtonOpen:"multiple-topics-list__dropdown-button--open",dropdownContent:".multiple-topics-list__dropdown-content",dropdownContentItem:".multiple-topics-list__dropdown-content-item",hideDivider:"multiple-topics-list__title-item-no-divider",yellowLine:".multiple-topics-list__animation-placeholder",animated:"animated"};
var b=function(){function n(s){_classCallCheck(this,n);
this.$el=s;
this.$title=this.$el.find(c.title);
this.$contentWrapper=this.$el.find(c.contentWrapper);
this.$content=this.$el.find(c.content);
this.$dropdown=this.$el.find(c.dropdown);
this.$dropdownButton=this.$el.find(c.dropdownButton);
this.$dropdownContent=this.$el.find(c.dropdownContent);
this.$dropdownContentItem=this.$el.find(c.dropdownContentItem);
this.$yellowLine=this.$el.find(c.yellowLine);
this.activeSlideId=$(this.$title[0]).attr("title-id");
this.slidesWithAnimation=[];
if(!d.isEditMode()){this.init();
this.setActiveTitle(this.activeSlideId,false)
}a.checkDividers(this.$title,c.hideDivider)
}_createClass(n,[{key:"init",value:function p(){var s=this;
this.$title.click(function(){s.switchContentOnClick($(this))
});
this.$dropdown.click(this.toggleDropdown.bind(this));
this.$dropdownContentItem.click(this.toggleDropdown.bind(this));
if(this.$el.hasClass(c.animated)){for(var t=0;
t<this.$yellowLine.length;
t++){this.loadAnimation(t)
}}this.setActiveSlideByAnchor();
this.scrollToElement()
}},{key:"scrollToElement",value:function j(){var s=70;
var t=window.location.hash.replace("#","");
if(t){$("html, body").animate({scrollTop:$("#"+t).offset().top-s},100)
}}},{key:"getActiveSlideIndexById",value:function g(u){var s=this.$content.toArray();
var t=s.findIndex(function(v){return v.getAttribute("content-id")===u
});
return t
}},{key:"runAnimation",value:function f(){e.increaseAnimationQueue({func:this.runAnimationSuccess.bind(this),isEnd:this.isAnimationEnd.bind(this)})
}},{key:"scrollToContent",value:function k(){var s=30;
var u=1024;
var t=$(window).width()<u?s:50;
$("html, body").animate({scrollTop:this.$contentWrapper.offset().top-t},100)
}},{key:"isAnimationEnd",value:function i(){return this.isAnimationRun
}},{key:"loadAnimation",value:function h(s){if(this.slidesWithAnimation.indexOf(s)===-1){this.slidesWithAnimation.push(s);
this.delayAnimation=bodymovin.loadAnimation({container:this.$yellowLine[s],renderer:"svg",loop:false,autoplay:true,path:"/etc/designs/epam-com/json-animations/yellow-curve-1.json",rendererSettings:{viewBoxOnly:true}});
this.delayAnimation.addEventListener("DOMLoaded",this.runAnimation.bind(this))
}}},{key:"runAnimationSuccess",value:function r(){if(this.isAnimationRun){return
}if(a.isElementInViewport(this.$el[0])){this.isAnimationRun=true;
this.delayAnimation.goToAndPlay(0)
}}},{key:"switchContentOnClick",value:function o(u){if(u.attr("title-id")){var t=u.attr("title-id");
this.setActiveTitle(t)
}else{var s=u.attr("mobile-title-id");
this.setActiveTitle(s)
}this.scrollToContent()
}},{key:"setActiveSlideByAnchor",value:function q(){var s=window.location.href.split("#")[1];
if(s){var u=this.$title.toArray().find(function(v){return s===v.getAttribute("id")
});
if(u){var t=u.getAttribute("title-id");
this.setActiveTitle(t)
}}}},{key:"setActiveTitle",value:function m(s){var u=arguments.length>1&&arguments[1]!==undefined?arguments[1]:true;
var z=this.$el.find('[title-id="'+s+'"]');
var y=this.$el.find('[mobile-title-id="'+s+'"]');
var v=this.$el.find('[content-id="'+s+'"]');
var B=$(z).text();
this.$dropdownButton.text(B);
z.addClass(c.active);
v.removeClass(c.hidden);
if(u){var w=v.find(c.blockContent);
w.focus()
}y.addClass(c.active);
if(this.activeSlideId!==s){var A=this.$el.find('[title-id="'+this.activeSlideId+'"]');
var t=this.$el.find('[mobile-title-id="'+this.activeSlideId+'"]');
var x=this.$el.find('[content-id="'+this.activeSlideId+'"]');
A.removeClass(c.active);
x.addClass(c.hidden);
t.removeClass(c.active);
this.activeSlideId=s
}}},{key:"toggleDropdown",value:function l(s){s.stopPropagation();
if(this.$dropdownContent.hasClass(c.hidden)){this.$dropdownContent.removeClass(c.hidden);
this.$dropdownButton.removeClass(c.dropdownButtonOpen)
}else{this.$dropdownContent.addClass(c.hidden);
this.$dropdownButton.addClass(c.dropdownButtonOpen)
}}}]);
return n
}();
b.moduleName="Multiple Topics List";
b.selector=".multiple-topics-list-ui";
return b
});
define("RolloverTiles",[],function(){var d={BLOCK:"rollover-tiles__block",ROLLOVER_BLOCK:"rollover-tiles__block--rollover",LINK:"rollover-tiles__link",LINK_A11Y:"rollover-tiles__link--a11y",ROLLOVER_TILE:"rollover-tiles__description--rollover",ROLLOVER_TEXT:"rollover-tiles__text"};
var c="(min-width: 768px)";
var b="(min-width: 1025px)";
var a=function(){function f(l){_classCallCheck(this,f);
this.el=l[0];
var k=window.matchMedia(b).matches;
var j=!k&&window.matchMedia(c).matches;
if(k||j){this.links=this.el.querySelectorAll("."+d.LINK)
}if(k){this.addEventListeners()
}else{if(j){this.changeLinksAriaLabels()
}}}_createClass(f,[{key:"addEventListeners",value:function i(){var j=this;
var k=this.el.querySelectorAll("."+d.BLOCK);
k.forEach(function(o,m){var l=o.querySelector("."+d.LINK_A11Y);
var n=o.querySelector("."+d.ROLLOVER_TILE);
if(l){l.removeAttribute("aria-hidden");
l.removeAttribute("tabindex");
j.addEventListenerToLinkA11y(o,l,n);
j.addEventListenerToRolloverTile(o,j.links[m],n)
}})
}},{key:"addEventListenerToLinkA11y",value:function e(l,j,k){j.addEventListener("click",function(m){m.preventDefault();
if(k){k.removeAttribute("aria-hidden");
k.setAttribute("tabindex",0);
k.focus();
l.classList.add(d.ROLLOVER_BLOCK)
}})
}},{key:"addEventListenerToRolloverTile",value:function h(l,k,j){j.addEventListener("click",function(){k.click()
});
j.addEventListener("blur",function(){setTimeout(function(){j.removeAttribute("tabindex");
j.setAttribute("aria-hidden",true);
l.classList.remove(d.ROLLOVER_BLOCK)
},40)
})
}},{key:"changeLinksAriaLabels",value:function g(){this.links.forEach(function(k){var l=k.getAttribute("aria-label");
var j=k.querySelector("."+d.ROLLOVER_TEXT).innerText;
k.setAttribute("aria-label",l+"\n"+j)
})
}}]);
return f
}();
a.moduleName="Rollover Tiles";
a.selector=".rollover-tiles-ui";
return a
});
define("VideoShowcasesClasses",[],function(){return{PLAYER:"video-showcase__player-section",VIDEO:"video-showcase__video",VIDEO_TITLE:"video-showcase__title",VIDEO_TITLE_ACTIVE:"video-showcase__title--active",OVERLAY_ICONS:"video-showcase__overlay-icons",OVERLAY_PLAY_ACTIVE:"overlay-play-active",OVERLAY_PAUSE_ACTIVE:"overlay-pause-active",PROGRESS_BAR:"video-showcase__progress-bar",DURATION:"video-showcase__duration",TIME_ELAPSED:"video-showcase__time-elapsed",VOLUME_BUTTON:"video-showcase__volume-button",VOLUME_ICONS:"video-showcase__volume-button svg",VOLUME_HIGH:"volume-high",VOLUME_LOW:"volume-low",VOLUME_MUTE:"volume-mute",VOLUME:"video-showcase__volume",FULLSCREEN_BUTTON:"video-showcase__fullscreen-button",PLAY_BUTTON:"video-showcase__play-button",CONTROL_SECTION:"video-showcase__controls-section",SLIDER_IMG_WRAPPER:"video-showcase__img-wrapper",TRAY_SEEK:"video-showcase__tray-seek",DELAY_PLAY:"video-showcase__delay-play",WAIT_FOR_PLAY:"video-showcase__wait-for-play",OWL:"owl-carousel",NEXT_ICON:"video-showcase__nav-control-next",PREV_ICON:"video-showcase__nav-control-prev",BLACK_FRAME:"video-showcase__black-frame",VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS:"video-showcase__progress-bar-progress",VIDEO_SHOWCASE_PROGRESS_BAR_TRACK:"video-showcase__progress-bar-track",VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA:"video-showcase__progress-bar-hidden-area",events:{PLAY_EVENT:"customPlayEvent",PAUSE_EVENT:"customPauseEvent",PLAY_FROM_START:"customPlayFromStartEvent",PLAY_TILE_EVENT:"customTilePlayEvent",NEW_LOAD_REQUEST:"customNewLoadEvent"}}
});
define("VideoShowcases",["utils-browser","utils","VideoShowcasePlayerFunctions","VideoShowcasesInitA11Y","VideoShowcasesClasses","utils-env"],function(d,a,c,f,e,h){var g=!!document.createElement("video").canPlayType;
var b=function(){function A(I){_classCallCheck(this,A);
this.$el=I[0];
this.isIE=d.isInternetExplorer();
this.$player=this.$el.querySelector("."+e.PLAYER);
this.$video=this.$el.querySelector("."+e.VIDEO);
this.$owl=$(this.$el.querySelector("."+e.OWL));
this.$isHideSlider=this.$el.dataset.hideCarousel;
this.$videoSliderItems=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
this.$videoTitleActive=this.$el.querySelector("."+e.VIDEO_TITLE_ACTIVE);
this.$progressBar=this.$el.querySelector("."+e.PROGRESS_BAR);
this.$controlSection=this.$el.querySelector("."+e.CONTROL_SECTION);
this.$duration=this.$el.querySelector("."+e.DURATION);
this.$timeElapsed=this.$el.querySelector("."+e.TIME_ELAPSED);
this.$overlayIcons=this.$el.querySelector("."+e.OVERLAY_ICONS);
this.$volumeButton=this.$el.querySelector("."+e.VOLUME_BUTTON);
this.$volumeIcons=this.$el.querySelectorAll("."+e.VOLUME_ICONS);
this.$volumeLow=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(2)");
this.$volumeHigh=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(3)");
this.$volumeMute=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(1)");
this.$volume=this.$el.querySelector("."+e.VOLUME);
this.$fullscreenButton=this.$el.querySelector("."+e.FULLSCREEN_BUTTON);
this.$playButton=this.$el.querySelector("."+e.PLAY_BUTTON);
this.$delayPlayContainer=this.$el.querySelector("."+e.DELAY_PLAY);
this.$waitForPlay=this.$el.querySelector("."+e.WAIT_FOR_PLAY);
this.nextIcon=this.$el.querySelector("."+e.NEXT_ICON);
this.prevIcon=this.$el.querySelector("."+e.PREV_ICON);
this.blackFrame=this.$el.querySelector("."+e.BLACK_FRAME);
this.$videoProgressBar=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS);
this.$videoProgressBarTrack=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_TRACK);
this.$videoProgressBarHiddenArea=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA);
this.isFirstPlay=true;
this.isOverlayRemoved=false;
this.activeVideoIndex=0;
this.userClick=false;
this.delayPlayRemoved=true;
this.activeIndex=[];
this.owlItems=[];
this.fromStart=false;
this.promisePending=false;
this.publishMode=!h.isEditMode();
this.customPlayEvent=document.createEvent("Event");
this.customPauseEvent=document.createEvent("Event");
this.customPlayFromStartEvent=document.createEvent("Event");
this.customTilePlayEvent=document.createEvent("Event");
this.customNewLoadRequestEvent=document.createEvent("Event");
this.customPlayEvent.initEvent(e.events.PLAY_EVENT,true,true);
this.customPauseEvent.initEvent(e.events.PAUSE_EVENT,true,true);
this.customPlayFromStartEvent.initEvent(e.events.PLAY_FROM_START,true,true);
this.customTilePlayEvent.initEvent(e.events.PLAY_TILE_EVENT,true,true);
this.customNewLoadRequestEvent.initEvent(e.events.NEW_LOAD_REQUEST,true,true);
this.init()
}_createClass(A,[{key:"init",value:function F(){this.setDefaultVideo();
this.initOwlCarousel();
if(this.publishMode){this.setDefaultVideo();
this.initEventsHandlers(this);
this.setVideoIndex();
this.initOwlCarousel();
f.loadDelayPlayIconAnimation.call(this);
this.activeTraySeek();
if(this.isIE||d.detectIOSDevice()){c.removeVideoOverlay.call(this)
}else{f.loadWaitAnimation.call(this);
this.isSupportPlayer();
this.customVideoEvents()
}}}},{key:"setVideoIndex",value:function s(){Array.prototype.forEach.call(this.$videoSliderItems,function(J,I){J.setAttribute("data-index",I)
})
}},{key:"initOwlCarousel",value:function r(){if(this.$isHideSlider==="1"){this.$el.querySelector(".video-showcase__slider-section").classList.add("hidden");
return
}var I=this.$videoSliderItems.length>3;
var J=this.$videoSliderItems.length>3?3:this.$videoSliderItems.length;
this.$owl.on("initialized.owl.carousel",function(){if(this.publishMode){f.initA11y.call(this);
f.stopVideoBySpaceA11y.call(this)
}this.$owl.on("refreshed.owl.carousel",function(){this.removeOwlAriaAttr();
f.reInitA11yAttr.call(this)
}.bind(this))
}.bind(this));
this.$owl.addClass("owl-item-count-"+J);
this.$owl.owlCarousel({nav:true,dots:false,items:J,responsive:false,mouseDrag:I,loop:I,navText:[this.prevIcon,this.nextIcon],navElement:"div"});
this.$owl[0].removeAttribute("style")
}},{key:"isSupportPlayer",value:function u(){if(g){this.$video.controls=false;
this.$controlSection.classList.remove("hidden");
c.updateVolumeIcon.call(this);
this.$normalProgressbarLength=this.$videoProgressBar.getBoundingClientRect().width;
this.$videoProgressBarLen=function(){return this.getBoundingClientRect().width
}.bind(this.$videoProgressBar)
}}},{key:"setDefaultVideo",value:function y(J){var I=J?J:this.$videoSliderItems[0];
if(I){this.changeActiveVideo(this.getVideoDataFromItem(I));
this.$video.load()
}}},{key:"delayPlayHandler",value:function q(){this.blackFrame.classList.add("hidden");
c.removeDelayPlay.call(this);
c.togglePlay.call(this)
}},{key:"sliderClickHandler",value:function x(J){var L=J.target;
var I=768;
if(this.isIE||L.tagName==="svg"||L.tagName==="use"||$(L).hasClass("video-showcase__img-wrapper-overlay")||$(L).hasClass("video-showcase__tray-text")||$(window).width()<I){var K=$(L).closest("."+e.SLIDER_IMG_WRAPPER);
if(K.length!==0){this.videoSlideClick(K.data().index,K[0])
}}}},{key:"videoSlideClick",value:function B(I,J){this.tileState=$(J).hasClass("active")||$(J).hasClass("pause");
!this.isFirstPlay&&c.saveVideoProgress.call(this);
this.activeVideoIndex=I;
this.activeItem=J;
this.fixPlayerHeight();
this.$video.classList.add("video-showcase__invincible");
this.changeActiveTile(J,I);
this.changeActiveVideo(this.getVideoDataFromItem(J));
this.$video.dispatchEvent(this.customNewLoadRequestEvent)
}},{key:"clearPlayerStyleProperties",value:function p(){this.$video.classList.remove("video-showcase__invincible");
this.$player.removeAttribute("style")
}},{key:"changeActiveTile",value:function k(K,I){var N=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
for(var J=0;
J<N.length;
J++){N[J].classList.remove("active");
N[J].classList.remove("pause")
}var M=this.$el.querySelectorAll('[data-index="'+I+'"]');
for(var L=0;
L<M.length;
L++){M[L].classList.add("active")
}}},{key:"getVideoDataFromItem",value:function n(I){return I?{sources:I.querySelector("img").getAttribute("data-source"),poster:I.querySelector("img").getAttribute("poster-source"),title:I.dataset.title}:null
}},{key:"changeActiveVideo",value:function D(J){var K=this;
var I=J.sources,M=J.poster,L=J.title;
this.$video.innerHTML="";
if(this.isFirstPlay){this.$video.poster=M
}JSON.parse(I).forEach(function(N){var O=N.type,Q=N.src;
var P=document.createElement("source");
P.setAttribute("type",O);
P.setAttribute("src",Q);
K.$video.appendChild(P)
});
if(!L){this.$videoTitleActive.classList.add("hidden")
}else{this.$videoTitleActive.classList.remove("hidden");
if(this.$videoTitleActive){this.$videoTitleActive.textContent=L
}}}},{key:"initializeVideo",value:function C(){var I=this;
this.videoDuration=Math.floor(this.$video.duration);
var J=c.formatTime(this.videoDuration);
this.$duration.innerText=J.minutes+":"+J.seconds;
this.$duration.setAttribute("datetime",J.minutes+"m "+J.seconds+"s");
if(this.traySeek!==undefined){this.traySeek.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.setAttribute("max",this.videoDuration)
}if(!this.isFirstPlay&&!this.fromStart){c.applyVideoProgress.call(this)
}this.fromStart=false;
$.each(this.activeIndex,function(K,L){$(I.owlItems[L]).removeClass("hide-tray-seek")
})
}},{key:"loadMetadataCallback",value:function G(){this.initializeVideo();
this.clearPlayerStyleProperties()
}},{key:"updatePlayButton",value:function w(){this.$playButton.classList.toggle("play")
}},{key:"updateFullscreenButton",value:function v(){this.$fullscreenButton.classList.toggle("fullscreen")
}},{key:"videoBorderTracker",value:function t(){var I=this.$el.getBoundingClientRect().top;
var O=window.pageYOffset||document.documentElement.scrollTop;
var K=O+I;
var J=O+I+this.$video.offsetHeight;
var N=O;
var M=N+window.innerHeight;
var L=function(){if(!this.$video.paused){c.togglePlay.call(this)
}}.bind(this);
if(N>J){L();
return
}if(M<K){L();
return
}}},{key:"activeTraySeek",value:function m(){this.activeIndex=[];
this.owlItems=$(this.$el).find(".owl-item");
$.each(this.owlItems,function(I,K){var L=$(K).find("."+e.VIDEO_TITLE)[0];
if(L){K.dataset.title=L.textContent
}$(K).addClass("hide-tray-seek");
var J=$(K).find('[data-index="'+this.activeVideoIndex+'"]');
if(J.length!==0){this.activeIndex.push(I)
}}.bind(this));
if(this.owlItems[this.activeIndex[0]]!==undefined){this.traySeek=this.owlItems[this.activeIndex[0]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[1]]!==undefined){this.clonedTraySeekStart=this.owlItems[this.activeIndex[1]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[2]]!==undefined){this.clonedTraySeekEnd=this.owlItems[this.activeIndex[2]].querySelector("."+e.TRAY_SEEK)
}}},{key:"mouseMove",value:function o(){this.$player.classList.add("mouse-move");
if(this.setTimeoutId!==undefined||this.setTimeoutId!==null){clearTimeout(this.setTimeoutId)
}this.setTimeoutId=setTimeout(function(){this.$player.classList.remove("mouse-move");
this.setTimeoutId=null
}.bind(this),15000)
}},{key:"fixPlayerHeight",value:function i(){var I=this.$player.getBoundingClientRect();
this.$player.setAttribute("style","height:"+I.height+"px")
}},{key:"resizeEventHandler",value:function l(){this.$owl.trigger("refresh.owl.carousel")
}},{key:"removeOwlAriaAttr",value:function H(){var J=this.$el.querySelectorAll('[role="tab"]');
for(var I=0;
I<J.length;
I++){J[I].removeAttribute("tabindex");
J[I].removeAttribute("aria-selected");
J[I].removeAttribute("role")
}}},{key:"customVideoEvents",value:function E(){this.$video.addEventListener("timeupdate",c.timeUpdate.bind(this));
this.$volume.addEventListener("input",c.updateVolume.bind(this));
this.$video.addEventListener("volumechange",c.updateVolumeIcon.bind(this));
this.$player.addEventListener("click",c.playerClick.bind(this));
this.$player.addEventListener("fullscreenchange",this.updateFullscreenButton.bind(this));
this.$player.addEventListener("mousemove",a.debounceExtend(this.mouseMove.bind(this),100))
}},{key:"initEventsHandlers",value:function j(){this.$video.addEventListener("timeupdate",c.updateTrayProgress.bind(this));
this.$video.addEventListener("ended",c.videoEnded.bind(this));
this.$video.addEventListener("loadedmetadata",this.loadMetadataCallback.bind(this));
this.$video.addEventListener("canplay",c.videoCanPlayEvent.bind(this));
this.$video.addEventListener("waiting",c.videoWaitEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_EVENT,c.handlePlayEvent.bind(this));
this.$video.addEventListener(e.events.PAUSE_EVENT,c.handlePauseEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_FROM_START,c.handlePlayFromStartEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_TILE_EVENT,c.handlePLayTileEvent.bind(this));
this.$video.addEventListener(e.events.NEW_LOAD_REQUEST,c.handleNewLoadEvent.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("click",c.progressBarClickHandler.bind(this));
this.$owl[0].addEventListener("click",this.sliderClickHandler.bind(this));
window.addEventListener("scroll",a.debounceExtend(this.videoBorderTracker.bind(this),100));
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler.bind(this),300));
this.initMouseMoveEvents()
}},{key:"initMouseMoveEvents",value:function z(){this.$videoProgressBarHiddenArea.addEventListener("mousedown",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("mouseup",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mouseleave",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mousemove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchmove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchstart",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("touchend",c.changeMouseState.bind(this,false))
}}]);
return A
}();
b.moduleName="Video Showcases";
b.selector=".video-showcase-ui";
return b
});
define("VideoShowcasesInitA11Y",["utils","VideoShowcasePlayerFunctions","VideoShowcaseA11y"],function(l,c,a){function b(m){if(this.$videoSliderItems.length>3){m(this);
this.$owl.trigger("to.owl.carousel",[this.currentSlide,0])
}}function k(){b.call(this,function(){if(this.$videoSliderItems.length-1>=this.currentSlideindex){this.currentSlideindex=0
}}.bind(this))
}function f(){b.call(this,function(){this.currentSlideindex--;
if(this.currentSlideindex<=0){this.currentSlideindex=this.$videoSliderItems.length-1
}}.bind(this))
}function d(n){var m=Number(n.querySelector(".video-showcase__img-wrapper").dataset.index);
if(this.activeVideoIndex===m){c.togglePlay.call(this);
return
}this.fixPlayerHeight();
this.videoSlideClick(m,n)
}function g(){$(this.$el).find(".owl-stage").addClass("a11y-navigation-panel");
a.init.call(this,{"list-item":"owl-item:not(.cloned)","move-forward-callback":k.bind(this),"move-downward-callback":f.bind(this),"enter-action":d.bind(this)})
}function h(){a.setSpecialAttribute.call(this)
}function i(){l.loadLottieFile({container:this.$waitForPlay,loop:true,autoplay:true,path:"/etc/designs/epam-com/json-animations/loading-balls.json"})
}function e(){this.delayAnimation=l.loadLottieFile({container:this.$delayPlayContainer,loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/delay-play.json"});
this.delayAnimation.addEventListener("complete",this.delayPlayHandler.bind(this))
}function j(){var n=this;
var m=this.$el.querySelector(".video-showcase__video-progress");
m.addEventListener("keydown",function(o){var p=o.keyCode;
if(p===32){c.togglePlay.call(n)
}})
}return{loadWaitAnimation:i,loadDelayPlayIconAnimation:e,initA11y:g,reInitA11yAttr:h,stopVideoBySpaceA11y:j}
});
define("VideoShowcasePlayerFunctions",["VideoShowcasesClasses"],function(g){function k(){if(this.$video.paused||this.$video.ended){this.$video.dispatchEvent(this.customPlayEvent)
}else{this.$video.dispatchEvent(this.customPauseEvent)
}}function r(){this.$video.play();
v.call(this);
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add");
n.call(this,g.OVERLAY_PAUSE_ACTIVE,g.OVERLAY_PLAY_ACTIVE)
}function N(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.promisePending=false;
O.$video.load();
O.tileState?O.$video.dispatchEvent(O.customPlayFromStartEvent):O.$video.dispatchEvent(O.customTilePlayEvent);
O.isFirstPlay=false
})
}}}function E(){this.activeTraySeek();
this.$video.play();
v.call(this);
y.call(this);
J.call(this,"play");
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add")
}function h(){this.fromStart=true;
this.$video.play()
}function i(O){O==="add"?this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.add("active"):this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.remove("active")
}function f(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.$video.pause();
O.promisePending=false;
J.call(O);
n.call(O,g.OVERLAY_PLAY_ACTIVE,g.OVERLAY_PAUSE_ACTIVE);
B(O.$playButton,"Play (k)","Pause (k)");
i.call(O,"remove")
})
}}}function n(P,Q){var O=this;
this.overlayTimerId&&clearTimeout(this.overlayTimerId);
this.$overlayIcons.classList.remove("hidden");
this.$player.classList.remove(P);
this.$player.classList.add(Q);
this.overlayTimerId=setTimeout(function(){O.$overlayIcons.classList.add("hidden")
},1000)
}function B(P,Q,O){var R=P.getAttribute("title");
var S=R===Q?O:Q;
P.setAttribute("title",S)
}function C(){sessionStorage.removeItem("track"+this.activeVideoIndex)
}function M(){this.$video.muted=!this.$video.muted;
if(this.$video.muted){this.$volume.setAttribute("data-volume",this.$volume.value);
this.$volume.value=0
}else{this.$volume.value=this.$volume.dataset.volume
}}function u(O){if(this.$video.muted){this.$video.muted=false
}this.$video.volume=this.$volume.value;
O.stopPropagation()
}function D(P){if(!isNaN(P)){var O=new Date(P*1000).toISOString().substr(11,8);
return{minutes:O.substr(3,2),seconds:O.substr(6,2)}
}}function p(){var O=D(Math.floor(this.$video.currentTime));
this.$timeElapsed.innerText=O.minutes+":"+O.seconds;
this.$timeElapsed.setAttribute("datetime",O.minutes+"m "+O.seconds+"s")
}function j(){if(this.videoDuration&&this.$videoProgressBarLen()){var P=F.call(this);
this.videoCurPosPercent=Math.round(P/this.videoDuration*100);
var O=this.$videoProgressBarLen()*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}}function a(){var O=this.$normalProgressbarLength*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}function G(){p.call(this);
j.call(this)
}function F(){return this.$video?Math.floor(this.$video.currentTime):null
}function d(){if(this.traySeek!==undefined){this.traySeek.value=F.call(this)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.value=F.call(this)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.value=F.call(this)
}}function I(){if(document.fullscreenElement){a.call(this);
document.exitFullscreen()
}else{if(document.webkitFullscreenElement){a.call(this);
document.webkitExitFullscreen()
}else{if(this.$player.requestFullscreen){this.$player.requestFullscreen()
}else{if(this.$player.webkitRequestFullscreen){this.$player.webkitRequestFullscreen()
}else{if(this.$player.mozRequestFullScreen){this.$player.mozRequestFullScreen()
}else{if(this.$player.msRequestFullscreen){this.$player.msRequestFullscreen()
}}}}}}}function L(){if(this.timerId){clearTimeout(this.timerId)
}}function K(){L.call(this);
this.$waitForPlay.classList.add("hidden")
}function l(){var O=this;
L.call(this);
this.timerId=setTimeout(function(){O.$waitForPlay.classList.remove("hidden")
},1000)
}function e(){this.$volumeIcons.forEach(function(O){O.classList.add("hidden")
});
this.$volumeButton.setAttribute("data-title","Mute (m)");
if(this.$video.muted||this.$video.volume===0){this.$volumeMute.classList.remove("hidden");
this.$volumeButton.setAttribute("data-title","Unmute (m)")
}else{if(this.$video.volume>0&&this.$video.volume<=0.5){this.$volumeLow.classList.remove("hidden")
}else{this.$volumeHigh.classList.remove("hidden")
}}this.$volume.setAttribute("aria-valuetext",this.$video.volume*100+"% volume")
}function o(){this.blackFrame.classList.remove("hidden");
this.fromStart=true;
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
C.call(this);
this.activeVideoIndex===this.$videoSliderItems.length-1?this.activeVideoIndex=0:this.activeVideoIndex+=1;
var P=this.$videoSliderItems[this.activeVideoIndex];
var O=P.querySelector("img").getAttribute("poster-source");
c.call(this,O);
this.changeActiveVideo(this.getVideoDataFromItem(P));
this.$video.load();
this.changeActiveTile(this.$videoSliderItems[this.activeVideoIndex],this.activeVideoIndex);
w.call(this);
this.$player.classList.add("delay-overlay");
this.$delayPlayContainer.classList.remove("hidden");
this.delayAnimation.goToAndPlay(0)
}function w(){this.$owl.trigger("next.owl.carousel");
this.activeTraySeek()
}function s(){if(this.$video.ended){return
}sessionStorage.setItem("track"+this.activeVideoIndex,this.$video.currentTime)
}function t(){var O=sessionStorage.getItem("track"+this.activeVideoIndex);
if(O){this.$video.currentTime=O
}}function v(){if(!this.isOverlayRemoved){this.$player.classList.remove("overlay");
this.$overlayIcons.classList.add("hidden");
this.isOverlayRemoved=true
}}function A(S){var T=S.target,Q=S.target.tagName;
var P=T.getAttribute("id");
var U=T;
var O=Q;
if($(U).hasClass("overlay")||O==="VIDEO"||P==="play"){k.call(this);
return
}if(P==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)");
return
}if(P==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)");
return
}if($(U).hasClass("delay-overlay")){y.call(this);
k.call(this);
return
}if(O==="use"){O="svg";
U=$(U).parent()[0]
}if(O==="svg"){var R=$(U).parent();
var V=R.attr("id");
if(V==="play"||V==="pause"||V==="overlay"||V==="play-overlay"){k.call(this)
}if(V==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)")
}if(V==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)")
}}}function J(O){O?this.$playButton.classList.add("play"):this.$playButton.classList.toggle("play")
}function y(){this.delayAnimation.stop();
this.$delayPlayContainer.classList.add("hidden");
this.$player.classList.remove("delay-overlay")
}function c(Q){var O=this;
var P=new Image();
P.onload=function(){O.blackFrame.classList.add("hidden");
O.$video.poster=Q
};
P.src=Q
}function x(P,R){var Q=R;
if(Q.touches){Q=Q.touches[0]
}var O=Math.round(Q.pageX-P.getBoundingClientRect().left);
var S=Math.round(Q.pageY-P.getBoundingClientRect().left);
return{x:O,y:S}
}function z(O){this.$videoProgressBarTrack.style.width=O+"px";
this.trackValue=O
}function q(){var P=Math.round(this.trackValue/this.$videoProgressBarLen()*100);
var O=this.videoDuration*P/100;
this.$video.currentTime=O
}function m(P){var Q=x(this.$videoProgressBar,P),O=Q.x;
z.call(this,O);
q.call(this)
}function b(Q){if(this.mousePressed){var P=x(this.$videoProgressBar,Q),O=P.x;
z.call(this,O);
q.call(this)
}}function H(O){this.mousePressed=O
}return{togglePlay:k,wipeVideoProgress:C,toggleMute:M,updateVolume:u,timeUpdate:G,updateTrayProgress:d,toggleFullScreen:I,formatTime:D,videoCanPlayEvent:K,videoWaitEvent:l,updateVolumeIcon:e,videoEnded:o,saveVideoProgress:s,applyVideoProgress:t,handlePlayEvent:r,handlePauseEvent:f,removeVideoOverlay:v,playerClick:A,handlePlayFromStartEvent:h,handlePLayTileEvent:E,removeDelayPlay:y,imageLoader:c,handleNewLoadEvent:N,progressBarClickHandler:m,mouseMoveEventHandler:b,changeMouseState:H}
});
define("ExperienceFragmentGDPRConsent",["constants"],function(m){var h="/conf/epam/settings/wcm/segments/",d=".content.html",k="first",f="gdprSegment";
var l=function l(o){_classCallCheck(this,l);
this.$el=o;
this.$form=o.closest("form");
if(window.ContextHub&&ContextHub.SegmentEngine){this.id=o.attr("id");
var p=o.data("mappings");
var n=o.data("defaultVariation");
if(p&&n){this.variants=j(p,n);
ContextHubJQ(b.bind(this));
return
}}c.apply(this)
};
function j(r,o){var n=[];
for(var p in r){if(Object.prototype.hasOwnProperty.call(r,p)){var q=Object.create(null);
q.title=p;
q.url=r[p]+d;
q.segments=[h+p.toLowerCase()];
q.segmentPath=h+p;
n.push(q)
}}n.push({title:"Default",url:o+d});
return n
}function b(){ContextHub.eventing.on(ContextHub.Constants.EVENT_TEASER_LOADED,i.bind(this));
ContextHub.SegmentEngine.PageInteraction.Teaser({locationId:this.id,variants:this.variants,strategy:k,trackingURL:null});
setTimeout(function(){c.apply(this)
}.bind(this),5000)
}function i(n,o){var q=this;
var p=this.id;
o.data.forEach(function(r){if(r.key===p){c.apply(q)
}});
a.call(this,f,e(n,o));
g.call(this)
}function g(){var n=this.$el.closest("form");
n.trigger(m.Events.initConsent)
}function c(){this.$el.removeClass("hidden")
}function e(p,q){try{var o=q.data[0].teaser;
var t=o.currentlyLoaded.url;
var n=o.details.variants;
var s=n.find(function(u){return t.startsWith(u.url)
});
return s.segmentPath
}catch(r){return""
}}function a(n,p){var o=this.$form.find("input[name="+n+"]");
if(o.length){o.first().val(p)
}}l.moduleName="Experience Fragment Give GDPR Consent";
l.selector=".epam-experience-fragment-ui";
return l
});
define("PageNavigation",["utils-dust","utils"],function(d,a){var b={MIN_AMOUNT_OF_ANCHOR:3,DESKTOP:"(max-width: 1440px)",HEADER_HEIGHT:68,ANIMATE_HEADER_HEIGHT:52};
var e={PAGE_ANCHOR:"page-anchor-ui",NAV_AREA_CLASS:"page-navigation__area",NAV_MENU:"page-navigation__menu",ACTIVE:"active",HEADER_CONTENT:"header-ui",BREADCRUMBS:"breadcrumbs-ui"};
var c=function(){function t(B){var C=this;
_classCallCheck(this,t);
this.$el=B[0];
this.$pageAnchors=document.querySelectorAll("."+e.PAGE_ANCHOR);
this.$header=document.querySelector("."+e.HEADER_CONTENT);
this.$breadcrumbs=document.querySelector("."+e.BREADCRUMBS);
this.scrollEventhandler=this.scrollEventhandler.bind(this);
document.body.onload=function(){C.init()
}
}_createClass(t,[{key:"init",value:function x(){if(this.checkRequiredCondition()){return
}this.createNavigationMenu();
this.initEventListener();
this.defineBreakPoint();
this.lastAnchorSectionCenter();
this.setNavigationMenuStartPosition();
this.scrollEventhandler();
this.resizeEventHandler();
window.addEventListener("scroll",this.scrollEventhandler);
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler.bind(this),300))
}},{key:"checkRequiredCondition",value:function q(){return this.$pageAnchors&&this.$pageAnchors.length>=b.MIN_AMOUNT_OF_ANCHOR?0:1
}},{key:"createNavigationMenu",value:function y(){var C=this.$pageAnchors.length-1;
var E={y:0};
var B=this.offset(this.$pageAnchors[this.$pageAnchors.length-1]);
var D=B.y-E.y;
d.append("navigation-area",{items:new Array(C)},$(document.body));
this.$navigationArea=document.querySelector("."+e.NAV_AREA_CLASS);
this.$topShift=E.y;
this.$navigationArea.setAttribute("style","top:"+E.y+"px; height: "+D+"px");
this.$navigationMenu=document.querySelector("."+e.NAV_MENU);
this.$navigationDots=this.$navigationMenu.querySelectorAll("li")
}},{key:"updateNavigationAreaPosition",value:function z(){var D={y:0};
var B=this.offset(this.$pageAnchors[this.$pageAnchors.length-1]);
var C=B.y-D.y;
this.$navigationArea.setAttribute("style","top: "+D.y+"px; height: "+C+"px")
}},{key:"initEventListener",value:function v(){var B=this;
[].slice.call(this.$navigationDots).forEach(function(D,C){D.addEventListener("click",B.navigationPointClickHandler.bind(B,B.$pageAnchors[C]))
})
}},{key:"offset",value:function m(B){var E=B.getBoundingClientRect(),D=this.getPageYOffset();
var C=E.top+D;
return{y:C}
}},{key:"getPageYOffset",value:function j(){return window.pageYOffset||document.documentElement.scrollTop
}},{key:"getElementHeight",value:function f(B){return B.offsetHeight
}},{key:"navigationPointClickHandler",value:function p(C){var D=this.offset(C).y;
var B=this.getElementHeight(this.$header);
this.scrollToSelector(D-B,C)
}},{key:"setNavigationMenuStartPosition",value:function k(){var C=this.getScreenHeight();
var B=this.getElementHeight(this.$navigationMenu);
this.$navigationMenuOffsetTop=Math.round(C/2-B/2);
this.$navigationMenu.setAttribute("style","top: "+this.$navigationMenuOffsetTop+"px")
}},{key:"scrollEventhandler",value:function o(){var B=Math.round(this.getPageYOffset())+this.$navigationMenuOffsetTop-this.$topShift+this.getElementHeight(this.$navigationMenu)/2;
if(B<=this.$centerOfLastSection){this.$navigationMenu.setAttribute("style","position: fixed; top: "+this.$navigationMenuOffsetTop+"px")
}else{var C=this.$centerOfLastSection-this.getElementHeight(this.$navigationMenu)/2;
this.$navigationMenu.setAttribute("style","position: absolute; top: "+C+"px")
}this.updateDots()
}},{key:"defineBreakPoint",value:function w(){var C=this;
var B=[].slice.call(this.$pageAnchors);
this.$breakPoints=[];
Array.prototype.forEach.call(B,function(D){C.$breakPoints.push(C.offset(D).y)
})
}},{key:"lastAnchorSectionCenter",value:function r(){var C=this.$pageAnchors.length;
var D=this.offset(this.$pageAnchors[C-1]).y;
var E=this.offset(this.$pageAnchors[C-2]).y;
var B=D-E;
this.$centerOfLastSection=Math.round(E+B/2-this.$topShift)
}},{key:"updateDots",value:function s(){var D=this.getScreenHeight()/2;
var B=Math.round(this.getPageYOffset()+D-this.$topShift);
for(var C=this.$breakPoints.length-2;
C>=0;
C--){if(B>this.$breakPoints[C]){this.removeActiveDot();
this.activateDot(this.$navigationDots[C]);
return
}}this.removeActiveDot();
this.activateDot(this.$navigationDots[0])
}},{key:"removeActiveDot",value:function A(){var B=this.$navigationArea.querySelector(".active");
if(B){B.classList.remove("active")
}}},{key:"activateDot",value:function l(B){B.classList.add(e.ACTIVE)
}},{key:"scrollToSelector",value:function i(C,B){$("html").animate({scrollTop:C},400,this.endAnimationAction.bind(this,B))
}},{key:"endAnimationAction",value:function h(C){var B=this.getElementHeight(this.$breadcrumbs);
var D=this.$breadcrumbs.classList.contains("breadcrumbs--hidden");
var F=this.getHeaderHeight();
if(D){B=0
}var H=Math.round(this.offset(this.$header).y+this.getElementHeight(this.$header)+B);
var E=Math.round(this.offset(C).y);
if(H!==E){var G=this.offset(C).y;
$("html, body").animate({scrollTop:G-F-B},200)
}}},{key:"resizeEventHandler",value:function g(){if(window.matchMedia(b.DESKTOP).matches){window.removeEventListener("scroll",this.scrollEventhandler);
return
}window.addEventListener("scroll",this.scrollEventhandler);
this.lastAnchorSectionCenter();
this.updateNavigationAreaPosition();
this.setNavigationMenuStartPosition();
this.scrollEventhandler()
}},{key:"getScreenHeight",value:function n(){return window.innerHeight
}},{key:"getHeaderHeight",value:function u(){var B=this.$header.classList.contains("header--animated");
var C=b.HEADER_HEIGHT;
if(B){C=b.ANIMATE_HEADER_HEIGHT
}return C
}}]);
return t
}();
c.moduleName="Page Navigation";
c.selector=".page-navigation-ui";
return c
});
define("Animation23",["utils"],function(a){var d={ANIMATION_IMAGE_CONTAINER:"animation__image-container"};
var c=100;
var b=function(){function h(l){_classCallCheck(this,h);
this.$el=l[0];
this.$imageContainer=this.$el.querySelector("."+d.ANIMATION_IMAGE_CONTAINER);
this.imageName=l.attr("data-image-name");
this.isActive=true;
this.isEditMode=l.is("[is-edit-mode]");
this.delayAnimation=this.loadAnimationPicture();
this.init();
this.initEvents()
}_createClass(h,[{key:"init",value:function j(){this.onScrollChange()
}},{key:"initEvents",value:function g(){window.addEventListener("scroll",a.debounce(this.onScrollChange.bind(this),300));
this.delayAnimation.addEventListener("data_ready",this.onAnimationLoaded.bind(this))
}},{key:"onScrollChange",value:function k(){if(this.isActive&&this.isOnScreen(c)){this.delayAnimation.play();
this.isActive=false
}}},{key:"isOnScreen",value:function f(n){var m=window.innerHeight*(n/100)+window.scrollY;
var o=window.scrollY+this.$imageContainer.getBoundingClientRect().top;
var l=o+this.$imageContainer.offsetHeight/2;
return l<=m
}},{key:"loadAnimationPicture",value:function e(){return bodymovin.loadAnimation({container:this.$imageContainer,renderer:"svg",loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/"+this.imageName+".json",rendererSettings:{className:"animation__svg",viewBoxOnly:true}})
}},{key:"onAnimationLoaded",value:function i(){if(this.isEditMode){this.delayAnimation.goToAndPlay(this.delayAnimation.totalFrames,true);
this.isActive=false
}}}]);
return h
}();
b.moduleName="Animation23";
b.selector=".animation-ui-23";
return b
});
define("CategoriesSwitcher23",["utils","utils-env"],function(b,d){var g={TILE:"categories-switcher__tile-title",LEFT_SECTION:"categories-switcher-left-part",ACTIVE:"active",ACTIVE_TILE:".categories-switcher__tile-title.active",ACTIVE_CONTENT:".categories-switcher__content-item.active",ACTIVE_CONTENT_MOB:".categories-switcher__content-item-mob.active",CONTENT_ITEM:"categories-switcher__content-item",CONTENT_ITEM_MOBILE:"categories-switcher__content-item-mob",HIDE:"hidden",RESPONSIVE_IMAGE:"responsive-image-ui",TITLES_SECTION:"categories-switcher-tiles-section"};
var f={RESPONSIVE_HEADER_HEIGHT:52,RESPONSIVE_TOP_INDENT:20};
var a={nextSlide:"cat.switcher.next",prevSlide:"cat.switcher.prev"};
var e=[];
var c=function(){function r(C){_classCallCheck(this,r);
this.$el=C;
this.$modernEl=C[0];
this.$tiles=$("."+g.TILE,this.$modernEl);
this.$items=$("."+g.CONTENT_ITEM,this.$modernEl);
this.$itemsMobile=$("."+g.CONTENT_ITEM_MOBILE,this.$modernEl);
this.$tilesSection=this.$modernEl.querySelector("."+g.TITLES_SECTION);
this.itemsLength=this.$items.length;
this.init();
e.push(this)
}_createClass(r,[{key:"init",value:function z(){if(d.isEditMode()){this.editModeEvents();
return
}this.resizeEventHandler(this);
this.initDefaultSwitcherView();
this.addEventHandler();
this.setTitleIndex();
this.initEvents()
}},{key:"setTitleIndex",value:function y(){$.each(this.$tiles,function(C,D){D.setAttribute("item-index",C)
})
}},{key:"nextSlide",value:function l(){var D=this.$items.index(this.getActiveSlide());
var C=D<this.itemsLength-1?D+1:0;
this.switchSlide(this.$items[C])
}},{key:"prevSlide",value:function i(){var D=this.$items.index(this.getActiveSlide());
var C=D>0?D-1:this.itemsLength-1;
this.switchSlide(this.$items[C])
}},{key:"switchSlide",value:function o(C){this.reset();
C.classList.remove(g.HIDE);
C.classList.add(g.ACTIVE);
this.renderResponsiveImg(C)
}},{key:"getActiveSlide",value:function u(){return this.$modernEl.querySelector(g.ACTIVE_CONTENT)
}},{key:"getActiveTitle",value:function t(){return this.$modernEl.querySelector(g.ACTIVE_TILE)
}},{key:"reset",value:function A(){for(var C=0;
C<this.$tiles.length;
C++){this.$tiles[C].classList.remove(g.ACTIVE)
}for(var E=0;
E<this.itemsLength;
E++){this.$items[E].classList.remove(g.ACTIVE);
this.$items[E].classList.add(g.HIDE)
}if(this.$itemsMobile.length>0){for(var D=0;
D<this.itemsLength;
D++){this.$itemsMobile[D].classList.remove(g.ACTIVE);
this.$itemsMobile[D].style.maxHeight=null
}}}},{key:"initDefaultSwitcherView",value:function n(){this.reset();
if(this.device==="desktop"){this.$tiles[0].classList.add(g.ACTIVE);
this.$tiles[0].setAttribute("tabindex",0);
this.$items[0].classList.add(g.ACTIVE);
this.$items[0].classList.remove(g.HIDE)
}}},{key:"addEventHandler",value:function h(){var D=this;
var C=Array.prototype.slice.call(this.$tiles);
C.forEach(function(E){E.addEventListener("click",function(F){D.tileClickHandler(F.currentTarget,D)
})
})
}},{key:"mobileClickHandler",value:function x(D,C){var F=this.$modernEl.querySelector(g.ACTIVE_TILE);
if(!!F&&!F.isEqualNode(D)){this.reset()
}var E=D.nextElementSibling;
D.classList.toggle(g.ACTIVE);
E.classList.toggle("active");
C.activeTile=D;
C.activeContent=E;
if(E.style.maxHeight){E.style.maxHeight=null
}else{E.style.maxHeight=E.scrollHeight+"px"
}}},{key:"moveContentToTop",value:function v(C){if(C.activeTile!==undefined&&C.activeTile.classList.contains(g.ACTIVE)){var D=document.body.getBoundingClientRect();
var E=C.activeContent.getBoundingClientRect();
$("html, body").animate({scrollTop:E.top-D.top-f.RESPONSIVE_HEADER_HEIGHT-f.RESPONSIVE_TOP_INDENT},500)
}}},{key:"desktopClickHandler",value:function m(D){this.reset();
var E=D.getAttribute("tile-id");
var C=this.$modernEl.querySelector('[content-id="'+E+'"]');
D.classList.add(g.ACTIVE);
C.classList.add(g.ACTIVE);
C.classList.remove(g.HIDE);
this.renderResponsiveImg(C)
}},{key:"renderResponsiveImg",value:function s(C){var D=C.querySelectorAll("."+g.RESPONSIVE_IMAGE);
if(D.length>0){$(window).trigger("resize")
}}},{key:"tileClickHandler",value:function q(D,C){if(this.device==="desktop"){this.desktopClickHandler(D,C)
}else{this.mobileClickHandler(D,C)
}}},{key:"resizeEventHandler",value:function k(){if(window.matchMedia("(min-width: 992px)").matches){this.device="desktop"
}else{this.device="mobile"
}}},{key:"getTitleItem",value:function j(C){if(C<0){return this.$tiles[this.itemsLength-1]
}if(C>this.itemsLength-1){return this.$tiles[0]
}return this.$tiles[C]
}},{key:"arrowClickHandler",value:function w(G){var E=this;
var C=function C(H,J){J.preventDefault();
E.$modernEl.querySelector('[tabindex="0"]').removeAttribute("tabindex");
var I=E.getTitleItem(H);
I.setAttribute("tabindex",0);
I.focus();
E.desktopClickHandler(I)
};
if(G.keyCode===36){C(0,G)
}if(G.keyCode===35){C(this.itemsLength-1,G)
}if(G.keyCode===38||G.keyCode===37){var D=this.getActiveTitle().getAttribute("item-index");
C(Number(D)-1,G)
}if(G.keyCode===40||G.keyCode===39){var F=this.getActiveTitle().getAttribute("item-index");
C(Number(F)+1,G)
}}},{key:"initEvents",value:function p(){var C=this;
window.addEventListener("resize",b.debounceExtend(function(){C.resizeEventHandler(C);
if(!C.currentDevice){C.currentDevice=C.device;
return
}if(C.currentDevice!==C.device){C.initDefaultSwitcherView();
C.currentDevice=C.device
}},300));
this.$modernEl.addEventListener("transitionend",b.debounceExtend(function(){C.moveContentToTop(C)
},100));
this.$tilesSection.addEventListener("keydown",this.arrowClickHandler.bind(this))
}},{key:"editModeEvents",value:function B(){var C=this;
this.switchSlide(this.$items[0]);
this.$el.on(a.prevSlide,function(){C.prevSlide()
});
this.$el.on(a.nextSlide,function(){C.nextSlide()
})
}}]);
return r
}();
c.moduleName="CategoriesSwitcher23";
c.activatedComponents=e;
c.events=a;
c.selector=".categories-switcher-ui-23";
return c
});
define("ColumnControl23",[],function(){var b={COLUMN_CONTROL_COLUMN:"colctrl__col",TEXT_UI:"text-ui-23"};
var a=function(){function l(p){var o=this;
_classCallCheck(this,l);
this.el=p[0];
var q=this.el.getAttribute("data-is-list");
q&&window.addEventListener("DOMContentLoaded",function(){o.items=o.getInteractiveItems();
o.items.length&&o.init()
})
}_createClass(l,[{key:"getInteractiveItems",value:function m(){var o=this;
return Array.from(this.el.querySelectorAll("."+b.COLUMN_CONTROL_COLUMN)).map(function(q){var p=q.querySelectorAll("img, ."+b.TEXT_UI);
if(p.length===0){return q
}if(p.length===1){return p[0]
}return o.getClosestCommonParent(Array.from(p))
})
}},{key:"getClosestCommonParent",value:function d(o){var p=o[0];
while(p.parentNode){p=p.parentNode;
if(o.every(function(q){return p.contains(q)
})){return p
}}}},{key:"init",value:function n(){var o;
if(!window.accessibility){window.accessibility={startIndexes:[],items:[],indexOfCurrentItem:-1};
this.addEventListenerForNavigationOnPage();
this.addEventListenerForNavigationInList();
this.addEventListenerOnTabPress()
}this.createRefresherForIndexOfCurrentItem();
window.accessibility.startIndexes.push(window.accessibility.items.length);
(o=window.accessibility.items).push.apply(o,_toConsumableArray(this.items))
}},{key:"addEventListenerForNavigationOnPage",value:function h(){var o=this;
window.addEventListener("keydown",function(p){if(p.key.toLowerCase()==="l"){!p.shiftKey?o.changeIndexOfCurrentItem(o.findNextStartIndex()):o.changeIndexOfCurrentItem(o.findPreviousStartIndex())
}})
}},{key:"findNextStartIndex",value:function j(){for(var o=0;
o<window.accessibility.startIndexes.length;
o++){if(window.accessibility.startIndexes[o]>window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"findPreviousStartIndex",value:function e(){for(var o=window.accessibility.startIndexes.length-1;
o>=0;
o--){if(window.accessibility.startIndexes[o]<window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"changeIndexOfCurrentItem",value:function f(o){if(o>=0&&o<=window.accessibility.items.length-1){window.accessibility.indexOfCurrentItem=o;
this.setFocusToCurrentItem()
}}},{key:"setFocusToCurrentItem",value:function k(){var q=window.accessibility.items[window.accessibility.indexOfCurrentItem];
var p=q.getAttribute("tabindex")&&q.getAttribute("tabindex")!=="-1";
if(!p){q.setAttribute("tabindex",0);
q.addEventListener("focusout",function o(){q.setAttribute("tabindex",-1);
q.removeEventListener("focusout",o)
})
}q.focus()
}},{key:"addEventListenerForNavigationInList",value:function i(){var o=this;
window.addEventListener("keydown",function(p){if(p.key==="ArrowRight"||!p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem+1)
}else{if(p.key==="ArrowLeft"||p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem-1)
}}})
}},{key:"addEventListenerOnTabPress",value:function c(){window.addEventListener("keydown",function(o){if(o.key==="Tab"){setTimeout(function(){var p=window.accessibility.items.findIndex(function(q){return document.activeElement.compareDocumentPosition(q)!==Node.DOCUMENT_POSITION_PRECEDING
});
window.accessibility.indexOfCurrentItem=p===-1?window.accessibility.items.length-1:p
},0)
}})
}},{key:"createRefresherForIndexOfCurrentItem",value:function g(){this.items.forEach(function(o){o.addEventListener("focus",function(){window.accessibility.indexOfCurrentItem=window.accessibility.items.indexOf(o)
})
})
}}]);
return l
}();
a.moduleName="Column Control 23";
a.selector=".colctrl-ui-23";
return a
});
define("DetailPagesFilter23",["utils-dust","utils-env","constants","jquery-plugins"],function(f,e,d){var c={industries:".detail-pages-filter-23__select--industries",contentTypes:".detail-pages-filter-23__select--content-types",topics:".detail-pages-filter-23__select--topics",detailPagesMainList:".detail-pages-list--main",detailPagesSecondaryList:".detail-pages-list--secondary",detailPagesList:" .detail-pages-list-ui__holder",detailPagesListNotEmpty:"detail-pages-list__holder--not-empty",viewMore:".detail-pages-filter-23__view-more",viewMoreLink:".detail-pages-filter-23__view-more-button",lastRowItem:"detail-pages-list-23__item-last-row",message:".detail-pages-filter-23__error-message",topPanel:".detail-pages-filter-23",detailPagesLink:".detail-pages-list-23__link",filterContainer:".detail-pages-filter-23__filter-wrap",filterDropdownContainer:".detail-pages-filter-23__filter-list-wrap",filterSelected:"detail-pages-filter-23__filter_selected",filterPanelBtn:".detail-pages-filter-23__filter-panel-btn",filterExpanded:"detail-pages-filter-23__filter_expanded",filterListItem:".detail-pages-filter-23__filter-list-item",filterListItemActive:"detail-pages-filter-23__filter-list-item_active",filterSelectedCount:".detail-pages-filter-23__filter-list-selected-count",filterClearParametersBtn:".detail-pages-filter-23__filter-list-btn-clear",filterApplyBtn:".detail-pages-filter-23__filter-list-btn-apply",filterTags:".detail-pages-filter-23__filter-tags",filterTagsNotEmpty:"detail-pages-filter-23__filter-tags-not-empty",filterTagItem:".detail-pages-filter-23__filter-tag-item",filterTagItemClear:".detail-pages-filter-23__filter-tag-item_clear",filterClearTagsBtn:".detail-pages-filter-23__filter-tags-btn-clear",filterRemoveTagBtn:".detail-pages-filter-23__filter-tag-btn-remove"};
var b={URL:"/services/search/detail-pages.json",DEFAULT_URL:"/services/search/detail-pages.default.json",TEMPLATE:"detail-pages-list-23",DEFAULT_IMAGE:"/etc/designs/epam-com/images/detail-page/default-filter-image.jpg",ROW_LENGTH:3,LIMIT:9,TOPICS_COUNT:"component.detail-pages-filter.topics-count"};
var g={ajaxErrorMessage:"component.general.ajax-error-message",ajaxErrorTryAgain:"component.general.ajax-error-try-again",searchNoResults:"component.detail-pages-filter.search-no-results",searchEmptyResult:"component.general.search-empty-result-for-"};
function a(h){this.$el=h;
this.$detailPagesMainList=this.$el.find(c.detailPagesMainList+c.detailPagesList);
this.$detailPagesSecondaryList=this.$el.find(c.detailPagesSecondaryList+c.detailPagesList);
this.$viewMore=this.$el.find(c.viewMore);
this.$viewMoreLink=this.$viewMore.find(c.viewMoreLink);
this.$preloader=this.$el.find("."+d.Classes.preloader);
this.$message=this.$el.find(c.message);
this.$messageText=this.$message.find("p");
this.$topPanel=this.$el.find(c.topPanel);
this.contentReferenceLabelsView=this.$el.data("content-reference-labels-view");
this.viewType=this.$el.data("viewType");
this.$filterContainer=this.$el.find(c.filterContainer);
this.$filterPanelBtn=this.$el.find(c.filterPanelBtn);
this.$filterSelectedCount=this.$el.find(c.filterSelectedCount);
this.$filterClearParametersBtn=this.$el.find(c.filterClearParametersBtn);
this.$filterListItem=this.$el.find(c.filterListItem);
this.$filterApplyBtn=this.$el.find(c.filterApplyBtn);
this.$filterTags=this.$el.find(c.filterTags);
this.$filterTagItemClear=this.$el.find(c.filterTagItemClear);
this.$filterClearTagsBtn=this.$el.find(c.filterClearTagsBtn);
this.isAuthor=e.isAuthor();
this.paths=this.$el.data("paths")||"";
this.defaultParameters={paths:this.paths.split(","),limit:b.LIMIT,offset:0,viewType:this.viewType};
this.initViewType();
this.$viewMoreLink.on("click",this.loadMoreDetailPages.bind(this));
this.focusOnFirstLoadedItem.bind(this)
}a.prototype.initViewType=function(){this.$filterPanelBtn.on("click",this.toggleFilterList.bind(this));
this.$filterContainer.on("click",c.filterListItem,this.toggleFilterListItem.bind(this));
this.$filterContainer.on("click",c.filterRemoveTagBtn,this.removeFilterTag.bind(this));
this.$filterClearParametersBtn.on("click",this.clearAllFilterParameters.bind(this));
this.$filterClearTagsBtn.on("click",this.clearAllFilterTags.bind(this));
this.$filterApplyBtn.on("click",this.applyFilters.bind(this));
this.closeOnClickOutside();
window.addEventListener("load",function(){this.collectParametersAndLoad(true)
}.bind(this))
};
a.prototype.closeOnClickOutside=function(){var h=this;
document.addEventListener("click",function i(k){var j=$(k.target);
if(!j.closest(c.filterDropdownContainer).length&&$(c.filterContainer).hasClass(c.filterExpanded)&&!j.closest(c.filterPanelBtn).length){h.toggleFilterList()
}})
};
a.prototype.toggleFilterList=function(){this.$filterContainer.toggleClass(c.filterExpanded)
};
a.prototype.toggleFilterListItem=function(h){$(h.target).toggleClass(c.filterListItemActive);
this.updateFilterListView()
};
a.prototype.clearAllFilterParameters=function(){this.$filterListItem.removeClass(c.filterListItemActive);
this.updateFilterListView()
};
a.prototype.clearAllFilterTags=function(){this.removeFilterTags();
this.clearAllFilterParameters();
this.$filterTags.removeClass(c.filterTagsNotEmpty);
this.collectParametersAndLoad()
};
a.prototype.removeFilterTag=function(j){var h=$(j.target);
var i=$(j.target).closest("li");
var k=h.attr("data-filter-tag-id");
this.$el.find("[data-filter-id='"+k+"']").removeClass(c.filterListItemActive);
i.remove();
this.updateFilterListView();
this.updateFilterTagsView();
this.collectParametersAndLoad()
};
a.prototype.removeFilterTags=function(){this.$filterTagItemClear.nextAll().remove()
};
a.prototype.applyFilters=function(){var h=function h(j){var i=j.label,k=j.value;
return'\n        <li class="detail-pages-filter-23__filter-tag-item">\n            <div class="detail-pages-filter-23__filter-tag">\n                <span class="detail-pages-filter-23__filter-tag-label">'+i+'</span>\n                <button type="button" class="detail-pages-filter-23__filter-tag-btn-remove" data-filter-tag-id="'+k+'"></button>\n            </div>\n        </li>\n        '
};
this.removeFilterTags();
this.$filterTagItemClear.after(this.getSelectedFilterParametrs().map(h).join(""));
this.toggleFilterList();
this.updateFilterTagsView();
this.collectParametersAndLoad()
};
a.prototype.updateFilterListView=function(){var h=this.getSelectedFilterParametrs().length;
if(h){this.$filterContainer.addClass(c.filterSelected)
}else{this.$filterContainer.removeClass(c.filterSelected)
}this.$filterSelectedCount.text(h)
};
a.prototype.updateFilterTagsView=function(){if(this.$el.find("[data-filter-tag-id]").length){this.$filterTags.addClass(c.filterTagsNotEmpty)
}else{this.$filterTags.removeClass(c.filterTagsNotEmpty)
}};
a.prototype.getSelectedFilterParametrs=function(){return $("."+c.filterListItemActive).map(function(h,i){return{value:$(i).attr("data-filter-id"),label:$(i).text()}
}).get()
};
a.prototype.collectFilterParameters=function(){var h=this.viewType==="filter"?"industries":"topics";
return $.extend({},this.defaultParameters,_defineProperty({},h,this.getSelectedFilterParametrs().map(function(i){return i.value
})))
};
a.prototype.loadMoreDetailPages=function(i){var j=this.$detailPagesMainList.children().length,h=$.extend(this.collectFilterParameters(),{offset:j});
this.loadDetailPages(h);
i.preventDefault()
};
a.prototype.collectParametersAndLoad=function(i){var h=this.collectFilterParameters();
if(i){h.buildSchemaOrgMarkup=i
}return this.loadDetailPages(h)
};
a.prototype.loadDetailPages=function(h){return $.ajax({url:this.defaultLoad?b.DEFAULT_URL:b.URL,data:h,cache:false,beforeSend:this.toggleLoadingState.bind(this,true),success:this.loadDetailPagesAdapter.bind(this,h),complete:this.toggleLoadingState.bind(this,false),error:this.showErrorMessage.bind(this)})
};
a.prototype.loadDetailPagesAdapter=function(i,j){if(this.viewType!=="filter"){this.updateDetailPages(i,j);
return
}var h=j;
this.defaultLoad=!j.result.length;
if(this.secondLoad){h.defaultResult=j.result;
j.result=[];
this.secondLoad=false;
this.defaultLoad=false;
this.updateDetailPages(i,h);
return
}if(this.defaultLoad){this.collectParametersAndLoad();
this.secondLoad=true;
this.defaultLoad=false;
return
}this.updateDetailPages(i,h)
};
a.prototype.toggleLoadingState=function(h){this.$preloader.toggleClass(d.Classes.hidden,!h);
h&&this.$message.addClass(d.Classes.hidden)
};
a.prototype.updateDetailPages=function(t,n){var u=n.result,s=n.schemaOrgMarkup,j=n.defaultResult||[],q=n.total,l=t.limit,m=t.offset,i=!u.length,h=!j.length,r=i&&h,k=q>m+l,p=t.buildSchemaOrgMarkup,o=this.$el.data("viewType")==="careers-blog"?"query":"combination";
if(i||!m){this.$detailPagesMainList.empty();
this.$detailPagesSecondaryList.empty()
}!h&&this.updateErrorMessage([g.searchNoResults]);
r&&this.updateErrorMessage([g.searchEmptyResult+o]);
this.$message.toggleClass(d.Classes.hidden,h&&!r);
this.$viewMore.toggleClass(d.Classes.hidden,!k);
if(this.$topPanel.length){this.$detailPagesMainList.toggleClass(c.detailPagesListNotEmpty,!i)
}this.renderDetailPages(j,m,this.$detailPagesSecondaryList);
this.renderDetailPages(u,m,this.$detailPagesMainList);
p&&!!s&&this.addSchemaOrgMarkup(s)
};
a.prototype.renderDetailPages=function(h,k,j){var i={pages:h,lastRowIdx:this.calculateLastRowIndex(h.length),defaultImage:b.DEFAULT_IMAGE,isAuthor:this.isAuthor,contentReferenceLabelsView:this.contentReferenceLabelsView,viewType:this.viewType};
k&&j.children().removeClass(c.lastRowItem);
f.append(b.TEMPLATE,i,j);
this.toggleLoadingState(false);
this.focusOnFirstLoadedItem(k)
};
a.prototype.focusOnFirstLoadedItem=function(i){var h=this.$detailPagesMainList.children();
if(h.length>b.LIMIT){h.eq(i).find(c.detailPagesLink).focus()
}};
a.prototype.calculateLastRowIndex=function(h){var i=Math.ceil(h/b.ROW_LENGTH);
return(i-1)*b.ROW_LENGTH
};
a.prototype.addSchemaOrgMarkup=function(h){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(h)+"<\/script>")
};
a.prototype.showErrorMessage=function(){this.updateErrorMessage([g.ajaxErrorMessage,g.ajaxErrorTryAgain]);
this.$message.removeClass(d.Classes.hidden)
};
a.prototype.updateErrorMessage=function(h){var i=h.length>1?h.map(function(j){return CQ.I18n.getMessage(j)
}).join(" "):CQ.I18n.getMessage(h[0]);
this.$messageText.html(i)
};
a.moduleName="Detail Pages Filter 23";
a.selector=".detail-pages-filter-23-ui";
return a
});
define("InstagramFeed23",["utils"],function(a){var c={scrollContainer:"instagram-feed__scroll-container",blocksContainer:"instagram-feed__container"};
function b(d){this.$el=d;
this.$slider=$(d.find("."+c.scrollContainer)[0]);
this.$blocksContainer=$(d.find("."+c.blocksContainer)[0]);
a.setHorizontalScrolling(this.$slider,this.$blocksContainer)
}b.moduleName="Instagram Feed 23";
b.selector=".instagram-feed-ui-23";
return b
});
define("LeadershipViewer23",[],function(){function a(b){this.element=$(b[0]);
this.slider=$(this.element.find(".leadership-viewer-ui-23-scroll")[0]);
this.isHovered=false;
this.mouseSrollScaleFactor=2.5;
this.mouseSrollLimit=40;
this.wheelListener=this.wheelListener.bind(this);
this.isRendering=false;
this.renderSmooth=10;
this.scrollSpeed=10;
this.currentScrollPosition=0;
this.finalScrollPosition=0;
this.render=this.render.bind(this);
if(this.slider){this.initEvents()
}}a.prototype.isSliderScrolled=function(){var b=this.slider[0].scrollWidth-this.slider[0].clientWidth;
return Math.abs(this.slider.scrollLeft()-b)<0.5
};
a.prototype.isSliderOnStartPosition=function(){return this.slider.scrollLeft()===0
};
a.prototype.render=function(){this.isRendering=true;
var b=(this.finalScrollPosition-this.currentScrollPosition)/this.renderSmooth;
if(Math.abs(this.finalScrollPosition-this.currentScrollPosition)<0.5){this.currentScrollPosition=this.finalScrollPosition;
this.slider[0].scrollLeft=this.finalScrollPosition;
this.isRendering=false;
return
}this.currentScrollPosition+=b;
this.slider[0].scrollLeft=this.currentScrollPosition;
window.requestAnimationFrame(this.render)
};
a.prototype.wheelListener=function(d){if(this.isSliderScrolled()&&d.deltaY>0){return
}if(this.isSliderOnStartPosition()&&this.isHovered&&d.deltaY<0){return
}if(this.isHovered){d.preventDefault();
var e=0;
var b=Math.max.apply(Math,[Math.abs(d.deltaY),Math.abs(d.deltaX)]);
if(b===Math.abs(d.deltaY)){e=d.deltaY
}else{e=d.deltaX
}var c=Math.abs(e)>this.mouseSrollLimit?e/this.mouseSrollScaleFactor:e;
this.finalScrollPosition+=this.scrollSpeed*c;
this.finalScrollPosition=Math.max(0,Math.min(this.finalScrollPosition,this.slider[0].scrollWidth-this.slider[0].clientWidth));
if(!this.isRendering){window.requestAnimationFrame(this.render)
}}};
a.prototype.initEvents=function(){window.addEventListener("wheel",this.wheelListener,{passive:false});
window.addEventListener("load",this.detectOutOfBoundsText.bind(this));
this.element.mouseover(function(){this.isHovered=true
}.bind(this));
this.element.mouseout(function(){this.isHovered=false
}.bind(this))
};
a.prototype.detectOutOfBoundsText=function(){var b=$(this.slider.find(".leadership-viewer-ui-23-scroll__info-wrapper"));
b.each(function(d,c){var f=$(c).find(".leadership-viewer-ui-23-scroll__name-hidden");
var e=$(f.clone());
e.css("display","inline").css("position","absolute").css("left","0").css("top","-200%").css("z-index","-1");
e.text(f.text());
$("body").append(e);
if(e[0].clientWidth>c.clientWidth){f.addClass("transferred")
}})
};
a.selector=".leadership-viewer-ui-23";
a.moduleName="LeadershipViewer23";
return a
});
define("PaddingComponent23",["utils"],function(a){var d={DATA_DESKTOP_HEIGHT:"data-desktopHeight",DATA_RESPONSIVE_HEIGHT:"data-responsiveHeight",DATA_RESPONSIVE_BREAKPOINTS:"data-responsiveBreakpoints",TABLET:"tablet",MOBILE:"mobile"};
var c={mobile:"(max-width: 767px)",tablet:"(min-width: 768px) and (max-width: 991px)"};
var b=function(){function e(h){_classCallCheck(this,e);
this._el=h[0];
this.desktopHeight=this._el.getAttribute(d.DATA_DESKTOP_HEIGHT);
this.responsiveHeight=this._el.getAttribute(d.DATA_RESPONSIVE_HEIGHT)||this.desktopHeight;
this.breakPoint=this._el.getAttribute(d.DATA_RESPONSIVE_BREAKPOINTS);
this.isTabletBreakPoint=this.breakPoint===d.TABLET;
this.isMobileBreakPoint=this.breakPoint===d.MOBILE;
this.init()
}_createClass(e,[{key:"init",value:function g(){this.resizeEventHandler();
window.addEventListener("resize",a.debounce(this.resizeEventHandler.bind(this),300))
}},{key:"resizeEventHandler",value:function f(){var i=window.matchMedia(c.tablet).matches;
var h=window.matchMedia(c.mobile).matches;
if(this.isTabletBreakPoint&&(h||i)){this._el.style.height=this.responsiveHeight+"px"
}else{if(this.isMobileBreakPoint&&h){this._el.style.height=this.responsiveHeight+"px"
}else{this._el.style.height=this.desktopHeight+"px"
}}}}]);
return e
}();
b.moduleName="Padding Component 23";
b.selector=".padding-component-ui-23";
return b
});
define("RolloverBlocks23",[],function(){var b={BLOCK:"rollover-blocks__block",FOCUSED_BLOCK:"rollover-blocks__block--focused",BLOCK_CONTENT:"rollover-blocks__content",ROLLOVER_BLOCK:"rollover-blocks__description-rollover",LINK_A11Y:"rollover-blocks__link-holder--a11y",LINK_LEARN_MORE:"rollover-blocks__link",RTE_LINKS:"rollover-blocks__text a"};
var a=function(){function d(h){_classCallCheck(this,d);
this.el=h[0];
this.blocks=this.el.querySelectorAll("."+b.BLOCK);
this.addEventListenersToBlocks()
}_createClass(d,[{key:"addEventListenersToBlocks",value:function g(){var h=this;
this.blocks.forEach(function(o,m){var l=o.querySelector("."+b.BLOCK_CONTENT);
var k=o.querySelector("."+b.ROLLOVER_BLOCK);
var i=o.querySelector("."+b.LINK_LEARN_MORE);
var n=o.querySelectorAll("."+b.RTE_LINKS);
var j=[i].concat(_toConsumableArray(n));
if(m===0){h.showForAccessibility(l)
}h.hideForAccessibility.apply(h,_toConsumableArray(n));
h.addEventListenerToRolloverBlock(o,k,j);
o.addEventListener("touchend",function(p){if(p.cancelable&&p.target.className!==b.LINK_LEARN_MORE){o.classList.contains("active")?o.classList.remove("active"):o.classList.add("active");
h.blocks.forEach(function(q){if(q!==o&&q.classList.contains("active")){q.classList.remove("active")
}})
}})
})
}},{key:"addEventListenerToRolloverBlock",value:function c(k,i,h){var j=this;
i.addEventListener("focus",function(){setTimeout(function(){k.classList.add(b.FOCUSED_BLOCK);
j.showForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
},5)
});
i.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
j.hideForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
});
h.forEach(function(l){if(l){l.addEventListener("focus",function(){k.classList.add(b.FOCUSED_BLOCK);
j.showForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
});
l.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
j.hideForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
})
}})
}},{key:"showForAccessibility",value:function e(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",0);
k.removeAttribute("aria-hidden")
}})
}},{key:"hideForAccessibility",value:function f(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",-1);
k.setAttribute("aria-hidden",true)
}})
}}]);
return d
}();
a.selector=".rollover-blocks-ui-23";
a.moduleName="Rollover Blocks 23";
return a
});
define("ScrollingBlocks23",["utils"],function(a){var c={scrollContainer:"scrolling-blocks__scroll-container",blocksContainer:"scrolling-blocks__container"};
function b(d){this.$el=d;
this.$slider=$(d.find("."+c.scrollContainer)[0]);
this.$blocksContainer=$(d.find("."+c.blocksContainer)[0]);
a.setHorizontalScrolling(this.$slider,this.$blocksContainer)
}b.selector=".scrolling-blocks-ui-23";
b.moduleName="Scrolling Blocks 23";
return b
});
define("ScrollingInfographic23",["utils"],function(a){var c={item:".scroll-infographic-ui-23__item",title:".scroll-infographic-ui-23__item-title"};
var b=function(){function e(i){_classCallCheck(this,e);
this.$el=i[0];
this.$items=this.$el.querySelectorAll(c.item);
this.init()
}_createClass(e,[{key:"init",value:function g(){this.bindEvents();
this.setTitleHeight()
}},{key:"bindEvents",value:function h(){window.addEventListener("resize",a.debounce(this.setTitleHeight.bind(this),300))
}},{key:"setTitleHeight",value:function d(){var i=this.getMaxTitleHeight();
[].concat(_toConsumableArray(this.$items)).forEach(function(j){var k=j.querySelector(c.title);
if(k&&k.offsetHeight<i){k.style.height=i+"px"
}})
}},{key:"getMaxTitleHeight",value:function f(){return[].concat(_toConsumableArray(this.$items)).reduce(function(j,i){var k=i.querySelector(c.title);
return k?Math.max(j,k.offsetHeight):j
},0)
}}]);
return e
}();
b.selector=".scroll-infographic-ui-23";
b.moduleName="Scrolling Infographic 23";
return b
});
define("UpcomingEvent23",["utils-env","utils-browser"],function(b){var d=768;
var c={wrapper:".upcoming-event-ui-23",image:".upcoming-event-ui-23__image img",title:".upcoming-event-ui-23__title",arrow:".upcoming-event-ui-23__arrow-button",underlined:"underlined",animated:"animated"};
var a=function(){function g(l){_classCallCheck(this,g);
this.$wrapper=l[0];
this.$image=l.find(c.image)[0];
this.$title=l.find(c.title)[0];
this.$arrow=l.find(c.arrow)[0];
this.bindedAnimateIfInViewPort=this.animateIfInViewPort.bind(this);
this.init();
if(b.isEditMode()){this.$wrapper.classList.add(c.animated)
}}_createClass(g,[{key:"init",value:function k(){window.addEventListener("scroll",this.bindedAnimateIfInViewPort);
var l=this;
window.addEventListener("load",function(){l.animateIfInViewPort()
});
if(window.innerWidth>=d){this.handleImageHover();
this.handleTitleHover();
this.handleArrowHover()
}}},{key:"handleImageHover",value:function j(){var l=this;
this.$image.addEventListener("mouseover",function(){l.$title.classList.add(c.underlined)
});
this.$image.addEventListener("mouseout",function(){l.$title.classList.remove(c.underlined)
})
}},{key:"handleTitleHover",value:function f(){var l=this;
this.$title.addEventListener("mouseover",function(){l.$image.classList.add(c.animated)
});
this.$title.addEventListener("mouseout",function(){l.$image.classList.remove(c.animated)
})
}},{key:"handleArrowHover",value:function i(){var l=this;
this.$arrow.addEventListener("mouseover",function(){l.$image.classList.add(c.animated);
l.$title.classList.add(c.underlined)
});
this.$arrow.addEventListener("mouseout",function(){l.$image.classList.remove(c.animated);
l.$title.classList.remove(c.underlined)
})
}},{key:"animateIfInViewPort",value:function e(){if(!this.$wrapper){return
}var u=this.$wrapper.getBoundingClientRect().top;
var n=window.scrollY||document.documentElement.scrollTop;
var r=n+u;
var s=r+this.$wrapper.offsetHeight;
var p=n+window.innerHeight;
var t=n;
var l=this.$wrapper;
var o=l.offsetHeight;
var q=p-r;
var m=s-t;
if(q>=o/2||m<=o/2){this.animateBlock();
window.removeEventListener("scroll",this.bindedAnimateIfInViewPort)
}}},{key:"animateBlock",value:function h(){var l=this;
setTimeout(function(){l.$wrapper.classList.add(c.animated)
},150)
}}]);
return g
}();
a.moduleName="Upcoming-Event-23";
a.selector=".upcoming-event-ui-23";
return a
});
define("VideoShowcasesClasses",[],function(){return{PLAYER:"video-showcase__player-section",VIDEO:"video-showcase__video",VIDEO_TITLE:"video-showcase__title",VIDEO_TITLE_ACTIVE:"video-showcase__title--active",OVERLAY_ICONS:"video-showcase__overlay-icons",OVERLAY_PLAY_ACTIVE:"overlay-play-active",OVERLAY_PAUSE_ACTIVE:"overlay-pause-active",PROGRESS_BAR:"video-showcase__progress-bar",DURATION:"video-showcase__duration",TIME_ELAPSED:"video-showcase__time-elapsed",VOLUME_BUTTON:"video-showcase__volume-button",VOLUME_ICONS:"video-showcase__volume-button svg",VOLUME_HIGH:"volume-high",VOLUME_LOW:"volume-low",VOLUME_MUTE:"volume-mute",VOLUME:"video-showcase__volume",FULLSCREEN_BUTTON:"video-showcase__fullscreen-button",PLAY_BUTTON:"video-showcase__play-button",CONTROL_SECTION:"video-showcase__controls-section",SLIDER_IMG_WRAPPER:"video-showcase__img-wrapper",TRAY_SEEK:"video-showcase__tray-seek",DELAY_PLAY:"video-showcase__delay-play",WAIT_FOR_PLAY:"video-showcase__wait-for-play",OWL:"owl-carousel",NEXT_ICON:"video-showcase__nav-control-next",PREV_ICON:"video-showcase__nav-control-prev",BLACK_FRAME:"video-showcase__black-frame",VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS:"video-showcase__progress-bar-progress",VIDEO_SHOWCASE_PROGRESS_BAR_TRACK:"video-showcase__progress-bar-track",VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA:"video-showcase__progress-bar-hidden-area",events:{PLAY_EVENT:"customPlayEvent",PAUSE_EVENT:"customPauseEvent",PLAY_FROM_START:"customPlayFromStartEvent",PLAY_TILE_EVENT:"customTilePlayEvent",NEW_LOAD_REQUEST:"customNewLoadEvent"}}
});
define("VideoShowcases23",["utils-browser","utils","VideoShowcasePlayerFunctions","VideoShowcasesInitA11Y","VideoShowcasesClasses","utils-env"],function(d,a,c,f,e,h){var g=!!document.createElement("video").canPlayType;
var b=function(){function A(I){_classCallCheck(this,A);
this.$el=I[0];
this.isIE=d.isInternetExplorer();
this.$player=this.$el.querySelector("."+e.PLAYER);
this.$video=this.$el.querySelector("."+e.VIDEO);
this.$owl=$(this.$el.querySelector("."+e.OWL));
this.$isHideSlider=this.$el.dataset.hideCarousel;
this.$videoSliderItems=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
this.$videoTitleActive=this.$el.querySelector("."+e.VIDEO_TITLE_ACTIVE);
this.$progressBar=this.$el.querySelector("."+e.PROGRESS_BAR);
this.$controlSection=this.$el.querySelector("."+e.CONTROL_SECTION);
this.$duration=this.$el.querySelector("."+e.DURATION);
this.$timeElapsed=this.$el.querySelector("."+e.TIME_ELAPSED);
this.$overlayIcons=this.$el.querySelector("."+e.OVERLAY_ICONS);
this.$volumeButton=this.$el.querySelector("."+e.VOLUME_BUTTON);
this.$volumeIcons=this.$el.querySelectorAll("."+e.VOLUME_ICONS);
this.$volumeLow=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(2)");
this.$volumeHigh=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(3)");
this.$volumeMute=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(1)");
this.$volume=this.$el.querySelector("."+e.VOLUME);
this.$fullscreenButton=this.$el.querySelector("."+e.FULLSCREEN_BUTTON);
this.$playButton=this.$el.querySelector("."+e.PLAY_BUTTON);
this.$delayPlayContainer=this.$el.querySelector("."+e.DELAY_PLAY);
this.$waitForPlay=this.$el.querySelector("."+e.WAIT_FOR_PLAY);
this.nextIcon=this.$el.querySelector("."+e.NEXT_ICON);
this.prevIcon=this.$el.querySelector("."+e.PREV_ICON);
this.blackFrame=this.$el.querySelector("."+e.BLACK_FRAME);
this.$videoProgressBar=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS);
this.$videoProgressBarTrack=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_TRACK);
this.$videoProgressBarHiddenArea=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA);
this.isFirstPlay=true;
this.isOverlayRemoved=false;
this.activeVideoIndex=0;
this.userClick=false;
this.delayPlayRemoved=true;
this.activeIndex=[];
this.owlItems=[];
this.fromStart=false;
this.promisePending=false;
this.publishMode=!h.isEditMode();
this.customPlayEvent=document.createEvent("Event");
this.customPauseEvent=document.createEvent("Event");
this.customPlayFromStartEvent=document.createEvent("Event");
this.customTilePlayEvent=document.createEvent("Event");
this.customNewLoadRequestEvent=document.createEvent("Event");
this.customPlayEvent.initEvent(e.events.PLAY_EVENT,true,true);
this.customPauseEvent.initEvent(e.events.PAUSE_EVENT,true,true);
this.customPlayFromStartEvent.initEvent(e.events.PLAY_FROM_START,true,true);
this.customTilePlayEvent.initEvent(e.events.PLAY_TILE_EVENT,true,true);
this.customNewLoadRequestEvent.initEvent(e.events.NEW_LOAD_REQUEST,true,true);
this.init()
}_createClass(A,[{key:"init",value:function F(){this.setDefaultVideo();
this.initOwlCarousel();
if(this.publishMode){this.setDefaultVideo();
this.initEventsHandlers(this);
this.setVideoIndex();
this.initOwlCarousel();
f.loadDelayPlayIconAnimation.call(this);
this.activeTraySeek();
if(this.isIE||d.detectIOSDevice()){c.removeVideoOverlay.call(this)
}else{f.loadWaitAnimation.call(this);
this.isSupportPlayer();
this.customVideoEvents()
}}}},{key:"setVideoIndex",value:function s(){Array.prototype.forEach.call(this.$videoSliderItems,function(J,I){J.setAttribute("data-index",I)
})
}},{key:"initOwlCarousel",value:function r(){if(this.$isHideSlider==="1"){this.$el.querySelector(".video-showcase__slider-section").classList.add("hidden");
return
}var I=this.$videoSliderItems.length>3;
var J=this.$videoSliderItems.length>3?3:this.$videoSliderItems.length;
this.$owl.on("initialized.owl.carousel",function(){if(this.publishMode){f.initA11y.call(this);
f.stopVideoBySpaceA11y.call(this)
}this.$owl.on("refreshed.owl.carousel",function(){this.removeOwlAriaAttr();
f.reInitA11yAttr.call(this)
}.bind(this))
}.bind(this));
this.$owl.addClass("owl-item-count-"+J);
this.$owl.owlCarousel({nav:true,dots:false,items:J,responsive:false,mouseDrag:I,loop:I,navText:[this.prevIcon,this.nextIcon],navElement:"div"});
this.$owl[0].removeAttribute("style")
}},{key:"isSupportPlayer",value:function u(){if(g){this.$video.controls=false;
this.$controlSection.classList.remove("hidden");
c.updateVolumeIcon.call(this);
this.$normalProgressbarLength=this.$videoProgressBar.getBoundingClientRect().width;
this.$videoProgressBarLen=function(){return this.getBoundingClientRect().width
}.bind(this.$videoProgressBar)
}}},{key:"setDefaultVideo",value:function y(J){var I=J?J:this.$videoSliderItems[0];
if(I){this.changeActiveVideo(this.getVideoDataFromItem(I));
this.$video.load()
}}},{key:"delayPlayHandler",value:function q(){this.blackFrame.classList.add("hidden");
c.removeDelayPlay.call(this);
c.togglePlay.call(this)
}},{key:"sliderClickHandler",value:function x(I){var L=I.target;
var J=768;
if(this.isIE||L.tagName==="svg"||L.tagName==="use"||$(L).hasClass("video-showcase__img-wrapper-overlay")||$(L).hasClass("video-showcase__tray-text")||$(window).width()<J){var K=$(L).closest("."+e.SLIDER_IMG_WRAPPER);
if(K.length!==0){this.videoSlideClick(K.data().index,K[0])
}}}},{key:"videoSlideClick",value:function B(I,J){this.tileState=$(J).hasClass("active")||$(J).hasClass("pause");
!this.isFirstPlay&&c.saveVideoProgress.call(this);
this.activeVideoIndex=I;
this.activeItem=J;
this.fixPlayerHeight();
this.$video.classList.add("video-showcase__invincible");
this.changeActiveTile(J,I);
this.changeActiveVideo(this.getVideoDataFromItem(J));
this.$video.dispatchEvent(this.customNewLoadRequestEvent)
}},{key:"clearPlayerStyleProperties",value:function p(){this.$video.classList.remove("video-showcase__invincible");
this.$player.removeAttribute("style")
}},{key:"changeActiveTile",value:function k(L,I){var N=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
for(var J=0;
J<N.length;
J++){N[J].classList.remove("active");
N[J].classList.remove("pause")
}var M=this.$el.querySelectorAll('[data-index="'+I+'"]');
for(var K=0;
K<M.length;
K++){M[K].classList.add("active")
}}},{key:"getVideoDataFromItem",value:function n(I){return I?{sources:I.querySelector("img").getAttribute("data-source"),poster:I.querySelector("img").getAttribute("poster-source"),title:I.dataset.title}:null
}},{key:"changeActiveVideo",value:function D(I){var K=this;
var J=I.sources,M=I.poster,L=I.title;
this.$video.innerHTML="";
if(this.isFirstPlay){this.$video.poster=M
}JSON.parse(J).forEach(function(N){var O=N.type,Q=N.src;
var P=document.createElement("source");
P.setAttribute("type",O);
P.setAttribute("src",Q);
K.$video.appendChild(P)
});
if(!L){this.$videoTitleActive.classList.add("hidden")
}else{this.$videoTitleActive.classList.remove("hidden");
if(this.$videoTitleActive){this.$videoTitleActive.textContent=L
}}}},{key:"initializeVideo",value:function C(){var I=this;
this.videoDuration=Math.floor(this.$video.duration);
var J=c.formatTime(this.videoDuration);
this.$duration.innerText=J.minutes+":"+J.seconds;
this.$duration.setAttribute("datetime",J.minutes+"m "+J.seconds+"s");
if(this.traySeek!==undefined){this.traySeek.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.setAttribute("max",this.videoDuration)
}if(!this.isFirstPlay&&!this.fromStart){c.applyVideoProgress.call(this)
}this.fromStart=false;
$.each(this.activeIndex,function(K,L){$(I.owlItems[L]).removeClass("hide-tray-seek")
})
}},{key:"loadMetadataCallback",value:function G(){this.initializeVideo();
this.clearPlayerStyleProperties()
}},{key:"updatePlayButton",value:function w(){this.$playButton.classList.toggle("play")
}},{key:"updateFullscreenButton",value:function v(){this.$fullscreenButton.classList.toggle("fullscreen")
}},{key:"videoBorderTracker",value:function t(){var I=this.$el.getBoundingClientRect().top;
var O=window.pageYOffset||document.documentElement.scrollTop;
var K=O+I;
var J=O+I+this.$video.offsetHeight;
var N=O;
var M=N+window.innerHeight;
var L=function(){if(!this.$video.paused){c.togglePlay.call(this)
}}.bind(this);
if(N>J){L();
return
}if(M<K){L();
return
}}},{key:"activeTraySeek",value:function m(){this.activeIndex=[];
this.owlItems=$(this.$el).find(".owl-item");
$.each(this.owlItems,function(I,K){var L=$(K).find("."+e.VIDEO_TITLE)[0];
if(L){K.dataset.title=L.textContent
}$(K).addClass("hide-tray-seek");
var J=$(K).find('[data-index="'+this.activeVideoIndex+'"]');
if(J.length!==0){this.activeIndex.push(I)
}}.bind(this));
if(this.owlItems[this.activeIndex[0]]!==undefined){this.traySeek=this.owlItems[this.activeIndex[0]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[1]]!==undefined){this.clonedTraySeekStart=this.owlItems[this.activeIndex[1]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[2]]!==undefined){this.clonedTraySeekEnd=this.owlItems[this.activeIndex[2]].querySelector("."+e.TRAY_SEEK)
}}},{key:"mouseMove",value:function o(){this.$player.classList.add("mouse-move");
if(this.setTimeoutId!==undefined||this.setTimeoutId!==null){clearTimeout(this.setTimeoutId)
}this.setTimeoutId=setTimeout(function(){this.$player.classList.remove("mouse-move");
this.setTimeoutId=null
}.bind(this),15000)
}},{key:"fixPlayerHeight",value:function i(){var I=this.$player.getBoundingClientRect();
this.$player.setAttribute("style","height:"+I.height+"px")
}},{key:"resizeEventHandler",value:function l(){this.$owl.trigger("refresh.owl.carousel")
}},{key:"removeOwlAriaAttr",value:function H(){var J=this.$el.querySelectorAll('[role="tab"]');
for(var I=0;
I<J.length;
I++){J[I].removeAttribute("tabindex");
J[I].removeAttribute("aria-selected");
J[I].removeAttribute("role")
}}},{key:"customVideoEvents",value:function E(){this.$video.addEventListener("timeupdate",c.timeUpdate.bind(this));
this.$volume.addEventListener("input",c.updateVolume.bind(this));
this.$video.addEventListener("volumechange",c.updateVolumeIcon.bind(this));
this.$player.addEventListener("click",c.playerClick.bind(this));
this.$player.addEventListener("fullscreenchange",this.updateFullscreenButton.bind(this));
this.$player.addEventListener("mousemove",a.debounceExtend(this.mouseMove.bind(this),100))
}},{key:"initEventsHandlers",value:function j(){this.$video.addEventListener("timeupdate",c.updateTrayProgress.bind(this));
this.$video.addEventListener("ended",c.videoEnded.bind(this));
this.$video.addEventListener("loadedmetadata",this.loadMetadataCallback.bind(this));
this.$video.addEventListener("canplay",c.videoCanPlayEvent.bind(this));
this.$video.addEventListener("waiting",c.videoWaitEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_EVENT,c.handlePlayEvent.bind(this));
this.$video.addEventListener(e.events.PAUSE_EVENT,c.handlePauseEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_FROM_START,c.handlePlayFromStartEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_TILE_EVENT,c.handlePLayTileEvent.bind(this));
this.$video.addEventListener(e.events.NEW_LOAD_REQUEST,c.handleNewLoadEvent.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("click",c.progressBarClickHandler.bind(this));
this.$owl[0].addEventListener("click",this.sliderClickHandler.bind(this));
window.addEventListener("scroll",a.debounceExtend(this.videoBorderTracker.bind(this),100));
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler.bind(this),300));
this.initMouseMoveEvents()
}},{key:"initMouseMoveEvents",value:function z(){this.$videoProgressBarHiddenArea.addEventListener("mousedown",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("mouseup",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mouseleave",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mousemove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchmove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchstart",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("touchend",c.changeMouseState.bind(this,false))
}}]);
return A
}();
b.moduleName="Video Showcases 23";
b.selector=".video-showcase-ui-23";
return b
});
define("VideoShowcasesInitA11Y",["utils","VideoShowcasePlayerFunctions","VideoShowcaseA11y"],function(l,c,a){function b(m){if(this.$videoSliderItems.length>3){m(this);
this.$owl.trigger("to.owl.carousel",[this.currentSlide,0])
}}function k(){b.call(this,function(){if(this.$videoSliderItems.length-1>=this.currentSlideindex){this.currentSlideindex=0
}}.bind(this))
}function f(){b.call(this,function(){this.currentSlideindex--;
if(this.currentSlideindex<=0){this.currentSlideindex=this.$videoSliderItems.length-1
}}.bind(this))
}function d(n){var m=Number(n.querySelector(".video-showcase__img-wrapper").dataset.index);
if(this.activeVideoIndex===m){c.togglePlay.call(this);
return
}this.fixPlayerHeight();
this.videoSlideClick(m,n)
}function g(){$(this.$el).find(".owl-stage").addClass("a11y-navigation-panel");
a.init.call(this,{"list-item":"owl-item:not(.cloned)","move-forward-callback":k.bind(this),"move-downward-callback":f.bind(this),"enter-action":d.bind(this)})
}function h(){a.setSpecialAttribute.call(this)
}function i(){l.loadLottieFile({container:this.$waitForPlay,loop:true,autoplay:true,path:"/etc/designs/epam-com/json-animations/loading-balls.json"})
}function e(){this.delayAnimation=l.loadLottieFile({container:this.$delayPlayContainer,loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/delay-play.json"});
this.delayAnimation.addEventListener("complete",this.delayPlayHandler.bind(this))
}function j(){var n=this;
var m=this.$el.querySelector(".video-showcase__video-progress");
m.addEventListener("keydown",function(o){var p=o.keyCode;
if(p===32){c.togglePlay.call(n)
}})
}return{loadWaitAnimation:i,loadDelayPlayIconAnimation:e,initA11y:g,reInitA11yAttr:h,stopVideoBySpaceA11y:j}
});
define("VideoShowcasePlayerFunctions",["VideoShowcasesClasses"],function(g){function k(){if(this.$video.paused||this.$video.ended){this.$video.dispatchEvent(this.customPlayEvent)
}else{this.$video.dispatchEvent(this.customPauseEvent)
}}function r(){this.$video.play();
v.call(this);
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add");
n.call(this,g.OVERLAY_PAUSE_ACTIVE,g.OVERLAY_PLAY_ACTIVE)
}function N(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.promisePending=false;
O.$video.load();
O.tileState?O.$video.dispatchEvent(O.customPlayFromStartEvent):O.$video.dispatchEvent(O.customTilePlayEvent);
O.isFirstPlay=false
})
}}}function E(){this.activeTraySeek();
this.$video.play();
v.call(this);
y.call(this);
J.call(this,"play");
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add")
}function h(){this.fromStart=true;
this.$video.play()
}function i(O){O==="add"?this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.add("active"):this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.remove("active")
}function f(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.$video.pause();
O.promisePending=false;
J.call(O);
n.call(O,g.OVERLAY_PLAY_ACTIVE,g.OVERLAY_PAUSE_ACTIVE);
B(O.$playButton,"Play (k)","Pause (k)");
i.call(O,"remove")
})
}}}function n(P,Q){var O=this;
this.overlayTimerId&&clearTimeout(this.overlayTimerId);
this.$overlayIcons.classList.remove("hidden");
this.$player.classList.remove(P);
this.$player.classList.add(Q);
this.overlayTimerId=setTimeout(function(){O.$overlayIcons.classList.add("hidden")
},1000)
}function B(P,Q,O){var R=P.getAttribute("title");
var S=R===Q?O:Q;
P.setAttribute("title",S)
}function C(){sessionStorage.removeItem("track"+this.activeVideoIndex)
}function M(){this.$video.muted=!this.$video.muted;
if(this.$video.muted){this.$volume.setAttribute("data-volume",this.$volume.value);
this.$volume.value=0
}else{this.$volume.value=this.$volume.dataset.volume
}}function u(O){if(this.$video.muted){this.$video.muted=false
}this.$video.volume=this.$volume.value;
O.stopPropagation()
}function D(P){if(!isNaN(P)){var O=new Date(P*1000).toISOString().substr(11,8);
return{minutes:O.substr(3,2),seconds:O.substr(6,2)}
}}function p(){var O=D(Math.floor(this.$video.currentTime));
this.$timeElapsed.innerText=O.minutes+":"+O.seconds;
this.$timeElapsed.setAttribute("datetime",O.minutes+"m "+O.seconds+"s")
}function j(){if(this.videoDuration&&this.$videoProgressBarLen()){var P=F.call(this);
this.videoCurPosPercent=Math.round(P/this.videoDuration*100);
var O=this.$videoProgressBarLen()*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}}function a(){var O=this.$normalProgressbarLength*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}function G(){p.call(this);
j.call(this)
}function F(){return this.$video?Math.floor(this.$video.currentTime):null
}function d(){if(this.traySeek!==undefined){this.traySeek.value=F.call(this)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.value=F.call(this)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.value=F.call(this)
}}function I(){if(document.fullscreenElement){a.call(this);
document.exitFullscreen()
}else{if(document.webkitFullscreenElement){a.call(this);
document.webkitExitFullscreen()
}else{if(this.$player.requestFullscreen){this.$player.requestFullscreen()
}else{if(this.$player.webkitRequestFullscreen){this.$player.webkitRequestFullscreen()
}else{if(this.$player.mozRequestFullScreen){this.$player.mozRequestFullScreen()
}else{if(this.$player.msRequestFullscreen){this.$player.msRequestFullscreen()
}}}}}}}function L(){if(this.timerId){clearTimeout(this.timerId)
}}function K(){L.call(this);
this.$waitForPlay.classList.add("hidden")
}function l(){var O=this;
L.call(this);
this.timerId=setTimeout(function(){O.$waitForPlay.classList.remove("hidden")
},1000)
}function e(){this.$volumeIcons.forEach(function(O){O.classList.add("hidden")
});
this.$volumeButton.setAttribute("data-title","Mute (m)");
if(this.$video.muted||this.$video.volume===0){this.$volumeMute.classList.remove("hidden");
this.$volumeButton.setAttribute("data-title","Unmute (m)")
}else{if(this.$video.volume>0&&this.$video.volume<=0.5){this.$volumeLow.classList.remove("hidden")
}else{this.$volumeHigh.classList.remove("hidden")
}}this.$volume.setAttribute("aria-valuetext",this.$video.volume*100+"% volume")
}function o(){this.blackFrame.classList.remove("hidden");
this.fromStart=true;
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
C.call(this);
this.activeVideoIndex===this.$videoSliderItems.length-1?this.activeVideoIndex=0:this.activeVideoIndex+=1;
var P=this.$videoSliderItems[this.activeVideoIndex];
var O=P.querySelector("img").getAttribute("poster-source");
c.call(this,O);
this.changeActiveVideo(this.getVideoDataFromItem(P));
this.$video.load();
this.changeActiveTile(this.$videoSliderItems[this.activeVideoIndex],this.activeVideoIndex);
w.call(this);
this.$player.classList.add("delay-overlay");
this.$delayPlayContainer.classList.remove("hidden");
this.delayAnimation.goToAndPlay(0)
}function w(){this.$owl.trigger("next.owl.carousel");
this.activeTraySeek()
}function s(){if(this.$video.ended){return
}sessionStorage.setItem("track"+this.activeVideoIndex,this.$video.currentTime)
}function t(){var O=sessionStorage.getItem("track"+this.activeVideoIndex);
if(O){this.$video.currentTime=O
}}function v(){if(!this.isOverlayRemoved){this.$player.classList.remove("overlay");
this.$overlayIcons.classList.add("hidden");
this.isOverlayRemoved=true
}}function A(V){var S=V.target,Q=V.target.tagName;
var P=S.getAttribute("id");
var T=S;
var O=Q;
if($(T).hasClass("overlay")||O==="VIDEO"||P==="play"){k.call(this);
return
}if(P==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)");
return
}if(P==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)");
return
}if($(T).hasClass("delay-overlay")){y.call(this);
k.call(this);
return
}if(O==="use"){O="svg";
T=$(T).parent()[0]
}if(O==="svg"){var R=$(T).parent();
var U=R.attr("id");
if(U==="play"||U==="pause"||U==="overlay"||U==="play-overlay"){k.call(this)
}if(U==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)")
}if(U==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)")
}}}function J(O){O?this.$playButton.classList.add("play"):this.$playButton.classList.toggle("play")
}function y(){this.delayAnimation.stop();
this.$delayPlayContainer.classList.add("hidden");
this.$player.classList.remove("delay-overlay")
}function c(P){var Q=this;
var O=new Image();
O.onload=function(){Q.blackFrame.classList.add("hidden");
Q.$video.poster=P
};
O.src=P
}function x(P,R){var Q=R;
if(Q.touches){Q=Q.touches[0]
}var O=Math.round(Q.pageX-P.getBoundingClientRect().left);
var S=Math.round(Q.pageY-P.getBoundingClientRect().left);
return{x:O,y:S}
}function z(O){this.$videoProgressBarTrack.style.width=O+"px";
this.trackValue=O
}function q(){var P=Math.round(this.trackValue/this.$videoProgressBarLen()*100);
var O=this.videoDuration*P/100;
this.$video.currentTime=O
}function m(Q){var P=x(this.$videoProgressBar,Q),O=P.x;
z.call(this,O);
q.call(this)
}function b(Q){if(this.mousePressed){var P=x(this.$videoProgressBar,Q),O=P.x;
z.call(this,O);
q.call(this)
}}function H(O){this.mousePressed=O
}return{togglePlay:k,wipeVideoProgress:C,toggleMute:M,updateVolume:u,timeUpdate:G,updateTrayProgress:d,toggleFullScreen:I,formatTime:D,videoCanPlayEvent:K,videoWaitEvent:l,updateVolumeIcon:e,videoEnded:o,saveVideoProgress:s,applyVideoProgress:t,handlePlayEvent:r,handlePauseEvent:f,removeVideoOverlay:v,playerClick:A,handlePlayFromStartEvent:h,handlePLayTileEvent:E,removeDelayPlay:y,imageLoader:c,handleNewLoadEvent:N,progressBarClickHandler:m,mouseMoveEventHandler:b,changeMouseState:H}
});