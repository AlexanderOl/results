$(function(){var a=document.querySelector(".display-section-block");
function b(c){return c.textContent.trim()===""
}if(a&&b(a)){a.classList.add("hidden")
}});
define("VideoShowcaseA11y",[],function(){var i={container:"a11y-container",navigationPanel:"a11y-navigation-panel"};
var j=0;
function l(n){this.$optionsA11=n;
this.$elA11=$(this.$el).find("."+i.container);
this.$navigationPanelA11=this.$elA11.find("."+i.navigationPanel);
this.$navigationItemsA11=this.$navigationPanelA11.find("."+this.$optionsA11["list-item"]);
this.$navigationItemsLengthA11=this.$navigationItemsA11.length;
d.call(this);
f.call(this)
}function d(o){this.$navigationPanelA11.attr("role","tablist");
var n=o?o:j;
$.each(this.$navigationItemsA11,function(p,q){if(p===n){$(q).attr("aria-selected","true").attr("role","tab").attr("tabindex","0");
return
}$(q).attr("aria-selected","false").attr("role","tab").attr("tabindex","-1")
})
}function b(){$.each(m.call(this),function(n,o){$(o).attr("aria-selected","false").attr("tabindex","-1")
})
}function m(){return this.$navigationPanelA11.find('[aria-selected="true"]')
}function h(){var n=m.call(this).next("."+this.$optionsA11["list-item"]);
return n.length!==0?n:$(this.$navigationItemsA11[0])
}function e(){var n=m.call(this).prev("."+this.$optionsA11["list-item"]);
return n.length!==0?n:$(this.$navigationItemsA11[this.$navigationItemsLengthA11-1])
}function c(o){var n=o();
b.call(this);
n.attr("aria-selected","true").attr("tabindex","0").focus()
}function g(){c.call(this,h.bind(this))
}function k(){c.call(this,e.bind(this))
}function a(o){var n=o.keyCode;
if(n===39||n===40){g.call(this);
this.$optionsA11["move-forward-callback"]&&this.$optionsA11["move-forward-callback"].call(this)
}if(n===37||n===38){k.call(this);
this.$optionsA11["move-downward-callback"]&&this.$optionsA11["move-downward-callback"].call(this)
}if(n===35||n===36){}if(n===13||n===32){this.$optionsA11["enter-action"]&&this.$optionsA11["enter-action"].call(null,o.target)
}}function f(){this.$navigationPanelA11.on("keydown",a.bind(this))
}return{init:l,setSpecialAttribute:d}
});
define("Video23",[],function(){var a='<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" frameborder="0" border="0" scroll="no" allowfullscreen scrolling="no"></iframe></div>',c=$(window);
function b(d){this.$el=d;
var e=this.$el.data("isPopup");
if(e){this.$playButton=this.$el.find("."+this.classes.button);
this.initPopup()
}else{this.$player=this.$el.find("."+this.classes.player);
this.$parent=this.$el.parent().parent();
this.$wrap=this.$el.find(".video__wrap");
this.width=parseInt(this.$wrap.data("width"));
this.height=parseInt(this.$wrap.data("height"));
this.aspectRatio=this.height/this.width;
c.on("resize",this.resizeVideo.bind(this));
this.resizeVideo();
if(this.$el.parents(".tabs-ui").length){c.on("tab.changed",this.resizeVideo.bind(this))
}}}b.prototype.initPopup=function(){var d={type:"iframe",disableOn:240,preloader:true,fixedContentPos:true,iframe:{patterns:{youtube:{index:"youtube.com/",id:"v=",src:this.$playButton.data("mfp-src")}},markup:a}};
this.$playButton.magnificPopup(d)
};
b.prototype.resizeVideo=function(){this.$wrap.css("padding-bottom",this.aspectRatio*100+"%")
};
b.prototype.classes={player:"video__player",button:"video__button"};
b.moduleName="Video 23";
b.selector=".video-ui-23";
return b
});
define("TimelineSlider23",["TabsUtil","utils-a11y","constants","utils-env"],function(f,b,j,h){var d=$(document),e=$("html"),a=$(window),g=$("body");
var c={item:".timeline-slider-ui-23__slide",historyImage:".timeline-slider-ui-23__view-more",historyGallery:".timeline-slider-ui-23__popup",active:"timeline-slider-ui-23--active",close:"timeline-slider-ui-23--close",popup:".timeline-slider-ui-23__popup",closePopupButton:".timeline-slider-ui-23__popup-close",carouselItem:".timeline-slider-ui-23__carousel-item",switcherCarousel:".timeline-slider-ui-23__switcher-carousel",switcherButton:".timeline-slider-ui-23__switcher-button",preloader:".timeline-slider-ui-23__preloader",allyActive:"ally-active",popupPrint:"popup-print",printImage:"print-image",tabPrev:".timeline-slider-ui-23__button-prev.js-tabs-prev",tabNext:".timeline-slider-ui-23__button-next.js-tabs-next"};
function i(k){this.$el=k;
this.$historyImage=this.$el.find(c.historyImage);
this.$historyGallery=this.$el.find(c.historyGallery);
this.$closePopupButton=this.$el.find(c.closePopupButton);
this.$switcherCarousel=this.$el.find(c.switcherCarousel);
this.$switcherButtons=this.$el.find(c.switcherButton);
this.$preloader=this.$el.find(c.preloader);
this.$tabNext=this.$el.find(c.tabNext);
this.$tabPrev=this.$el.find(c.tabPrev);
this.$switcherNav=this.$el.find(".owl-nav");
this.$historyImage.on("click",this.onButtonClick.bind(this));
this.$closePopupButton.on("click",this.closePopup.bind(this));
a.on("tab.changed",this.onTabChanged.bind(this));
a.on("beforeprint",this.beforeprintHandler.bind(this));
d.on("keyup",this.keyupHandler.bind(this));
this.$switcherCarousel.on("changed.owl.carousel",function(l){this.onSwitcherItemChanged(l)
}.bind(this));
this.$historyGallery.on("load.owl.lazy",this.showPreloader.bind(this));
this.$historyGallery.on("loaded.owl.lazy",this.hidePreloader.bind(this));
this.$switcherCarousel.owlCarousel(this.switcherDefaultConfig);
this.$switcherCarousel.trigger("refresh.owl.carousel");
f.call(this,k,{items:k.find(c.item),verticalNavigation:true});
this.$el.on("tab.loaded tab.change",function(){this.$items.eq(this.activeItem).addClass(c.allyActive)
}.bind(this));
this.$items.on(j.Events.transitionEnd,function(){this.$items.not("."+this.classes.active).removeClass(c.allyActive)
}.bind(this))
}i.prototype=Object.create(f.prototype);
i.prototype.wcmModeChange=function(k){k==="preview"&&this.setColorClass()
};
i.prototype.onButtonClick=function(k){k.preventDefault();
this.openPopup(k)
};
i.prototype.keyupHandler=function(k){if(k.key===j.Keys.esc){this.closePopup()
}};
i.prototype.openPopup=function(k){var m=$(k.currentTarget).parent(c.popup),l=m.find(c.closePopupButton);
this.$currentHistoryImage=m.find(c.historyImage);
this.$currentGallery=m.find(c.historyGallery);
this.$el.addClass(c.active);
g.addClass(c.popupPrint);
g.addClass(j.Classes.pinnedFilter);
e.addClass(j.Classes.noscroll);
this.$historyImage.attr("tabindex",-1);
this.carouselItemLength=m.find(c.carouselItem).length;
l.focus();
this.initGallery();
b.handlePopupFocus(m)
};
i.prototype.closePopup=function(){if(!this.$el.hasClass(c.active)){return
}this.$el.removeClass(c.active).addClass(c.close);
this.$historyImage.removeAttr("tabindex");
setTimeout(function(){g.removeClass(c.popupPrint);
g.removeClass(j.Classes.pinnedFilter);
e.removeClass(j.Classes.noscroll);
this.refreshGallery();
this.$el.removeClass(c.close);
this.$currentHistoryImage.focus()
}.bind(this),100)
};
i.prototype.initGallery=function(){var k=this.carouselItemLength>1?this.mainDefaultConfig:$.extend({},this.mainDefaultConfig,{mouseDrag:false,touchDrag:false,nav:false,dots:false});
if(this.$currentGallery.hasClass("owl-loaded")){this.$currentGallery.trigger("refresh.owl.carousel")
}else{this.$currentGallery.owlCarousel(k);
this.enableTopSwitcher()
}};
i.prototype.refreshGallery=function(){this.$currentGallery.trigger("to.owl.carousel",[0,20])
};
i.prototype.onTabChanged=function(){if(h.isEditMode()){return
}var k=this.$switcherButtons.filter("."+this.classes.active).data("item");
this.$switcherCarousel.trigger("to.owl.carousel",[k,20]);
this.activeBgColor=this.getBgColorClass(this.$items.eq(this.activeItem));
this.setColorClass();
this.enableTopSwitcher()
};
i.prototype.onSwitcherItemChanged=function(k){var l=k.item.index;
this.$el.trigger("tab.change",{tab:l,skipFocus:true});
this.$tabPrev.removeAttr("disabled");
this.$tabNext.removeAttr("disabled");
if(l+1>=k.item.count){this.$tabNext.attr("disabled","disabled")
}else{this.$tabNext.removeAttr("disabled")
}if(l===0){this.$tabPrev.attr("disabled","disabled")
}else{this.$tabPrev.removeAttr("disabled")
}this.enableTopSwitcher()
};
i.prototype.setColorClass=function(){var k=this.getBgColorClass(this.$el);
this.$el.removeClass(k).addClass(this.activeBgColor)
};
i.prototype.getBgColorClass=function(l){if(!l){return
}var k=l.attr("class").match(/bg-color[\w-]*\b/);
return k&&k.join(" ")
};
i.prototype.showPreloader=function(){this.$preloader.removeClass(j.Classes.hidden)
};
i.prototype.hidePreloader=function(){this.$preloader.addClass(j.Classes.hidden)
};
i.prototype.beforeprintHandler=function(){if(!this.$el.hasClass(c.active)){this.$currentGallery.owlCarousel("destroy")
}if(this.$el.hasClass(c.active)){this.addPrintImage()
}};
i.prototype.addPrintImage=function(){var k=$("."+c.printImage),l=this.$items.eq(this.activeItem).find(".owl-item.active .timeline-slider__carousel-image--desktop").attr("src");
if(!k.length){k=$('<img class="'+c.printImage+'" />').attr("src",l);
g.append(k);
return
}k.attr("src",l)
};
i.prototype.enableTopSwitcher=function(){var k=document.querySelector(".owl-item.active .timeline-slider-ui-23__switcher-carousel-item p");
this.$switcherNav=this.$el.find(".owl-nav");
if(k&&this.$switcherNav){$(this.$switcherNav).css("width",k.clientWidth)
}};
i.prototype.mainDefaultConfig={nav:true,center:true,items:1,lazyLoad:true,lazyLoadEager:0,rewind:false};
i.prototype.switcherDefaultConfig={nav:true,center:true,items:1,dots:false,rewind:false,touchDrag:false,mouseDrag:false};
i.moduleName="Timeline Slider 23";
i.selector=".timeline-slider-ui-23";
return i
});
define("Text23",["utils"],function(a){function b(c){this.$el=c;
this.$el.find("table").wrap('<div class="'+this.classes.tableWrapper+'"></div>');
a.insertArrowPictureForLinks(this.$el)
}b.prototype.classes={tableWrapper:"text__table-wrapper"};
b.moduleName="Text23";
b.selector=".text-ui-23";
return b
});
define("Tabs23",["TabsUtil","utils","media","jquery-plugins"],function(f,a,d){var e=$(window);
var c={title:".tabs__title",hideDivider:"tabs__title--no-divider",tabsWrapper:".tabs-23__ul-wrapper"};
function b(g){f.call(this,g,{useHistory:true,responsiveView:false,scrollToElement:g,responsiveBreakpoint:d.modes.Tablet.end,autoWidth:false,nav:false,dots:false});
this.$titles=this.$el.find(c.title);
e.on("popstate",this.onPopState.bind(this));
a.checkDividers(this.$titles,c.hideDivider);
a.redirectToPageAnchor();
$(window).on("click",this.closeTabOnOutsideClick.bind(this))
}b.prototype=Object.create(f.prototype);
b.prototype.onPopState=function(j){var h='[href="'+location.hash+'"]',g=this.$links.filter(h),i=g.data("item");
if(!g.length&&j.state){history.back()
}g.length&&this.$el.trigger(f.events.tabChange,{tab:i})
};
b.prototype.closeTabOnOutsideClick=function(){var g=this.$el.find(c.tabsWrapper);
g.hasClass("open")&&g.toggleClass("open")
};
b.moduleName="Tabs-23";
b.selector=".tabs-ui-23";
return b
});
define("Slider23",["utils-env","imager","constants","ResponsiveImage","utils","media"],function(c,f,i,d,g,a){var e={singleFullWidth:"single-full-width",twoColumns:"text-in-two-columns",textImage:"text-and-image-in-two-columns"};
var b={progressBar:"slider__progress-bar",owlRoot:"slider-ui-23__owl-root",desktopMod:"--desktop",mobileMod:"--mobile",navigationContainer:"slider__navigation",pagination:"slider__pagination",sumPage:"slider__pagination--sum-page",currentPage:"slider__pagination--current-page",leftArrow:"slider__left-arrow",rightArrow:"slider__right-arrow",dot:"slider__dot",sliderSlide:"slider__slide",active:".active",sliderDrag:"slider--drag",sliderLoaded:"slider--loaded",expanded:"slider--expanded",twoCellsSlideUi:".two-cells-slide-ui",singleSlideUi:"single-slide-ui",singleSlider:"slider--single",singleSlideContent:"single-slide__content-container",twoCellsSlideContent:".two-cells-slide__content",sliderPositionContentSide:"slider-position-content-side",twoCellsSlideContentLeft:"two-cells-slide__content-left",twoCellsSlideContentRight:"two-cells-slide__content-right"};
function h(j){this.$parentNode=j;
this.$el=j.find("."+b.owlRoot);
this.isEditMode=c.isEditMode();
this.itemCount=this.$el.children().length;
this.$sliderSlide=this.$el.find("."+b.sliderSlide);
this.singleSlideContent=this.$el.find("."+b.singleSlideContent);
this.playspeed=this.$parentNode.data("playSpeed")>=0?this.$parentNode.data("playSpeed"):5;
this.currentCount=1;
this.slidesCount=this.$parentNode.data("slides-count");
this.slidesCountDesktop=Math.ceil(this.slidesCount/2);
this.dotsColor=this.$parentNode.data("dots-color");
this.dotActiveColor=this.$parentNode.data("dot-active-color");
this.contentWidth=j.data("content-width");
this.configuration=j.data("configuration");
this.isDragging=false;
this.isMobile=a.currentMode().lessThan(a.modes.Desktop);
this.config=$.extend({},this.defaultConfig,this.playspeed?{autoplayTimeout:this.playspeed*1000,onDragged:this.stopAutoplay.bind(this),dotsData:true,onChanged:this.setCurrentSlide.bind(this)}:{autoplay:false,onChanged:this.setCurrentSlide.bind(this)},{dotClass:b.dot+" "+this.dotsColor,navContainerClass:b.navigationContainer+" "+this.dotsColor});
this.revealCurrentCarousel();
this.adjustContentWidth();
this.setDotsHiddenText();
this.initSliding(c.isEditMode());
this.initSliderButtons();
this.setDotsPosition();
this.initPagination();
this.placeCTALink();
this.initEvents();
g.applyShadowOnImage(this.$el,this.$el.find(".single-slide__image--mobile"))
}h.prototype.revealCurrentCarousel=function(){if(this.configuration!==e.twoColumns){this.$el=this.$parentNode.find("."+b.owlRoot);
this.itemCount=this.$el.children().length;
return
}if(a.currentMode().lessThan(a.modes.Desktop)){this.$el=this.$parentNode.find("."+b.owlRoot+b.mobileMod);
this.$parentNode.find("."+b.owlRoot+b.desktopMod).hide()
}else{this.$el=this.$parentNode.find("."+b.owlRoot+b.desktopMod);
this.$parentNode.find("."+b.owlRoot+b.mobileMod).hide()
}this.$el.show();
this.itemCount=this.$el.children().length
};
h.prototype.initEvents=function(){function j(){this.changeContentHeightToAuto();
this.setDotsPosition();
this.adjustContentWidth();
if(this.isMobile!==a.currentMode().lessThan(a.modes.Desktop)){this.isMobile=a.currentMode().lessThan(a.modes.Desktop);
this.onChangeMediaQuery()
}this.placeCTALink()
}window.addEventListener("resize",g.debounce(j.bind(this),300));
window.addEventListener("resize",g.debounceExtend(j.bind(this),300))
};
h.prototype.onChangeMediaQuery=function(){if(this.configuration===e.twoColumns){this.switchOwl()
}if(this.configuration===e.singleFullWidth&&this.isMobile){this.changeContentWidthToAuto()
}};
h.prototype.changeContentHeightToAuto=function(){this.$el.find("."+b.singleSlideContent).each(function(){$(this).css("height","")
})
};
h.prototype.changeContentWidthToAuto=function(){this.$el.find("."+b.singleSlideContent).each(function(){$(this).css("width","")
})
};
h.prototype.placeCTALink=function(){var j=0;
this.$el.find("."+b.singleSlideContent).each(function(){var k=$(this).height();
if(k>j){j=k
}});
this.$el.find("."+b.singleSlideContent).each(function(){$(this).height(j)
})
};
h.prototype.switchOwl=function(){var j=this.$el.height();
this.$parentNode.find("."+b.owlRoot+b.mobileMod).height(j);
this.$parentNode.find("."+b.owlRoot+b.desktopMod).height(j);
this.$el.trigger("destroy.owl.carousel").removeClass("owl-carousel owl-loaded");
this.$el.find(".owl-stage-outer").children().unwrap();
this.revealCurrentCarousel();
this.$el.removeAttr("style");
this.setDotsHiddenText();
this.initSliding(c.isEditMode());
this.initSliderButtons();
this.setDotsPosition();
this.initPagination()
};
h.prototype.setDotsHiddenText=function(){for(var m=0;
m<this.$sliderSlide.length;
m++){var j=m+1;
var n=this.$sliderSlide[m].querySelector(".layout-box__wrapper");
var o=this.$sliderSlide[m].querySelector(".text-ui");
var l=this.$sliderSlide[m].querySelector(b.twoCellsSlideContent);
var r=this.$sliderSlide[m].querySelector(".button");
var p="";
if(r){var k=r.querySelector(".button__content--mobile");
p=this.$sliderSlide[m].textContent.replace(k.textContent,"")
}var q="";
if(n&&r||l&&r){q='<span class="rs-only"> Slide '+j+": "+p+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}else{if(n){q='<span class="rs-only"> Slide '+j+": "+n.textContent+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}else{if(l){q='<span class="rs-only"> Slide '+j+": "+l.textContent+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}else{if(o){q='<span class="rs-only"> Slide '+j+": "+o.textContent+"</span>";
$(this.$sliderSlide[m]).attr("data-dot",q)
}}}}}};
h.prototype.setDotsPosition=function(){if(this.$el.hasClass(b.singleSlider)&&this.$el.hasClass(b.sliderPositionContentSide)){this.setContentSide(b.singleSlideContent,0)
}if(this.$el.hasClass(b.sliderPositionContentSide)){if(this.$el.find(b.twoCellsSlideUi).hasClass(b.twoCellsSlideContentLeft)){this.setContentSide(b.twoCellsSlideContent,0,".two-cells-slide__content-left")
}if(this.$el.find(b.twoCellsSlideUi).hasClass(b.twoCellsSlideContentRight)){this.setContentSide(b.twoCellsSlideContent,0,".two-cells-slide__content-right")
}}};
h.prototype.setContentSide=function(l,k,o){var n=this.$el.find(".owl-item.active "+(o?o:"")+" "+l)[0];
if(n){var m=this.$el.find("."+b.progressBar);
m.css({left:""});
var p=m.offset().left;
var r=n.firstElementChild?n.firstElementChild:n;
var q=r.getBoundingClientRect().left;
var j=parseInt(window.getComputedStyle(r,null).getPropertyValue("padding-left"));
m.css({left:q+k+j-p+"px"})
}};
h.prototype.initPagination=function(){if(this.isEditMode){return
}var j=this.slidesCount;
if(this.configuration===e.twoColumns){j=this.isMobile?this.slidesCount:this.slidesCountDesktop
}var k=this.$el.find("."+b.leftArrow);
k.after('<div class="'+b.pagination+'"><span class="'+b.currentPage+'">'+this.currentCount.toString().padStart(2,"0")+'</span><span class="'+b.sumPage+'"> / '+j.toString().padStart(2,"0")+"</span></div>")
};
h.prototype.adjustContentWidth=function(){if(this.configuration===e.singleFullWidth&&!this.isEditMode&&!this.isMobile){this.singleSlideContent.width(this.contentWidth+"%")
}};
h.prototype.setCurrentSlide=function(j){if(j.page.index===-1){this.currentCount=1
}else{this.currentCount=j.page.index+1
}this.$el.find("."+b.currentPage).text(this.currentCount.toString().padStart(2,"0"))
};
h.prototype.initDotsColors=function(){if(this.dotsColor===this.dotActiveColor){return
}this.toggleActiveDotClass(this.dots.filter(b.active),true);
this.$el.on("translated.owl.carousel",function(){setTimeout(function(){if(!this.isDragging){this.setDotsPosition()
}}.bind(this),50)
}.bind(this));
this.$el.on("drag.owl.carousel",function(){this.isDragging=true
}.bind(this));
this.$el.on("dragged.owl.carousel",function(){this.isDragging=false
}.bind(this));
this.$el.on("changed.owl.carousel",function(){this.toggleActiveDotClass(this.dots,false);
this.toggleActiveDotClass(this.dots.filter(b.active),true)
}.bind(this))
};
h.prototype.toggleActiveDotClass=function(j,k){j.toggleClass(this.dotsColor,!k).toggleClass(this.dotActiveColor,k)
};
h.prototype.initSliding=function(k){var j=!k&&this.itemCount>1;
if(!j){return
}this.$el.owlCarousel(this.config);
this.carouselData=this.$el.data("owl.carousel");
this.dots=this.$el.find("."+b.dot);
if(this.playspeed){$(document).on("visibilitychange",this.continueAutoplay.bind(this));
this.$el.find("."+b.dot).on("click",this.stopAutoplay.bind(this))
}this.reloadClonedImages();
this.initDotsColors.call(this)
};
h.prototype.initSliderButtons=function(){this.$el.find("."+b.rightArrow).click(this.stopAutoplay.bind(this));
this.$el.find("."+b.leftArrow).click(this.stopAutoplay.bind(this))
};
h.prototype.wcmModeChange=function(j){if(this.carouselData){this.carouselData.destroy()
}this.initSliding(j==="edit")
};
h.prototype.continueAutoplay=function(){if(this.isStopped){return
}this.carouselData.next()
};
h.prototype.stopAutoplay=function(){this.carouselData._plugins.autoplay.destroy();
this.isStopped=true
};
h.prototype.reloadClonedImages=function(){var j=this.$el.find(".cloned .responsive-image-ui");
if(j.length===1){new d(j)
}};
h.prototype.defaultConfig={loop:true,center:false,autoplay:true,playspeed:0,items:1,autoplayHoverPause:true,loadedClass:b.sliderLoaded,dragClass:b.sliderDrag,navClass:[b.leftArrow,b.rightArrow],dotClass:b.dot,dotsClass:b.progressBar,responsiveRefreshRate:0,lazyLoad:true,lazyLoadEager:3,nav:true,navText:[" "," "]};
h.selector=".slider-ui-23";
h.moduleName="Slider23";
return h
});
define("ShareToSocialConstants",function(){var c={common:{print:".js-print",email:".js-email-share",copy:".js-copy-link"},menu:{link:".share-menu__link",notice:".share-menu__notice"},popup:{container:".share-popup__container",button:".share-popup__share-button",link:".share-popup__link",title:".share-popup__item-title",notice:".share-popup__notice"}};
var g={copyText:"copy link",copiedText:"link copied"};
var f=991;
var e=72;
var b=location.href.match(/[^http(s)?://www.].+[\.$]/gi)[0];
var a=2000;
var d={fb:"facebook",tw:"twitter",li:"linkedin"};
return{classes:c,text:g,mobileDevice:f,headerPlaceholder:e,shortUrl:b,noticeVisibilityDelay:a,SOCIAL_ICONS:d}
});
define("ShareToSocialUtils",["ShareToSocialConstants","utils-share"],function(d,f){var c=function(i){i.preventDefault();
f.go($(this).data())
};
var h=function(j){var i=JSON.parse(localStorage.getItem(j+"edPagesUrls"))||[];
if(i.indexOf(d.shortUrl)===-1){i.push(d.shortUrl)
}localStorage.setItem(j+"edPagesUrls",JSON.stringify(i))
};
var b=function(i){window.print();
i.attr("href",location.href);
h("print")
};
var e=function(j){var k=JSON.parse(localStorage.getItem(j+"edPagesUrls"))||[];
var i=k.indexOf(d.shortUrl)!==-1;
return location.href+(i?"":"-"+j)
};
var g=function(k){var j=encodeURIComponent(k.data("subject")),i=encodeURIComponent(location.href);
return"mailto:?subject="+j+"&body="+i
};
var a=function(i){navigator.clipboard.writeText(i);
h("copy")
};
return{shareToSocial:c,addToUrls:h,printPage:b,getButtonHref:e,emailSharingLink:g,copyToClipboard:a}
});
define("SharePopup23",["ShareToSocialConstants","ShareToSocialUtils","utils","utils-share"],function(c,e,a,d){function b(f){this.$el=f;
this.$container=this.$el.find(c.classes.popup.container);
this.$links=this.$el.find(c.classes.popup.link);
this.$button=this.$el.find(c.classes.popup.button);
this.$menu=this.$el.find(c.classes.popup.container);
this.toggleMenu();
this.setSocialLinks();
this.setPrintButton();
this.setEmailButton();
this.setCopyLinkButton()
}b.prototype.toggleMenu=function(){var f=this;
var g=false;
this.$button.off().on("click",function(){var i=f.$el.offset().top-c.headerPlaceholder;
var h=window.innerWidth<=c.mobileDevice;
if(h){g=!g;
f.$menu.stop().slideToggle();
$(this).attr("aria-expanded",g);
if(g){$("html, body").animate({scrollTop:i},300)
}}})
};
b.prototype.setSocialLinks=function(){var f=this.$links.not(c.classes.common.print).not(c.classes.common.email).not(c.classes.common.copy);
f.on("click",e.shareToSocial);
f.each(function(){var g=$(this).attr("data-type");
var i=c.SOCIAL_ICONS[g];
i&&$(this).attr("aria-label",i);
$(this).find(c.classes.popup.title).text(i);
var h=d.getLink($(this).data());
h&&$(this).attr("href",h)
})
};
b.prototype.setPrintButton=function(){var f=this.$links.filter(c.classes.common.print);
f.attr("href",e.getButtonHref("print"));
f.on("click",function(g){g.preventDefault();
e.printPage(f)
})
};
b.prototype.setEmailButton=function(){var f=this.$links.filter(c.classes.common.email);
f.attr("href",e.getButtonHref("email"));
f.click(function(g){g.preventDefault();
$("<a />").attr("href",e.emailSharingLink(f)).get(0).click();
f.attr("href",location.href);
e.addToUrls("email")
})
};
b.prototype.setCopyLinkButton=function(){var f=this.$links.filter(c.classes.common.copy);
var g=this.$el.find(c.classes.popup.notice);
f.attr("href",e.getButtonHref("copy"));
f.on("click",function(j){j.preventDefault();
e.copyToClipboard(location.href);
var h=window.innerWidth<=c.mobileDevice;
var i=$(this).find(c.classes.popup.title);
if(h){i.text(c.text.copiedText);
setTimeout(function(){i.text(c.text.copyText)
},c.noticeVisibilityDelay)
}else{g.fadeIn();
setTimeout(function(){g.fadeOut()
},c.noticeVisibilityDelay)
}})
};
b.moduleName="Share To Social 23";
b.selector=".share-popup-ui-23";
return b
});
define("ShareMenu23",["ShareToSocialConstants","ShareToSocialUtils","utils-share"],function(c,a,d){function b(e){this.$el=e;
this.$links=this.$el.find(c.classes.menu.link);
this.setSocialLinks(this);
this.setPrintButton(this);
this.setEmailButton(this);
this.setCopyLinkButton(this)
}b.prototype.setSocialLinks=function(){var e=this.$links.not(c.classes.common.print).not(c.classes.common.email).not(c.classes.common.copy);
e.on("click",a.shareToSocial);
e.each(function(){var f=$(this).attr("data-type");
var h=c.SOCIAL_ICONS[f];
h&&$(this).attr("aria-label",h);
var g=d.getLink($(this).data());
g&&$(this).attr("href",g)
})
};
b.prototype.setPrintButton=function(){var e=this.$links.filter(c.classes.common.print);
e.attr("href",a.getButtonHref("print"));
e.on("click",function(f){f.preventDefault();
a.printPage(e)
})
};
b.prototype.setEmailButton=function(){var e=this.$links.filter(c.classes.common.email);
e.attr("href",a.getButtonHref("email"));
e.click(function(f){f.preventDefault();
$("<a />").attr("href",a.emailSharingLink(e)).get(0).click();
e.attr("href",location.href);
a.addToUrls("email")
})
};
b.prototype.setCopyLinkButton=function(){var e=this.$links.filter(c.classes.common.copy);
var f=this.$el.find(c.classes.menu.notice);
e.attr("href",a.getButtonHref("copy"));
e.off().on("click",function(g){g.preventDefault();
a.copyToClipboard(location.href);
f.fadeIn();
setTimeout(function(){f.fadeOut()
},c.noticeVisibilityDelay)
})
};
b.moduleName="Share To Social 23";
b.selector=".share-menu-ui-23";
return b
});
define("Search23",["utils","utils-dust","utils-env","constants"],function(a,f,e,d){var g=$(window);
var c={form:".search-results__panel",field:".search__field",container:".search-results__items",more:".search-results__view-more",exception:".search-results__exception-message",error:".search-results--error",emptyResult:".search-results--empty-result",counter:".search-results__counter",input:".frequent-searches__input",searchInput:".search__input",titleLink:".search-results__title-link",autoCorrectMessage:".search-results__auto-correct-message",autoCorrectTotal:".search-results__auto-correct-total",autoCorrectTerm:".search-results__auto-correct-term",opened:"opened"};
function b(h){this.$form=h.find(c.form);
this.$field=h.find(c.field);
this.$searchInput=this.$field.find(c.searchInput);
this.$query=this.$form.find(c.input);
this.defaultPlaceholder=this.$query.attr("placeholder");
this.$container=h.find(c.container);
this.$counter=h.find(c.counter);
this.$preloader=h.find("."+d.Classes.preloader);
this.$viewMore=h.find(c.more);
this.$exceptionMessages=h.find(c.exception);
this.$autoCorrectMessage=h.find(c.autoCorrectMessage);
this.$autoCorrectTerm=this.$autoCorrectMessage.find(c.autoCorrectTerm);
this.$autoCorrectTotal=this.$autoCorrectMessage.find(c.autoCorrectTotal);
this.$errorMessage=this.$exceptionMessages.filter(c.error);
this.$emptyResultMessage=this.$exceptionMessages.filter(c.emptyResult);
this.isAuthor=e.isAuthor();
this.configPath=h.data("config-path");
this.openEl=this.openEl.bind(this);
this.closeEl=this.closeEl.bind(this);
this.$form.on("submit",this.submit.bind(this));
this.$viewMore.on("click",this.loadMoreResults.bind(this));
g.on("scroll",this.loadResultsOnScroll.bind(this));
g.on("popstate",this.refreshResult.bind(this));
this.init()
}b.prototype.refreshResult=function(){var i=this.getParameters().q;
var h=a.getQueryParameters(location.href.replace(location.hash,"")).q;
if(i!==h){this.cleanResult();
this.init()
}};
b.prototype.init=function(){this.$query.on("focus",this.openEl).on("keyup",this.openEl);
this.$searchInput.on("focus",this.openEl).on("keyup",this.openEl);
this.updateForm();
this.loadResults(this.getParameters())
};
b.prototype.toggleEl=function(){const h=$(document).find(".frequent-searches-23--hidden");
this.$form.toggleClass(c.opened,!h.length);
this.$field.toggleClass(c.opened,!h.length)
};
b.prototype.openEl=function(){this.toggleEl();
g.on("click",this.closeEl)
};
b.prototype.closeEl=function(h){if(h&&this.$query.is(h.target)){return
}if(h&&this.$searchInput.is(h.target)){return
}this.toggleEl();
g.off("click",this.closeEl)
};
b.prototype.updateElState=function(h){if(!h){this.$searchInput.off("keydown");
this.$query.off("keydown");
return
}this.clearElState()
};
b.prototype.clearElState=function(){this.$searchInput.off("keydown");
this.$searchInput.attr("placeholder",this.defaultPlaceholder);
this.$query.off("keydown");
this.$query.attr("placeholder",this.defaultPlaceholder)
};
b.prototype.getParameters=function(h){return{q:this.$query.val().trim(),offset:h||0,config:this.configPath,bf:["events","news"]}
};
b.prototype.updateForm=function(){var h=window.location,i=a.getQueryParameters(h.href.replace(h.hash,"")).q||"";
this.$query.val(i)
};
b.prototype.loadResults=function(h){if(!h.q){this.$query.val("");
return
}$.ajax({url:this.config.searchUrl,data:h,beforeSend:this.toggleLoadingState.bind(this,true),complete:this.toggleLoadingState.bind(this,false),success:this.updateSearchResults.bind(this,h),error:this.showErrorMessage.bind(this)})
};
b.prototype.loadMoreResults=function(i){i&&i.preventDefault();
var j=this.$container.children().length,h=this.getParameters(j);
if(i){h.shouldFocusOnResult=true
}this.loadResults(h)
};
b.prototype.loadResultsOnScroll=function(){if(this.loading||!this.shouldLoadOnScroll){return
}var j=g.height(),i=g.scrollTop(),h=this.$container.children().last().offset().top;
if(j+i>h){this.loadMoreResults()
}};
b.prototype.toggleLoadingState=function(h){h&&this.$viewMore.addClass(d.Classes.hidden);
this.$preloader.toggleClass(d.Classes.hidden,!h);
this.loading=h
};
b.prototype.showErrorMessage=function(){this.$errorMessage.removeClass(d.Classes.hidden)
};
b.prototype.showAutoCorrectMessage=function(h){this.$autoCorrectMessage.removeClass(d.Classes.hidden);
this.$autoCorrectTotal.text(h.suggestedResultTotal);
this.$autoCorrectTerm.text(h.suggestedQuery);
this.$autoCorrectTerm.attr("href",this.getLink(h.suggestedQuery))
};
b.prototype.updateSearchResults=function(m,k){var l=k.total,j=k.result.length&&k.result||k.suggestedResult,i=m.offset===0,h=l>m.offset+this.config.limit;
this.shouldLoadOnScroll=i&&h;
i&&this.showResultMessage(m.q,l);
k.suggestedResultTotal&&this.showAutoCorrectMessage(k);
f.append("search-results",{items:j,isAuthor:this.isAuthor},this.$container);
this.$viewMore.toggleClass(d.Classes.hidden,i||!h);
m.shouldFocusOnResult&&this.$container.find(c.titleLink).eq(m.offset).focus()
};
b.prototype.showResultMessage=function(i,h){this.$counter.text(h?this.getResultMessage(i,h):"");
if(h){this.$counter.removeClass(d.Classes.hidden).focus();
return
}this.$emptyResultMessage.removeClass(d.Classes.hidden)
};
b.prototype.getResultMessage=function(j,i){var h=i===1?"component.search-results.found-single-result":"component.search-results.found-multiple-results";
return CQ.I18n.getMessage(h,[j,i])
};
b.prototype.submit=function(i){i.preventDefault();
this.cleanResult();
var h=this.getParameters();
this.updateUrl(h);
this.loadResults(h)
};
b.prototype.cleanResult=function(){this.$counter.addClass(d.Classes.hidden);
this.$container.empty();
this.$exceptionMessages.addClass(d.Classes.hidden);
this.$autoCorrectMessage.addClass(d.Classes.hidden);
this.$viewMore.addClass(d.Classes.hidden)
};
b.prototype.updateUrl=function(h){if(h.q!==a.getQueryParameters(window.location.href).q){window.history.pushState({},"",this.getLink(h.q))
}};
b.prototype.getLink=function(h){return window.location.pathname+"?q="+encodeURIComponent(h)
};
b.prototype.config={searchUrl:"/services/search/global",limit:10};
b.moduleName="Search 23";
b.selector=".search-ui-23";
return b
});
define("ResponsiveImage23",["require","media","utils","imager"],function(b,c){var d=$(window);
function a(e){this.$el=e;
this.$placeholder=this.$el.find("."+this.classes.placeholder);
this.data=$.extend({},this.$placeholder.data(),this.$el.data());
this.hideOnMobile=this.$el.hasClass(this.classes.hideOnMobile);
this.isDownloaded=false;
this.$el.on("renderImage",function(){this.render()
}.bind(this));
if(this.shouldBeShown()){this.render()
}d.on("resize",b("utils").debounce(this.render.bind(this),100))
}a.prototype.shouldBeShown=function(){if(b("utils-env").isEditMode()){return true
}return this.data.width!==0&&(c.currentMode().greaterThan(c.modes.WideMobile)||!this.hideOnMobile)
};
a.prototype.setMaxWidth=function(e,f){if(f.width&&f.widthUnits){e.css({maxWidth:f.width+f.widthUnits})
}};
a.prototype.render=function(){var e=this.isDownloaded||!this.shouldBeShown()||!this.$placeholder.is(":visible");
if(e){d.one("tab.changed",this.render.bind(this));
return
}b("imager").create(this.$placeholder);
this.isDownloaded=true;
this.$img=this.$el.find("."+this.classes.img);
this.$img.attr("title",this.data.title);
this.setMaxWidth(this.$img,this.data)
};
a.prototype.classes={placeholder:"responsive-image__placeholder",img:"responsive-image__img",hideOnMobile:"responsive-image--hide-on-mobile"};
a.selector=".responsive-image-ui-23";
a.moduleName="Responsive Image 23";
return a
});
define("RecruitingSearch23",["constants","geolocation","utils-env","utils"],function(l,f,e,g){var a=$(window),j={formOnly:"searchForm",formWithResults:"searchFormAndResults"};
var i="";
var d=new Intl.Collator();
var b={form:".recruiting-search__form",autocomplete:".js-autocomplete",fakeAutoComplete:".recruiting-search__fake-input",select:".recruiting-search__select",selectOption:"select2-results__option",selectOptions:"select2-results__options",selectOptionGroup:'select2-results__option[role="list"]',selectGroup:"select2-results__group",selectRendered:"select2-selection__rendered",selectBoxContainer:".select2-container",formComponentField:"form-component__field",location:".recruiting-search__location",searchFilter:".recruiting-search__filter",checkbox:".recruiting-search__checkbox",resultList:".search-result__list",resultContainer:".search-result",resultHeader:".search-result__heading",sortingMenu:".search-result__sorting-menu",sortingItem:".search-result__sorting-item",sortingRadio:".search-result__sorting-radio",hiddenDividerItem:"search-result__sorting-item--no-divider",itemName:".search-result__item-name",viewMore:".search-result__view-more",errorMessage:".search-result__error-message"};
function c(r,p){if($.trim(r.term)===""){return p
}if(typeof p.children==="undefined"){return null
}var m=i=r.term.toUpperCase();
var q="(^|.*\\s)("+m+")";
if(p.text.trim().toUpperCase().match(q)!==null){return p
}var n=[];
$.each(p.children,function(s,t){if(s>0){if(t.text.trim().toUpperCase().match(q)!==null){n.push(t)
}}});
if(n.length){var o=$.extend({},p,{text:"",hasChild:true},true);
o.children=n;
return o
}return null
}function k(n){function r(t,s){return d.compare(t.text,s.text)
}function p(t,s){$.each(t.children,function(u,v){s.push(v)
})
}function o(t,s){if(t.children.length!==0){$.each(t.children,function(u,v){if(u>0&&v.text.trim().toUpperCase().indexOf(i)===0&&v.text.trim().toUpperCase().indexOf(t.text.trim().toUpperCase())!==0){s.push(v)
}})
}}function m(){var s=this.$el.find(".dropdown-cities");
var t=s.find(".select2-results__options--nested");
if(s.length!==0&&t.length!==0){s.removeClass("dropdown-cities");
t.removeClass("open")
}}if(this.$el.find(".select2-search__field").val().trim().length!==0){var q=[];
$.each(n,function(s,t){if(t.hasChild){p(t,q)
}else{o(t,q);
q.push(t)
}});
if(q.length>1){setTimeout(m.bind(this),0)
}return q.sort(r)
}return n
}function h(m){this.$el=m;
this.$form=m.find(b.form);
this.$autocomplete=this.$form.find(b.autocomplete);
this.$fakeAutoComplete=$(".job-search-ui-23").find(b.fakeAutoComplete);
this.$select=this.$form.find(b.select);
this.$location=this.$form.find(b.location);
this.$results=this.$el.find(b.resultList);
this.isAuthor=e.isAuthor();
this.viewType=this.$el.data("view");
this.resultsUrl=this.$el.data("resultsUrl");
this.recruitingUrl=this.$el.data("recruitingUrl");
this.defaultSearchParameters={locale:CQ.I18n.getLocale(),limit:20,recruitingUrl:this.recruitingUrl};
this.init&&this.init();
this.initAutocomplete();
this.initSelect();
this.$el.data("useGeolocation")&&f.onGeolocationUpdate(this.fillWithGeolocation.bind(this));
this.$form.on("submit",this.submit.bind(this));
if(!this.isFormOnly()){this.initSearchResult()
}}h.prototype.init=null;
h.prototype.initAutocomplete=function(){this.$fakeAutoComplete.autocomplete($.extend({},this.getAutocompleteConfig(),{appendTo:this.$fakeAutoComplete.parent(),onSelect:function(m){this.submit(m,"fake")
}.bind(this)})).on("keyup",this.onEnter.bind(this));
this.$autocomplete.autocomplete($.extend({},this.getAutocompleteConfig(),{onSelect:function(m){this.submit(m,"real")
}.bind(this)})).on("keyup",this.onEnter.bind(this))
};
h.prototype.onEnter=function(m){m.key===l.Keys.enter&&this.submit()
};
h.prototype.getAutocompleteConfig=function(){return{serviceUrl:this.config.autocompletePath,triggerSelectOnValidInput:false,deferRequestBy:500,appendTo:this.$autocomplete.parent(),params:{locale:this.defaultSearchParameters.locale},transformResult:function(m){return{suggestions:JSON.parse(m)}
},onSelect:this.submit.bind(this),width:"343%",zIndex:10}
};
h.prototype.submit=function(n,m){n&&n.preventDefault&&n.preventDefault();
this.$form.trigger(l.Events.autocompleteSelected,[{initialInput:m}]);
if(!this.isFormOnly()){this.updateUrlAndLoadResults();
return
}window.location=this.toUrl(this.resultsUrl,this.getSubmitContext(),this.isAuthor)
};
h.prototype.getSubmitContext=null;
h.prototype.initSelect=function(){this.$select.selectWoo(this.getSelectConfig());
this.$selectBoxContainer=this.$el.find(b.selectBoxContainer);
this.$selectBoxContainer.addClass(b.formComponentField);
this.$location.on("click",this.openSelection.bind(this)).on("click","."+b.selectOption,this.toggleSelectItem.bind(this)).on("click","."+b.selectOptionGroup,this.toggleCities.bind(this))
};
h.prototype.openSelection=function(q,o){var p,n;
if(o){p=o.parents("."+b.selectOptionGroup)
}else{n=this.$location.find('[aria-selected="true"]')
}if(n&&n.length){p=n.parents("."+b.selectOptionGroup);
n.parents("."+b.selectOptions).addClass("open")
}if(p&&p.hasClass("dropdown-cities")){var r=p.offset().top-p.offsetParent().offset().top;
var m=this.$location.find("."+b.selectOptions+":first");
m.animate({scrollTop:m.scrollTop()+r+"px"},300)
}};
h.prototype.toggleSelectItem=function(p){var m=$(p.target),n=m.hasClass(b.selectGroup),o=n?m.siblings("."+b.selectOptions):m.children("."+b.selectOptions);
if(!o.length){return
}o.toggleClass("open")
};
h.prototype.toggleCities=function(n){var m=$(n.target);
if(m.hasClass(b.selectRendered)){return
}if(m.hasClass(b.selectGroup)){m.parent().toggleClass("dropdown-cities")
}else{m.toggleClass("dropdown-cities")
}this.openSelection(null,m);
return false
};
h.prototype.getSelectConfig=function(){return{dropdownParent:this.$location,placeholderOption:"first",matcher:c,width:"off",sorter:k.bind(this)}
};
h.prototype.fillWithGeolocation=function(m){var o={name:m.country},n={name:m.city};
if(!o.name){return
}o.$item=this.$select.find('[data-geolocation-name="'+o.name+'"]');
o.value=o.$item.length&&"all_"+o.$item.data("name");
if(n.name){n.$item=o.$item.find('[data-geolocation-name="'+n.name+'"]');
n.value=n.$item.val()
}if(o.value||n.value){this.$select.val(n.value||o.value).trigger("change")
}};
h.prototype.isFormOnly=function(){return this.viewType===j.formOnly
};
h.prototype.initSearchResult=function(){this.$resultContainer=this.$el.find(b.resultContainer);
this.$resultHeader=this.$resultContainer.find(b.resultHeader);
this.$sortingMenu=this.$resultContainer.find(b.sortingMenu);
this.$sortingItem=this.$resultContainer.find(b.sortingItem);
this.$sortingRadio=this.$resultContainer.find(b.sortingRadio);
this.$preloader=this.$resultContainer.find("."+l.Classes.preloader).toggle(false);
this.$viewMore=this.$resultContainer.find(b.viewMore).toggle(false);
this.$errorMessage=this.$resultContainer.find(b.errorMessage).toggle(false);
this.$sortingRadio.on("change",this.updateUrlAndLoadResults.bind(this));
this.$select.on("change",this.updateUrlAndLoadResults.bind(this));
this.$viewMore.on("click",this.loadMoreResults.bind(this));
a.on("scroll",this.loadResultsOnScroll.bind(this));
this.beforeLoadResults&&this.beforeLoadResults();
this.loadResults(this.collectSearchParameters(0,true))
};
h.prototype.beforeLoadResults=null;
h.prototype.loadMoreResults=function(m){var o=this.$results.children().length,n=this.collectSearchParameters(o);
this.loadResults(n);
m&&m.preventDefault()
};
h.prototype.loadResultsOnScroll=function(){if(this.loading||!this.loadOnScroll||this.$viewMore.is(":visible")){return
}var o=a.height(),n=a.scrollTop(),m=this.$results.children().last().offset().top;
if(o+n>m){this.loadMoreResults()
}};
h.prototype.collectSearchParameters=function(n,o){var m={query:this.$autocomplete.val(),country:this.getCountry(),city:this.getCity(),sort:this.getSorting(),offset:n||0,buildSchemaOrgMarkup:o};
return $.extend({},this.defaultSearchParameters,m)
};
h.prototype.getCountry=function(){return this.$select.find(":selected").parent().data("name")
};
h.prototype.getCity=function(){if(!this.$select.find(":selected").is(":first-child")){return this.$select.val()
}};
h.prototype.getSorting=function(){return this.$sortingMenu?this.$sortingMenu.find(":checked").val():null
};
h.prototype.updateUrlAndLoadResults=function(m){m&&m.stopPropagation();
var o=this.collectSearchParameters(),n=this.updateUrl(o);
this.loadResults(o,n)
};
h.prototype.updateUrl=function(o){var r=$.extend({},o,{locale:null,limit:null,offset:null}),n=window.location.href,q=this.toUrl(window.location.pathname,r),m=n.length-q.length;
if(m<0||n.indexOf(q,m)!==m){window.history.pushState({},"",q);
if(window.initWechat){var p=window.location.href.split("#")[0];
initWechat(p)
}return true
}return false
};
h.prototype.toUrl=function(o,n,q){var m=o+(q?".html":""),p={};
Object.keys(n).forEach(function(s){var t=n[s],r=t&&(!$.isArray(t)||t.length);
if(r){p[s]=t
}});
return Object.keys(p).length?m+"?"+$.param(p):m
};
h.prototype.loadResults=function(m,n){$.ajax({url:this.config.searchUrl,data:m,cache:false,beforeSend:this.toggleLoadingState.bind(this,true),complete:this.toggleLoadingState.bind(this,false),success:this.updateSearchResults.bind(this,m),error:this.showErrorMessage.bind(this,n)})
};
h.prototype.updateSearchResults=function(w,o){var x=o.result,v=o.schemaOrgMarkup,t=o.total,m=this.getResultsContext(x),p=w.limit,q=w.offset,u=!x.length,s=q===0,n=t>q+p,r=!!w.buildSchemaOrgMarkup;
this.loadOnScroll=s&&n;
if(u||s){this.$results.empty()
}require("utils-dust").append("recruiting-search-23-result",m,this.$results);
this.showResultMessage(w.query,t);
this.$sortingMenu.toggleClass(l.Classes.hidden,u);
this.$resultHeader.toggle(!u);
this.$errorMessage.toggle(u);
this.$viewMore.toggle(!s&&n);
!s&&this.$results.find(b.itemName).eq(q).focus();
g.checkDividers(this.$sortingItem,b.hiddenDividerItem);
r&&!!v&&this.addSchemaOrgMarkup(v)
};
h.prototype.addSchemaOrgMarkup=function(m){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(m)+"<\/script>")
};
h.prototype.getResultsContext=null;
h.prototype.showErrorMessage=function(n){var m=CQ.I18n.getMessage("component.general.ajax-error-message")+" "+CQ.I18n.getMessage("component.general.ajax-error-try-again");
this.$errorMessage.text(m).show();
this.$sortingMenu.addClass(l.Classes.hidden);
if(n){this.$results.empty();
this.$resultHeader.hide();
this.$viewMore.hide()
}else{if(this.$results.children().length>=this.defaultSearchParameters.limit){this.$viewMore.show()
}}};
h.prototype.toggleLoadingState=function(m){this.$preloader.toggle(m);
this.loading=m
};
h.prototype.showResultMessage=function(p,o){if(!o){this.$errorMessage.text(CQ.I18n.getMessage("component.general.search-empty-result-for-combination"));
return
}var n=p?this.getResultMessageWithQuery(p,o):this.getResultMessage(o);
var m=n.replace(o,"<span>"+o+"</span>");
this.$resultHeader[0].innerHTML=m
};
h.prototype.getResultMessageWithQuery=null;
h.prototype.getResultMessage=null;
h.prototype.classes=b;
return h
});
define("PersonInfo23",["utils","media","imager"],function(b,d,a){var e=$(window);
function c(f){this.desktopImageLoaded=false;
this.mobileImageLoaded=false;
this.$el=f;
this.$mobilePlaceholder=this.$el.find("."+this.classes.mobilePlaceholder);
this.$desktopPlaceholder=this.$el.find("."+this.classes.desktopPlaceholder);
this.render();
e.on("resize",b.debounce(this.render.bind(this),100))
}c.prototype.isDesktop=function(){return d.currentMode().greaterThan(d.modes.Tablet)
};
c.prototype.render=function(){if(this.isDesktop()){if(!this.desktopImageLoaded){a.create(this.$desktopPlaceholder);
this.desktopImageLoaded=true
}}else{if(!this.mobileImageLoaded){a.create(this.$mobilePlaceholder);
this.mobileImageLoaded=true
}}};
c.prototype.classes={desktopPlaceholder:"person-info-23__desktop-placeholder",mobilePlaceholder:"person-info-23__mobile-placeholder"};
c.moduleName="Person Info 23";
c.selector=".person-info-ui-23";
return c
});
define("NewsReleases23",["utils-share"],function(b){function a(c){this.$el=c;
this.$newsList=this.$el.find("."+this.classes.newsList);
this.$socialLinks=this.$el.find("."+this.classes.socialLink);
this.setSocialLinks();
this.$newsList.on("click","."+this.classes.socialLink,this.openPopup.bind(this))
}a.prototype.setSocialLinks=function(){this.$socialLinks.each(function(){var c=window.location.origin+$(this).data("path");
$(this).removeAttr("data-path").attr("data-url",c).attr("data-count_url",c)
})
};
a.prototype.openPopup=function(d){var c=this.getLinkData(d.currentTarget);
b.openPopup(c);
return false
};
a.prototype.getLinkData=function(c){return b.getLink($(c).data())
};
a.prototype.classes={socialLink:"news-releases-23__social-link",newsList:"news-releases-23__list"};
a.moduleName="News Releases 2023";
a.selector=".news-releases-ui-23";
return a
});
define("NewsFilter23",["require","media","constants","NewsFilterA11YLayer","utils-share","utils-env","utils-dust","jquery-plugins"],function(c,g,d,a){var h=$(window),f=$("body");
var e=c("utils-share");
function b(i){this.$el=i;
this.$newsList=this.$el.find("."+this.classes.newsList);
this.$preloader=this.$el.find("."+d.Classes.preloader);
this.$viewMore=this.$el.find("."+this.classes.viewMore);
this.$errorMessage=this.$el.find("."+this.classes.errorMessage);
this.$badRequestMessage=this.$el.find("."+this.classes.badRequestMessage);
this.$emptyResultMessage=this.$el.find("."+this.classes.emptyResultMessage);
this.defaultParameters={paths:this.$el.data("paths"),dateFormat:this.$el.data("dateFormat"),limit:this.constants.LIMIT,offset:0,locale:CQ.I18n.getLocale()};
this.defaulContext=this.createDefaultContext();
this.isTouch=Modernizr.touchevents;
this.initFilters();
this.$newsFilterA11YLayer=new a(i,this,e);
this.$newsList.on(this.isTouch?"click":"mouseover","."+this.classes.share,this.toggleShare.bind(this));
this.$newsList.on("click","."+this.classes.socialLink,this.openPopup.bind(this));
this.$viewMore.on("click",this.loadMoreNewsPages.bind(this));
this.collectParametersAndLoad(true);
this.$el.pinFilterTop()
}b.prototype.createDefaultContext=function(){var i=this.$el.data("socialIcons")||"";
return{socialIcons:i.split(","),spritePath:EPAM.spritePath,origin:window.location.origin,isAuthor:c("utils-env").isAuthor()}
};
b.prototype.initFilters=function(){var j=this.$el.find("."+this.classes.newsFilter),i=this.$el.data("hasNewsFilter");
this.$year=j.filter("."+this.classes.year);
this.initSelect(this.$year);
this.collectParameters=this.collectYearParameters;
if(i){this.$newsType=j.filter("."+this.classes.newsType);
this.initSelect(this.$newsType);
this.collectParameters=this.collectNewsTypeParameters
}j.on("change",function(){this.collectParametersAndLoad();
this.scrollResultsToTop()
}.bind(this))
};
b.prototype.initSelect=function(i){i.selectWoo({width:"off",dropdownParent:i.parent("."+this.classes.input)});
this.$selectBoxContainer=this.$el.find(this.classes.selectBoxContainer);
this.$selectBoxContainer.addClass(this.classes.formComponentField)
};
b.prototype.collectNewsTypeParameters=function(){return $.extend(this.collectYearParameters(),{newsType:this.getFilterValue(this.$newsType)})
};
b.prototype.collectYearParameters=function(){return $.extend({},this.defaultParameters,{year:this.getFilterValue(this.$year)})
};
b.prototype.getFilterValue=function(i){var j=i.val();
if(j){return j
}};
b.prototype.toggleShare=function(m){var l=$(m.currentTarget),j=g.currentMode().greaterThan(g.modes.WideMobile),i=$(m.target),k=this.classes.shareOpened;
function n(){l.removeClass(k)
}if(!j&&!i.parents().hasClass(this.classes.shareMobile)){return
}else{l.addClass(k);
if(this.isTouch){m.stopPropagation();
h.one("click",n)
}else{l.one("mouseout",n)
}}};
b.prototype.openPopup=function(j){var i=this.getLinkData(j.currentTarget);
e.openPopup(i);
return false
};
b.prototype.getLinkData=function(i){return e.getLink($(i).data())
};
b.prototype.loadMoreNewsPages=function(){var j=this.$newsList.children().length,i=$.extend(this.collectParameters(),{offset:j});
this.loadNewsPages(i)
};
b.prototype.collectParametersAndLoad=function(i){this.loadNewsPages($.extend(this.collectParameters(),{buildSchemaOrgMarkup:i}))
};
b.prototype.loadNewsPages=function(i){$.ajax({url:this.constants.URL,data:i,beforeSend:this.toggleLoadingState.bind(this,true),success:this.updateNewsPages.bind(this,i),error:this.showErrorMessage.bind(this),complete:this.toggleLoadingState.bind(this,false),cache:false})
};
b.prototype.toggleLoadingState=function(i){this.$preloader.toggleClass(d.Classes.hidden,!i);
i&&this.$errorMessage.addClass(d.Classes.hidden)
};
b.prototype.updateNewsPages=function(p,l){var q=l.result,o=l.schemaOrgMarkup,k=p.offset,n=!q.length,j=l.total>k+p.limit,m=!!p.buildSchemaOrgMarkup;
var i=this.$newsList.find(this.classes.lastNews);
(n||!k)&&this.$newsList.empty();
this.$emptyResultMessage.toggleClass(d.Classes.hidden,!n);
this.$viewMore.toggleClass(d.Classes.hidden,!j);
this.renderNewsPages(q);
this.$newsFilterA11YLayer.focusFirstItemAfterLoadNewItems(i);
m&&!!o&&this.addSchemaOrgMarkup(o)
};
b.prototype.renderNewsPages=function(i){var j=$.extend({pages:i},this.defaulContext);
c("utils-dust").append(this.constants.TEMPLATE,j,this.$newsList)
};
b.prototype.addSchemaOrgMarkup=function(i){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(i)+"<\/script>")
};
b.prototype.showErrorMessage=function(){this.$badRequestMessage.removeClass(d.Classes.hidden)
};
b.prototype.scrollResultsToTop=function(){if(f.hasClass(d.Classes.pinnedFilter)){this.$el.scrollToSelector({duration:500})
}};
b.prototype.constants={URL:"/services/search/news-pages",TEMPLATE:"news-list-23",LIMIT:12};
b.prototype.classes={selectBoxContainer:".select2-container",formComponentField:"form-component__field",input:"news-filter-23__input",newsFilter:"news-filter-23__select",newsType:"news-filter-23__select--newstype",year:"news-filter-23__select--year",share:"news-filter-23__item",shareMobile:"news-filter-23__share",shareOpened:"news-filter-23__share--opened",shareButton:"news-filter-23__share-button",socialLink:"news-filter-23__social-link",newsList:"news-filter-23__results",viewMore:"news-filter-23__view-more",errorMessage:"news-filter-23__error-message",badRequestMessage:"news-filter-23--bad-request",emptyResultMessage:"news-filter-23--empty-result",lastNews:">li:last-child",newsItemIcon:"news-filter-23__icon-item"};
b.moduleName="News Filter 2023";
b.selector=".news-filter-ui-23";
return b
});
define("NewsFilterA11YLayer",[],function(){var a=$("html");
var c={shareButton:".news-filter-23__share-button",newsFilterItem:".news-filter-23__item",newsFilterShareOpened:"news-filter-23__share--opened",newsFilterIconsListFirstChild:".news-filter-23__icons-list > li:first-child",newFilterTitle:".news-filter-23__title",newsFilterTitleLink:".news-filter-23__title a"};
function b(f,e,d){this._el=f;
this._self=e;
this._shareLib=d;
this.init()
}b.prototype.init=function(){this.initEvents()
};
b.prototype.onShareButtonClickHandler=function(e){var d=$(e.target).parents(c.newsFilterItem);
if(d.length){d.addClass(c.newsFilterShareOpened);
d.find(c.newsFilterIconsListFirstChild).focus()
}};
b.prototype.onFocusinHandler=function(){if(a.hasClass("key-used")){var d=this._el.find("."+c.newsFilterShareOpened);
if(d.length){d.removeClass(c.newsFilterShareOpened)
}}};
b.prototype.focusFirstItemAfterLoadNewItems=function(d){if(d.length){d.next().find(c.newsFilterTitleLink).focus()
}};
b.prototype.onKeydownHandler=function(e){if(e.key==="Enter"){var d=this._shareLib.getLink($(e.currentTarget).children("a").data());
this._shareLib.openPopup(d);
return false
}};
b.prototype.onClickHandler=function(e){var f=e.target.firstChild;
var d=this._self.getLinkData(f);
this._shareLib.openPopup(d);
return false
};
b.prototype.initEvents=function(){this._el.on("click",c.shareButton,this.onShareButtonClickHandler.bind(this));
this._el.on("focusin",c.newFilterTitle,this.onFocusinHandler.bind(this));
this._self.$newsList.on("keydown","."+this._self.classes.newsItemIcon,this.onKeydownHandler.bind(this));
this._self.$newsList.on("click","."+this._self.classes.newsItemIcon,this.onClickHandler.bind(this))
};
return b
});
define("MixedVacancyBlock23",["constants","utm-utils"],function(d,f){var a=$("html");
var c={placeOfWork:".mixed-vacancy-block__place-of-work",buttonWrapper:".mixed-vacancy-block__button-wrapper",buttonDisabled:"mixed-vacancy-block__button-wrapper--disabled",checkbox:".checkbox"};
const e={office:"office",home:"home"};
function b(g){this.$el=g;
this.$placeOfWork=this.$el.find(c.placeOfWork);
this.$buttonWrapper=this.$el.find(c.buttonWrapper);
this.$checkbox=this.$el.find(c.checkbox);
this.$vacancyButton=this.$buttonWrapper.find("button");
this.$vacancyLink=this.$buttonWrapper.find("a");
this.$inputOffice=this.$el.find("#place-of-work_office");
this.$inputHome=this.$el.find("#place-of-work_home");
this.$vacancyButton.on("click",this.handleButtonClick.bind(this));
this.$vacancyLink.on("click",this.handleLinkClick.bind(this));
this.$placeOfWork.on("change","input",this.handleRadioButtonChange.bind(this))
}b.prototype.handleRadioButtonChange=function(h){const g=$(h.target).val();
this.$buttonWrapper.removeClass(c.buttonDisabled);
if(this.$inputOffice.prop("checked")===false&&this.$inputHome.prop("checked")===false){this.$buttonWrapper.addClass(c.buttonDisabled)
}if(g===e.office){this.$vacancyLink.addClass(d.Classes.hidden);
this.$vacancyButton.removeClass(d.Classes.hidden)
}else{if(g===e.home){this.$vacancyLink.removeClass(d.Classes.hidden);
this.$vacancyButton.addClass(d.Classes.hidden)
}}this.$checkbox.change(function(){const i=$(this).prop("checked");
$(".checkbox").prop("checked",false);
$(this).prop("checked",true);
if(i===false){$(this).prop("checked",false)
}})
};
b.prototype.handleButtonClick=function(){a.trigger(d.Events.showVacancyForm);
this.$el.addClass(d.Classes.hidden)
};
b.prototype.handleLinkClick=function(){var g=f.buildAnywhereUrl(this.$vacancyLink.data("href"));
this.$vacancyLink.attr("href",g)
};
b.moduleName="Mixed Vacancy Block 23";
b.selector=".mixed-vacancy-block-ui-23";
return b
});
define("LocationsViewer23",["media","utils","SocialIcons","jquery-plugins"],function(b,h,d){var a=$(window),f=60,c=194,g=100;
var e={carousel:".locations-viewer-23__carousel",country:"locations-viewer-23__country",countryButton:".locations-viewer-23__country-btn",countryList:".locations-viewer-23__country-list",active:"active",owlLoaded:"owl-loaded",carouselButtons:".owl-nav button",nextLocationBtn:".locations-viewer-23__next-country-btn",activeCountryTile:".owl-item.active .locations-viewer-23__country"};
function i(k){this.$el=k;
this.$carousel=this.$el.find(e.carousel);
this.$countryList=this.$el.find(e.countryList);
this.countryCount=this.$countryList.children().length;
this.$countryButton=this.$el.find(e.countryButton);
this.$nextLocationBtn=this.$el.find(e.nextLocationBtn);
this.windowWidth=a.width();
var l={};
l[b.modes.WideMobile.start]={items:this.countryCount>2?2:this.countryCount};
l[b.modes.Desktop.start]={items:this.countryCount>3?3:this.countryCount};
l[b.modes.Broad.start]={items:this.countryCount>4?4:this.countryCount};
var j=$.extend({},this.config,{dots:false,lazyLoadEager:8,lazyLoad:true,loop:false,nav:false,onInitialized:this.carouselInitialized.bind(this),navElement:'button type="button"',navText:["Previous card","Next card"]});
this.$el.attr("data-item-count",this.countryCount);
this.$parentTabItem=this.$carousel.parents(".js-tabs-item");
if(!this.$parentTabItem.length){this.$carousel.owlCarousel(j)
}a.on("tab.loaded tab.changed tab.change",function(){this.$parentTabItem.removeAttr("tabindex");
if(this.$carousel.parents(".js-tabs-item.active").length&&!this.$carousel.hasClass(e.owlLoaded)){this.$carousel.owlCarousel(j);
this.$carouselButtons=this.$carousel.find(e.carouselButtons);
this.addEventListenersToCarouselButtons();
this.addEventListenersToNextLocation()
}}.bind(this));
this.$actualElements=this.$carousel.find(".owl-item:not(.cloned)");
this.$countries=this.$carousel.find("."+e.country);
this.$carousel.on("click","."+e.country,this.toggleExpand.bind(this)).on("refreshed.owl.carousel",this.updateSelectors.bind(this)).on("translated.owl.carousel",this.onTranslated.bind(this));
a.on("resize orientationchange",function(){if(a.width()!==this.windowWidth){h.debounce(this.recalculateHeight(),g);
this.reInitCarousel(j).done(this.focusOnActive.bind(this))
}}.bind(this));
this.socialIcons=new d(this.$el);
h.addExtensionToPhoneNumber(this.$el);
this.isUrlContainsHash(j);
this.addEventListenersToCountryButtons(this.countryCount)
}i.prototype.isUrlContainsHash=function(l){var k=window.location.href;
var m=new RegExp("(/?#.{1,})","i");
var j=m.test(k);
if(j){this.reInitCarousel(l).done(this.focusOnActive.bind(this))
}};
i.prototype.carouselInitialized=function(){this.$carouselButtons=this.$carousel.find(e.carouselButtons)
};
i.prototype.reInitCarousel=function(j){var k=$.Deferred();
setTimeout(function(){this.$carousel.owlCarousel("destroy");
this.$carousel.owlCarousel(j);
k.resolve()
}.bind(this),g);
return k.promise()
};
i.prototype.recalculateHeight=function(){if(!this.$countryList.hasClass(e.active)){return
}setTimeout(function(){this.$countryList.height(this.$opened.outerHeight())
}.bind(this),0)
};
i.prototype.scrollToList=function(k){var j=window.innerWidth>window.innerHeight&&b.currentMode().lessThan(b.modes.Tablet);
if(j&&k.hasClass(e.active)){return
}var l=j?-c:f;
this.$carousel.scrollToSelector({reservedSpace:l,duration:400})
};
i.prototype.updateSelectors=function(){this.$countries=this.$carousel.find("."+e.country)
};
i.prototype.clearState=function(){this.$countries.removeClass(e.active);
this.$countryList.children().removeClass(e.active).attr("aria-hidden",true);
if(this.$carouselButtons){this.$carouselButtons.removeAttr("tabindex")
}};
i.prototype.updateHeight=function(){var j=this.$opened.outerHeight();
this.$countryList.toggleClass(e.active,!!j).height(j?j:0)
};
i.prototype.onTranslated=function(){if(!this.currentActiveCountry){return
}this.$countries.filter('[data-country="'+this.currentActiveCountry+'"]').removeClass("active");
this.$el.find(".owl-item.active").find('[data-country="'+this.currentActiveCountry+'"]').addClass("active")
};
i.prototype.toggleExpand=function(l){var j=$(l.currentTarget),m=j.data("country");
this.$opened=this.$countryList.find('[data-country="'+m+'"]');
var k=this.$opened.hasClass(e.active);
this.currentActiveCountry=k?null:m;
this.toggleBlock(k,m,j);
this.updateHeight();
this.scrollToList(j)
};
i.prototype.toggleBlock=function(o,q,p){this.clearState();
var k=this.$countries.filter('[data-country="'+q+'"]'),m=this.$carousel.find(".owl-item.active").find(e.countryButton),n=p.find("button"),l=this.$carousel.find(e.countryButton),j=this.$countries.index(k);
k.toggleClass(e.active,!o);
this.$opened.toggleClass(e.active,!o);
this.$carousel.toggleClass(e.active,!o);
this.$carousel.trigger("to.owl.carousel",[j,300]);
if(!o){this.$opened.removeAttr("aria-hidden");
if(this.$carouselButtons){this.$carouselButtons.attr("tabindex","-1")
}l.attr("tabindex","-1");
l.attr("aria-expanded",true);
n.attr("tabindex","0")
}else{this.$opened.attr("aria-hidden",true);
l.attr("aria-expanded",false);
m.attr("tabindex","0")
}};
i.prototype.focusOnActive=function(){if(!this.currentActiveCountry){return
}this.$actualElements=this.$carousel.find(".owl-item:not(.cloned)");
var j=this.$actualElements.has("."+e.country+'[data-country="'+this.currentActiveCountry+'"]');
this.$carousel.trigger("to.owl.carousel",this.$actualElements.index(j))
};
i.prototype.config={loop:true,callbacks:true,items:1,autoWidth:true,responsive:{},lazyLoad:true,nav:true};
i.prototype.addEventListenersToCountryButtons=function(j){this.$countryButton.each(function(n){var q=$(this);
var o=q.attr("data-country-title");
var p=q.attr("data-cities-count");
var k=p>1?" locations":" location";
var m="Card "+(n+1)+" of "+j+" "+o;
q.attr("aria-label",m);
function l(){return q.attr("aria-expanded")!=="false"
}q.on("unfocus",function(){!l()&&q.attr("aria-label",m)
});
q.on("click",function(){l()?q.attr("aria-label",m):q.attr("aria-label",o+" button "+p+k)
})
})
};
i.prototype.addEventListenersToCarouselButtons=function(){var j=this;
this.$carouselButtons.on("focus",function(){var l=this.closest(".section__wrapper");
var k=l.getBoundingClientRect().top;
if(k<0){var m=$(l).offset().top;
$("html, body").animate({scrollTop:m},0)
}});
this.$carouselButtons.on("click",function(){j.refreshActiveCardsCounts();
var k=j.createCarouselButtonAriaLabelText();
$(this).attr("aria-label",k)
});
this.$carouselButtons.on("blur",function(){$(this).removeAttr("aria-label")
})
};
i.prototype.addEventListenersToNextLocation=function(){var j=this;
this.$nextLocationBtn.on("click",function(){var l=j.$countries.filter(".active"),k=j.$countries.index(l);
if(k!==j.countryCount-1){l.parent().next().find(e.countryButton).click()
}else{j.$countries.first().find(e.countryButton).click()
}})
};
i.prototype.refreshActiveCardsCounts=function(){var j=this.$carousel.find(e.activeCountryTile);
this.activeCardsCounts=j.map(function(){return $(this).attr("data-count")
})
};
i.prototype.createCarouselButtonAriaLabelText=function(){var n=this.activeCardsCounts.length;
for(var m=0;
m<this.activeCardsCounts.length-1;
m++){if(this.activeCardsCounts[m]>this.activeCardsCounts[m+1]){n=m+1
}}var o=[];
var l=this.activeCardsCounts.slice(0,n);
var k=this.activeCardsCounts.slice(n);
var p=this.createRange(l);
var j=this.createRange(k);
p&&o.push(p);
j&&o.push(j);
return"Cards "+o.join(", ")+" out of "+this.countryCount+" are shown"
};
i.prototype.createRange=function(j){if(j.length===0){return""
}if(j.length===1){return j[0]
}return j[0]+" - "+j[j.length-1]
};
i.moduleName="Locations Viewer 23";
i.selector=".locations-viewer-ui-23";
return i
});
define("JobSearch23",["RecruitingSearch23","analytics","utils-share","constants","media","jquery-plugins"],function(l,g,j,k,b){var a=$(window);
var d=$("body");
var c=$.extend({},l.prototype.classes,{multiselect:".js-multi-select",searchSelect:".recruiting-search__select",searchCheckbox:".recruiting-search__checkbox",initializedMultiSelect:".multi-select-filter",departments:"job-search__departments",resultItem:".search-result__item",shareButton:"button.search-result__share-button",referLink:"a.search-result__share-button",shareOpened:"search-result__share--opened",socialLink:".search-result__social-link",submitButton:".recruiting-search__submit",header:".header-ui",preserveHeader:"job-search-preserve-header",keywordLabel:".recruiting-search__keyword-label",wrapperMobile:".recruiting-search__wrapper-mobile",filterButton:".recruiting-search__filter-button",filterButtonClose:"recruiting-search__filter-button-close",fakePinnedInput:"recruiting-search__fake-input",searchInput:"recruiting-search__input:not(.recruiting-search__fake-input)",jobSearchOpenButton:".recruiting-search__job-search",pinnedPanelCloseButton:".recruiting-search__close-button"});
var f={experience:'[name="experience"]',relocation:'[name="relocation"]',remote:'[name="remote"]',office:'[name="office"]'};
function h(m){return function(n){return m[n]
}
}function e(n,m){n[m]={type:m,title:CQ.I18n.getMessage("component.general.social-icon.icon-"+m)};
return n
}function i(m){l.call(this,m);
this.$departmentsSelect=$('select[name="department"]');
this.$jobSearchDepartments=m.find(".job-search__departments");
this.$isShouldUpdate=true;
var n=this.$el.data("socialIcons");
if(!n){return
}this.titles=["fb","tw","li","vk"].reduce(e,{});
this.socialIcons=this.getSocialIconsFromData(this.$el.data("socialIcons")).map(h(this.titles));
this.$fetchOptions={beforeSend:function(){this.$departmentsSelect.trigger(k.Events.multiSelectBeforeUpdate)
}.bind(this),successCallback:function(p){try{var o=JSON.parse(p);
this.handleSuccessSkillsFetch(o)
}catch(q){console.warn(q)
}}.bind(this)};
this.$jobSearchDepartments.on("dropdown:open",function(){if(this.$isShouldUpdate){this.$fetchOptions.url=this.createSkillsFetchRequest();
this.fetch(this.$fetchOptions)
}}.bind(this));
this.firstDepartmentUpdate()
}i.prototype=Object.create(l.prototype);
i.prototype.init=function(){var o=this.$el.hasClass("dark-style");
this.$isApplyOverlay=this.$el.hasClass("apply-overlay");
this.$mobileWrapper=this.$el.find(c.wrapperMobile);
this.$pinnedPanelCloseButton=this.$el.find(c.pinnedPanelCloseButton);
if(o){var m=this.$el.find(c.jobSearchOpenButton);
m.on("click",this.toggleShowForm.bind(this))
}this.$filterButton=this.$el.find(c.filterButton);
this.$fakeSearchInput=this.$el.find("."+c.fakePinnedInput);
this.$realSearchInput=this.$el.find("."+c.searchInput);
this.$filterButton.removeClass(c.filterButtonClose);
this.$filterButton.on("click",this.toggleShowForm.bind(this));
this.$pinnedPanelCloseButton.on("click",this.toggleShowForm.bind(this));
this.$form.on("submit",function(){if(this.$form.hasClass("show")){this.$form.toggleClass("show");
this.$filterButton.toggleClass(c.filterButtonClose)
}}.bind(this));
this.$el.attr("data-location",this.getCountry());
this.$isPinned=this.$el.data("is-pinned");
this.$multiSelect=this.$el.find(c.multiselect);
this.$searchFilters=this.$form.find(c.searchFilter);
this.$checkbox=this.$searchFilters.find(c.checkbox);
this.$header=d.find(c.header);
this.$searchCheckbox=this.$el.find(c.searchCheckbox);
if(this.$multiSelect.length){this.$multiSelect.multiSelectFilter({showTags:true,className:c.departments});
this.$multiSelectEl=this.$el.find(c.initializedMultiSelect)
}this.$location.on("select2:open",function(){this.$multiSelectEl.trigger("dropdown:close")
}.bind(this));
this.$location.on("select2:select",function(){this.setDataLocation();
this.$isShouldUpdate=true
}.bind(this));
this.$results.on("click",c.shareButton,this.toggleShare.bind(this));
this.$results.on("click",c.referLink,this.pushGtmEvent);
var n=this.$realSearchInput.val()||this.$fakeSearchInput.val();
this.$realSearchInput.val(n);
this.$fakeSearchInput.val(n);
this.$fakeSearchInput.on("input keydown",this.fakeSearchInputChangeHandler.bind(this));
this.$realSearchInput.on("input keydown",this.searchInputChangeHandler.bind(this));
this.$fakeSearchInput.keypress(this.fakeSearchInputKeypressHandler.bind(this));
this.$searchCheckbox.on("change",this.handlerCheckBoxSelect.bind(this));
if(this.$isPinned){this.$searchSelect=this.$el.find(c.searchSelect);
this.$submitButton=this.$el.find(c.submitButton);
this.$el.pinFilterTop(true,{value:50,getSpacerHeight:function(){if(b.currentMode().lessThan(b.modes.Desktop)){return 650
}return 250
},getPanelTopOffset:this.getPanelTopOffset.bind(this)});
this.$multiSelect.on("change",this.scrollToTop.bind(this));
this.$searchSelect.on("change",this.scrollToTop.bind(this));
this.$searchCheckbox.on("change",this.scrollToTop.bind(this));
this.$submitButton.on("click",this.scrollToTop.bind(this));
this.$header.addClass(c.preserveHeader);
$(window).trigger("scroll");
this.$form.on(k.Events.autocompleteSelected,this.autoCompleteSelectWasSelected.bind(this))
}};
i.prototype.getPanelTopOffset=function(){return this.$isApplyOverlay?this.$el.offset().top-200:this.$el.offset().top
};
i.prototype.toggleShowForm=function(){this.$form.toggleClass("show");
this.$mobileWrapper.toggleClass("expanded");
this.$filterButton.toggleClass(c.filterButtonClose)
};
i.prototype.firstDepartmentUpdate=function(){this.$departments=null;
var o=window.location.search;
var m=new URLSearchParams(o);
this.$departments=m.getAll("department");
if(this.$departments.length>0){var n={url:this.createSkillsFetchRequest(),successCallback:function(p){try{this.handleFirstSuccessSkillsFetch(JSON.parse(p))
}catch(q){console.warn(q)
}}.bind(this)};
this.fetch(n)
}};
i.prototype.handlerCheckBoxSelect=function(){this.$isShouldUpdate=true
};
i.prototype.autoCompleteSelectWasSelected=function(m,n){if(n.initialInput==="fake"){this.fakeSearchInputChangeHandler()
}else{this.searchInputChangeHandler()
}};
i.prototype.fakeSearchInputChangeHandler=function(){this.$realSearchInput.val(this.$fakeSearchInput.val());
this.$isShouldUpdate=true
};
i.prototype.searchInputChangeHandler=function(){this.$fakeSearchInput.val(this.$realSearchInput.val());
this.$isShouldUpdate=true
};
i.prototype.fakeSearchInputKeypressHandler=function(m){if(m.keyCode===13){this.$submitButton.trigger("click")
}};
i.prototype.scrollToTop=function(){if(b.currentMode().greaterThan(b.modes.Tablet)){this.scrollResultsToTop()
}};
i.prototype.getSocialIconsFromData=function(m){return m&&m.split(",")
};
i.prototype.beforeLoadResults=function(){this.$multiSelect.on("change",this.updateUrlAndLoadResults.bind(this));
this.$checkbox.on("change",this.updateUrlAndLoadResults.bind(this));
this.$results.on("click",c.socialLink,this.openPopup.bind(this))
};
i.prototype.collectSearchParameters=function(n){var m={query:this.$autocomplete.val(),country:this.getCountry(),city:this.getCity(),sort:this.getSorting(),department:this.$multiSelect.val()||[],experience:this.getExperience(),relocation:this.isRelocation(),remote:this.isRemote(),office:this.isOffice(),offset:n||0,searchType:this.$el.data("searchtype")||""};
return $.extend({},this.defaultSearchParameters,m)
};
i.prototype.getExperience=function(){return this.$checkbox.filter(f.experience+":checked").map(function(){return $(this).val()
}).get()
};
i.prototype.isRelocation=function(){return this.$checkbox.filter(f.relocation+":checked").val()
};
i.prototype.isRemote=function(){return this.$checkbox.filter(f.remote+":checked").val()
};
i.prototype.isOffice=function(){return this.$checkbox.filter(f.office+":checked").val()
};
i.prototype.getSubmitContext=function(){return{query:this.$autocomplete.val(),country:this.getCountry(),city:this.getCity(),department:this.$multiSelect.val(),relocation:this.isRelocation(),office:this.isOffice(),remote:this.isRemote()}
};
i.prototype.getResultsContext=function(m){return{list:m,spritePath:EPAM.spritePath,socialIcons:this.socialIcons,gtmLabel:this.$el.data("referGtmLabel"),showFooter:true}
};
i.prototype.getResultMessageWithQuery=function(o,n){var m='"'+o+'"';
return n===1?CQ.I18n.getMessage("component.job-search.result_header.one_result",[m]):CQ.I18n.getMessage("component.job-search.result_header",[m,n])
};
i.prototype.getResultMessage=function(m){return m===1?CQ.I18n.getMessage("component.job-search.result_header.no_query.one_result"):CQ.I18n.getMessage("component.job-search.result_header.no_query",[m])
};
i.prototype.toggleShare=function(n){var o=$(n.currentTarget),m=o.closest(c.resultItem);
function p(q){return function(){q.removeClass(c.shareOpened)
}
}m.addClass(c.shareOpened);
setTimeout(function(){m.find(c.socialLink).first().focus()
});
a.one("click",function(){a.one("click",p(m))
})
};
i.prototype.pushGtmEvent=function(m){var n=$(m.currentTarget);
var o=g.getEvent(n);
g.push(o)
};
i.prototype.openPopup=function(n){var m=j.getLink($(n.currentTarget).data());
j.openPopup(m);
return false
};
i.prototype.setDataLocation=function(){var m=this.getCountry();
this.$el.attr("data-location",m?m:"")
};
i.prototype.scrollResultsToTop=function(){if(d.hasClass(k.Classes.pinnedFilter)){this.$el.scrollToSelector({duration:500,reservedSpace:400})
}};
i.prototype.fetch=function(m){$.ajax(m.url,{beforeSend:m.beforeSend,success:m.successCallback,error:function(o,p,n){this.$departmentsSelect.trigger(k.Events.multiSelectErrorUpdate);
console.warn(n)
}})
};
i.prototype.handleSuccessSkillsFetch=function(m){this.$isShouldUpdate=false;
var n=[];
for(var o=0;
o<m.length;
o++){n.push(new Option(m[o],m[o],false,false))
}this.$departmentsSelect.empty();
this.$departmentsSelect.append(n);
this.$departmentsSelect.trigger(k.Events.multiSelectUpdate)
};
i.prototype.handleFirstSuccessSkillsFetch=function(m){this.$isShouldUpdate=false;
var o=[];
for(var p=0;
p<m.length;
p++){var n=this.$departments.includes(m[p]);
o.push(new Option(m[p],m[p],n,n))
}this.$departmentsSelect.empty();
this.$departmentsSelect.append(o);
this.$departmentsSelect.trigger(k.Events.multiSelectFirstUpdate);
this.$form.trigger("submit")
};
i.prototype.createSkillsFetchRequest=function(){var m=this.collectSearchParameters();
delete m.department;
return this.toUrl("/services/department/search",m)
};
i.prototype.config={autocompletePath:"/services/search/smart-search.vacancy.json",searchUrl:"/services/vacancy/search"};
i.moduleName="Job Search 23";
i.selector=".job-search-ui-23";
return i
});
define("HeaderSearch23",["Header23","media","constants"],function(g,f,e){var b=$("html"),a=$("body").children("."+e.Classes.overlay).last();
var d={button:".header-search__button",panel:".header-search__panel",input:".header-search__input",submit:".header-search__submit",opened:"opened",frequentSearch:".frequent-searches-ui"};
function c(h){this.$el=h;
this.$button=this.$el.find(d.button);
this.$panel=this.$el.find(d.panel);
this.$input=this.$panel.find(d.input);
this.$submit=this.$panel.find(d.submit);
this.openPanel=this.openPanel.bind(this);
this.closePanel=this.closePanel.bind(this);
this.closeWhenClickedOutside=this.closeWhenClickedOutside.bind(this);
this.onShiftTabOnButton=this.onShiftTabOnButton.bind(this);
this.$button.one("click",this.triggerOpen);
this.$el.on("keyup",this.onEscPress.bind(this));
this.$submit.on("keydown",this.onTabOnSubmit.bind(this));
this.$el.on("click",this.onClickHandler.bind(this));
g.registerMenu({name:c.moduleName,hasOverlay:true,hasDisabledScroll:function(){return f.currentMode().lessThan(f.modes.Desktop)
},onOpen:this.openPanel,onClose:this.closePanel,closeWhenClickedOutside:this.closeWhenClickedOutside})
}c.prototype.onClickHandler=function(h){h.stopPropagation()
};
c.prototype.onEscPress=function(h){if(h.key!==e.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
c.prototype.onTabOnSubmit=function(h){if(h.key!==e.Keys.tab||h.shiftKey){return
}h.preventDefault();
this.$button.focus()
};
c.prototype.onShiftTabOnButton=function(h){if(h.key!==e.Keys.tab||!h.shiftKey){return
}h.preventDefault();
this.$submit.focus()
};
c.prototype.triggerOpen=function(){b.trigger(e.Events.menuOpen,{opened:c.moduleName})
};
c.prototype.triggerClose=function(){b.trigger(e.Events.menuClose)
};
c.prototype.openPanel=function(){this.$panel.stop(true).slideDown().queue(function(){this.$input.focus();
this.$panel.addClass(d.opened)
}.bind(this));
this.$button.attr("aria-expanded",true).addClass(d.opened).one("click",this.triggerClose).on("keydown",this.onShiftTabOnButton);
a.one("click",this.triggerClose)
};
c.prototype.closePanel=function(){this.$input.blur();
this.$panel.removeClass(d.opened);
this.$panel.stop(true).slideUp();
a.off("click",this.triggerClose);
this.$button.attr("aria-expanded",false).removeClass(d.opened).off("click",this.triggerClose).one("click",this.triggerOpen).off("keydown",this.onShiftTabOnButton)
};
c.prototype.closeWhenClickedOutside=function(){var h=this.$el.find(d.frequentSearch);
if(h.length===0){this.closePanel();
return
}if(h.length>0&&h.hasClass("frequent-searches--hidden")){this.closePanel()
}};
c.prototype.classes=d;
c.moduleName="Header Search 23";
c.selector=".header-search-ui-23";
return c
});
define("LocationSelector23",["Header23","utils-a11y","constants"],function(g,b,j){var d=$("html"),e=$("body"),h=e.children("."+j.Classes.overlay).last();
var c={button:".location-selector__button",locations:".location-selector__panel",link:".location-selector__link",opened:"opened"};
function a(){d.trigger(j.Events.menuOpen,{opened:i.moduleName})
}function f(){d.trigger(j.Events.menuClose)
}function i(k){this.$el=k;
this.$button=this.$el.find(c.button);
this.$locations=this.$el.find(c.locations);
this.$lastLink=this.$locations.find(c.link).last();
this.hideLocations=this.toggleLocations.bind(this,false);
this.showLocations=this.showLocations.bind(this);
this.$button.one("click",a);
this.$el.on("keyup",this.closeOnEsc.bind(this));
this.$lastLink.on("keydown",this.cycleForwardTabNavigation.bind(this));
g.registerMenu({name:i.moduleName,onOpen:this.showLocations,onClose:this.hideLocations,hasOverlay:true});
this.ariaLabelHidden=this.$button.attr("aria-label-hidden")
}i.prototype.closeOnEsc=function(k){if(k.key!==j.Keys.esc){return
}f();
this.$button.focus()
};
i.prototype.cycleForwardTabNavigation=function(k){if(k.key!==j.Keys.tab||k.shiftKey){return
}k.preventDefault();
this.$button.focus()
};
i.prototype.cycleBackwardTabNavigation=function(k){if(k.key!==j.Keys.tab||!k.shiftKey){return
}k.preventDefault();
this.$lastLink.focus()
};
i.prototype.showLocations=function(){this.toggleLocations(true);
this.$button.on("keydown",this.cycleBackwardTabNavigation.bind(this))
};
i.prototype.toggleLocations=function(k){this.$button.attr("aria-label",k?this.ariaLabelHidden:"");
this.$locations[k?"slideDown":"slideUp"]();
h[k?"one":"off"]("click",f);
this.$button.attr("aria-expanded",k).toggleClass(c.opened,k).off().one("click",k?f:a)
};
i.moduleName="Location Selector";
i.selector=".location-selector-ui-23";
return i
});
define("MobileLocationSelector23",[],function(){var c=$(window);
var b={button:".mobile-location-selector__button",panel:".mobile-location-selector__panel"};
function a(d){this.$el=d;
this.$button=this.$el.find(b.button);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$button.one("click",this.openMenu)
}a.prototype.openMenu=function(){this.$el.addClass("opened");
this.$button.attr("aria-expanded",true).one("click",this.closeMenu);
c.on("click",this.closeMenu);
this.reApplyMenuButtonFocus();
return false
};
a.prototype.closeMenu=function(){this.$el.removeClass("opened");
this.$button.attr("aria-expanded",false).one("click",this.openMenu);
c.off("click",this.closeMenu);
this.reApplyMenuButtonFocus()
};
a.prototype.reApplyMenuButtonFocus=function(){this.$button.blur();
setTimeout(function(){this.$button.focus()
}.bind(this),100)
};
a.moduleName="Location Selector Mobile";
a.selector=".mobile-location-selector-ui-23";
return a
});
define("Header23",["constants"],function(d){var b=$("html"),a=$("body").children("."+d.Classes.overlay).last(),e=10;
function c(f){this.$el=f;
this.$hamburgerMenu=this.$el.find(".hamburger-menu-ui-23");
$(window).on("scroll",this.shrinkMenu.bind(this));
b.on(d.Events.menuOpen,this.openMenu).on(d.Events.menuClose,this.closeMenu);
b.on("focusin",this.closeMenuWhenLooseFocus.bind(this));
$(document).on("click",this.bodyClickEventHandler.bind(this))
}c.prototype.closeMenuWhenLooseFocus=function(f){if(!this.$hamburgerMenu.find(f.target).length){this.activeMenu="Hamburger Menu 23";
this.closeMenu()
}};
c.prototype.bodyClickEventHandler=function(){var f=c.menus["Header Search 23"];
f.closeWhenClickedOutside()
};
c.prototype.openMenu=function(i,h){if(!h){return
}var g=c.menus[h.opened];
this.activeMenu&&c.menus[this.activeMenu].onClose();
this.activeMenu=h.opened;
g.onOpen();
a.toggleClass(d.Classes.hidden,!g.hasOverlay);
var f=typeof g.hasDisabledScroll==="function"?g.hasDisabledScroll():!!g.hasDisabledScroll;
b.toggleClass(d.Classes.noscroll,f)
};
c.prototype.closeMenu=function(j,i){if(!this.activeMenu){return
}var h=c.menus[this.activeMenu],g=i&&i.couldBeIgnored&&h.ignoresWhenPossible,f=i&&i.closed&&this.activeMenu!==i.closed;
if(g||f){return
}h.onClose();
a.addClass(d.Classes.hidden);
b.removeClass(d.Classes.noscroll);
this.activeMenu=null
};
c.prototype.shrinkMenu=function(){var f=window.pageYOffset||document.documentElement.scrollTop;
this.$el.toggleClass(this.classes.shrink,f>=e);
$(document.body).toggleClass(this.classes.shrink,f>=e)
};
c.menus={};
c.registerMenu=function(f){c.menus[f.name]={onOpen:f.onOpen,onClose:f.onClose,closeWhenClickedOutside:f.closeWhenClickedOutside,hasOverlay:f.hasOverlay,hasDisabledScroll:f.hasDisabledScroll,ignoresWhenPossible:f.ignoresWhenPossible}
};
c.prototype.classes={shrink:"header--animated"};
c.moduleName="Header23";
c.selector=".header-ui-23";
return c
});
define("HamburgerMenu23",["Header23","constants","media","utils"],function(h,f,g,c){var b=$("html");
var e={button:".hamburger-menu__button",menu:".hamburger-menu__dropdown",menuSection:".hamburger-menu__dropdown-section",accordeon:".item--collapsed",thirdLevelAccordion:"third-level-item--collapsed",link:".hamburger-menu__link",expandedAccordeon:"item--expanded",expandedThirdLevelAccordion:"third-level-item--expanded",menuExpanded:"hamburger-menu--expanded",child:"item--child",active:".active",expandChildButton:"hamburger-menu__sub-menu-toggle-button",clickableLink:"hamburger-menu__active-button",ctaButton:".cta-button-ui",openedArrowNode:'[aria-expanded="true"]',hamburgerMenuList:".hamburger-menu__list",thirdLevelSubMenuToggleButton:"hamburger-menu__third-level-sub-menu-toggle-button",thirdLevelItem:"hamburger-menu__third-level-item",firstLevelLink:"first-level-link",fixedSidePanelPosition:"fixed-position"};
var a={sidePanelFixPositionQuery:"(min-width: 1920px)"};
function d(i){this.$el=i;
this.$button=this.$el.find(e.button);
this.$menu=this.$el.find(e.menu);
this.$menuSection=this.$el.find(e.menuSection);
this.$hamburgerMenuList=this.$el.find(e.hamburgerMenuList);
this.$accordeon=this.$el.find(e.accordeon);
this.$thirdLevelAccordions=this.$el.find("."+e.thirdLevelAccordion);
this.$link=this.$el.find(e.link);
var j=this.$el.find(e.ctaButton);
this.$lastLink=j.length&&j||this.$link.last();
this.$expandChildButton=i.find("."+e.expandChildButton);
this.$expandThirdLevelChildButton=i.find("."+e.thirdLevelSubMenuToggleButton);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$menu.on("keyup",this.keysPressHandler.bind(this));
this.$link.on("click",function(k){k.stopPropagation()
});
this.$button.one("click",this.triggerOpen);
this.$accordeon.on("click",this.onArrowClick.bind(this));
this.$expandChildButton.on("click",this.onRealArrowClick.bind(this));
this.$expandThirdLevelChildButton.on("click",this.onRealArrowClick.bind(this));
this.$clickableLinks=i.find("."+e.clickableLink);
this.$clickableLinks.on("click",this.onClickableLinkHandler.bind(this));
h.registerMenu({name:d.moduleName,onOpen:this.openMenu,onClose:this.closeMenu,hasDisabledScroll:true,ignoresWhenPossible:true});
this.expandActiveDropdown();
this.init()
}d.prototype.init=function(){if(this.mediaQuery().isDesktop()){$(window).on("resize",c.debounce(this.resizeHandler.bind(this),200));
this.adjustSidePanelPositions()
}};
d.prototype.resizeHandler=function(){this.adjustSidePanelPositions()
};
d.prototype.adjustSidePanelPositions=function(){if(this.mediaQuery().fixedSidePanel()){this.$menuSection.addClass(e.fixedSidePanelPosition)
}else{this.$menuSection.removeClass(e.fixedSidePanelPosition)
}};
d.prototype.onEscPress=function(i){if(i.key!==f.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
d.prototype.triggerOpen=function(){b.trigger(f.Events.menuOpen,{opened:d.moduleName});
return false
};
d.prototype.triggerClose=function(){b.trigger(f.Events.menuClose,{closed:d.moduleName})
};
d.prototype.toggleMenu=function(i){if(i==="openMenu"){this.$menu.stop().slideDown()
}else{this.$menu.stop().slideUp()
}};
d.prototype.mediaQuery=function(){return{isDesktop:function(){return g.currentMode().greaterThan(g.modes.Tablet)
},fixedSidePanel:function(){return window.matchMedia(a.sidePanelFixPositionQuery).matches
}}
};
d.prototype.menuToggleProxy=function(j){var i=this.mediaQuery().isDesktop();
if(i){if(j==="openMenu"){b.toggleClass(f.Classes.noscroll);
this.$menu.css("display","flex")
}}else{b.removeClass(f.Classes.noscroll);
this.toggleMenu(j)
}};
d.prototype.openMenu=function(){b.addClass(e.menuExpanded);
this.menuToggleProxy("openMenu");
this.$button.attr("aria-expanded",true).one("click",this.triggerClose)
};
d.prototype.closeMenu=function(){b.removeClass(e.menuExpanded);
this.menuToggleProxy("closeMenu");
this.$button.attr("aria-expanded",false).off().one("click",this.triggerOpen)
};
d.prototype.onArrowClick=function(j){var i=$(j.target);
if(i.hasClass(e.thirdLevelAccordion)){i.has("ul").length&&this.toggleThirdLevelDropdown(i,j)
}else{i.has("ul").length&&this.toggleDropdown(i,j)
}return false
};
d.prototype.onRealArrowClick=function(j){var k=$(j.target);
var i=k.parent();
if(k.hasClass(e.thirdLevelSubMenuToggleButton)){i.has("ul").length&&this.toggleThirdLevelDropdown(i,j)
}else{i.has("ul").length&&this.toggleDropdown(i,j)
}};
d.prototype.closedOpenedHamburgerMenuItem=function(j){var i=this.$hamburgerMenuList.find(e.openedArrowNode);
if(i.length&&!j.is(i)){i.attr("aria-expanded","false")
}};
d.prototype.toggleAriaAttribute=function(i){i.attr("aria-expanded",function(j,k){return k==="false"
})
};
d.prototype.adjustAriaAttributes=function(i){if(i){var j=$(i.target);
this.closedOpenedHamburgerMenuItem(j);
this.toggleAriaAttribute(j)
}};
d.prototype.toggleDropdown=function(i,j){this.adjustAriaAttributes(j);
i.toggleClass(e.expandedAccordeon);
this.$accordeon.not(i).removeClass(e.expandedAccordeon)
};
d.prototype.toggleThirdLevelDropdown=function(i,j){this.adjustAriaAttributes(j);
i.toggleClass(e.expandedThirdLevelAccordion);
this.$thirdLevelAccordions.not(i).removeClass(e.expandedThirdLevelAccordion)
};
d.prototype.expandActiveDropdown=function(){var j=this.$link.filter(e.active);
var i=j.parent();
if(j.hasClass(e.firstLevelLink)){return
}if(i.hasClass(e.thirdLevelItem)){this.toggleThirdLevelDropdown(j.parents("."+e.thirdLevelAccordion))
}this.toggleDropdown(j.parents(e.accordeon))
};
d.prototype.enterKeyPressHandler=function(j){var i=j.key;
var k=$(j.target);
if(i==="Enter"&&(k.hasClass(e.clickableLink)||k.hasClass(e.expandChildButton))){this.toggleDropdown(k.parent(),j)
}};
d.prototype.onClickableLinkHandler=function(i){var j=$(i.target);
this.toggleDropdown(j.parent(),i)
};
d.prototype.keysPressHandler=function(i){this.enterKeyPressHandler(i);
this.onEscPress(i)
};
d.prototype.classes=e;
d.moduleName="Hamburger Menu 23";
d.selector=".hamburger-menu-ui-23";
return d
});
define("TopNavigation23",["constants"],function(d){var a=$("html");
var c={item:".top-navigation__item",dropdown:".top-navigation__flyout",openSubmenu:"js-opened",linkA11y:".top-navigation__item-link--a11y",flyout:".top-navigation__flyout-inner-section"};
function b(e){this.$el=e;
this.$items=this.$el.find(c.item);
this.$dropdowns=this.$el.find(c.dropdown);
this.$linkA11y=this.$el.find(c.linkA11y);
this.$flyout=this.$el.find(c.flyout);
this.$itemsWithSubmenu=this.$items.filter(this.hasDropdown);
this.$lastSubLinks=$([]);
this.$dropdowns.each(function(g,f){this.$lastSubLinks=this.$lastSubLinks.add($(f).find("a").last())
}.bind(this));
this.$itemsWithSubmenu.on("mouseover",this.onItemHover.bind(this));
this.$itemsWithSubmenu.on("mouseleave",this.onItemLeave.bind(this));
this.$flyout.on("mouseleave",this.subItemsMouseLeave.bind(this));
this.$dropdowns.on("keydown",this.onEscOnItem.bind(this));
this.$linkA11y.on("click",this.openSubmenuA11y.bind(this));
this.$linkA11y.on("focus",this.closeAll.bind(this));
this.$lastSubLinks.on("keydown",this.closeAllWithoutShiftKey.bind(this));
$(document).on("click",this.closeAll.bind(this))
}b.prototype.subItemsMouseLeave=function(g){var f=$(g.target).parents("."+c.openSubmenu);
if(f.length>0){setTimeout(function(){f.removeClass(c.openSubmenu)
},20)
}};
b.prototype.closeAllWithoutShiftKey=function(e){if(e.shiftKey){return
}this.closeAll()
};
b.prototype.onItemHover=function(e){this.openSubmenu($(e.currentTarget))
};
b.prototype.onItemLeave=function(){this.closeAll()
};
b.prototype.openSubmenuA11y=function(e){e.stopPropagation();
var f=$(e.currentTarget).parents(c.item);
this.openSubmenu(f);
f.find("a").eq(1).focus()
};
b.prototype.onEscOnItem=function(e){if(e.key!==d.Keys.esc){return
}this.closeAll();
$(e.currentTarget).parent().find(c.linkA11y).focus()
};
b.prototype.openSubmenu=function(e){a.trigger(d.Events.menuClose,{couldBeIgnored:true});
e.addClass(c.openSubmenu)
};
b.prototype.closeAll=function(){this.$itemsWithSubmenu.removeClass(c.openSubmenu)
};
b.prototype.hasDropdown=function(){return $(this).children(c.dropdown).length>0
};
b.moduleName="Top Navigation 23";
b.selector=".top-navigation-ui-23";
return b
});
define("Breadcrumbs",["media","constants"],function(g,e){var f=5,b={shown:"shown",hidden:"hidden"},d={hidden:"breadcrumbs--hidden",lastBreadcrumbItemLink:".breadcrumbs__item:last > a"};
var h=$(window),a=$("html");
function c(i){this.$el=i;
this.lastScrollTop=0;
this.toggleBreadcrumbs=this.toggleBreadcrumbs.bind(this);
this.activateScroll();
this.addA11YAttributes();
a.on(e.Events.menuOpen,this.detach.bind(this)).on(e.Events.menuClose,this.activate.bind(this))
}c.prototype.addA11YAttributes=function(){var i=this.$el.find(d.lastBreadcrumbItemLink);
if(i.length){i.attr("aria-current","page")
}};
c.prototype.toggleBreadcrumbs=function(){var j=!g.currentMode().greaterThan(g.modes.Desktop),n=h.scrollTop(),m=Math.abs(this.lastScrollTop-n)<=f;
if(j||m){return
}var k=n>this.lastScrollTop&&n>=0,i=n+h.height()<$(document).height(),l=this.$el;
this.lastScrollTop=n;
if(k){l.addClass(d.hidden).on(e.Events.transitionEnd,function(){requestAnimationFrame(function(){l.addClass(e.Classes.hidden)
});
l.off(e.Events.transitionEnd)
});
return
}if(i){l.removeClass(e.Classes.hidden);
requestAnimationFrame(function(){l.removeClass(d.hidden).off(e.Events.transitionEnd)
})
}};
c.prototype.detach=function(){this.ignoreScroll();
this.previousState=this.$el.hasClass(this.classes.hidden)?b.hidden:b.shown;
this.$el.addClass(this.classes.hidden)
};
c.prototype.activate=function(k,j){var i=j&&j.couldBeIgnored;
if(!this.previousState||i){return
}this.activateScroll();
this.previousState===b.shown&&this.$el.removeClass(this.classes.hidden);
this.previousState=null
};
c.prototype.ignoreScroll=function(){h.off("scroll",this.toggleBreadcrumbs)
};
c.prototype.activateScroll=function(){h.on("scroll",this.toggleBreadcrumbs)
};
c.prototype.classes=d;
c.moduleName="Breadcrumbs";
c.selector=".breadcrumbs-ui";
return c
});
define("GeneralVacancyBlock23",["constants"],function(d){var a=$("html");
var c={vacancyForm:".general-vacancy-form-holder"};
function b(e){this.$vacancyForm=e.find(c.vacancyForm);
a.on(d.Events.showVacancyForm,this.showVacancyForm.bind(this));
$(document).ready(this.resizeVideos)
}b.prototype.showVacancyForm=function(){this.$vacancyForm.removeClass(d.Classes.hidden)
};
b.prototype.resizeVideos=function(){var e=$(document).find(".vacancy_content iframe");
e.each(function(){var i=$(this).attr("width");
var f=$(this).width();
if(f<i){var h=$(this).attr("height");
var g=i/h;
$(this).height(f/g)
}})
};
b.moduleName="General Vacancy Block 23";
b.selector=".general-vacancy-block-ui-23";
return b
});
define("FrequentSearches23",["constants"],function(c){var b={frequentSearches:".frequent-searches-ui-23",hidden:"frequent-searches-23--hidden",input:".frequent-searches__input",headerSearchInput:".header-search__input",headerSearchField:".header-search__field",searchInput:".search__input",searchResultsInput:".search-results__input",item:".frequent-searches__item",itemActive:"frequent-searches__item--active",footer:".footer-ui-23"};
var d=$(window);
function a(e){this.$el=e;
this.elHeight=e.height();
this.$input=$(document).find(b.input);
this.$headerSearchField=$(document).find(b.headerSearchField);
this.$headerSearchInput=$(document).find(b.headerSearchInput);
this.$searchResultsInput=$(document).find(b.searchResultsInput);
this.$searchInput=$(document).find(b.searchInput);
this.$items=e.find(b.item);
this.currentItemIndex=-1;
this.defaultPlaceholder=this.$input.attr("placeholder");
this.$footer=$(b.footer);
this.openEl=this.openEl.bind(this);
this.closeEl=this.closeEl.bind(this);
this.markActiveItem=this.markActiveItem.bind(this);
this.resetActiveItem=this.resetActiveItem.bind(this);
this.$input.attr("autocomplete","off");
this.initEvents();
this.updateHeight()
}a.prototype.initEvents=function(){this.$input.on("focus",this.openEl).on("keyup",this.openEl);
this.$items.on("click",this.onItemClick.bind(this));
d.on("resize",this.updateHeight.bind(this))
};
a.prototype.updateHeight=function(){var g=this.$footer.offset().top-20,e=this.$el.offset().top,f=e+this.elHeight;
this.$el.css("max-height",f>g?g-e:"none")
};
a.prototype.toggleEl=function(e){if($(".header-search__button").hasClass("opened")){if(e||!!this.$headerSearchInput.val().length){this.resetActiveItem()
}this.$headerSearchField.children(b.frequentSearches).toggleClass(b.hidden,e||!!this.$headerSearchInput.val().length);
return
}if(this.$searchInput.length!==0){if(e||!!this.$searchInput.val().length){this.resetActiveItem()
}this.$el.toggleClass(b.hidden,e||!!this.$searchInput.val().length);
return
}if(this.$searchResultsInput.length!==0){if(e||!!this.$searchResultsInput.val().length){this.resetActiveItem()
}this.$el.toggleClass(b.hidden,e||!!this.$searchResultsInput.val().length);
return
}this.updateElState(e);
if(this.$input.val().length){this.$input.removeAttr("aria-describedby")
}else{this.$input.attr("aria-describedby","search-label")
}};
a.prototype.openEl=function(){this.toggleEl(false);
d.on("click",this.closeEl)
};
a.prototype.closeEl=function(e){if(e&&this.$input.is(e.target)){return
}this.toggleEl(true);
d.off("click",this.closeEl)
};
a.prototype.updateElState=function(e){if(!e){this.$input.off("keydown");
this.$input.on("keydown",this.onKeyDown.bind(this));
this.updateHeight();
return
}this.clearElState()
};
a.prototype.clearElState=function(){this.$input.off("keydown");
this.currentItemIndex=-1;
this.$items.removeClass(b.itemActive);
this.resetActiveItem();
this.$input.attr("placeholder",this.defaultPlaceholder)
};
a.prototype.onItemClick=function(e){this.$input.val(e.target.innerText).focus();
this.closeEl()
};
a.prototype.resetActiveItem=function(){this.$input.removeAttr("aria-activedescendant");
this.$items.removeAttr("aria-selected id")
};
a.prototype.markActiveItem=function(e){var f="selected-option";
this.$input.attr("aria-activedescendant",f);
e.attr({"aria-selected":"true",id:f})
};
a.prototype.selectItem=function(e){this.activeItem=this.$items.eq(e);
this.$items.removeClass(b.itemActive);
this.activeItem.addClass(b.itemActive);
this.resetActiveItem();
this.markActiveItem(this.activeItem);
this.$input.attr("placeholder",this.activeItem[0].innerText);
this.currentItemIndex=e
};
a.prototype.selectPrev=function(){if(this.currentItemIndex<=0){this.selectItem(this.$items.length-1);
return
}this.selectItem(this.currentItemIndex-1)
};
a.prototype.selectNext=function(){if(this.currentItemIndex>=this.$items.length-1){this.selectItem(0);
return
}this.selectItem(this.currentItemIndex+1)
};
a.prototype.onKeyDown=function(e){switch(e.key){case c.Keys.arrowUp:this.selectPrev();
break;
case c.Keys.arrowDown:this.selectNext();
break;
case c.Keys.enter:this.$input.removeAttr("aria-describedby");
if(this.currentItemIndex>-1){e.preventDefault();
this.$input.val(this.$items.eq(this.currentItemIndex)[0].innerText);
this.clearElState()
}break;
case c.Keys.tab:this.closeEl();
break;
default:break
}};
a.prototype.classes=b;
a.moduleName="Frequent Searches 23";
a.selector=".frequent-searches-ui-23";
return a
});
define("Footer23",["WeChatPopup","jquery-plugins"],function(b){function a(c){this.$el=c;
this.$linksContainer=this.$el.find("."+this.classes.linksContainer);
this.$weChatLink=this.$el.find("."+this.classes.link+'[data-type="wechat"]');
this.data={src:this.$el.data("wechatQrSrc"),id:this.$el.data("wechatId")};
$(window).on("resize",this.removeLinksDot.bind(this));
$.onFontLoad(this.removeLinksDot.bind(this));
this.$weChatLink.length&&this.initWeChatPopup();
$("#scroll-top").click(function(){$("html, body").animate({scrollTop:0},1000)
})
}a.prototype.removeLinksDot=function(){var d=this.classes.pipe,c;
this.$linksContainer.each(function(){var e=$(this);
e.toggleClass(d,$.isOffsetEqual([c||e,e]));
c=e
})
};
a.prototype.initWeChatPopup=function(){this.$popup=new b();
this.$weChatLink.on("click",function(c){c.preventDefault();
this.$popup.open(this.data,this.$weChatLink)
}.bind(this))
};
a.prototype.classes={linksContainer:"social-links",link:"social-link",pipe:"item--piped"};
a.selector=".footer-ui-23";
a.moduleName="Footer23";
return a
});
define("EventsViewer23",["utils-dust","utils-env"],function(e,d){function c(f){this.$el=f;
this.$list=this.$el.find("."+this.classes.list);
this.$viewMore=this.$el.find("."+this.classes.viewMore);
this.$errorMessage=this.$el.find("."+this.classes.ajaxError);
this.path=this.$el.data("path");
this.isAuthor=d.isAuthor();
this.category=this.$el.data("category");
this.language=CQ.I18n.getLocale();
this.dateFormat=this.$el.data("dateFormat");
this.getEvents();
this.$viewMore.on("click",this.getEvents.bind(this))
}c.prototype.getEvents=function(){var g=this.$list.children().length,f={method:"GET",url:this.config.eventUrl,data:{path:this.path,category:this.category,language:this.language,limit:this.constants.LIMIT,offset:g,dateFormat:this.dateFormat,buildSchemaOrgMarkup:g===0},success:this.renderEvents.bind(this),error:this.showErrorMessage.bind(this)};
$.ajax(f)
};
var a,b=false;
c.prototype.fillEventsListMarkup=function(g){if(a!==null&&a!==undefined){for(var f=0;
f<g.itemListElement.length;
f++){g.itemListElement[f].position=a.itemListElement.length+f+1
}a.itemListElement=Object.values(a.itemListElement).concat(Object.values(g.itemListElement))
}else{a=g
}};
c.prototype.renderEvents=function(g){var f=g.schemaOrgMarkup;
if(b){if(f){this.fillEventsListMarkup(f)
}if(a!==null&&a!==undefined){this.addSchemaOrgMarkup(a)
}}else{a=f
}b=true;
var h=this.$list.children().length;
e.append("events-viewer23-items",{content:g.result,isAuthor:this.isAuthor,category:this.category},this.$list);
if(h+g.result.length>=g.total){return this.$viewMore.addClass(this.classes.buttonDisabled)
}};
c.prototype.addSchemaOrgMarkup=function(f){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(f)+"<\/script>")
};
c.prototype.showErrorMessage=function(){var f=this.classes.active;
this.$errorMessage.addClass(f)
};
c.prototype.classes={list:"events-viewer23__list",ajaxError:"events-viewer23__ajax-error-message",buttonDisabled:"hidden",viewMore:"events-viewer23__view-more",active:"active"};
c.prototype.config={eventUrl:"/services/search/events/viewer"};
c.prototype.constants={LIMIT:12};
c.moduleName="Events Viewer 2023";
c.selector=".events-viewer-ui-23";
return c
});
define("ContactDetailsReference23",["utils"],function(a){function b(c){a.addExtensionToPhoneNumber(c)
}b.moduleName="Contact Details Reference 2023";
b.selector=".contact-details-reference-ui-23";
return b
});
define("BackgroundVideo23",["utils","media"],function(a,d){var f=$(window),e=52;
var c={container:".background-video__container",showMobileImage:"background-video--show-mobile-image",fullSizeVideo:"background-video--match-size-of-video",contentPointer:"background-video__content-pointer",soundIcon:"background-video__sound-icon",enableSound:"background-video__hasSound",showArrow:"background-video__show-arrow"};
function b(g){this.$el=g;
this.$parent=this.$el.parent(".background-video");
this.$parent.addClass("background-video--relative");
this.$player=this.$el.find(c.container)[0];
this.$contentPointer=this.$parent.find("."+c.contentPointer);
this.$soundIcon=this.$parent.find("."+c.soundIcon);
this.$isShowArrow=this.$el.hasClass(c.showArrow);
this.$playSound=this.$el.hasClass(c.enableSound);
$(document).ready(this.documentReadyCallback.bind(this));
f.on("scroll",a.debounce(this.scrollCallback.bind(this),3));
f.on("resize",a.debounce(this.resizeCallback.bind(this),100));
this.$contentPointer.on("click",this.scrollToContent.bind(this));
this.$soundIcon.on("click",this.toggleMute.bind(this))
}b.prototype.getVideoRect=function(){return{bottomY:this.$el[0].getBoundingClientRect().bottom+window.pageYOffset}
};
b.prototype.scrollToContent=function(){$("html, body").animate({scrollTop:this.getVideoRect().bottomY-e},800)
};
b.prototype.callbackFunctions=function(){this.playPauseVideo();
if(this.$isShowArrow){this.isShowAdditionalIcons()
}};
b.prototype.documentReadyCallback=function(){this.callbackFunctions();
if(!this.$isShowArrow){this.$contentPointer.addClass("hidden")
}};
b.prototype.scrollCallback=function(){this.callbackFunctions()
};
b.prototype.resizeCallback=function(){this.callbackFunctions()
};
b.prototype.isShowAdditionalIcons=function(){if(!this.$el.hasClass(c.fullSizeVideo)){return
}var g=window.innerHeight+window.pageYOffset;
if(this.getVideoRect().bottomY>g&&this.$el.hasClass(c.fullSizeVideo)&&d.currentMode().greaterThan(d.modes.Tablet)){this.$contentPointer.removeClass("hidden");
this.$soundIcon.addClass("background-video--icon-fixed");
return
}this.$contentPointer.addClass("hidden");
this.$soundIcon.removeClass("background-video--icon-fixed")
};
b.prototype.toggleMute=function(){if(this.$player.muted){this.$soundIcon.addClass("background-video--sound-enabled");
this.$player.muted=false
}else{this.$player.muted=true;
this.$soundIcon.removeClass("background-video--sound-enabled")
}};
b.prototype.isOnScreen=function(){var j=f.scrollTop(),h=j+f.height(),g=this.$el.offset().top,i=g+this.$el.outerHeight()/2;
return !(j+e>i||i>h)
};
b.prototype.playPauseVideo=function(){var g=this.$el.hasClass(c.showMobileImage)&&d.currentMode().lessThan(d.modes.Tablet);
if(!g&&this.isOnScreen()){this.$player.play();
return
}this.$player.pause()
};
b.selector=".background-video-ui-23";
b.moduleName="Background Video 23";
return b
});
define("AnywhereVacancyBlock23",["utm-utils"],function(c){var b={button:".anywhere-vacancy-block__button",link:".anywhere-vacancy-block__link"};
function a(d){this.$button=d.find(b.button);
this.$link=d.find(b.link);
this.handleButtonClick();
this.handleLinkClick()
}a.prototype.handleButtonClick=function(){var d=c.buildAnywhereUrl(this.$button.data("href"));
this.$button.attr("href",d)
};
a.prototype.handleLinkClick=function(){var e=this.$link.data("href");
if(e!==undefined&&e.indexOf("anywhere")>=0){var d=c.buildAnywhereUrl(e);
this.$link.attr("href",d)
}};
a.moduleName="Anywhere Vacancy Block 23";
a.selector=".anywhere-vacancy-block-ui-23";
return a
});
define("Accordion23",["utils-env"],function(d){function a(e){this.$el=e;
this.$accordionButton=e.find(b.accordionButton);
this.$accordionTitle=e.find(b.accordionTitle);
this.$accordionButtonRead=e.find(b.accordionButtonRead);
this.$accordionBackgroundPanel=e.find(b.accordionBackgroundPanel);
this.$accordionPasys=e.find(b.accordionPasys);
this.$responsiveImages=this.$el.find(b.responsiveImage);
this.init();
var f=function(g){return function(h){if(h.children[0]){if(h.children[0].children[0]){return h.children[0].children[0]===g.context
}}return null
}
};
this.$sections=Array.prototype.slice.call(document.querySelectorAll(".section__wrapper",0));
this.$accordeonWrapper=this.$sections.filter(f(this.$el));
this.$accordeonWrapper.forEach(function(g){g.classList.add("accordion-margin")
});
if(d.isEditMode()){this.$accordionPasys.removeClass(b.hidden)
}}a.prototype.init=function(){this.$accordionBackgroundPanel.click(this.toggleContent.bind(this,false));
this.$accordionButtonRead.click(this.toggleContent.bind(this,true));
this.$accordionButtonRead.text("");
var e=this.$accordionButton.attr(c.showInExpandedView);
if(e==="true"){this.$accordionPasys.removeClass(b.hidden);
this.$accordionButtonRead.append('<div class="accordion-23__read-less">'+c.readLess+"</div>");
this.$accordionButtonRead.append('<div class="accordion-23__arrow"></div>');
this.$accordionButton.removeClass(b.accordionButtonOpen);
this.$accordionTitle.removeClass(b.accordionTitleOpen);
this.$responsiveImages.trigger(c.renderImage);
this.$accordionButtonRead.attr("aria-label",c.readLess);
this.$accordionBackgroundPanel.attr("aria-label",c.expanded)
}};
a.prototype.toggleContent=function(e){this.$responsiveImages=this.$el.find(b.responsiveImage);
var f=this.$el.offset().top;
if(this.$accordionPasys.hasClass(b.hidden)){this.$accordionPasys.removeClass(b.hidden);
this.$accordionButton.removeClass(b.accordionButtonOpen);
this.$accordionTitle.removeClass(b.accordionTitleOpen);
this.$accordionButtonRead.append('<div class="accordion-23__read-less">'+c.readLess+"</div>");
this.$accordionButtonRead.append('<div class="accordion-23__arrow"></div>');
this.$responsiveImages.trigger(c.renderImage);
this.$accordionBackgroundPanel.attr("aria-expanded",true);
this.$accordionBackgroundPanel.attr("aria-label",c.expanded);
this.$accordionButtonRead.attr("aria-label",c.readLess)
}else{this.$accordionPasys.addClass(b.hidden);
this.$accordionButton.addClass(b.accordionButtonOpen);
this.$accordionTitle.addClass(b.accordionTitleOpen);
this.$accordionButtonRead.text("");
this.$accordionButtonRead.attr("aria-label","");
this.$accordionBackgroundPanel.attr("aria-expanded",false);
this.$accordionBackgroundPanel.attr("aria-label",c.collapsed);
if(e&&$(window).width()<=c.mobileDevice){$(window).scrollTop(f-83)
}else{if(e){$(window).scrollTop(f-95)
}}}};
var c={readLess:Granite.I18n.get("component.accordion.read_less"),readMore:"",showInExpandedView:"showInExpandedView",renderImage:"renderImage",collapsed:"collapsed",expanded:"expanded",mobileDevice:991};
var b={accordionBackgroundPanel:".accordion-23__background-panel",accordionButton:".accordion-23__button",accordionTitle:".accordion-23__title",accordionButtonRead:".accordion-23__button-read",accordionPasys:".accordion-23__parsys",responsiveImage:".responsive-image-ui",accordionButtonOpen:"accordion-23__button-open",accordionTitleOpen:"accordion-23__title-open",hidden:"hidden"};
a.moduleName="Accordion-23";
a.selector=".accordion-ui-23";
return a
});
"use strict";
var _createClass=function(){function a(e,c){for(var b=0;
b<c.length;
b++){var d=c[b];
d.enumerable=d.enumerable||false;
d.configurable=true;
if("value" in d){d.writable=true
}Object.defineProperty(e,d.key,d)
}}return function(d,b,c){if(b){a(d.prototype,b)
}if(c){a(d,c)
}return d
}
}();
function _defineProperty(c,a,b){if(a in c){Object.defineProperty(c,a,{value:b,enumerable:true,configurable:true,writable:true})
}else{c[a]=b
}return c
}function _toConsumableArray(a){if(Array.isArray(a)){for(var c=0,b=Array(a.length);
c<a.length;
c++){b[c]=a[c]
}return b
}else{return Array.from(a)
}}function _classCallCheck(a,b){if(!(a instanceof b)){throw new TypeError("Cannot call a class as a function")
}}define("Animation",["utils"],function(a){var d={ANIMATION_IMAGE_CONTAINER:"animation__image-container"};
var c=100;
var b=function(){function h(l){_classCallCheck(this,h);
this.$el=l[0];
this.$imageContainer=this.$el.querySelector("."+d.ANIMATION_IMAGE_CONTAINER);
this.imageName=l.attr("data-image-name");
this.isActive=true;
this.isEditMode=l.is("[is-edit-mode]");
this.delayAnimation=this.loadAnimationPicture();
this.init();
this.initEvents()
}_createClass(h,[{key:"init",value:function j(){this.onScrollChange()
}},{key:"initEvents",value:function g(){window.addEventListener("scroll",a.debounce(this.onScrollChange.bind(this),300));
this.delayAnimation.addEventListener("data_ready",this.onAnimationLoaded.bind(this))
}},{key:"onScrollChange",value:function k(){if(this.isActive&&this.isOnScreen(c)){this.delayAnimation.play();
this.isActive=false
}}},{key:"isOnScreen",value:function f(n){var m=window.innerHeight*(n/100)+window.scrollY;
var o=window.scrollY+this.$imageContainer.getBoundingClientRect().top;
var l=o+this.$imageContainer.offsetHeight/2;
return l<=m
}},{key:"loadAnimationPicture",value:function e(){return bodymovin.loadAnimation({container:this.$imageContainer,renderer:"svg",loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/"+this.imageName+".json",rendererSettings:{className:"animation__svg",viewBoxOnly:true}})
}},{key:"onAnimationLoaded",value:function i(){if(this.isEditMode){this.delayAnimation.goToAndPlay(this.delayAnimation.totalFrames,true);
this.isActive=false
}}}]);
return h
}();
b.moduleName="Animation";
b.selector=".animation-ui";
return b
});
define("AnimationLogos",["utils-env","utils-browser"],function(c,b){var d={item:".animated-logos__wrapper-item",wrapperItems:".animated-logos__wrapper-items",image:".animated-logos__image"};
var a=function(){function f(m){_classCallCheck(this,f);
this.$el=m[0];
this.$item=this.$el.querySelectorAll(d.item);
this.$wrapperItems=this.$el.querySelector(d.wrapperItems);
this.bindedAnimateIfInViewPort=this.animateIfInViewPort.bind(this);
this.init();
if(c.isEditMode()){var l=[];
for(var k=0;
k<this.$item.length;
k++){l.push(this.$item[k])
}l.forEach(function(n){n.classList.add("animated")
})
}}_createClass(f,[{key:"init",value:function i(){window.addEventListener("scroll",this.bindedAnimateIfInViewPort);
var k=this;
window.addEventListener("load",function(){k.animateIfInViewPort()
});
if(b.isInternetExplorer()){k.setSizes()
}}},{key:"animateIfInViewPort",value:function e(){if(!this.$wrapperItems){return
}var t=this.$wrapperItems.getBoundingClientRect().top;
var l=window.scrollY||document.documentElement.scrollTop;
var p=l+t;
var q=p+this.$wrapperItems.offsetHeight;
var n=l+window.innerHeight;
var s=l;
var r=this.$wrapperItems;
var m=r.offsetHeight;
var o=n-p;
var k=q-s;
if(o>=m/2||k<=m/2){this.animationLogos();
window.removeEventListener("scroll",this.bindedAnimateIfInViewPort)
}}},{key:"animationLogos",value:function j(){var l=[];
for(var k=0;
k<this.$item.length;
k++){l.push(this.$item[k])
}l.forEach(function(n,m){setTimeout(function(){n.classList.add("animated")
},150*m)
})
}},{key:"calcWrapperItemsWidth",value:function g(){var k=function k(l){return l/10
};
return k($(this.$wrapperItems).width())
}},{key:"setSizes",value:function h(){for(var m=0;
m<this.$item.length;
m++){var n=parseInt($(this.$item[m]).css("width"),10);
var k=parseInt($(this.$item[m]).css("padding-bottom"),10);
var l=n/k;
var p=$(this.$item[m]).find(d.image);
var o=p[0].naturalWidth/p[0].naturalHeight;
l>o?p.css("width","auto"):p.css("height","auto")
}}}]);
return f
}();
a.moduleName="Animation Logos";
a.selector=".animated-logos-ui";
return a
});
define("BlocksTabs",["utils"],function(e){var g={TABS_LINK:".blocks-tabs__tab",TAB_WRAPPER:".blocks-tabs-tab-wrapper",CONTENT_ITEM:".blocks-tabs__content-item",ACTIVE_CONTENT_ITEM:".blocks-tabs__content-item.active",ACTIVE_TAB:".blocks-tabs-tab-wrapper.active",TABS_WRAPPER:".blocks-tabs-tabs-wrapper",SCROLL_TO_CONTENT:"scroll-to-content",TABS_CONTENT_SECTION:".blocks-tabs-content-section",TABS_TITLE_SECTION:".blocks-tabs-title-section",OWL_STAGE:".owl-stage",SECTION_WRAPPER:".section__wrapper",SECTION_WRAPPERS_IN_TABS_CONTENT:".blocks-tabs__content-item .section__wrapper"};
var f={nextSlide:"blocks.tabs.next",prevSlide:"blocks.tabs.prev",owl:{to:"to.owl.carousel",destroy:"destroy.owl.carousel",refresh:"refresh.owl.carousel",initialized:"initialized.owl.carousel",translated:"translated.owl.carousel"}};
var c=52;
var h=1000;
var b=40;
var d="(min-width: 992px)";
var a=[];
var i=function(){function A(N){_classCallCheck(this,A);
this.$el=N;
this._el=N[0];
this._owl=$(".owl-carousel");
this._owlSingleInst=$(this._el.querySelector(".owl-carousel"));
this.$activeTabColor=this._el.dataset.activeTabColor;
this.$tabs=this._el.querySelectorAll(g.TAB_WRAPPER);
this.$tabsLinks=this._el.querySelectorAll(g.TABS_LINK);
this.$items=$(g.CONTENT_ITEM,this._el);
this.$tabsWrapper=this._el.querySelector(g.TABS_WRAPPER);
this.$tabsContentSection=this._el.querySelector(g.TABS_CONTENT_SECTION);
this.$tabsTitleSection=this._el.querySelector(g.TABS_TITLE_SECTION);
this.$isScrollToContent=this._el.classList.contains(g.SCROLL_TO_CONTENT);
this.$isOwlInit=false;
this.$isOwlDestroy=false;
this.$isDesktop=true;
this.$fisrtOwlRefresh=false;
this.$delayOwlEvent=null;
this.init();
a.push(this)
}_createClass(A,[{key:"init",value:function F(){this.editModeEvents();
this.initEvents();
this.checkDevice();
this.setDefaultActiveTab();
this.initOwlCarousel();
this.resizeEventHandler();
this.initKeysHandler();
this.addSpanWidthSpaceInTabsContent()
}},{key:"addSpanWidthSpaceInTabsContent",value:function K(){var O=function N(Q){if(Q.firstElementChild){N(Q.firstElementChild);
return
}else{if(Q.closest("a")){var R=document.createElement("span");
var P=Q.closest(g.SECTION_WRAPPER);
R.innerHTML="&nbsp;";
P.insertBefore(R,P.children[0])
}if(Q.tagName==="SPAN"&&!Q.innerText){Q.innerHTML="&nbsp;"
}return
}};
this.$tabsContentSection.querySelectorAll(g.SECTION_WRAPPERS_IN_TABS_CONTENT).forEach(function(P){O(P)
})
}},{key:"getNextItem",value:function u(O){var N=Array.prototype.indexOf.call(this.$tabs,O);
if(N===this.$tabs.length-1){return this.$tabs[0].getAttribute("tab-id")
}return this.$tabs[N+1].getAttribute("tab-id")
}},{key:"getPrevItem",value:function G(O){var N=Array.prototype.indexOf.call(this.$tabs,O);
if(N===0){return this.$tabs[this.$tabs.length-1].getAttribute("tab-id")
}return this.$tabs[N-1].getAttribute("tab-id")
}},{key:"changeActiveTab",value:function k(N){this.setActiveTab(N);
this.setActiveTabsContent(N);
var O=this._el.querySelector(g.TAB_WRAPPER+"[tab-id="+N+"]");
O.focus()
}},{key:"horizontalKeyHandlerCallback",value:function s(O){var Q=O.keyCode;
var R=O.target.closest(g.TAB_WRAPPER);
if(Q===39||Q===37||Q===35||Q===36){O.preventDefault()
}if(Q===39){var N=this.getNextItem(R);
this.changeActiveTab(N)
}if(Q===37){var P=this.getPrevItem(R);
this.changeActiveTab(P)
}if(Q===35){this.changeActiveTab(this.$tabs[this.$tabs.length-1].getAttribute("tab-id"))
}if(Q===36){this.changeActiveTab(this.$tabs[0].getAttribute("tab-id"))
}}},{key:"shiftTabHandlerCallback",value:function z(N){if(N.shiftKey&&N.keyCode===9){this.blocksTabsScroll(this.$tabsTitleSection)
}}},{key:"initKeysHandler",value:function D(){var N=this;
this.$tabsWrapper.addEventListener("keydown",function(O){N.horizontalKeyHandlerCallback(O)
});
this.$tabsContentSection.addEventListener("keydown",function(O){N.shiftTabHandlerCallback(O)
})
}},{key:"tabsClickHandler",value:function H(R){var T=e.isElementInViewport(this.$tabsContentSection,100);
var S=R.target;
if(!this.$fisrtOwlRefresh){this._owl.trigger(f.owl.refresh)
}if(S.classList.contains("blocks-tabs__tab")){S=S.parentNode
}var P=S.getAttribute("tab-id");
var Q=this.getTabIndex(P);
var O=this.setActiveTab(P),N=O.activeTabId;
this.setActiveTabsContent(P);
if(N!==P){this.moveToSelectedTab(Q)
}if(!T||this.$isScrollToContent){this.scrollToNode()
}$(window).trigger("tab.changed");
return false
}},{key:"scrollToNode",value:function I(){if(!this.$isScrollToContent){this.blocksTabsScroll(this.$tabsWrapper)
}else{this.blocksTabsScroll(this.$tabsContentSection)
}}},{key:"getTabIndex",value:function q(P){for(var O=0;
O<this.$tabs.length;
O++){var N=this.$tabs[O].getAttribute("tab-id");
if(N===P){return O
}}return -1
}},{key:"getTabIdByAnchor",value:function M(N){for(var O=0;
O<this.$tabsLinks.length;
O++){var P=this.$tabsLinks[O].getAttribute("href");
if(P===N){return this.$tabs[O].getAttribute("tab-id")
}}return null
}},{key:"moveToSelectedTab",value:function n(N){if(N!==-1){this._owlSingleInst.trigger(f.owl.to,[N,h])
}}},{key:"initEvents",value:function v(){var N=this;
window.onresize=e.debounceExtend(function(){return N.resizeEventHandler()
},200);
this.handleTabsClickEvent();
this.imitateHoverEventForTabs()
}},{key:"imitateHoverEventForTabs",value:function B(){var Q=this;
var O=function O(R,S){if(R.classList.contains("active")){return
}S()
};
for(var N=0;
N<this.$tabs.length;
N++){var P=this.$tabs[N];
P.addEventListener("mouseleave",function(R){var S=R.target;
O(S,function(){S.classList.remove(Q.$activeTabColor);
S.classList.remove("hover")
})
});
P.addEventListener("mouseenter",function(S){var R=S.target;
O(R,function(){R.classList.add(Q.$activeTabColor);
R.classList.add("hover")
})
})
}}},{key:"handleTabsClickEvent",value:function E(){for(var N=0;
N<this.$tabsLinks.length;
N++){this.$tabsLinks[N].addEventListener("click",this.tabsClickHandler.bind(this))
}}},{key:"resizeEventHandler",value:function o(){this.checkDevice();
this.initOwlCarousel()
}},{key:"checkDevice",value:function w(){var N=window.matchMedia(d).matches;
if(N){this.$isDesktop=true;
if(!this.$isOwlDestroy){this.$isOwlDestroy=true;
this.$isOwlInit=false;
this._owl.trigger(f.owl.destroy);
this._owl.off(f.owl.translated)
}}else{this.$isDesktop=false
}}},{key:"initOwlCarousel",value:function t(){var O=this;
if(!this.$isOwlInit&&!this.$isDesktop){this.$isOwlInit=true;
this.$isOwlDestroy=false;
this._owl.on(f.owl.initialized,function(){if(O.$delayOwlEvent&&O.$delayOwlEvent.event===f.owl.to){var R=O.getTabIndex(O.$delayOwlEvent.activeTabId);
setTimeout(function(){O.moveToSelectedTab(R)
},1000);
O.$delayOwlEvent=null
}});
this._owl.owlCarousel({autoWidth:true,dots:false});
this._owl.on(f.owl.refresh,function(){O.$fisrtOwlRefresh=true
});
var Q=this.$el.find(g.OWL_STAGE);
var P=Q.width();
var N=this.updateStagePosition(Q,this.$el);
this._owl.on(f.owl.translated,N.bind(this,P))
}}},{key:"setDefaultActiveTab",value:function p(){var P=this.checkURLAnchor();
if(P){var O=this.getTabIdByAnchor(P);
if(O){this.setActiveTab(O);
this.setActiveTabsContent(O);
this.scrollToNode();
if(!this.$isDesktop){this.$delayOwlEvent={event:f.owl.to,activeTabId:O}
}return
}}var N=this.$tabs[0].getAttribute("tab-id");
this.setActiveTab(N);
this.setActiveTabsContent(N)
}},{key:"checkURLAnchor",value:function m(){var N=window.location.hash.slice(0);
return N.length>1?N:null
}},{key:"setActiveTab",value:function y(P){var O=this._el.querySelector(g.ACTIVE_TAB);
var N=null;
if(O){O.classList.remove("active");
O.classList.remove("hover");
O.classList.remove(this.$activeTabColor);
O.setAttribute("aria-selected",false);
O.tabIndex=-1;
N=O.getAttribute("tab-id")
}var Q=this._el.querySelector(g.TAB_WRAPPER+"[tab-id="+P+"]");
if(Q){Q.classList.add("active");
Q.classList.add(this.$activeTabColor);
Q.setAttribute("aria-selected",true);
Q.tabIndex=0
}return{activeTabId:N}
}},{key:"blocksTabsScroll",value:function x(N){var O=N.getBoundingClientRect().top+window.scrollY-c;
window.scroll({top:O,left:0,behavior:"smooth"})
}},{key:"setActiveTabsContent",value:function l(N){var P=this._el.querySelector(g.ACTIVE_CONTENT_ITEM);
if(P){P.classList.remove("active");
P.classList.add("hidden");
P.tabIndex=-1
}var O=this._el.querySelector(g.CONTENT_ITEM+"[content-id="+N+"]");
O.classList.remove("hidden");
O.classList.add("active");
O.tabIndex=0
}},{key:"navigationArrowHandler",value:function J(O){var N=this.$tabs[O].getAttribute("tab-id");
this.setActiveTab(N);
this.setActiveTabsContent(N)
}},{key:"goToNextTab",value:function C(O,P){var N=P.tab;
this.navigationArrowHandler(N)
}},{key:"goToPrevTab",value:function r(P,O){var N=O.tab;
this.navigationArrowHandler(N)
}},{key:"editModeEvents",value:function L(){$(this._el).on(f.nextSlide,this.goToNextTab.bind(this));
$(this._el).on(f.prevSlide,this.goToPrevTab.bind(this))
}},{key:"updateStagePosition",value:function j(O,N){return function(T){var Q=parseInt(O.css("transform").split(",")[4]),R=N.width()-b,P=T-R,S=-Q>P;
S&&O.css("transform","translateX(-"+P+"px)")
}
}}]);
return A
}();
i.events=f;
i.activatedComponents=a;
i.moduleName="Blocks Tabs";
i.selector=".blocks-tabs-ui";
return i
});
define("CategoriesSwitcher",["utils","utils-env"],function(b,d){var g={TILE:"categories-switcher__tile-title",LEFT_SECTION:"categories-switcher-left-part",ACTIVE:"active",ACTIVE_TILE:".categories-switcher__tile-title.active",ACTIVE_CONTENT:".categories-switcher__content-item.active",ACTIVE_CONTENT_MOB:".categories-switcher__content-item-mob.active",CONTENT_ITEM:"categories-switcher__content-item",CONTENT_ITEM_MOBILE:"categories-switcher__content-item-mob",COLOR_PANEL:"categories-switcher-background",HIDE:"hidden",RESPONSIVE_IMAGE:"responsive-image-ui",TITLES_SECTION:"categories-switcher-tiles-section"};
var f={RESPONSIVE_HEADER_HEIGHT:52};
var a={nextSlide:"cat.switcher.next",prevSlide:"cat.switcher.prev"};
var e=[];
var c=function(){function r(C){_classCallCheck(this,r);
this.$el=C;
this.$modernEl=C[0];
this.$tiles=$("."+g.TILE,this.$modernEl);
this.$items=$("."+g.CONTENT_ITEM,this.$modernEl);
this.$itemsMobile=$("."+g.CONTENT_ITEM_MOBILE,this.$modernEl);
this.$tilesSection=this.$modernEl.querySelector("."+g.TITLES_SECTION);
this.itemsLength=this.$items.length;
this.init();
e.push(this)
}_createClass(r,[{key:"init",value:function z(){if(d.isEditMode()){this.editModeEvents();
return
}this.resizeEventHandler(this);
this.initDefaultSwitcherView();
this.addEventHandler();
this.setTitleIndex();
this.initEvents()
}},{key:"setTitleIndex",value:function y(){$.each(this.$tiles,function(C,D){D.setAttribute("item-index",C)
})
}},{key:"nextSlide",value:function l(){var D=this.$items.index(this.getActiveSlide());
var C=D<this.itemsLength-1?D+1:0;
this.switchSlide(this.$items[C])
}},{key:"prevSlide",value:function i(){var D=this.$items.index(this.getActiveSlide());
var C=D>0?D-1:this.itemsLength-1;
this.switchSlide(this.$items[C])
}},{key:"switchSlide",value:function o(C){this.reset();
C.classList.remove(g.HIDE);
C.classList.add(g.ACTIVE);
this.renderResponsiveImg(C)
}},{key:"getActiveSlide",value:function u(){return this.$modernEl.querySelector(g.ACTIVE_CONTENT)
}},{key:"getActiveTitle",value:function t(){return this.$modernEl.querySelector(g.ACTIVE_TILE)
}},{key:"reset",value:function A(){for(var C=0;
C<this.$tiles.length;
C++){this.$tiles[C].classList.remove(g.ACTIVE)
}for(var D=0;
D<this.itemsLength;
D++){this.$items[D].classList.remove(g.ACTIVE);
this.$items[D].classList.add(g.HIDE)
}if(this.$itemsMobile.length>0){for(var E=0;
E<this.itemsLength;
E++){this.$itemsMobile[E].classList.remove(g.ACTIVE);
this.$itemsMobile[E].style.maxHeight=null
}}}},{key:"initDefaultSwitcherView",value:function n(){this.reset();
if(this.device==="desktop"){this.$tiles[0].classList.add(g.ACTIVE);
this.$tiles[0].setAttribute("tabindex",0);
this.$items[0].classList.add(g.ACTIVE);
this.$items[0].classList.remove(g.HIDE)
}}},{key:"addEventHandler",value:function h(){var D=this;
var C=Array.prototype.slice.call(this.$tiles);
C.forEach(function(E){E.addEventListener("click",function(F){D.tileClickHandler(F.currentTarget,D)
})
})
}},{key:"mobileClickHandler",value:function x(D,C){var F=this.$modernEl.querySelector(g.ACTIVE_TILE);
if(!!F&&!F.isEqualNode(D)){this.reset()
}var E=D.nextElementSibling;
D.classList.toggle(g.ACTIVE);
E.classList.toggle("active");
C.activeTile=D;
C.activeContent=E;
if(E.style.maxHeight){E.style.maxHeight=null
}else{E.style.maxHeight=E.scrollHeight+"px"
}}},{key:"moveContentToTop",value:function v(C){if(C.activeTile!==undefined&&C.activeTile.classList.contains(g.ACTIVE)){var D=document.body.getBoundingClientRect();
var E=C.activeContent.getBoundingClientRect();
$("html, body").animate({scrollTop:E.top-D.top-f.RESPONSIVE_HEADER_HEIGHT},500)
}}},{key:"desktopClickHandler",value:function m(D){this.reset();
var E=D.getAttribute("tile-id");
var C=this.$modernEl.querySelector('[content-id="'+E+'"]');
D.classList.add(g.ACTIVE);
C.classList.add(g.ACTIVE);
C.classList.remove(g.HIDE);
this.renderResponsiveImg(C)
}},{key:"renderResponsiveImg",value:function s(C){var D=C.querySelectorAll("."+g.RESPONSIVE_IMAGE);
if(D.length>0){$(window).trigger("resize")
}}},{key:"tileClickHandler",value:function q(D,C){if(this.device==="desktop"){this.desktopClickHandler(D,C)
}else{this.mobileClickHandler(D,C)
}}},{key:"resizeEventHandler",value:function k(){if(window.matchMedia("(min-width: 768px)").matches){this.device="desktop"
}else{this.device="mobile"
}}},{key:"getTitleItem",value:function j(C){if(C<0){return this.$tiles[this.itemsLength-1]
}if(C>this.itemsLength-1){return this.$tiles[0]
}return this.$tiles[C]
}},{key:"arrowClickHandler",value:function w(G){var C=this;
var D=function D(H,J){J.preventDefault();
C.$modernEl.querySelector('[tabindex="0"]').removeAttribute("tabindex");
var I=C.getTitleItem(H);
I.setAttribute("tabindex",0);
I.focus();
C.desktopClickHandler(I)
};
if(G.keyCode===36){D(0,G)
}if(G.keyCode===35){D(this.itemsLength-1,G)
}if(G.keyCode===38||G.keyCode===37){var E=this.getActiveTitle().getAttribute("item-index");
D(Number(E)-1,G)
}if(G.keyCode===40||G.keyCode===39){var F=this.getActiveTitle().getAttribute("item-index");
D(Number(F)+1,G)
}}},{key:"initEvents",value:function p(){var C=this;
window.addEventListener("resize",b.debounceExtend(function(){C.resizeEventHandler(C);
if(!C.currentDevice){C.currentDevice=C.device;
return
}if(C.currentDevice!==C.device){C.initDefaultSwitcherView();
C.currentDevice=C.device
}},300));
this.$modernEl.addEventListener("transitionend",b.debounceExtend(function(){C.moveContentToTop(C)
},100));
this.$tilesSection.addEventListener("keydown",this.arrowClickHandler.bind(this))
}},{key:"editModeEvents",value:function B(){var C=this;
this.switchSlide(this.$items[0]);
this.$el.on(a.prevSlide,function(){C.prevSlide()
});
this.$el.on(a.nextSlide,function(){C.nextSlide()
})
}}]);
return r
}();
c.moduleName="Categories Switcher";
c.activatedComponents=e;
c.events=a;
c.selector=".categories-switcher-ui";
return c
});
define("ClientLogicPopUp",["utils","utils-env","ClientLogicPopUpService"],function(b,e,a){var f={POP_UP_CONTENT:".pop-up__content",POP_UP_SUCCESS_REQUEST_MESSAGE:".pop-up__request-message-success",POP_UP_ERROR_REQUEST_MESSAGE:".pop-up__request-message-error",POP_UP_CLOSE_BUTTON:".pop-up__button-close",POP_UP_BACKDROP:".pop-up__backdrop",POP_UP_WRAPPER:".pop-up__wrapper",POP_UP_FORM:".pop-up__form",POP_UP_TRY_AGAIN_LINK:".pop-up__request-message-error__link",POP_UP_EMAIL_INPUT:".pop-up__email-input",POP_UP_HELP_SECTION:".pop-up__help",TEXT_FIELD_UI:".text-field-ui",VALIDATION_TOOLTIP:".validation-tooltip",VALIDATION_TEXT:".validation-text",SUBMIT_BUTTON:".button-ui",BUTTON_SUBMIT_LOADING_GIF:".button-submit__loading-gif",REMEMBER_ME:".remember-me",POP_UP_HELP_LINK:".pop-up__help-link",HAMBURGER_MENU_BUTTON:".hamburger-menu__button",POP_UP_HELP_LOADING_GIF:".pop-up__help-loading-gif"};
var d="(max-width: 1129px)";
var c=function(){function s(A){_classCallCheck(this,s);
this._el=A[0];
this.$rememberMe=this._el.querySelector(f.REMEMBER_ME);
this.$popUpHelpLink=this._el.querySelector(f.POP_UP_HELP_LINK);
this.$popUpContent=this._el.querySelector(f.POP_UP_CONTENT);
this.$successMessage=this._el.querySelector(f.POP_UP_SUCCESS_REQUEST_MESSAGE);
this.$errorMessage=this._el.querySelector(f.POP_UP_ERROR_REQUEST_MESSAGE);
this.$popUpCloseButton=this._el.querySelector(f.POP_UP_CLOSE_BUTTON);
this.$popUpBackDrop=this._el.querySelector(f.POP_UP_BACKDROP);
this.$popUpWrapper=this._el.querySelector(f.POP_UP_WRAPPER);
this.$popUpForm=this._el.querySelector(f.POP_UP_FORM);
this.$popUpTryAgainLink=this._el.querySelector(f.POP_UP_TRY_AGAIN_LINK);
this.$popUpEmailInput=this._el.querySelector(f.POP_UP_EMAIL_INPUT);
this.$textFieldUI=this._el.querySelector(f.TEXT_FIELD_UI);
this.$popUpValidationTooltip=this._el.querySelector(f.VALIDATION_TOOLTIP);
this.$popUpValidationText=this._el.querySelector(f.VALIDATION_TEXT);
this.$popUpHelpSection=this._el.querySelector(f.POP_UP_HELP_SECTION);
this.$submitButton=this._el.querySelector(f.SUBMIT_BUTTON);
this.$buttonSubmitLoadingGif=this._el.querySelector(f.BUTTON_SUBMIT_LOADING_GIF);
this.$popUpHelpLoadingGif=this._el.querySelector(f.POP_UP_HELP_LOADING_GIF);
this.$hamburgerMenuButton=document.body.querySelector(f.HAMBURGER_MENU_BUTTON);
this.isAuthor=e.isAuthor();
this.setCurrentClientLoginButtonAndEvent();
this.initEvents();
new a(this)
}_createClass(s,[{key:"validateEmail",value:function u(A){var B=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
return B.test(A)
}},{key:"setCurrentClientLoginButtonAndEvent",value:function k(){var A=window.matchMedia(d).matches;
if(A){this.isAuthor?this.$clientLoginButton=document.body.querySelector('.hamburger-menu__link[href="/content/infongen/en/client-login.html"]'):this.$clientLoginButton=document.body.querySelector('.hamburger-menu__link[href="/client-login"]')
}else{this.isAuthor?this.$clientLoginButton=document.body.querySelector('.top-navigation__item-link[href="/content/infongen/en/client-login.html"]'):this.$clientLoginButton=document.body.querySelector('.top-navigation__item-link[href="/client-login"]')
}}},{key:"initEvents",value:function m(){this.$clientLoginButton.addEventListener("click",this.openPopUp.bind(this));
window.addEventListener("resize",b.debounce(this.setCurrentClientLoginButtonAndEvent.bind(this),300));
this.$popUpCloseButton.addEventListener("click",this.closePopUp.bind(this));
this.$popUpTryAgainLink.addEventListener("click",this.resetPopUpWithNeedHelpSection.bind(this));
this.$popUpBackDrop.addEventListener("mousedown",this.closePopUp.bind(this));
this.$popUpWrapper.addEventListener("mousedown",function(A){return A.stopPropagation()
});
this.$popUpEmailInput.addEventListener("change",this.isEmailValid.bind(this))
}},{key:"isEmailValid",value:function r(){var B=this.$popUpEmailInput.value;
var A=this.validateEmail(B);
if(A){this.$textFieldUI.classList.remove("validation-field")
}else{this.$textFieldUI.classList.add("validation-field");
!B.length?this.$popUpValidationText.textContent="This is required field":this.$popUpValidationText.textContent="Incorrect email format";
this.$popUpEmailInput.focus()
}return A
}},{key:"resetPopUpWithNeedHelpSection",value:function t(){var A=arguments.length>0&&arguments[0]!==undefined?arguments[0]:true;
this.$errorMessage.classList.remove("active");
this.$errorMessage.classList.add("hidden");
this.$successMessage.classList.remove("active");
this.$successMessage.classList.add("hidden");
this.$popUpContent.classList.remove("hidden");
this.$popUpContent.classList.add("active");
this._el.classList.remove("show-unknown-email-error");
if(A){this.showHelpSection()
}else{this.hideHelpSection()
}}},{key:"showHelpSection",value:function x(){this.$popUpHelpSection.classList.remove("hidden");
this.$popUpHelpSection.classList.add("active")
}},{key:"hideHelpSection",value:function g(){this.$popUpHelpSection.classList.add("hidden");
this.$popUpHelpSection.classList.remove("active")
}},{key:"closePopUp",value:function v(){this.$clientLoginButton.classList.remove("active");
this._el.classList.add("hidden");
this._el.classList.remove("active");
this.resetPopUpWithNeedHelpSection(false);
this.hideSpinner()
}},{key:"closeHamburgerMenu",value:function o(){var A=document.querySelector("html").classList.contains("hamburger-menu--expanded");
A&&this.$hamburgerMenuButton.click()
}},{key:"remembermeProxy",value:function p(B,A){var C=this.getCookieByName("rememberme");
if(C==="true"){B&&B()
}else{A&&A()
}}},{key:"openPopUp",value:function w(A){var B=this;
A.preventDefault();
this.remembermeProxy(function(){B.$submitButton.click()
},function(){B.showPopupWindow()
})
}},{key:"showPopupWindow",value:function z(){this.closeHamburgerMenu();
this.$clientLoginButton.classList.add("active");
this._el.classList.remove("hidden");
this._el.classList.add("active")
}},{key:"getCookieByName",value:function n(B){var A=document.cookie.match(new RegExp("(?:^|; )"+B.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,"\\$1")+"=([^;]*)"));
return A?decodeURIComponent(A[1]):undefined
}},{key:"showSpinner",value:function j(){this.$submitButton.textContent="";
this.$submitButton.setAttribute("disabled",true);
this.$buttonSubmitLoadingGif.classList.remove("hidden");
this.$buttonSubmitLoadingGif.classList.add("active")
}},{key:"hideSpinner",value:function l(){this.$submitButton.textContent="Continue";
this.$submitButton.removeAttribute("disabled");
this.$buttonSubmitLoadingGif.classList.remove("active");
this.$buttonSubmitLoadingGif.classList.add("hidden")
}},{key:"showHelpSectionSpinner",value:function h(){this.$popUpHelpLoadingGif.classList.remove("hidden");
this.$popUpHelpLoadingGif.classList.add("active");
this.$popUpHelpLink.classList.remove("active");
this.$popUpHelpLink.classList.add("hidden")
}},{key:"hideHelpSectionSpinner",value:function i(){this.$popUpHelpLoadingGif.classList.add("hidden");
this.$popUpHelpLoadingGif.classList.remove("active");
this.$popUpHelpLink.classList.add("active");
this.$popUpHelpLink.classList.remove("hidden")
}},{key:"showMessage",value:function q(A){this.$popUpContent.classList.remove("active");
this.$popUpContent.classList.add("hidden");
this._el.classList.remove("show-unknown-email-error");
if(A==="error"){this.$errorMessage.classList.remove("hidden");
this.$errorMessage.classList.add("active")
}else{this.$successMessage.classList.remove("hidden");
this.$successMessage.classList.add("active")
}}},{key:"showUnknownEmailError",value:function y(){this._el.classList.add("show-unknown-email-error")
}}]);
return s
}();
c.moduleName="Client Logic Pop Up";
c.selector=".client-logic-pop-up-ui";
return c
});
define("ClientLogicFetchService",[],function(){var b=function b(d,c){if(!d.ok){c&&c();
throw Error(d.statusText)
}return d
};
var a=function a(f){var e=f.url,g=f.data,c=f.successCallback,d=f.errorCallback;
fetch(e,g).then(function(h){return b(h,d)
}).then(function(h){c(h)
})
};
return{sendRequest:a}
});
define("ClientLogicPopUpService",["ClientLogicFetchService"],function(d){var f={popup:".client-logic-pop-up-ui script",recaptcha:".recaptcha-ui.g-recaptcha"};
var a={popupLoaded:"recaptcha.event.loaded",fetchSend:"fetched.send"};
var b={captchaValidation:"/services/recaptcha/validation",infongenContentPath:"/content/infongen/en",supportEmailUrl:"/services/notify/infongen-support-team?userEmail="};
var e={method:"GET",headers:{Referer:"https://www.infongen.com/"}};
var c=function(){function q(E){_classCallCheck(this,q);
this._popupComponent=E;
this.$recaptchaOnloadScript=document.querySelector(f.popup);
this.$isRecaptchaLaoded=false;
this.init()
}_createClass(q,[{key:"init",value:function y(){this.initEvents()
}},{key:"initEvents",value:function i(){var E=this;
this._popupComponent.$popUpForm.addEventListener("submit",function(F){return E.handlePopupFormSubmit(F)
});
this._popupComponent._el.addEventListener(a.popupLoaded,function(F){return E.handleRecaptchaScriptLoaded(F)
});
this._popupComponent.$popUpHelpLink.addEventListener("click",function(){return E.sendEmailToSupport()
})
}},{key:"handleRecaptchaScriptLoaded",value:function D(){this.renderRecaptchaForm();
grecaptcha.execute(this.$recaptchaId)
}},{key:"sendRecaptcha",value:function g(){this._popupComponent.showSpinner();
this.loadRecaptcha()
}},{key:"loadRecaptcha",value:function t(){if(!this.$isRecaptchaLaoded){this.createAndAddReCaptchaScript()
}else{grecaptcha.execute(this.$recaptchaId)
}}},{key:"handlePopupFormSubmit",value:function k(E){var F=this;
E.preventDefault();
this._popupComponent.remembermeProxy(function(){F.sendRecaptcha()
},function(){if(!F._popupComponent.isEmailValid()){return
}F.sendRecaptcha()
})
}},{key:"createAndAddReCaptchaScript",value:function w(){var E=document.createElement("script");
E.setAttribute("src","https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit");
E.defer=true;
E.async=true;
this._popupComponent._el.insertBefore(E,this.$recaptchaOnloadScript);
this.$isRecaptchaLaoded=true
}},{key:"renderRecaptchaForm",value:function m(){var E=document.querySelector("#popup-recaptcha-container").dataset.sitekey;
this.$recaptchaId=grecaptcha.render("popup-recaptcha-container",{sitekey:E,callback:this.recaptchaOnExecuteHandler.bind(this),size:"invisible"})
}},{key:"getPagePath",value:function B(){var E=/\.[^.]*$/;
var F=window.location.pathname.replace(E,"");
return F.includes(b.infongenContentPath)?F:b.infongenContentPath+F
}},{key:"recaptchaErrorCallback",value:function s(){grecaptcha.reset(this.$recaptchaId);
this.showErrorMessage();
this._popupComponent.hideSpinner();
this.saveToCookie("rememberme","false")
}},{key:"recaptchaOnExecuteHandler",value:function j(H){var G=this;
d.sendRequest({url:b.captchaValidation+"?currentPage="+this.getPagePath()+"&g-recaptcha-response="+H,body:{headers:{Accept:"application/json","Content-Type":"application/json"}},successCallback:function E(I){return G.handleRecaptchaSuccessfulResponse(I)
},errorCallback:function F(){return G.recaptchaErrorCallback()
}})
}},{key:"handleRecaptchaSuccessfulResponse",value:function h(E){var F=this;
E.json().then(function(G){if(G){F.sendEmailToInfongen()
}else{F.recaptchaErrorCallback()
}})
}},{key:"getUserEmail",value:function z(){var E=this;
var F=null;
this._popupComponent.remembermeProxy(function(){F=E._popupComponent.getCookieByName("client-login-user-email")
},function(){F=E._popupComponent.$popUpEmailInput.value
});
return this.escapeUserLogin(F)
}},{key:"sendEmailToInfongen",value:function u(){var H=this;
var F=document.querySelector(".client-logic-pop-up-ui").dataset.endPoint;
d.sendRequest({url:""+F+this.getUserEmail(),data:e,successCallback:function E(I){H.infongenFinalActions();
H.handleInfongenSuccessResponse(I)
},errorCallback:function G(){H.infongenFinalActions();
H.showErrorMessage();
H.saveToCookie("rememberme","false")
}})
}},{key:"handleInfongenSuccessResponse",value:function l(F){var E=this;
F.text().then(function(G){var H=G.length===0;
if(H){E._popupComponent.showPopupWindow();
E._popupComponent.resetPopUpWithNeedHelpSection();
E._popupComponent.showUnknownEmailError();
E.setPreviousEmail()
}else{if(E._popupComponent.$rememberMe.checked){E.saveToCookie("rememberme","true");
E.saveToCookie("client-login-user-email",E._popupComponent.$popUpEmailInput.value)
}window.location.href=G
}})
}},{key:"infongenFinalActions",value:function r(){this._popupComponent.hideSpinner();
grecaptcha.reset(this.$recaptchaId)
}},{key:"setPreviousEmail",value:function v(){var E=this;
this._popupComponent.remembermeProxy(function(){var F=E._popupComponent.getCookieByName("client-login-user-email");
E._popupComponent.$popUpEmailInput.value=F
})
}},{key:"saveToCookie",value:function C(E,F){if(F.trim().length!==0){document.cookie=E+"="+F
}}},{key:"escapeUserLogin",value:function x(E){return encodeURI(E)
}},{key:"showErrorMessage",value:function n(){this._popupComponent.showPopupWindow();
this._popupComponent.showMessage("error");
this.saveToCookie("rememberme","false")
}},{key:"showSuccessMessage",value:function p(){this._popupComponent.showPopupWindow();
this._popupComponent.showMessage();
this.saveToCookie("rememberme","false")
}},{key:"hidePopUpHelpAndSpinner",value:function A(){this._popupComponent.hideHelpSectionSpinner();
this._popupComponent.hideHelpSection()
}},{key:"sendEmailToSupport",value:function o(){var F=this;
if(!this._popupComponent.isEmailValid()){return
}this._popupComponent.showHelpSectionSpinner();
d.sendRequest({url:""+b.supportEmailUrl+this.getUserEmail(),data:e,successCallback:function E(){F.hidePopUpHelpAndSpinner();
F.showSuccessMessage()
},errorCallback:function G(){F.hidePopUpHelpAndSpinner();
F.showErrorMessage()
}})
}}]);
return q
}();
c.moduleName="Client Logic Pop Up";
return c
});
define("a11y-tools",[],function(){var f=function f(h,i){return(" "+h.className+" ").indexOf(" "+i+" ")>-1
};
var a=function a(j,h){if(h.$tiles.length===0){return
}var i=Array.prototype.slice.call(h.$tiles);
Array.prototype.forEach.call(i,function(l,k){if(f(l,"active")){l.setAttribute("tabindex","0");
l.setAttribute("aria-selected",true);
h.$tilesContent[k].setAttribute("tabindex",0)
}else{l.setAttribute("tabindex","-1");
l.setAttribute("aria-selected",false)
}l.classList.add("a11y-focus")
})
};
var d=function d(h,j){var i=Array.prototype.indexOf.call(h,j);
if(i===h.length-1){return{item:h[0],index:0}
}return{item:h[i+1],index:i+1}
};
var e=function e(h,j){var i=Array.prototype.indexOf.call(h,j);
if(i===0){return{item:h[h.length-1],index:h.length-1}
}return{item:h[i-1],index:i-1}
};
var b=function b(i,k){var h=k.$tilesSection.querySelector(".feature-blocks__active");
var j=Array.prototype.indexOf.call(k.$tiles,h);
k.activeTile(i.item);
k.activeTileContent(i.index);
k.$tilesContent[i.index].setAttribute("tabindex",0);
k.$tilesContent[j].removeAttribute("tabindex");
h.setAttribute("tabindex","-1");
h.setAttribute("aria-selected",false);
i.item.setAttribute("tabindex","0");
i.item.setAttribute("aria-selected",true);
i.item.focus()
};
var g=function g(k,j){var l=k.keyCode;
var m=k.target;
if(l===39||l===37||l===35||l===36){k.preventDefault()
}if(l===39){var h=d(j.$tiles,m);
b(h,j)
}if(l===37){var i=e(j.$tiles,m);
b(i,j)
}if(l===35){b({item:j.$tiles[j.$tiles.length-1],index:j.$tiles.length-1},j)
}if(l===36){b({item:j.$tiles[0],index:0},j)
}};
var c=function c(i,h){h.$tilesSection.addEventListener("keydown",function(j){g(j,h)
})
};
return{initFocusAndTabindex:a,initKeysHandler:c}
});
define("FeatureBlocks",["a11y-tools"],function(b){var d={FEATURE_BLOCKS_NAV_TILE:"feature-blocks__nav-tile",ACTIVE_TILE:"feature-blocks__active",ACTIVE_TILE_CONTENT:"feature-blocks__content-active",TILE_CONTENT_SECTION:"feature-blocks__tile-content-section",TILE_TEXT_WRAPPER:"feature-blocks__tile-text-wrapper",SINGLE_IMG:"feature-blocks__single-image",NAVIGATION_SECTION:"feature-blocks__nav-section",INSIDE_INACTIVE_MULTI_LEVEL_TAB:".multi-level-tab__accordion-item:not(.active)",ACTIVE:"active"};
var c=0;
var a=function(){function g(m){_classCallCheck(this,g);
this.$el=m[0];
this.$tiles=this.$el.querySelectorAll("."+d.FEATURE_BLOCKS_NAV_TILE);
this.$tilesContent=this.$el.querySelectorAll("."+d.TILE_CONTENT_SECTION);
this.$tilesL=this.$tiles.length;
this.$tilesSection=this.$el.querySelector("."+d.NAVIGATION_SECTION);
this.init()
}_createClass(g,[{key:"init",value:function l(){this.setDefaultTile();
this.initEventHandler();
this.resizeHandler();
window.addEventListener("resize",this.resizeHandler.bind(this));
b.initFocusAndTabindex(this.$el,this);
b.initKeysHandler(this.$el,this)
}},{key:"initEventHandler",value:function k(){var n=this;
var m=Array.prototype.slice.call(this.$tiles);
Array.prototype.forEach.call(m,function(p,o){var q=p.querySelector("."+d.TILE_TEXT_WRAPPER);
if(q===null){p.classList.add(d.SINGLE_IMG)
}p.addEventListener("click",n.tileClickHandler.bind(n,o,p))
})
}},{key:"tileClickHandler",value:function e(n,m){this.activeTile(m);
this.activeTileContent(n)
}},{key:"activeTile",value:function j(m){var n=this.$el.querySelector("."+d.ACTIVE_TILE);
if(n!==null){n.classList.remove(d.ACTIVE_TILE)
}m.classList.add(d.ACTIVE_TILE)
}},{key:"activeTileContent",value:function f(m){var n=this.$el.querySelector("."+d.ACTIVE_TILE_CONTENT);
if(n!==null){n.classList.remove(d.ACTIVE_TILE_CONTENT,d.ACTIVE);
n.classList.remove(d.ACTIVE)
}this.$tilesContent[m].classList.add(d.ACTIVE_TILE_CONTENT);
this.$tilesContent[m].classList.add(d.ACTIVE)
}},{key:"setDefaultTile",value:function i(){var n=this;
var m=function m(o){n.$tiles[o].classList.add(d.ACTIVE_TILE);
n.$tiles[o].classList.add(d.ACTIVE);
n.$tilesContent[o].classList.add(d.ACTIVE_TILE_CONTENT)
};
m(0)
}},{key:"resizeHandler",value:function h(){if(this.$el.closest(d.INSIDE_INACTIVE_MULTI_LEVEL_TAB)){return
}var p=this.$tiles[0].offsetWidth;
var n=this.$tiles[0].offsetHeight;
var m=Array.prototype.slice.call(this.$tiles);
var o=function o(){m.forEach(function(q){q.setAttribute("style","height:"+p+"px")
})
};
if(c===0){c=p
}if(this.$tilesL===3){o()
}else{if(p<n||c<=p){o();
c=p
}}}}]);
return g
}();
a.moduleName="Feature Blocks";
a.selector=".feature-blocks-ui";
return a
});
define("LogoCarousel",["utils","utils-browser"],function(a,c){var d={tilesContainer:"logo-carousel__tiles-container",tilePreview:"logo-carousel__tile-preview",tilesTrack:"logo-carousel__tiles-track",tileContainer:"logo-carousel__tile-hide-container",tile:"logo-carousel__tile-container",next:"logo-carousel__next",prev:"logo-carousel__prev",clone:"clone",pagination:"logo-carousel__pagination",paginationDot:"logo-carousel__pagination-dot",paginationDotActive:"logo-carousel__pagination-dot--active",navigarionWrapper:"logo-carousel__navigation-wrapper",mediumTile:"medium-tile",mLeft:"m-left",mRight:"m-right",sLeft:"s-left",sRight:"s-right",center:"center",resize:"resize",objectFit:"object-fit"};
var b=function(){function u(N){_classCallCheck(this,u);
this.$settings={items:2,step:1,speed:300,start:0,centerItem:2,shift:0};
this.$xDown=null;
this.$yDown=null;
this.$itemWidth=0;
this.$trackWidth=0;
this.$trackPosition=0;
this.$startPosition=0;
this.$endPosition=0;
this.$isActive=false;
this.$isEnd=false;
this.$isStart=false;
this.$tileIndex=0;
this.$moveDirection=null;
this.$steps=0;
this.$resizeTile=false;
this.$el=N[0];
this.$items=[];
this.$tilesContainer=this.$el.querySelector(".".concat(d.tileContainer));
this.$tilePreview=this.$el.querySelector(".".concat(d.tilePreview));
this.$tilesTrack=this.$el.querySelector(".".concat(d.tilesTrack));
this.$tileContainer=this.$el.querySelector(".".concat(d.tileContainer));
this.$next=this.$el.querySelector(".".concat(d.next));
this.$prev=this.$el.querySelector(".".concat(d.prev));
this.$pagination=this.$el.querySelector(".".concat(d.pagination));
this.$originItems=Array.prototype.slice.call(this.$el.querySelectorAll(".".concat(d.tileContainer)));
this.$naviagationWrapper=this.$el.querySelector(".".concat(d.navigarionWrapper));
this.nextButClickHandler=this.nextButClickHandler.bind(this);
this.prevButClickHandler=this.prevButClickHandler.bind(this);
this.transitionEndEventHandler=this.transitionEndEventHandler.bind(this);
this.resizeEventHandler=this.resizeEventHandler.bind(this);
this.tileClickHandler=this.tileClickHandler.bind(this);
this.keysNavigation=this.keysNavigation.bind(this);
this.paginationKeyHanler=this.paginationKeyHanler.bind(this);
this.handleTouchMove=this.handleTouchMove.bind(this);
this.handleTouchStart=this.handleTouchStart.bind(this);
this.detectIE();
this.init()
}_createClass(u,[{key:"detectIE",value:function E(){var O=c.isInternetExplorer();
if(O){var N=this.$el.querySelectorAll("img");
var P=Array.from(N);
P.forEach(function(R){var S=R.src;
var Q=R.parentNode;
var T=document.createElement("div");
if(S){T.style.backgroundImage="url(".concat(S,")");
T.classList.add(d.objectFit);
Q.removeChild(R);
Q.appendChild(T)
}})
}}},{key:"appendChild",value:function s(N,O){O.forEach(function(P){N.appendChild(P)
})
}},{key:"initUI",value:function J(){var P=document.createElement("div");
var N=Array.from(this.$originItems);
if(this.$settings.items===3){var Q=N[N.length-1];
N.splice(N.length-1,1);
N.unshift(Q)
}else{if(this.$settings.items===5){var O=N.slice(N.length-2,N.length);
N.splice(N.length-2,N.length);
N.unshift.apply(N,_toConsumableArray(O))
}}var S=N.slice(N.length-this.$settings.items,N.length).map(function(T){var U=T.cloneNode(true);
U.classList.add(d.clone);
return U
});
var R=N.slice(0,this.$settings.items).map(function(T){var U=T.cloneNode(true);
U.classList.add(d.clone);
return U
});
this.$items=Array.prototype.concat.call(S,N,R);
if(this.$resizeTile){this.$el.classList.add(d.resize)
}else{if(this.$items[0].classList.contains(d.resize)){this.$el.classList.remove(d.resize)
}}this.$tilePreview.removeChild(this.$tilesTrack);
this.$tilesTrack=P;
this.$tilesTrack.classList.add(d.tilesTrack);
this.appendChild(this.$tilesTrack,this.$items);
this.$tilePreview.appendChild(this.$tilesTrack)
}},{key:"initItemWidth",value:function p(){this.$itemWidth=Math.floor(this.$tilePreview.offsetWidth/this.$settings.items)
}},{key:"initTrackWidth",value:function j(){this.$trackWidth=this.$itemWidth*this.$items.length;
this.$tilesTrack.style.width=this.$trackWidth+"px"
}},{key:"next",value:function x(){if(this.$items.length===1){return
}this.$trackPosition-=this.$itemWidth*this.$settings.step;
this.move();
this.animateTile("next")
}},{key:"prev",value:function w(){if(this.$items.length===1){return
}this.$trackPosition+=this.$itemWidth*this.$settings.step;
this.move();
this.animateTile("prev")
}},{key:"move",value:function y(){this.$tilesTrack.style.transition="transform ".concat(this.$settings.speed,"ms ease");
this.$tilesTrack.style.transform="translate3d(".concat(this.$trackPosition,"px,0,0)");
this.updatePagination()
}},{key:"nextButClickHandler",value:function i(){if(this.$isActive){return
}this.$isActive=true;
this.next()
}},{key:"prevButClickHandler",value:function e(){if(this.$isActive){return
}this.$isActive=true;
this.prev()
}},{key:"setTrackPosition",value:function r(){this.$tilesTrack.style.transitionProperty="none";
this.$tilesTrack.style.transform="translate3d(".concat(this.$trackPosition,"px,0,0)")
}},{key:"setTrackStartPosition",value:function g(){if(this.$items.length===1){this.$trackPosition=0
}else{this.$startPosition=(this.$settings.start+this.$settings.items)*this.$itemWidth;
this.$trackPosition=this.$startPosition*-1
}this.setTrackPosition()
}},{key:"setTrackEndPosition",value:function B(){this.$endPosition=Math.abs(this.$trackPosition)-this.$itemWidth*(this.$items.length-this.$settings.items*2);
this.$trackPosition=this.$endPosition;
this.setTrackPosition()
}},{key:"transitionEndEventHandler",value:function F(N){var O=this;
if(!N.target.classList.contains(d.tilesTrack)){return
}if(this.$items.length!==1){this.$isEnd=Math.abs(this.$trackPosition)===this.$trackWidth-this.$itemWidth*this.$settings.items;
if(this.$isEnd){this.setTrackStartPosition()
}this.$isStart=Math.abs(this.$trackPosition)===0;
if(this.$isStart){this.setTrackEndPosition()
}}this.$isActive=false;
setTimeout(function(){O.tileMove()
},0)
}},{key:"goTo",value:function L(N){this.$trackPosition=-(N*this.$itemWidth);
this.$tileIndex=N;
this.move();
this.animateTile()
}},{key:"updatePagination",value:function l(){var N=0;
N=Math.abs(this.$trackPosition)/this.$itemWidth-this.$settings.items;
if(N===this.$items.length-this.$settings.items*2){N=0
}else{if(N<0){N=this.$items.length-this.$settings.items*2+N
}}var P=this.$el.querySelectorAll(".".concat(d.paginationDot));
var O=Array.from(P);
O.forEach(function(Q){return Q.classList.remove(d.paginationDotActive)
});
O[N].classList.add(d.paginationDotActive)
}},{key:"createPagination",value:function G(){var R=this;
var P=document.createElement("div");
var O=null;
var Q=[];
for(var N=0;
N<this.$originItems.length;
N++){O=document.createElement("div");
O.classList.add(d.paginationDot);
O.tabIndex=0;
Q.push(O)
}Q.forEach(function(U,S){var T=S+R.$settings.items;
U.addEventListener("click",function(){return R.goTo(T)
})
});
this.appendChild(P,Q);
this.$pagination.innerHTML="";
this.$pagination.appendChild(P)
}},{key:"resizeEventHandler",value:function f(){this.init()
}},{key:"animateTile",value:function h(P){this.$items.forEach(function(Q){Q.firstElementChild.style.transform="";
Q.classList.remove(d.center,d.mLeft,d.mRight,d.sLeft,d.sRight)
});
var N=Math.abs(this.$trackPosition)===this.$trackWidth-this.$itemWidth*this.$settings.items;
var O=Math.abs(this.$trackPosition)===0;
if(O||N){this.$tileIndex=O?this.$tileIndex-1:this.$tileIndex+1;
this.applyTileStyle();
this.changeTileIndex(P);
this.applyTileStyle()
}else{this.changeTileIndex(P);
this.applyTileStyle()
}}},{key:"applyTileStyle",value:function k(){var O=this;
var Q=function Q(R,U,S,T){O.$items[R].firstElementChild.style.transform=U;
O.$items[R].firstElementChild.style.transition=S;
O.$items[R].setAttribute("data-index",T);
O.$items[R].classList.add(T)
};
if(this.$settings.items===2){this.$items[this.$tileIndex].setAttribute("data-index",d.mLeft);
this.$items[this.$tileIndex+1].setAttribute("data-index",d.mRight);
return
}else{if(this.$settings.items===3||this.$settings.items===5){var P=this.$settings.items===5?28:0;
var N="transform ".concat(this.$settings.speed,"ms ease 0ms");
Q(this.$tileIndex+this.$settings.centerItem-1,"scale(1.18, 1.2) translateX(-"+P+"px)",N,d.mLeft);
Q(this.$tileIndex+this.$settings.centerItem,"scale(1.555, 1.6)",N,d.center);
Q(this.$tileIndex+this.$settings.centerItem+1,"scale(1.18, 1.2) translateX("+P+"px)",N,d.mRight);
if(this.$settings.items===5){Q(this.checkNextTileIndex(this.$tileIndex+this.$settings.centerItem-2),"translateX(-18px)",N,d.sLeft);
Q(this.checkNextTileIndex(this.$tileIndex+this.$settings.centerItem+2),"translateX(20px)",N,d.sRight)
}}}}},{key:"checkNextTileIndex",value:function z(N){if(N>=this.$items.length){return 0+this.$settings.items
}if(N<=0){return this.$items.length-this.$settings.items*2
}return N
}},{key:"changeTileIndex",value:function M(N){if(N==="next"){this.incTileIndex()
}else{if(N==="prev"){this.decTileIndex()
}}}},{key:"incTileIndex",value:function o(){if(this.$tileIndex>=this.$items.length-this.$settings.items-1){this.$tileIndex=this.$settings.items;
return
}this.$tileIndex=this.$tileIndex+1
}},{key:"decTileIndex",value:function K(){this.$tileIndex=this.$tileIndex-1;
if(this.$tileIndex<=0){this.$tileIndex=this.$items.length-this.$settings.items*2
}}},{key:"initEventsListener",value:function v(){this.$next.addEventListener("click",this.nextButClickHandler);
this.$prev.addEventListener("click",this.prevButClickHandler);
this.$tilesTrack.addEventListener("transitionend",this.transitionEndEventHandler);
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler,300));
this.$naviagationWrapper.addEventListener("click",this.tileClickHandler);
this.$tilePreview.addEventListener("keydown",this.keysNavigation);
this.$pagination.addEventListener("keydown",this.paginationKeyHanler);
this.$el.addEventListener("touchstart",this.handleTouchStart,{passive:true});
this.$el.addEventListener("touchmove",this.handleTouchMove,{passive:true})
}},{key:"getTouches",value:function D(N){return N.touches||N.originalEvent.touches
}},{key:"handleTouchStart",value:function n(N){var O=this.getTouches(N)[0];
this.$xDown=O.clientX;
this.$yDown=O.clientY
}},{key:"handleTouchMove",value:function q(N){if(!this.$xDown||!this.$yDown){return
}var Q=N.touches[0].clientX;
var O=N.touches[0].clientY;
var R=this.$xDown-Q;
var P=this.$yDown-O;
if(Math.abs(R)>Math.abs(P)){if(R>0){this.nextButClickHandler()
}else{this.prevButClickHandler()
}}this.$xDown=null;
this.$yDown=null
}},{key:"paginationKeyHanler",value:function I(N){var P=N.keyCode,O=N.target;
if(P===13){O.click()
}}},{key:"tileClickHandler",value:function m(R){var O=R.target;
var P=O.tagName;
var N=null;
var T=P.localeCompare("IMG");
var S=O.classList.contains(d.tile);
var Q=null;
if(T===0){Q=O.parentNode.parentNode;
N=Q.getAttribute("data-index")
}else{if(S){Q=O.parentNode;
N=Q.getAttribute("data-index")
}}switch(N){case d.sLeft:this.$moveDirection="prev";
this.$steps=2;
break;
case d.mLeft:this.$moveDirection="prev";
this.$steps=1;
break;
case d.sRight:this.$moveDirection="next";
this.$steps=2;
break;
case d.mRight:this.$moveDirection="next";
this.$steps=1;
break;
default:this.$moveDirection=null;
this.$steps=0;
return
}this.tileMove()
}},{key:"tileMove",value:function t(){if(this.$steps===0||this.$moveDirection===null){return
}this.$steps--;
if(this.$moveDirection==="next"){this.nextButClickHandler()
}else{if(this.$moveDirection==="prev"){this.prevButClickHandler()
}}}},{key:"keysNavigation",value:function H(N){var O=N.keyCode;
if(O===39){this.nextButClickHandler()
}if(O===37){this.prevButClickHandler()
}}},{key:"setItemsCount",value:function A(){this.$tilePreview.style.width="";
var N=this.$tilePreview.offsetWidth;
this.$resizeTile=false;
if(N===222){this.$settings.items=1;
this.$tileIndex=1
}else{if(N===444){this.$settings.items=2;
this.$tileIndex=2
}else{if(N===788){this.$settings.items=3;
this.$tileIndex=3;
this.$settings.centerItem=1
}else{if(this.$originItems.length>=5){this.$settings.items=5;
this.$tileIndex=5;
this.$settings.centerItem=2
}else{this.$settings.items=3;
this.$tileIndex=3;
this.$settings.centerItem=1;
this.$tilePreview.style.width=788+"px";
this.$resizeTile=true
}}}}}},{key:"init",value:function C(){this.setItemsCount();
this.initUI();
this.createPagination();
this.initItemWidth();
this.initTrackWidth();
this.setTrackStartPosition();
this.updatePagination();
this.animateTile();
this.initEventsListener()
}}]);
return u
}();
b.moduleName="Logo Carousel";
b.selector=".logo-carousel-ui";
return b
});
define("MultipleTopicsList",["utils","utils-env","RequestAnimationFrame"],function(a,d,e){var c={title:".multiple-topics-list__title-item",content:".multiple-topics-list__content",blockContent:".multiple-topics-list__block-content",contentWrapper:".multiple-topics-list__content-wrapper",hidden:"hidden",active:"active",dropdown:".multiple-topics-list__dropdown",dropdownButton:".multiple-topics-list__dropdown-button",dropdownButtonOpen:"multiple-topics-list__dropdown-button--open",dropdownContent:".multiple-topics-list__dropdown-content",dropdownContentItem:".multiple-topics-list__dropdown-content-item",hideDivider:"multiple-topics-list__title-item-no-divider",yellowLine:".multiple-topics-list__animation-placeholder",animated:"animated"};
var b=function(){function n(s){_classCallCheck(this,n);
this.$el=s;
this.$title=this.$el.find(c.title);
this.$contentWrapper=this.$el.find(c.contentWrapper);
this.$content=this.$el.find(c.content);
this.$dropdown=this.$el.find(c.dropdown);
this.$dropdownButton=this.$el.find(c.dropdownButton);
this.$dropdownContent=this.$el.find(c.dropdownContent);
this.$dropdownContentItem=this.$el.find(c.dropdownContentItem);
this.$yellowLine=this.$el.find(c.yellowLine);
this.activeSlideId=$(this.$title[0]).attr("title-id");
this.slidesWithAnimation=[];
if(!d.isEditMode()){this.init();
this.setActiveTitle(this.activeSlideId,false)
}a.checkDividers(this.$title,c.hideDivider)
}_createClass(n,[{key:"init",value:function p(){var s=this;
this.$title.click(function(){s.switchContentOnClick($(this))
});
this.$dropdown.click(this.toggleDropdown.bind(this));
this.$dropdownContentItem.click(this.toggleDropdown.bind(this));
if(this.$el.hasClass(c.animated)){for(var t=0;
t<this.$yellowLine.length;
t++){this.loadAnimation(t)
}}this.setActiveSlideByAnchor();
this.scrollToElement()
}},{key:"scrollToElement",value:function j(){var s=70;
var t=window.location.hash.replace("#","");
if(t){$("html, body").animate({scrollTop:$("#"+t).offset().top-s},100)
}}},{key:"getActiveSlideIndexById",value:function g(u){var s=this.$content.toArray();
var t=s.findIndex(function(v){return v.getAttribute("content-id")===u
});
return t
}},{key:"runAnimation",value:function f(){e.increaseAnimationQueue({func:this.runAnimationSuccess.bind(this),isEnd:this.isAnimationEnd.bind(this)})
}},{key:"scrollToContent",value:function k(){var s=30;
var u=1024;
var t=$(window).width()<u?s:50;
$("html, body").animate({scrollTop:this.$contentWrapper.offset().top-t},100)
}},{key:"isAnimationEnd",value:function i(){return this.isAnimationRun
}},{key:"loadAnimation",value:function h(s){if(this.slidesWithAnimation.indexOf(s)===-1){this.slidesWithAnimation.push(s);
this.delayAnimation=bodymovin.loadAnimation({container:this.$yellowLine[s],renderer:"svg",loop:false,autoplay:true,path:"/etc/designs/epam-com/json-animations/yellow-curve-1.json",rendererSettings:{viewBoxOnly:true}});
this.delayAnimation.addEventListener("DOMLoaded",this.runAnimation.bind(this))
}}},{key:"runAnimationSuccess",value:function r(){if(this.isAnimationRun){return
}if(a.isElementInViewport(this.$el[0])){this.isAnimationRun=true;
this.delayAnimation.goToAndPlay(0)
}}},{key:"switchContentOnClick",value:function o(u){if(u.attr("title-id")){var t=u.attr("title-id");
this.setActiveTitle(t)
}else{var s=u.attr("mobile-title-id");
this.setActiveTitle(s)
}this.scrollToContent()
}},{key:"setActiveSlideByAnchor",value:function q(){var s=window.location.href.split("#")[1];
if(s){var u=this.$title.toArray().find(function(v){return s===v.getAttribute("id")
});
if(u){var t=u.getAttribute("title-id");
this.setActiveTitle(t)
}}}},{key:"setActiveTitle",value:function m(s){var u=arguments.length>1&&arguments[1]!==undefined?arguments[1]:true;
var z=this.$el.find('[title-id="'+s+'"]');
var y=this.$el.find('[mobile-title-id="'+s+'"]');
var v=this.$el.find('[content-id="'+s+'"]');
var B=$(z).text();
this.$dropdownButton.text(B);
z.addClass(c.active);
v.removeClass(c.hidden);
if(u){var w=v.find(c.blockContent);
w.focus()
}y.addClass(c.active);
if(this.activeSlideId!==s){var A=this.$el.find('[title-id="'+this.activeSlideId+'"]');
var t=this.$el.find('[mobile-title-id="'+this.activeSlideId+'"]');
var x=this.$el.find('[content-id="'+this.activeSlideId+'"]');
A.removeClass(c.active);
x.addClass(c.hidden);
t.removeClass(c.active);
this.activeSlideId=s
}}},{key:"toggleDropdown",value:function l(s){s.stopPropagation();
if(this.$dropdownContent.hasClass(c.hidden)){this.$dropdownContent.removeClass(c.hidden);
this.$dropdownButton.removeClass(c.dropdownButtonOpen)
}else{this.$dropdownContent.addClass(c.hidden);
this.$dropdownButton.addClass(c.dropdownButtonOpen)
}}}]);
return n
}();
b.moduleName="Multiple Topics List";
b.selector=".multiple-topics-list-ui";
return b
});
define("RolloverTiles",[],function(){var d={BLOCK:"rollover-tiles__block",ROLLOVER_BLOCK:"rollover-tiles__block--rollover",LINK:"rollover-tiles__link",LINK_A11Y:"rollover-tiles__link--a11y",ROLLOVER_TILE:"rollover-tiles__description--rollover",ROLLOVER_TEXT:"rollover-tiles__text"};
var c="(min-width: 768px)";
var b="(min-width: 1025px)";
var a=function(){function f(l){_classCallCheck(this,f);
this.el=l[0];
var k=window.matchMedia(b).matches;
var j=!k&&window.matchMedia(c).matches;
if(k||j){this.links=this.el.querySelectorAll("."+d.LINK)
}if(k){this.addEventListeners()
}else{if(j){this.changeLinksAriaLabels()
}}}_createClass(f,[{key:"addEventListeners",value:function i(){var j=this;
var k=this.el.querySelectorAll("."+d.BLOCK);
k.forEach(function(o,m){var l=o.querySelector("."+d.LINK_A11Y);
var n=o.querySelector("."+d.ROLLOVER_TILE);
if(l){l.removeAttribute("aria-hidden");
l.removeAttribute("tabindex");
j.addEventListenerToLinkA11y(o,l,n);
j.addEventListenerToRolloverTile(o,j.links[m],n)
}})
}},{key:"addEventListenerToLinkA11y",value:function e(l,j,k){j.addEventListener("click",function(m){m.preventDefault();
if(k){k.removeAttribute("aria-hidden");
k.setAttribute("tabindex",0);
k.focus();
l.classList.add(d.ROLLOVER_BLOCK)
}})
}},{key:"addEventListenerToRolloverTile",value:function h(l,k,j){j.addEventListener("click",function(){k.click()
});
j.addEventListener("blur",function(){setTimeout(function(){j.removeAttribute("tabindex");
j.setAttribute("aria-hidden",true);
l.classList.remove(d.ROLLOVER_BLOCK)
},40)
})
}},{key:"changeLinksAriaLabels",value:function g(){this.links.forEach(function(k){var l=k.getAttribute("aria-label");
var j=k.querySelector("."+d.ROLLOVER_TEXT).innerText;
k.setAttribute("aria-label",l+"\n"+j)
})
}}]);
return f
}();
a.moduleName="Rollover Tiles";
a.selector=".rollover-tiles-ui";
return a
});
define("VideoShowcasesClasses",[],function(){return{PLAYER:"video-showcase__player-section",VIDEO:"video-showcase__video",VIDEO_TITLE:"video-showcase__title",VIDEO_TITLE_ACTIVE:"video-showcase__title--active",OVERLAY_ICONS:"video-showcase__overlay-icons",OVERLAY_PLAY_ACTIVE:"overlay-play-active",OVERLAY_PAUSE_ACTIVE:"overlay-pause-active",PROGRESS_BAR:"video-showcase__progress-bar",DURATION:"video-showcase__duration",TIME_ELAPSED:"video-showcase__time-elapsed",VOLUME_BUTTON:"video-showcase__volume-button",VOLUME_ICONS:"video-showcase__volume-button svg",VOLUME_HIGH:"volume-high",VOLUME_LOW:"volume-low",VOLUME_MUTE:"volume-mute",VOLUME:"video-showcase__volume",FULLSCREEN_BUTTON:"video-showcase__fullscreen-button",PLAY_BUTTON:"video-showcase__play-button",CONTROL_SECTION:"video-showcase__controls-section",SLIDER_IMG_WRAPPER:"video-showcase__img-wrapper",TRAY_SEEK:"video-showcase__tray-seek",DELAY_PLAY:"video-showcase__delay-play",WAIT_FOR_PLAY:"video-showcase__wait-for-play",OWL:"owl-carousel",NEXT_ICON:"video-showcase__nav-control-next",PREV_ICON:"video-showcase__nav-control-prev",BLACK_FRAME:"video-showcase__black-frame",VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS:"video-showcase__progress-bar-progress",VIDEO_SHOWCASE_PROGRESS_BAR_TRACK:"video-showcase__progress-bar-track",VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA:"video-showcase__progress-bar-hidden-area",events:{PLAY_EVENT:"customPlayEvent",PAUSE_EVENT:"customPauseEvent",PLAY_FROM_START:"customPlayFromStartEvent",PLAY_TILE_EVENT:"customTilePlayEvent",NEW_LOAD_REQUEST:"customNewLoadEvent"}}
});
define("VideoShowcases",["utils-browser","utils","VideoShowcasePlayerFunctions","VideoShowcasesInitA11Y","VideoShowcasesClasses","utils-env"],function(d,a,c,f,e,h){var g=!!document.createElement("video").canPlayType;
var b=function(){function A(I){_classCallCheck(this,A);
this.$el=I[0];
this.isIE=d.isInternetExplorer();
this.$player=this.$el.querySelector("."+e.PLAYER);
this.$video=this.$el.querySelector("."+e.VIDEO);
this.$owl=$(this.$el.querySelector("."+e.OWL));
this.$isHideSlider=this.$el.dataset.hideCarousel;
this.$videoSliderItems=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
this.$videoTitleActive=this.$el.querySelector("."+e.VIDEO_TITLE_ACTIVE);
this.$progressBar=this.$el.querySelector("."+e.PROGRESS_BAR);
this.$controlSection=this.$el.querySelector("."+e.CONTROL_SECTION);
this.$duration=this.$el.querySelector("."+e.DURATION);
this.$timeElapsed=this.$el.querySelector("."+e.TIME_ELAPSED);
this.$overlayIcons=this.$el.querySelector("."+e.OVERLAY_ICONS);
this.$volumeButton=this.$el.querySelector("."+e.VOLUME_BUTTON);
this.$volumeIcons=this.$el.querySelectorAll("."+e.VOLUME_ICONS);
this.$volumeLow=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(2)");
this.$volumeHigh=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(3)");
this.$volumeMute=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(1)");
this.$volume=this.$el.querySelector("."+e.VOLUME);
this.$fullscreenButton=this.$el.querySelector("."+e.FULLSCREEN_BUTTON);
this.$playButton=this.$el.querySelector("."+e.PLAY_BUTTON);
this.$delayPlayContainer=this.$el.querySelector("."+e.DELAY_PLAY);
this.$waitForPlay=this.$el.querySelector("."+e.WAIT_FOR_PLAY);
this.nextIcon=this.$el.querySelector("."+e.NEXT_ICON);
this.prevIcon=this.$el.querySelector("."+e.PREV_ICON);
this.blackFrame=this.$el.querySelector("."+e.BLACK_FRAME);
this.$videoProgressBar=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS);
this.$videoProgressBarTrack=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_TRACK);
this.$videoProgressBarHiddenArea=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA);
this.isFirstPlay=true;
this.isOverlayRemoved=false;
this.activeVideoIndex=0;
this.userClick=false;
this.delayPlayRemoved=true;
this.activeIndex=[];
this.owlItems=[];
this.fromStart=false;
this.promisePending=false;
this.publishMode=!h.isEditMode();
this.customPlayEvent=document.createEvent("Event");
this.customPauseEvent=document.createEvent("Event");
this.customPlayFromStartEvent=document.createEvent("Event");
this.customTilePlayEvent=document.createEvent("Event");
this.customNewLoadRequestEvent=document.createEvent("Event");
this.customPlayEvent.initEvent(e.events.PLAY_EVENT,true,true);
this.customPauseEvent.initEvent(e.events.PAUSE_EVENT,true,true);
this.customPlayFromStartEvent.initEvent(e.events.PLAY_FROM_START,true,true);
this.customTilePlayEvent.initEvent(e.events.PLAY_TILE_EVENT,true,true);
this.customNewLoadRequestEvent.initEvent(e.events.NEW_LOAD_REQUEST,true,true);
this.init()
}_createClass(A,[{key:"init",value:function F(){this.setDefaultVideo();
this.initOwlCarousel();
if(this.publishMode){this.setDefaultVideo();
this.initEventsHandlers(this);
this.setVideoIndex();
this.initOwlCarousel();
f.loadDelayPlayIconAnimation.call(this);
this.activeTraySeek();
if(this.isIE||d.detectIOSDevice()){c.removeVideoOverlay.call(this)
}else{f.loadWaitAnimation.call(this);
this.isSupportPlayer();
this.customVideoEvents()
}}}},{key:"setVideoIndex",value:function s(){Array.prototype.forEach.call(this.$videoSliderItems,function(J,I){J.setAttribute("data-index",I)
})
}},{key:"initOwlCarousel",value:function r(){if(this.$isHideSlider==="1"){this.$el.querySelector(".video-showcase__slider-section").classList.add("hidden");
return
}var I=this.$videoSliderItems.length>3;
var J=this.$videoSliderItems.length>3?3:this.$videoSliderItems.length;
this.$owl.on("initialized.owl.carousel",function(){if(this.publishMode){f.initA11y.call(this);
f.stopVideoBySpaceA11y.call(this)
}this.$owl.on("refreshed.owl.carousel",function(){this.removeOwlAriaAttr();
f.reInitA11yAttr.call(this)
}.bind(this))
}.bind(this));
this.$owl.addClass("owl-item-count-"+J);
this.$owl.owlCarousel({nav:true,dots:false,items:J,responsive:false,mouseDrag:I,loop:I,navText:[this.prevIcon,this.nextIcon],navElement:"div"});
this.$owl[0].removeAttribute("style")
}},{key:"isSupportPlayer",value:function u(){if(g){this.$video.controls=false;
this.$controlSection.classList.remove("hidden");
c.updateVolumeIcon.call(this);
this.$normalProgressbarLength=this.$videoProgressBar.getBoundingClientRect().width;
this.$videoProgressBarLen=function(){return this.getBoundingClientRect().width
}.bind(this.$videoProgressBar)
}}},{key:"setDefaultVideo",value:function y(J){var I=J?J:this.$videoSliderItems[0];
if(I){this.changeActiveVideo(this.getVideoDataFromItem(I));
this.$video.load()
}}},{key:"delayPlayHandler",value:function q(){this.blackFrame.classList.add("hidden");
c.removeDelayPlay.call(this);
c.togglePlay.call(this)
}},{key:"sliderClickHandler",value:function x(J){var L=J.target;
var I=768;
if(this.isIE||L.tagName==="svg"||L.tagName==="use"||$(L).hasClass("video-showcase__img-wrapper-overlay")||$(L).hasClass("video-showcase__tray-text")||$(window).width()<I){var K=$(L).closest("."+e.SLIDER_IMG_WRAPPER);
if(K.length!==0){this.videoSlideClick(K.data().index,K[0])
}}}},{key:"videoSlideClick",value:function B(I,J){this.tileState=$(J).hasClass("active")||$(J).hasClass("pause");
!this.isFirstPlay&&c.saveVideoProgress.call(this);
this.activeVideoIndex=I;
this.activeItem=J;
this.fixPlayerHeight();
this.$video.classList.add("video-showcase__invincible");
this.changeActiveTile(J,I);
this.changeActiveVideo(this.getVideoDataFromItem(J));
this.$video.dispatchEvent(this.customNewLoadRequestEvent)
}},{key:"clearPlayerStyleProperties",value:function p(){this.$video.classList.remove("video-showcase__invincible");
this.$player.removeAttribute("style")
}},{key:"changeActiveTile",value:function k(K,I){var N=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
for(var J=0;
J<N.length;
J++){N[J].classList.remove("active");
N[J].classList.remove("pause")
}var M=this.$el.querySelectorAll('[data-index="'+I+'"]');
for(var L=0;
L<M.length;
L++){M[L].classList.add("active")
}}},{key:"getVideoDataFromItem",value:function n(I){return I?{sources:I.querySelector("img").getAttribute("data-source"),poster:I.querySelector("img").getAttribute("poster-source"),title:I.dataset.title}:null
}},{key:"changeActiveVideo",value:function D(J){var K=this;
var I=J.sources,M=J.poster,L=J.title;
this.$video.innerHTML="";
if(this.isFirstPlay){this.$video.poster=M
}JSON.parse(I).forEach(function(N){var O=N.type,Q=N.src;
var P=document.createElement("source");
P.setAttribute("type",O);
P.setAttribute("src",Q);
K.$video.appendChild(P)
});
if(!L){this.$videoTitleActive.classList.add("hidden")
}else{this.$videoTitleActive.classList.remove("hidden");
if(this.$videoTitleActive){this.$videoTitleActive.textContent=L
}}}},{key:"initializeVideo",value:function C(){var I=this;
this.videoDuration=Math.floor(this.$video.duration);
var J=c.formatTime(this.videoDuration);
this.$duration.innerText=J.minutes+":"+J.seconds;
this.$duration.setAttribute("datetime",J.minutes+"m "+J.seconds+"s");
if(this.traySeek!==undefined){this.traySeek.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.setAttribute("max",this.videoDuration)
}if(!this.isFirstPlay&&!this.fromStart){c.applyVideoProgress.call(this)
}this.fromStart=false;
$.each(this.activeIndex,function(K,L){$(I.owlItems[L]).removeClass("hide-tray-seek")
})
}},{key:"loadMetadataCallback",value:function G(){this.initializeVideo();
this.clearPlayerStyleProperties()
}},{key:"updatePlayButton",value:function w(){this.$playButton.classList.toggle("play")
}},{key:"updateFullscreenButton",value:function v(){this.$fullscreenButton.classList.toggle("fullscreen")
}},{key:"videoBorderTracker",value:function t(){var I=this.$el.getBoundingClientRect().top;
var O=window.pageYOffset||document.documentElement.scrollTop;
var K=O+I;
var J=O+I+this.$video.offsetHeight;
var N=O;
var M=N+window.innerHeight;
var L=function(){if(!this.$video.paused){c.togglePlay.call(this)
}}.bind(this);
if(N>J){L();
return
}if(M<K){L();
return
}}},{key:"activeTraySeek",value:function m(){this.activeIndex=[];
this.owlItems=$(this.$el).find(".owl-item");
$.each(this.owlItems,function(I,K){var L=$(K).find("."+e.VIDEO_TITLE)[0];
if(L){K.dataset.title=L.textContent
}$(K).addClass("hide-tray-seek");
var J=$(K).find('[data-index="'+this.activeVideoIndex+'"]');
if(J.length!==0){this.activeIndex.push(I)
}}.bind(this));
if(this.owlItems[this.activeIndex[0]]!==undefined){this.traySeek=this.owlItems[this.activeIndex[0]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[1]]!==undefined){this.clonedTraySeekStart=this.owlItems[this.activeIndex[1]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[2]]!==undefined){this.clonedTraySeekEnd=this.owlItems[this.activeIndex[2]].querySelector("."+e.TRAY_SEEK)
}}},{key:"mouseMove",value:function o(){this.$player.classList.add("mouse-move");
if(this.setTimeoutId!==undefined||this.setTimeoutId!==null){clearTimeout(this.setTimeoutId)
}this.setTimeoutId=setTimeout(function(){this.$player.classList.remove("mouse-move");
this.setTimeoutId=null
}.bind(this),15000)
}},{key:"fixPlayerHeight",value:function i(){var I=this.$player.getBoundingClientRect();
this.$player.setAttribute("style","height:"+I.height+"px")
}},{key:"resizeEventHandler",value:function l(){this.$owl.trigger("refresh.owl.carousel")
}},{key:"removeOwlAriaAttr",value:function H(){var J=this.$el.querySelectorAll('[role="tab"]');
for(var I=0;
I<J.length;
I++){J[I].removeAttribute("tabindex");
J[I].removeAttribute("aria-selected");
J[I].removeAttribute("role")
}}},{key:"customVideoEvents",value:function E(){this.$video.addEventListener("timeupdate",c.timeUpdate.bind(this));
this.$volume.addEventListener("input",c.updateVolume.bind(this));
this.$video.addEventListener("volumechange",c.updateVolumeIcon.bind(this));
this.$player.addEventListener("click",c.playerClick.bind(this));
this.$player.addEventListener("fullscreenchange",this.updateFullscreenButton.bind(this));
this.$player.addEventListener("mousemove",a.debounceExtend(this.mouseMove.bind(this),100))
}},{key:"initEventsHandlers",value:function j(){this.$video.addEventListener("timeupdate",c.updateTrayProgress.bind(this));
this.$video.addEventListener("ended",c.videoEnded.bind(this));
this.$video.addEventListener("loadedmetadata",this.loadMetadataCallback.bind(this));
this.$video.addEventListener("canplay",c.videoCanPlayEvent.bind(this));
this.$video.addEventListener("waiting",c.videoWaitEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_EVENT,c.handlePlayEvent.bind(this));
this.$video.addEventListener(e.events.PAUSE_EVENT,c.handlePauseEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_FROM_START,c.handlePlayFromStartEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_TILE_EVENT,c.handlePLayTileEvent.bind(this));
this.$video.addEventListener(e.events.NEW_LOAD_REQUEST,c.handleNewLoadEvent.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("click",c.progressBarClickHandler.bind(this));
this.$owl[0].addEventListener("click",this.sliderClickHandler.bind(this));
window.addEventListener("scroll",a.debounceExtend(this.videoBorderTracker.bind(this),100));
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler.bind(this),300));
this.initMouseMoveEvents()
}},{key:"initMouseMoveEvents",value:function z(){this.$videoProgressBarHiddenArea.addEventListener("mousedown",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("mouseup",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mouseleave",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mousemove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchmove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchstart",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("touchend",c.changeMouseState.bind(this,false))
}}]);
return A
}();
b.moduleName="Video Showcases";
b.selector=".video-showcase-ui";
return b
});
define("VideoShowcasesInitA11Y",["utils","VideoShowcasePlayerFunctions","VideoShowcaseA11y"],function(l,c,a){function b(m){if(this.$videoSliderItems.length>3){m(this);
this.$owl.trigger("to.owl.carousel",[this.currentSlide,0])
}}function k(){b.call(this,function(){if(this.$videoSliderItems.length-1>=this.currentSlideindex){this.currentSlideindex=0
}}.bind(this))
}function f(){b.call(this,function(){this.currentSlideindex--;
if(this.currentSlideindex<=0){this.currentSlideindex=this.$videoSliderItems.length-1
}}.bind(this))
}function d(n){var m=Number(n.querySelector(".video-showcase__img-wrapper").dataset.index);
if(this.activeVideoIndex===m){c.togglePlay.call(this);
return
}this.fixPlayerHeight();
this.videoSlideClick(m,n)
}function g(){$(this.$el).find(".owl-stage").addClass("a11y-navigation-panel");
a.init.call(this,{"list-item":"owl-item:not(.cloned)","move-forward-callback":k.bind(this),"move-downward-callback":f.bind(this),"enter-action":d.bind(this)})
}function h(){a.setSpecialAttribute.call(this)
}function i(){l.loadLottieFile({container:this.$waitForPlay,loop:true,autoplay:true,path:"/etc/designs/epam-com/json-animations/loading-balls.json"})
}function e(){this.delayAnimation=l.loadLottieFile({container:this.$delayPlayContainer,loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/delay-play.json"});
this.delayAnimation.addEventListener("complete",this.delayPlayHandler.bind(this))
}function j(){var n=this;
var m=this.$el.querySelector(".video-showcase__video-progress");
m.addEventListener("keydown",function(o){var p=o.keyCode;
if(p===32){c.togglePlay.call(n)
}})
}return{loadWaitAnimation:i,loadDelayPlayIconAnimation:e,initA11y:g,reInitA11yAttr:h,stopVideoBySpaceA11y:j}
});
define("VideoShowcasePlayerFunctions",["VideoShowcasesClasses"],function(g){function k(){if(this.$video.paused||this.$video.ended){this.$video.dispatchEvent(this.customPlayEvent)
}else{this.$video.dispatchEvent(this.customPauseEvent)
}}function r(){this.$video.play();
v.call(this);
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add");
n.call(this,g.OVERLAY_PAUSE_ACTIVE,g.OVERLAY_PLAY_ACTIVE)
}function N(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.promisePending=false;
O.$video.load();
O.tileState?O.$video.dispatchEvent(O.customPlayFromStartEvent):O.$video.dispatchEvent(O.customTilePlayEvent);
O.isFirstPlay=false
})
}}}function E(){this.activeTraySeek();
this.$video.play();
v.call(this);
y.call(this);
J.call(this,"play");
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add")
}function h(){this.fromStart=true;
this.$video.play()
}function i(O){O==="add"?this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.add("active"):this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.remove("active")
}function f(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.$video.pause();
O.promisePending=false;
J.call(O);
n.call(O,g.OVERLAY_PLAY_ACTIVE,g.OVERLAY_PAUSE_ACTIVE);
B(O.$playButton,"Play (k)","Pause (k)");
i.call(O,"remove")
})
}}}function n(P,Q){var O=this;
this.overlayTimerId&&clearTimeout(this.overlayTimerId);
this.$overlayIcons.classList.remove("hidden");
this.$player.classList.remove(P);
this.$player.classList.add(Q);
this.overlayTimerId=setTimeout(function(){O.$overlayIcons.classList.add("hidden")
},1000)
}function B(P,Q,O){var R=P.getAttribute("title");
var S=R===Q?O:Q;
P.setAttribute("title",S)
}function C(){sessionStorage.removeItem("track"+this.activeVideoIndex)
}function M(){this.$video.muted=!this.$video.muted;
if(this.$video.muted){this.$volume.setAttribute("data-volume",this.$volume.value);
this.$volume.value=0
}else{this.$volume.value=this.$volume.dataset.volume
}}function u(O){if(this.$video.muted){this.$video.muted=false
}this.$video.volume=this.$volume.value;
O.stopPropagation()
}function D(P){if(!isNaN(P)){var O=new Date(P*1000).toISOString().substr(11,8);
return{minutes:O.substr(3,2),seconds:O.substr(6,2)}
}}function p(){var O=D(Math.floor(this.$video.currentTime));
this.$timeElapsed.innerText=O.minutes+":"+O.seconds;
this.$timeElapsed.setAttribute("datetime",O.minutes+"m "+O.seconds+"s")
}function j(){if(this.videoDuration&&this.$videoProgressBarLen()){var P=F.call(this);
this.videoCurPosPercent=Math.round(P/this.videoDuration*100);
var O=this.$videoProgressBarLen()*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}}function a(){var O=this.$normalProgressbarLength*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}function G(){p.call(this);
j.call(this)
}function F(){return this.$video?Math.floor(this.$video.currentTime):null
}function d(){if(this.traySeek!==undefined){this.traySeek.value=F.call(this)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.value=F.call(this)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.value=F.call(this)
}}function I(){if(document.fullscreenElement){a.call(this);
document.exitFullscreen()
}else{if(document.webkitFullscreenElement){a.call(this);
document.webkitExitFullscreen()
}else{if(this.$player.requestFullscreen){this.$player.requestFullscreen()
}else{if(this.$player.webkitRequestFullscreen){this.$player.webkitRequestFullscreen()
}else{if(this.$player.mozRequestFullScreen){this.$player.mozRequestFullScreen()
}else{if(this.$player.msRequestFullscreen){this.$player.msRequestFullscreen()
}}}}}}}function L(){if(this.timerId){clearTimeout(this.timerId)
}}function K(){L.call(this);
this.$waitForPlay.classList.add("hidden")
}function l(){var O=this;
L.call(this);
this.timerId=setTimeout(function(){O.$waitForPlay.classList.remove("hidden")
},1000)
}function e(){this.$volumeIcons.forEach(function(O){O.classList.add("hidden")
});
this.$volumeButton.setAttribute("data-title","Mute (m)");
if(this.$video.muted||this.$video.volume===0){this.$volumeMute.classList.remove("hidden");
this.$volumeButton.setAttribute("data-title","Unmute (m)")
}else{if(this.$video.volume>0&&this.$video.volume<=0.5){this.$volumeLow.classList.remove("hidden")
}else{this.$volumeHigh.classList.remove("hidden")
}}this.$volume.setAttribute("aria-valuetext",this.$video.volume*100+"% volume")
}function o(){this.blackFrame.classList.remove("hidden");
this.fromStart=true;
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
C.call(this);
this.activeVideoIndex===this.$videoSliderItems.length-1?this.activeVideoIndex=0:this.activeVideoIndex+=1;
var P=this.$videoSliderItems[this.activeVideoIndex];
var O=P.querySelector("img").getAttribute("poster-source");
c.call(this,O);
this.changeActiveVideo(this.getVideoDataFromItem(P));
this.$video.load();
this.changeActiveTile(this.$videoSliderItems[this.activeVideoIndex],this.activeVideoIndex);
w.call(this);
this.$player.classList.add("delay-overlay");
this.$delayPlayContainer.classList.remove("hidden");
this.delayAnimation.goToAndPlay(0)
}function w(){this.$owl.trigger("next.owl.carousel");
this.activeTraySeek()
}function s(){if(this.$video.ended){return
}sessionStorage.setItem("track"+this.activeVideoIndex,this.$video.currentTime)
}function t(){var O=sessionStorage.getItem("track"+this.activeVideoIndex);
if(O){this.$video.currentTime=O
}}function v(){if(!this.isOverlayRemoved){this.$player.classList.remove("overlay");
this.$overlayIcons.classList.add("hidden");
this.isOverlayRemoved=true
}}function A(S){var T=S.target,Q=S.target.tagName;
var P=T.getAttribute("id");
var U=T;
var O=Q;
if($(U).hasClass("overlay")||O==="VIDEO"||P==="play"){k.call(this);
return
}if(P==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)");
return
}if(P==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)");
return
}if($(U).hasClass("delay-overlay")){y.call(this);
k.call(this);
return
}if(O==="use"){O="svg";
U=$(U).parent()[0]
}if(O==="svg"){var R=$(U).parent();
var V=R.attr("id");
if(V==="play"||V==="pause"||V==="overlay"||V==="play-overlay"){k.call(this)
}if(V==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)")
}if(V==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)")
}}}function J(O){O?this.$playButton.classList.add("play"):this.$playButton.classList.toggle("play")
}function y(){this.delayAnimation.stop();
this.$delayPlayContainer.classList.add("hidden");
this.$player.classList.remove("delay-overlay")
}function c(Q){var O=this;
var P=new Image();
P.onload=function(){O.blackFrame.classList.add("hidden");
O.$video.poster=Q
};
P.src=Q
}function x(P,R){var Q=R;
if(Q.touches){Q=Q.touches[0]
}var O=Math.round(Q.pageX-P.getBoundingClientRect().left);
var S=Math.round(Q.pageY-P.getBoundingClientRect().left);
return{x:O,y:S}
}function z(O){this.$videoProgressBarTrack.style.width=O+"px";
this.trackValue=O
}function q(){var P=Math.round(this.trackValue/this.$videoProgressBarLen()*100);
var O=this.videoDuration*P/100;
this.$video.currentTime=O
}function m(P){var Q=x(this.$videoProgressBar,P),O=Q.x;
z.call(this,O);
q.call(this)
}function b(Q){if(this.mousePressed){var P=x(this.$videoProgressBar,Q),O=P.x;
z.call(this,O);
q.call(this)
}}function H(O){this.mousePressed=O
}return{togglePlay:k,wipeVideoProgress:C,toggleMute:M,updateVolume:u,timeUpdate:G,updateTrayProgress:d,toggleFullScreen:I,formatTime:D,videoCanPlayEvent:K,videoWaitEvent:l,updateVolumeIcon:e,videoEnded:o,saveVideoProgress:s,applyVideoProgress:t,handlePlayEvent:r,handlePauseEvent:f,removeVideoOverlay:v,playerClick:A,handlePlayFromStartEvent:h,handlePLayTileEvent:E,removeDelayPlay:y,imageLoader:c,handleNewLoadEvent:N,progressBarClickHandler:m,mouseMoveEventHandler:b,changeMouseState:H}
});
define("ExperienceFragmentGDPRConsent",["constants"],function(m){var h="/conf/epam/settings/wcm/segments/",d=".content.html",k="first",f="gdprSegment";
var l=function l(o){_classCallCheck(this,l);
this.$el=o;
this.$form=o.closest("form");
if(window.ContextHub&&ContextHub.SegmentEngine){this.id=o.attr("id");
var p=o.data("mappings");
var n=o.data("defaultVariation");
if(p&&n){this.variants=j(p,n);
ContextHubJQ(b.bind(this));
return
}}c.apply(this)
};
function j(r,o){var n=[];
for(var p in r){if(Object.prototype.hasOwnProperty.call(r,p)){var q=Object.create(null);
q.title=p;
q.url=r[p]+d;
q.segments=[h+p.toLowerCase()];
q.segmentPath=h+p;
n.push(q)
}}n.push({title:"Default",url:o+d});
return n
}function b(){ContextHub.eventing.on(ContextHub.Constants.EVENT_TEASER_LOADED,i.bind(this));
ContextHub.SegmentEngine.PageInteraction.Teaser({locationId:this.id,variants:this.variants,strategy:k,trackingURL:null});
setTimeout(function(){c.apply(this)
}.bind(this),5000)
}function i(n,o){var q=this;
var p=this.id;
o.data.forEach(function(r){if(r.key===p){c.apply(q)
}});
a.call(this,f,e(n,o));
g.call(this)
}function g(){var n=this.$el.closest("form");
n.trigger(m.Events.initConsent)
}function c(){this.$el.removeClass("hidden")
}function e(p,q){try{var o=q.data[0].teaser;
var t=o.currentlyLoaded.url;
var n=o.details.variants;
var s=n.find(function(u){return t.startsWith(u.url)
});
return s.segmentPath
}catch(r){return""
}}function a(n,p){var o=this.$form.find("input[name="+n+"]");
if(o.length){o.first().val(p)
}}l.moduleName="Experience Fragment Give GDPR Consent";
l.selector=".epam-experience-fragment-ui";
return l
});
define("PageNavigation",["utils-dust","utils"],function(d,a){var b={MIN_AMOUNT_OF_ANCHOR:3,DESKTOP:"(max-width: 1440px)",HEADER_HEIGHT:68,ANIMATE_HEADER_HEIGHT:52};
var e={PAGE_ANCHOR:"page-anchor-ui",NAV_AREA_CLASS:"page-navigation__area",NAV_MENU:"page-navigation__menu",ACTIVE:"active",HEADER_CONTENT:"header-ui",BREADCRUMBS:"breadcrumbs-ui"};
var c=function(){function t(B){var C=this;
_classCallCheck(this,t);
this.$el=B[0];
this.$pageAnchors=document.querySelectorAll("."+e.PAGE_ANCHOR);
this.$header=document.querySelector("."+e.HEADER_CONTENT);
this.$breadcrumbs=document.querySelector("."+e.BREADCRUMBS);
this.scrollEventhandler=this.scrollEventhandler.bind(this);
document.body.onload=function(){C.init()
}
}_createClass(t,[{key:"init",value:function x(){if(this.checkRequiredCondition()){return
}this.createNavigationMenu();
this.initEventListener();
this.defineBreakPoint();
this.lastAnchorSectionCenter();
this.setNavigationMenuStartPosition();
this.scrollEventhandler();
this.resizeEventHandler();
window.addEventListener("scroll",this.scrollEventhandler);
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler.bind(this),300))
}},{key:"checkRequiredCondition",value:function q(){return this.$pageAnchors&&this.$pageAnchors.length>=b.MIN_AMOUNT_OF_ANCHOR?0:1
}},{key:"createNavigationMenu",value:function y(){var C=this.$pageAnchors.length-1;
var E={y:0};
var B=this.offset(this.$pageAnchors[this.$pageAnchors.length-1]);
var D=B.y-E.y;
d.append("navigation-area",{items:new Array(C)},$(document.body));
this.$navigationArea=document.querySelector("."+e.NAV_AREA_CLASS);
this.$topShift=E.y;
this.$navigationArea.setAttribute("style","top:"+E.y+"px; height: "+D+"px");
this.$navigationMenu=document.querySelector("."+e.NAV_MENU);
this.$navigationDots=this.$navigationMenu.querySelectorAll("li")
}},{key:"updateNavigationAreaPosition",value:function z(){var D={y:0};
var B=this.offset(this.$pageAnchors[this.$pageAnchors.length-1]);
var C=B.y-D.y;
this.$navigationArea.setAttribute("style","top: "+D.y+"px; height: "+C+"px")
}},{key:"initEventListener",value:function v(){var B=this;
[].slice.call(this.$navigationDots).forEach(function(D,C){D.addEventListener("click",B.navigationPointClickHandler.bind(B,B.$pageAnchors[C]))
})
}},{key:"offset",value:function m(B){var E=B.getBoundingClientRect(),D=this.getPageYOffset();
var C=E.top+D;
return{y:C}
}},{key:"getPageYOffset",value:function j(){return window.pageYOffset||document.documentElement.scrollTop
}},{key:"getElementHeight",value:function f(B){return B.offsetHeight
}},{key:"navigationPointClickHandler",value:function p(C){var D=this.offset(C).y;
var B=this.getElementHeight(this.$header);
this.scrollToSelector(D-B,C)
}},{key:"setNavigationMenuStartPosition",value:function k(){var C=this.getScreenHeight();
var B=this.getElementHeight(this.$navigationMenu);
this.$navigationMenuOffsetTop=Math.round(C/2-B/2);
this.$navigationMenu.setAttribute("style","top: "+this.$navigationMenuOffsetTop+"px")
}},{key:"scrollEventhandler",value:function o(){var B=Math.round(this.getPageYOffset())+this.$navigationMenuOffsetTop-this.$topShift+this.getElementHeight(this.$navigationMenu)/2;
if(B<=this.$centerOfLastSection){this.$navigationMenu.setAttribute("style","position: fixed; top: "+this.$navigationMenuOffsetTop+"px")
}else{var C=this.$centerOfLastSection-this.getElementHeight(this.$navigationMenu)/2;
this.$navigationMenu.setAttribute("style","position: absolute; top: "+C+"px")
}this.updateDots()
}},{key:"defineBreakPoint",value:function w(){var C=this;
var B=[].slice.call(this.$pageAnchors);
this.$breakPoints=[];
Array.prototype.forEach.call(B,function(D){C.$breakPoints.push(C.offset(D).y)
})
}},{key:"lastAnchorSectionCenter",value:function r(){var C=this.$pageAnchors.length;
var D=this.offset(this.$pageAnchors[C-1]).y;
var E=this.offset(this.$pageAnchors[C-2]).y;
var B=D-E;
this.$centerOfLastSection=Math.round(E+B/2-this.$topShift)
}},{key:"updateDots",value:function s(){var D=this.getScreenHeight()/2;
var B=Math.round(this.getPageYOffset()+D-this.$topShift);
for(var C=this.$breakPoints.length-2;
C>=0;
C--){if(B>this.$breakPoints[C]){this.removeActiveDot();
this.activateDot(this.$navigationDots[C]);
return
}}this.removeActiveDot();
this.activateDot(this.$navigationDots[0])
}},{key:"removeActiveDot",value:function A(){var B=this.$navigationArea.querySelector(".active");
if(B){B.classList.remove("active")
}}},{key:"activateDot",value:function l(B){B.classList.add(e.ACTIVE)
}},{key:"scrollToSelector",value:function i(C,B){$("html").animate({scrollTop:C},400,this.endAnimationAction.bind(this,B))
}},{key:"endAnimationAction",value:function h(C){var B=this.getElementHeight(this.$breadcrumbs);
var D=this.$breadcrumbs.classList.contains("breadcrumbs--hidden");
var F=this.getHeaderHeight();
if(D){B=0
}var H=Math.round(this.offset(this.$header).y+this.getElementHeight(this.$header)+B);
var E=Math.round(this.offset(C).y);
if(H!==E){var G=this.offset(C).y;
$("html, body").animate({scrollTop:G-F-B},200)
}}},{key:"resizeEventHandler",value:function g(){if(window.matchMedia(b.DESKTOP).matches){window.removeEventListener("scroll",this.scrollEventhandler);
return
}window.addEventListener("scroll",this.scrollEventhandler);
this.lastAnchorSectionCenter();
this.updateNavigationAreaPosition();
this.setNavigationMenuStartPosition();
this.scrollEventhandler()
}},{key:"getScreenHeight",value:function n(){return window.innerHeight
}},{key:"getHeaderHeight",value:function u(){var B=this.$header.classList.contains("header--animated");
var C=b.HEADER_HEIGHT;
if(B){C=b.ANIMATE_HEADER_HEIGHT
}return C
}}]);
return t
}();
c.moduleName="Page Navigation";
c.selector=".page-navigation-ui";
return c
});
define("Animation23",["utils"],function(a){var d={ANIMATION_IMAGE_CONTAINER:"animation__image-container"};
var c=100;
var b=function(){function h(l){_classCallCheck(this,h);
this.$el=l[0];
this.$imageContainer=this.$el.querySelector("."+d.ANIMATION_IMAGE_CONTAINER);
this.imageName=l.attr("data-image-name");
this.isActive=true;
this.isEditMode=l.is("[is-edit-mode]");
this.delayAnimation=this.loadAnimationPicture();
this.init();
this.initEvents()
}_createClass(h,[{key:"init",value:function j(){this.onScrollChange()
}},{key:"initEvents",value:function g(){window.addEventListener("scroll",a.debounce(this.onScrollChange.bind(this),300));
this.delayAnimation.addEventListener("data_ready",this.onAnimationLoaded.bind(this))
}},{key:"onScrollChange",value:function k(){if(this.isActive&&this.isOnScreen(c)){this.delayAnimation.play();
this.isActive=false
}}},{key:"isOnScreen",value:function f(n){var m=window.innerHeight*(n/100)+window.scrollY;
var o=window.scrollY+this.$imageContainer.getBoundingClientRect().top;
var l=o+this.$imageContainer.offsetHeight/2;
return l<=m
}},{key:"loadAnimationPicture",value:function e(){return bodymovin.loadAnimation({container:this.$imageContainer,renderer:"svg",loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/"+this.imageName+".json",rendererSettings:{className:"animation__svg",viewBoxOnly:true}})
}},{key:"onAnimationLoaded",value:function i(){if(this.isEditMode){this.delayAnimation.goToAndPlay(this.delayAnimation.totalFrames,true);
this.isActive=false
}}}]);
return h
}();
b.moduleName="Animation23";
b.selector=".animation-ui-23";
return b
});
define("CategoriesSwitcher23",["utils","utils-env"],function(b,d){var g={TILE:"categories-switcher__tile-title",LEFT_SECTION:"categories-switcher-left-part",ACTIVE:"active",ACTIVE_TILE:".categories-switcher__tile-title.active",ACTIVE_CONTENT:".categories-switcher__content-item.active",ACTIVE_CONTENT_MOB:".categories-switcher__content-item-mob.active",CONTENT_ITEM:"categories-switcher__content-item",CONTENT_ITEM_MOBILE:"categories-switcher__content-item-mob",HIDE:"hidden",RESPONSIVE_IMAGE:"responsive-image-ui",TITLES_SECTION:"categories-switcher-tiles-section"};
var f={RESPONSIVE_HEADER_HEIGHT:52,RESPONSIVE_TOP_INDENT:20};
var a={nextSlide:"cat.switcher.next",prevSlide:"cat.switcher.prev"};
var e=[];
var c=function(){function r(C){_classCallCheck(this,r);
this.$el=C;
this.$modernEl=C[0];
this.$tiles=$("."+g.TILE,this.$modernEl);
this.$items=$("."+g.CONTENT_ITEM,this.$modernEl);
this.$itemsMobile=$("."+g.CONTENT_ITEM_MOBILE,this.$modernEl);
this.$tilesSection=this.$modernEl.querySelector("."+g.TITLES_SECTION);
this.itemsLength=this.$items.length;
this.init();
e.push(this)
}_createClass(r,[{key:"init",value:function z(){if(d.isEditMode()){this.editModeEvents();
return
}this.resizeEventHandler(this);
this.initDefaultSwitcherView();
this.addEventHandler();
this.setTitleIndex();
this.initEvents()
}},{key:"setTitleIndex",value:function y(){$.each(this.$tiles,function(C,D){D.setAttribute("item-index",C)
})
}},{key:"nextSlide",value:function l(){var D=this.$items.index(this.getActiveSlide());
var C=D<this.itemsLength-1?D+1:0;
this.switchSlide(this.$items[C])
}},{key:"prevSlide",value:function i(){var D=this.$items.index(this.getActiveSlide());
var C=D>0?D-1:this.itemsLength-1;
this.switchSlide(this.$items[C])
}},{key:"switchSlide",value:function o(C){this.reset();
C.classList.remove(g.HIDE);
C.classList.add(g.ACTIVE);
this.renderResponsiveImg(C)
}},{key:"getActiveSlide",value:function u(){return this.$modernEl.querySelector(g.ACTIVE_CONTENT)
}},{key:"getActiveTitle",value:function t(){return this.$modernEl.querySelector(g.ACTIVE_TILE)
}},{key:"reset",value:function A(){for(var C=0;
C<this.$tiles.length;
C++){this.$tiles[C].classList.remove(g.ACTIVE)
}for(var E=0;
E<this.itemsLength;
E++){this.$items[E].classList.remove(g.ACTIVE);
this.$items[E].classList.add(g.HIDE)
}if(this.$itemsMobile.length>0){for(var D=0;
D<this.itemsLength;
D++){this.$itemsMobile[D].classList.remove(g.ACTIVE);
this.$itemsMobile[D].style.maxHeight=null
}}}},{key:"initDefaultSwitcherView",value:function n(){this.reset();
if(this.device==="desktop"){this.$tiles[0].classList.add(g.ACTIVE);
this.$tiles[0].setAttribute("tabindex",0);
this.$items[0].classList.add(g.ACTIVE);
this.$items[0].classList.remove(g.HIDE)
}}},{key:"addEventHandler",value:function h(){var D=this;
var C=Array.prototype.slice.call(this.$tiles);
C.forEach(function(E){E.addEventListener("click",function(F){D.tileClickHandler(F.currentTarget,D)
})
})
}},{key:"mobileClickHandler",value:function x(D,C){var F=this.$modernEl.querySelector(g.ACTIVE_TILE);
if(!!F&&!F.isEqualNode(D)){this.reset()
}var E=D.nextElementSibling;
D.classList.toggle(g.ACTIVE);
E.classList.toggle("active");
C.activeTile=D;
C.activeContent=E;
if(E.style.maxHeight){E.style.maxHeight=null
}else{E.style.maxHeight=E.scrollHeight+"px"
}}},{key:"moveContentToTop",value:function v(C){if(C.activeTile!==undefined&&C.activeTile.classList.contains(g.ACTIVE)){var D=document.body.getBoundingClientRect();
var E=C.activeContent.getBoundingClientRect();
$("html, body").animate({scrollTop:E.top-D.top-f.RESPONSIVE_HEADER_HEIGHT-f.RESPONSIVE_TOP_INDENT},500)
}}},{key:"desktopClickHandler",value:function m(D){this.reset();
var E=D.getAttribute("tile-id");
var C=this.$modernEl.querySelector('[content-id="'+E+'"]');
D.classList.add(g.ACTIVE);
C.classList.add(g.ACTIVE);
C.classList.remove(g.HIDE);
this.renderResponsiveImg(C)
}},{key:"renderResponsiveImg",value:function s(C){var D=C.querySelectorAll("."+g.RESPONSIVE_IMAGE);
if(D.length>0){$(window).trigger("resize")
}}},{key:"tileClickHandler",value:function q(D,C){if(this.device==="desktop"){this.desktopClickHandler(D,C)
}else{this.mobileClickHandler(D,C)
}}},{key:"resizeEventHandler",value:function k(){if(window.matchMedia("(min-width: 992px)").matches){this.device="desktop"
}else{this.device="mobile"
}}},{key:"getTitleItem",value:function j(C){if(C<0){return this.$tiles[this.itemsLength-1]
}if(C>this.itemsLength-1){return this.$tiles[0]
}return this.$tiles[C]
}},{key:"arrowClickHandler",value:function w(G){var E=this;
var C=function C(H,J){J.preventDefault();
E.$modernEl.querySelector('[tabindex="0"]').removeAttribute("tabindex");
var I=E.getTitleItem(H);
I.setAttribute("tabindex",0);
I.focus();
E.desktopClickHandler(I)
};
if(G.keyCode===36){C(0,G)
}if(G.keyCode===35){C(this.itemsLength-1,G)
}if(G.keyCode===38||G.keyCode===37){var D=this.getActiveTitle().getAttribute("item-index");
C(Number(D)-1,G)
}if(G.keyCode===40||G.keyCode===39){var F=this.getActiveTitle().getAttribute("item-index");
C(Number(F)+1,G)
}}},{key:"initEvents",value:function p(){var C=this;
window.addEventListener("resize",b.debounceExtend(function(){C.resizeEventHandler(C);
if(!C.currentDevice){C.currentDevice=C.device;
return
}if(C.currentDevice!==C.device){C.initDefaultSwitcherView();
C.currentDevice=C.device
}},300));
this.$modernEl.addEventListener("transitionend",b.debounceExtend(function(){C.moveContentToTop(C)
},100));
this.$tilesSection.addEventListener("keydown",this.arrowClickHandler.bind(this))
}},{key:"editModeEvents",value:function B(){var C=this;
this.switchSlide(this.$items[0]);
this.$el.on(a.prevSlide,function(){C.prevSlide()
});
this.$el.on(a.nextSlide,function(){C.nextSlide()
})
}}]);
return r
}();
c.moduleName="CategoriesSwitcher23";
c.activatedComponents=e;
c.events=a;
c.selector=".categories-switcher-ui-23";
return c
});
define("ColumnControl23",[],function(){var b={COLUMN_CONTROL_COLUMN:"colctrl__col",TEXT_UI:"text-ui-23"};
var a=function(){function l(p){var o=this;
_classCallCheck(this,l);
this.el=p[0];
var q=this.el.getAttribute("data-is-list");
q&&window.addEventListener("DOMContentLoaded",function(){o.items=o.getInteractiveItems();
o.items.length&&o.init()
})
}_createClass(l,[{key:"getInteractiveItems",value:function m(){var o=this;
return Array.from(this.el.querySelectorAll("."+b.COLUMN_CONTROL_COLUMN)).map(function(q){var p=q.querySelectorAll("img, ."+b.TEXT_UI);
if(p.length===0){return q
}if(p.length===1){return p[0]
}return o.getClosestCommonParent(Array.from(p))
})
}},{key:"getClosestCommonParent",value:function d(o){var p=o[0];
while(p.parentNode){p=p.parentNode;
if(o.every(function(q){return p.contains(q)
})){return p
}}}},{key:"init",value:function n(){var o;
if(!window.accessibility){window.accessibility={startIndexes:[],items:[],indexOfCurrentItem:-1};
this.addEventListenerForNavigationOnPage();
this.addEventListenerForNavigationInList();
this.addEventListenerOnTabPress()
}this.createRefresherForIndexOfCurrentItem();
window.accessibility.startIndexes.push(window.accessibility.items.length);
(o=window.accessibility.items).push.apply(o,_toConsumableArray(this.items))
}},{key:"addEventListenerForNavigationOnPage",value:function h(){var o=this;
window.addEventListener("keydown",function(p){if(p.key.toLowerCase()==="l"){!p.shiftKey?o.changeIndexOfCurrentItem(o.findNextStartIndex()):o.changeIndexOfCurrentItem(o.findPreviousStartIndex())
}})
}},{key:"findNextStartIndex",value:function j(){for(var o=0;
o<window.accessibility.startIndexes.length;
o++){if(window.accessibility.startIndexes[o]>window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"findPreviousStartIndex",value:function e(){for(var o=window.accessibility.startIndexes.length-1;
o>=0;
o--){if(window.accessibility.startIndexes[o]<window.accessibility.indexOfCurrentItem){return window.accessibility.startIndexes[o]
}}return -1
}},{key:"changeIndexOfCurrentItem",value:function f(o){if(o>=0&&o<=window.accessibility.items.length-1){window.accessibility.indexOfCurrentItem=o;
this.setFocusToCurrentItem()
}}},{key:"setFocusToCurrentItem",value:function k(){var q=window.accessibility.items[window.accessibility.indexOfCurrentItem];
var p=q.getAttribute("tabindex")&&q.getAttribute("tabindex")!=="-1";
if(!p){q.setAttribute("tabindex",0);
q.addEventListener("focusout",function o(){q.setAttribute("tabindex",-1);
q.removeEventListener("focusout",o)
})
}q.focus()
}},{key:"addEventListenerForNavigationInList",value:function i(){var o=this;
window.addEventListener("keydown",function(p){if(p.key==="ArrowRight"||!p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem+1)
}else{if(p.key==="ArrowLeft"||p.shiftKey&&p.key.toLowerCase()==="i"){o.changeIndexOfCurrentItem(window.accessibility.indexOfCurrentItem-1)
}}})
}},{key:"addEventListenerOnTabPress",value:function c(){window.addEventListener("keydown",function(o){if(o.key==="Tab"){setTimeout(function(){var p=window.accessibility.items.findIndex(function(q){return document.activeElement.compareDocumentPosition(q)!==Node.DOCUMENT_POSITION_PRECEDING
});
window.accessibility.indexOfCurrentItem=p===-1?window.accessibility.items.length-1:p
},0)
}})
}},{key:"createRefresherForIndexOfCurrentItem",value:function g(){this.items.forEach(function(o){o.addEventListener("focus",function(){window.accessibility.indexOfCurrentItem=window.accessibility.items.indexOf(o)
})
})
}}]);
return l
}();
a.moduleName="Column Control 23";
a.selector=".colctrl-ui-23";
return a
});
define("DetailPagesFilter23",["utils-dust","utils-env","constants","jquery-plugins"],function(f,e,d){var c={industries:".detail-pages-filter-23__select--industries",contentTypes:".detail-pages-filter-23__select--content-types",topics:".detail-pages-filter-23__select--topics",detailPagesMainList:".detail-pages-list--main",detailPagesSecondaryList:".detail-pages-list--secondary",detailPagesList:" .detail-pages-list-ui__holder",detailPagesListNotEmpty:"detail-pages-list__holder--not-empty",viewMore:".detail-pages-filter-23__view-more",viewMoreLink:".detail-pages-filter-23__view-more-button",lastRowItem:"detail-pages-list-23__item-last-row",message:".detail-pages-filter-23__error-message",topPanel:".detail-pages-filter-23",detailPagesLink:".detail-pages-list-23__link",filterContainer:".detail-pages-filter-23__filter-wrap",filterDropdownContainer:".detail-pages-filter-23__filter-list-wrap",filterSelected:"detail-pages-filter-23__filter_selected",filterPanelBtn:".detail-pages-filter-23__filter-panel-btn",filterExpanded:"detail-pages-filter-23__filter_expanded",filterListItem:".detail-pages-filter-23__filter-list-item",filterListItemActive:"detail-pages-filter-23__filter-list-item_active",filterSelectedCount:".detail-pages-filter-23__filter-list-selected-count",filterClearParametersBtn:".detail-pages-filter-23__filter-list-btn-clear",filterApplyBtn:".detail-pages-filter-23__filter-list-btn-apply",filterTags:".detail-pages-filter-23__filter-tags",filterTagsNotEmpty:"detail-pages-filter-23__filter-tags-not-empty",filterTagItem:".detail-pages-filter-23__filter-tag-item",filterTagItemClear:".detail-pages-filter-23__filter-tag-item_clear",filterClearTagsBtn:".detail-pages-filter-23__filter-tags-btn-clear",filterRemoveTagBtn:".detail-pages-filter-23__filter-tag-btn-remove"};
var b={URL:"/services/search/detail-pages.json",DEFAULT_URL:"/services/search/detail-pages.default.json",TEMPLATE:"detail-pages-list-23",DEFAULT_IMAGE:"/etc/designs/epam-com/images/detail-page/default-filter-image.jpg",ROW_LENGTH:3,LIMIT:9,TOPICS_COUNT:"component.detail-pages-filter.topics-count"};
var g={ajaxErrorMessage:"component.general.ajax-error-message",ajaxErrorTryAgain:"component.general.ajax-error-try-again",searchNoResults:"component.detail-pages-filter.search-no-results",searchEmptyResult:"component.general.search-empty-result-for-"};
function a(h){this.$el=h;
this.$detailPagesMainList=this.$el.find(c.detailPagesMainList+c.detailPagesList);
this.$detailPagesSecondaryList=this.$el.find(c.detailPagesSecondaryList+c.detailPagesList);
this.$viewMore=this.$el.find(c.viewMore);
this.$viewMoreLink=this.$viewMore.find(c.viewMoreLink);
this.$preloader=this.$el.find("."+d.Classes.preloader);
this.$message=this.$el.find(c.message);
this.$messageText=this.$message.find("p");
this.$topPanel=this.$el.find(c.topPanel);
this.contentReferenceLabelsView=this.$el.data("content-reference-labels-view");
this.viewType=this.$el.data("viewType");
this.$filterContainer=this.$el.find(c.filterContainer);
this.$filterPanelBtn=this.$el.find(c.filterPanelBtn);
this.$filterSelectedCount=this.$el.find(c.filterSelectedCount);
this.$filterClearParametersBtn=this.$el.find(c.filterClearParametersBtn);
this.$filterListItem=this.$el.find(c.filterListItem);
this.$filterApplyBtn=this.$el.find(c.filterApplyBtn);
this.$filterTags=this.$el.find(c.filterTags);
this.$filterTagItemClear=this.$el.find(c.filterTagItemClear);
this.$filterClearTagsBtn=this.$el.find(c.filterClearTagsBtn);
this.isAuthor=e.isAuthor();
this.paths=this.$el.data("paths")||"";
this.defaultParameters={paths:this.paths.split(","),limit:b.LIMIT,offset:0,viewType:this.viewType};
this.initViewType();
this.$viewMoreLink.on("click",this.loadMoreDetailPages.bind(this));
this.focusOnFirstLoadedItem.bind(this)
}a.prototype.initViewType=function(){this.$filterPanelBtn.on("click",this.toggleFilterList.bind(this));
this.$filterContainer.on("click",c.filterListItem,this.toggleFilterListItem.bind(this));
this.$filterContainer.on("click",c.filterRemoveTagBtn,this.removeFilterTag.bind(this));
this.$filterClearParametersBtn.on("click",this.clearAllFilterParameters.bind(this));
this.$filterClearTagsBtn.on("click",this.clearAllFilterTags.bind(this));
this.$filterApplyBtn.on("click",this.applyFilters.bind(this));
this.closeOnClickOutside();
window.addEventListener("load",function(){this.collectParametersAndLoad(true)
}.bind(this))
};
a.prototype.closeOnClickOutside=function(){var h=this;
document.addEventListener("click",function i(k){var j=$(k.target);
if(!j.closest(c.filterDropdownContainer).length&&$(c.filterContainer).hasClass(c.filterExpanded)&&!j.closest(c.filterPanelBtn).length){h.toggleFilterList()
}})
};
a.prototype.toggleFilterList=function(){this.$filterContainer.toggleClass(c.filterExpanded)
};
a.prototype.toggleFilterListItem=function(h){$(h.target).toggleClass(c.filterListItemActive);
this.updateFilterListView()
};
a.prototype.clearAllFilterParameters=function(){this.$filterListItem.removeClass(c.filterListItemActive);
this.updateFilterListView()
};
a.prototype.clearAllFilterTags=function(){this.removeFilterTags();
this.clearAllFilterParameters();
this.$filterTags.removeClass(c.filterTagsNotEmpty);
this.collectParametersAndLoad()
};
a.prototype.removeFilterTag=function(j){var h=$(j.target);
var i=$(j.target).closest("li");
var k=h.attr("data-filter-tag-id");
this.$el.find("[data-filter-id='"+k+"']").removeClass(c.filterListItemActive);
i.remove();
this.updateFilterListView();
this.updateFilterTagsView();
this.collectParametersAndLoad()
};
a.prototype.removeFilterTags=function(){this.$filterTagItemClear.nextAll().remove()
};
a.prototype.applyFilters=function(){var h=function h(j){var i=j.label,k=j.value;
return'\n        <li class="detail-pages-filter-23__filter-tag-item">\n            <div class="detail-pages-filter-23__filter-tag">\n                <span class="detail-pages-filter-23__filter-tag-label">'+i+'</span>\n                <button type="button" class="detail-pages-filter-23__filter-tag-btn-remove" data-filter-tag-id="'+k+'"></button>\n            </div>\n        </li>\n        '
};
this.removeFilterTags();
this.$filterTagItemClear.after(this.getSelectedFilterParametrs().map(h).join(""));
this.toggleFilterList();
this.updateFilterTagsView();
this.collectParametersAndLoad()
};
a.prototype.updateFilterListView=function(){var h=this.getSelectedFilterParametrs().length;
if(h){this.$filterContainer.addClass(c.filterSelected)
}else{this.$filterContainer.removeClass(c.filterSelected)
}this.$filterSelectedCount.text(h)
};
a.prototype.updateFilterTagsView=function(){if(this.$el.find("[data-filter-tag-id]").length){this.$filterTags.addClass(c.filterTagsNotEmpty)
}else{this.$filterTags.removeClass(c.filterTagsNotEmpty)
}};
a.prototype.getSelectedFilterParametrs=function(){return $("."+c.filterListItemActive).map(function(h,i){return{value:$(i).attr("data-filter-id"),label:$(i).text()}
}).get()
};
a.prototype.collectFilterParameters=function(){var h=this.viewType==="filter"?"industries":"topics";
return $.extend({},this.defaultParameters,_defineProperty({},h,this.getSelectedFilterParametrs().map(function(i){return i.value
})))
};
a.prototype.loadMoreDetailPages=function(i){var j=this.$detailPagesMainList.children().length,h=$.extend(this.collectFilterParameters(),{offset:j});
this.loadDetailPages(h);
i.preventDefault()
};
a.prototype.collectParametersAndLoad=function(i){var h=this.collectFilterParameters();
if(i){h.buildSchemaOrgMarkup=i
}return this.loadDetailPages(h)
};
a.prototype.loadDetailPages=function(h){return $.ajax({url:this.defaultLoad?b.DEFAULT_URL:b.URL,data:h,cache:false,beforeSend:this.toggleLoadingState.bind(this,true),success:this.loadDetailPagesAdapter.bind(this,h),complete:this.toggleLoadingState.bind(this,false),error:this.showErrorMessage.bind(this)})
};
a.prototype.loadDetailPagesAdapter=function(i,j){if(this.viewType!=="filter"){this.updateDetailPages(i,j);
return
}var h=j;
this.defaultLoad=!j.result.length;
if(this.secondLoad){h.defaultResult=j.result;
j.result=[];
this.secondLoad=false;
this.defaultLoad=false;
this.updateDetailPages(i,h);
return
}if(this.defaultLoad){this.collectParametersAndLoad();
this.secondLoad=true;
this.defaultLoad=false;
return
}this.updateDetailPages(i,h)
};
a.prototype.toggleLoadingState=function(h){this.$preloader.toggleClass(d.Classes.hidden,!h);
h&&this.$message.addClass(d.Classes.hidden)
};
a.prototype.updateDetailPages=function(t,n){var u=n.result,s=n.schemaOrgMarkup,j=n.defaultResult||[],q=n.total,l=t.limit,m=t.offset,i=!u.length,h=!j.length,r=i&&h,k=q>m+l,p=t.buildSchemaOrgMarkup,o=this.$el.data("viewType")==="careers-blog"?"query":"combination";
if(i||!m){this.$detailPagesMainList.empty();
this.$detailPagesSecondaryList.empty()
}!h&&this.updateErrorMessage([g.searchNoResults]);
r&&this.updateErrorMessage([g.searchEmptyResult+o]);
this.$message.toggleClass(d.Classes.hidden,h&&!r);
this.$viewMore.toggleClass(d.Classes.hidden,!k);
if(this.$topPanel.length){this.$detailPagesMainList.toggleClass(c.detailPagesListNotEmpty,!i)
}this.renderDetailPages(j,m,this.$detailPagesSecondaryList);
this.renderDetailPages(u,m,this.$detailPagesMainList);
p&&!!s&&this.addSchemaOrgMarkup(s)
};
a.prototype.renderDetailPages=function(h,k,j){var i={pages:h,lastRowIdx:this.calculateLastRowIndex(h.length),defaultImage:b.DEFAULT_IMAGE,isAuthor:this.isAuthor,contentReferenceLabelsView:this.contentReferenceLabelsView,viewType:this.viewType};
k&&j.children().removeClass(c.lastRowItem);
f.append(b.TEMPLATE,i,j);
this.toggleLoadingState(false);
this.focusOnFirstLoadedItem(k)
};
a.prototype.focusOnFirstLoadedItem=function(i){var h=this.$detailPagesMainList.children();
if(h.length>b.LIMIT){h.eq(i).find(c.detailPagesLink).focus()
}};
a.prototype.calculateLastRowIndex=function(h){var i=Math.ceil(h/b.ROW_LENGTH);
return(i-1)*b.ROW_LENGTH
};
a.prototype.addSchemaOrgMarkup=function(h){this.$el.prepend('<script type="application/ld+json">'+JSON.stringify(h)+"<\/script>")
};
a.prototype.showErrorMessage=function(){this.updateErrorMessage([g.ajaxErrorMessage,g.ajaxErrorTryAgain]);
this.$message.removeClass(d.Classes.hidden)
};
a.prototype.updateErrorMessage=function(h){var i=h.length>1?h.map(function(j){return CQ.I18n.getMessage(j)
}).join(" "):CQ.I18n.getMessage(h[0]);
this.$messageText.html(i)
};
a.moduleName="Detail Pages Filter 23";
a.selector=".detail-pages-filter-23-ui";
return a
});
define("InstagramFeed23",["utils"],function(a){var c={scrollContainer:"instagram-feed__scroll-container",blocksContainer:"instagram-feed__container"};
function b(d){this.$el=d;
this.$slider=$(d.find("."+c.scrollContainer)[0]);
this.$blocksContainer=$(d.find("."+c.blocksContainer)[0]);
a.setHorizontalScrolling(this.$slider,this.$blocksContainer)
}b.moduleName="Instagram Feed 23";
b.selector=".instagram-feed-ui-23";
return b
});
define("LeadershipViewer23",[],function(){function a(b){this.element=$(b[0]);
this.slider=$(this.element.find(".leadership-viewer-ui-23-scroll")[0]);
this.isHovered=false;
this.mouseSrollScaleFactor=2.5;
this.mouseSrollLimit=40;
this.wheelListener=this.wheelListener.bind(this);
this.isRendering=false;
this.renderSmooth=10;
this.scrollSpeed=10;
this.currentScrollPosition=0;
this.finalScrollPosition=0;
this.render=this.render.bind(this);
if(this.slider){this.initEvents()
}}a.prototype.isSliderScrolled=function(){var b=this.slider[0].scrollWidth-this.slider[0].clientWidth;
return Math.abs(this.slider.scrollLeft()-b)<0.5
};
a.prototype.isSliderOnStartPosition=function(){return this.slider.scrollLeft()===0
};
a.prototype.render=function(){this.isRendering=true;
var b=(this.finalScrollPosition-this.currentScrollPosition)/this.renderSmooth;
if(Math.abs(this.finalScrollPosition-this.currentScrollPosition)<0.5){this.currentScrollPosition=this.finalScrollPosition;
this.slider[0].scrollLeft=this.finalScrollPosition;
this.isRendering=false;
return
}this.currentScrollPosition+=b;
this.slider[0].scrollLeft=this.currentScrollPosition;
window.requestAnimationFrame(this.render)
};
a.prototype.wheelListener=function(d){if(this.isSliderScrolled()&&d.deltaY>0){return
}if(this.isSliderOnStartPosition()&&this.isHovered&&d.deltaY<0){return
}if(this.isHovered){d.preventDefault();
var e=0;
var b=Math.max.apply(Math,[Math.abs(d.deltaY),Math.abs(d.deltaX)]);
if(b===Math.abs(d.deltaY)){e=d.deltaY
}else{e=d.deltaX
}var c=Math.abs(e)>this.mouseSrollLimit?e/this.mouseSrollScaleFactor:e;
this.finalScrollPosition+=this.scrollSpeed*c;
this.finalScrollPosition=Math.max(0,Math.min(this.finalScrollPosition,this.slider[0].scrollWidth-this.slider[0].clientWidth));
if(!this.isRendering){window.requestAnimationFrame(this.render)
}}};
a.prototype.initEvents=function(){window.addEventListener("wheel",this.wheelListener,{passive:false});
window.addEventListener("load",this.detectOutOfBoundsText.bind(this));
this.element.mouseover(function(){this.isHovered=true
}.bind(this));
this.element.mouseout(function(){this.isHovered=false
}.bind(this))
};
a.prototype.detectOutOfBoundsText=function(){var b=$(this.slider.find(".leadership-viewer-ui-23-scroll__info-wrapper"));
b.each(function(d,c){var f=$(c).find(".leadership-viewer-ui-23-scroll__name-hidden");
var e=$(f.clone());
e.css("display","inline").css("position","absolute").css("left","0").css("top","-200%").css("z-index","-1");
e.text(f.text());
$("body").append(e);
if(e[0].clientWidth>c.clientWidth){f.addClass("transferred")
}})
};
a.selector=".leadership-viewer-ui-23";
a.moduleName="LeadershipViewer23";
return a
});
define("PaddingComponent23",["utils"],function(a){var d={DATA_DESKTOP_HEIGHT:"data-desktopHeight",DATA_RESPONSIVE_HEIGHT:"data-responsiveHeight",DATA_RESPONSIVE_BREAKPOINTS:"data-responsiveBreakpoints",TABLET:"tablet",MOBILE:"mobile"};
var c={mobile:"(max-width: 767px)",tablet:"(min-width: 768px) and (max-width: 991px)"};
var b=function(){function e(h){_classCallCheck(this,e);
this._el=h[0];
this.desktopHeight=this._el.getAttribute(d.DATA_DESKTOP_HEIGHT);
this.responsiveHeight=this._el.getAttribute(d.DATA_RESPONSIVE_HEIGHT)||this.desktopHeight;
this.breakPoint=this._el.getAttribute(d.DATA_RESPONSIVE_BREAKPOINTS);
this.isTabletBreakPoint=this.breakPoint===d.TABLET;
this.isMobileBreakPoint=this.breakPoint===d.MOBILE;
this.init()
}_createClass(e,[{key:"init",value:function g(){this.resizeEventHandler();
window.addEventListener("resize",a.debounce(this.resizeEventHandler.bind(this),300))
}},{key:"resizeEventHandler",value:function f(){var i=window.matchMedia(c.tablet).matches;
var h=window.matchMedia(c.mobile).matches;
if(this.isTabletBreakPoint&&(h||i)){this._el.style.height=this.responsiveHeight+"px"
}else{if(this.isMobileBreakPoint&&h){this._el.style.height=this.responsiveHeight+"px"
}else{this._el.style.height=this.desktopHeight+"px"
}}}}]);
return e
}();
b.moduleName="Padding Component 23";
b.selector=".padding-component-ui-23";
return b
});
define("RolloverBlocks23",[],function(){var b={BLOCK:"rollover-blocks__block",FOCUSED_BLOCK:"rollover-blocks__block--focused",BLOCK_CONTENT:"rollover-blocks__content",ROLLOVER_BLOCK:"rollover-blocks__description-rollover",LINK_A11Y:"rollover-blocks__link-holder--a11y",LINK_LEARN_MORE:"rollover-blocks__link",RTE_LINKS:"rollover-blocks__text a"};
var a=function(){function d(h){_classCallCheck(this,d);
this.el=h[0];
this.blocks=this.el.querySelectorAll("."+b.BLOCK);
this.addEventListenersToBlocks()
}_createClass(d,[{key:"addEventListenersToBlocks",value:function g(){var h=this;
this.blocks.forEach(function(o,m){var l=o.querySelector("."+b.BLOCK_CONTENT);
var k=o.querySelector("."+b.ROLLOVER_BLOCK);
var i=o.querySelector("."+b.LINK_LEARN_MORE);
var n=o.querySelectorAll("."+b.RTE_LINKS);
var j=[i].concat(_toConsumableArray(n));
if(m===0){h.showForAccessibility(l)
}h.hideForAccessibility.apply(h,_toConsumableArray(n));
h.addEventListenerToRolloverBlock(o,k,j);
o.addEventListener("touchend",function(p){if(p.cancelable&&p.target.className!==b.LINK_LEARN_MORE){o.classList.contains("active")?o.classList.remove("active"):o.classList.add("active");
h.blocks.forEach(function(q){if(q!==o&&q.classList.contains("active")){q.classList.remove("active")
}})
}})
})
}},{key:"addEventListenerToRolloverBlock",value:function c(k,i,h){var j=this;
i.addEventListener("focus",function(){setTimeout(function(){k.classList.add(b.FOCUSED_BLOCK);
j.showForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
},5)
});
i.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
j.hideForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
});
h.forEach(function(l){if(l){l.addEventListener("focus",function(){k.classList.add(b.FOCUSED_BLOCK);
j.showForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
});
l.addEventListener("blur",function(){k.classList.remove(b.FOCUSED_BLOCK);
j.hideForAccessibility.apply(j,[i].concat(_toConsumableArray(h)))
})
}})
}},{key:"showForAccessibility",value:function e(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",0);
k.removeAttribute("aria-hidden")
}})
}},{key:"hideForAccessibility",value:function f(){for(var i=arguments.length,h=Array(i),j=0;
j<i;
j++){h[j]=arguments[j]
}h.forEach(function(k){if(k){k.setAttribute("tabindex",-1);
k.setAttribute("aria-hidden",true)
}})
}}]);
return d
}();
a.selector=".rollover-blocks-ui-23";
a.moduleName="Rollover Blocks 23";
return a
});
define("ScrollingBlocks23",["utils"],function(a){var c={scrollContainer:"scrolling-blocks__scroll-container",blocksContainer:"scrolling-blocks__container"};
function b(d){this.$el=d;
this.$slider=$(d.find("."+c.scrollContainer)[0]);
this.$blocksContainer=$(d.find("."+c.blocksContainer)[0]);
a.setHorizontalScrolling(this.$slider,this.$blocksContainer)
}b.selector=".scrolling-blocks-ui-23";
b.moduleName="Scrolling Blocks 23";
return b
});
define("ScrollingInfographic23",["utils"],function(a){var c={item:".scroll-infographic-ui-23__item",title:".scroll-infographic-ui-23__item-title"};
var b=function(){function e(i){_classCallCheck(this,e);
this.$el=i[0];
this.$items=this.$el.querySelectorAll(c.item);
this.init()
}_createClass(e,[{key:"init",value:function g(){this.bindEvents();
this.setTitleHeight()
}},{key:"bindEvents",value:function h(){window.addEventListener("resize",a.debounce(this.setTitleHeight.bind(this),300))
}},{key:"setTitleHeight",value:function d(){var i=this.getMaxTitleHeight();
[].concat(_toConsumableArray(this.$items)).forEach(function(j){var k=j.querySelector(c.title);
if(k&&k.offsetHeight<i){k.style.height=i+"px"
}})
}},{key:"getMaxTitleHeight",value:function f(){return[].concat(_toConsumableArray(this.$items)).reduce(function(j,i){var k=i.querySelector(c.title);
return k?Math.max(j,k.offsetHeight):j
},0)
}}]);
return e
}();
b.selector=".scroll-infographic-ui-23";
b.moduleName="Scrolling Infographic 23";
return b
});
define("UpcomingEvent23",["utils-env","utils-browser"],function(b){var d=768;
var c={wrapper:".upcoming-event-ui-23",image:".upcoming-event-ui-23__image img",title:".upcoming-event-ui-23__title",arrow:".upcoming-event-ui-23__arrow-button",underlined:"underlined",animated:"animated"};
var a=function(){function g(l){_classCallCheck(this,g);
this.$wrapper=l[0];
this.$image=l.find(c.image)[0];
this.$title=l.find(c.title)[0];
this.$arrow=l.find(c.arrow)[0];
this.bindedAnimateIfInViewPort=this.animateIfInViewPort.bind(this);
this.init();
if(b.isEditMode()){this.$wrapper.classList.add(c.animated)
}}_createClass(g,[{key:"init",value:function k(){window.addEventListener("scroll",this.bindedAnimateIfInViewPort);
var l=this;
window.addEventListener("load",function(){l.animateIfInViewPort()
});
if(window.innerWidth>=d){this.handleImageHover();
this.handleTitleHover();
this.handleArrowHover()
}}},{key:"handleImageHover",value:function j(){var l=this;
this.$image.addEventListener("mouseover",function(){l.$title.classList.add(c.underlined)
});
this.$image.addEventListener("mouseout",function(){l.$title.classList.remove(c.underlined)
})
}},{key:"handleTitleHover",value:function f(){var l=this;
this.$title.addEventListener("mouseover",function(){l.$image.classList.add(c.animated)
});
this.$title.addEventListener("mouseout",function(){l.$image.classList.remove(c.animated)
})
}},{key:"handleArrowHover",value:function i(){var l=this;
this.$arrow.addEventListener("mouseover",function(){l.$image.classList.add(c.animated);
l.$title.classList.add(c.underlined)
});
this.$arrow.addEventListener("mouseout",function(){l.$image.classList.remove(c.animated);
l.$title.classList.remove(c.underlined)
})
}},{key:"animateIfInViewPort",value:function e(){if(!this.$wrapper){return
}var u=this.$wrapper.getBoundingClientRect().top;
var n=window.scrollY||document.documentElement.scrollTop;
var r=n+u;
var s=r+this.$wrapper.offsetHeight;
var p=n+window.innerHeight;
var t=n;
var l=this.$wrapper;
var o=l.offsetHeight;
var q=p-r;
var m=s-t;
if(q>=o/2||m<=o/2){this.animateBlock();
window.removeEventListener("scroll",this.bindedAnimateIfInViewPort)
}}},{key:"animateBlock",value:function h(){var l=this;
setTimeout(function(){l.$wrapper.classList.add(c.animated)
},150)
}}]);
return g
}();
a.moduleName="Upcoming-Event-23";
a.selector=".upcoming-event-ui-23";
return a
});
define("VideoShowcasesClasses",[],function(){return{PLAYER:"video-showcase__player-section",VIDEO:"video-showcase__video",VIDEO_TITLE:"video-showcase__title",VIDEO_TITLE_ACTIVE:"video-showcase__title--active",OVERLAY_ICONS:"video-showcase__overlay-icons",OVERLAY_PLAY_ACTIVE:"overlay-play-active",OVERLAY_PAUSE_ACTIVE:"overlay-pause-active",PROGRESS_BAR:"video-showcase__progress-bar",DURATION:"video-showcase__duration",TIME_ELAPSED:"video-showcase__time-elapsed",VOLUME_BUTTON:"video-showcase__volume-button",VOLUME_ICONS:"video-showcase__volume-button svg",VOLUME_HIGH:"volume-high",VOLUME_LOW:"volume-low",VOLUME_MUTE:"volume-mute",VOLUME:"video-showcase__volume",FULLSCREEN_BUTTON:"video-showcase__fullscreen-button",PLAY_BUTTON:"video-showcase__play-button",CONTROL_SECTION:"video-showcase__controls-section",SLIDER_IMG_WRAPPER:"video-showcase__img-wrapper",TRAY_SEEK:"video-showcase__tray-seek",DELAY_PLAY:"video-showcase__delay-play",WAIT_FOR_PLAY:"video-showcase__wait-for-play",OWL:"owl-carousel",NEXT_ICON:"video-showcase__nav-control-next",PREV_ICON:"video-showcase__nav-control-prev",BLACK_FRAME:"video-showcase__black-frame",VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS:"video-showcase__progress-bar-progress",VIDEO_SHOWCASE_PROGRESS_BAR_TRACK:"video-showcase__progress-bar-track",VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA:"video-showcase__progress-bar-hidden-area",events:{PLAY_EVENT:"customPlayEvent",PAUSE_EVENT:"customPauseEvent",PLAY_FROM_START:"customPlayFromStartEvent",PLAY_TILE_EVENT:"customTilePlayEvent",NEW_LOAD_REQUEST:"customNewLoadEvent"}}
});
define("VideoShowcases23",["utils-browser","utils","VideoShowcasePlayerFunctions","VideoShowcasesInitA11Y","VideoShowcasesClasses","utils-env"],function(d,a,c,f,e,h){var g=!!document.createElement("video").canPlayType;
var b=function(){function A(I){_classCallCheck(this,A);
this.$el=I[0];
this.isIE=d.isInternetExplorer();
this.$player=this.$el.querySelector("."+e.PLAYER);
this.$video=this.$el.querySelector("."+e.VIDEO);
this.$owl=$(this.$el.querySelector("."+e.OWL));
this.$isHideSlider=this.$el.dataset.hideCarousel;
this.$videoSliderItems=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
this.$videoTitleActive=this.$el.querySelector("."+e.VIDEO_TITLE_ACTIVE);
this.$progressBar=this.$el.querySelector("."+e.PROGRESS_BAR);
this.$controlSection=this.$el.querySelector("."+e.CONTROL_SECTION);
this.$duration=this.$el.querySelector("."+e.DURATION);
this.$timeElapsed=this.$el.querySelector("."+e.TIME_ELAPSED);
this.$overlayIcons=this.$el.querySelector("."+e.OVERLAY_ICONS);
this.$volumeButton=this.$el.querySelector("."+e.VOLUME_BUTTON);
this.$volumeIcons=this.$el.querySelectorAll("."+e.VOLUME_ICONS);
this.$volumeLow=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(2)");
this.$volumeHigh=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(3)");
this.$volumeMute=this.$el.querySelector(".video-showcase__volume-button svg:nth-child(1)");
this.$volume=this.$el.querySelector("."+e.VOLUME);
this.$fullscreenButton=this.$el.querySelector("."+e.FULLSCREEN_BUTTON);
this.$playButton=this.$el.querySelector("."+e.PLAY_BUTTON);
this.$delayPlayContainer=this.$el.querySelector("."+e.DELAY_PLAY);
this.$waitForPlay=this.$el.querySelector("."+e.WAIT_FOR_PLAY);
this.nextIcon=this.$el.querySelector("."+e.NEXT_ICON);
this.prevIcon=this.$el.querySelector("."+e.PREV_ICON);
this.blackFrame=this.$el.querySelector("."+e.BLACK_FRAME);
this.$videoProgressBar=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_PROGRESS);
this.$videoProgressBarTrack=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_TRACK);
this.$videoProgressBarHiddenArea=this.$el.querySelector("."+e.VIDEO_SHOWCASE_PROGRESS_BAR_HIDDEN_AREA);
this.isFirstPlay=true;
this.isOverlayRemoved=false;
this.activeVideoIndex=0;
this.userClick=false;
this.delayPlayRemoved=true;
this.activeIndex=[];
this.owlItems=[];
this.fromStart=false;
this.promisePending=false;
this.publishMode=!h.isEditMode();
this.customPlayEvent=document.createEvent("Event");
this.customPauseEvent=document.createEvent("Event");
this.customPlayFromStartEvent=document.createEvent("Event");
this.customTilePlayEvent=document.createEvent("Event");
this.customNewLoadRequestEvent=document.createEvent("Event");
this.customPlayEvent.initEvent(e.events.PLAY_EVENT,true,true);
this.customPauseEvent.initEvent(e.events.PAUSE_EVENT,true,true);
this.customPlayFromStartEvent.initEvent(e.events.PLAY_FROM_START,true,true);
this.customTilePlayEvent.initEvent(e.events.PLAY_TILE_EVENT,true,true);
this.customNewLoadRequestEvent.initEvent(e.events.NEW_LOAD_REQUEST,true,true);
this.init()
}_createClass(A,[{key:"init",value:function F(){this.setDefaultVideo();
this.initOwlCarousel();
if(this.publishMode){this.setDefaultVideo();
this.initEventsHandlers(this);
this.setVideoIndex();
this.initOwlCarousel();
f.loadDelayPlayIconAnimation.call(this);
this.activeTraySeek();
if(this.isIE||d.detectIOSDevice()){c.removeVideoOverlay.call(this)
}else{f.loadWaitAnimation.call(this);
this.isSupportPlayer();
this.customVideoEvents()
}}}},{key:"setVideoIndex",value:function s(){Array.prototype.forEach.call(this.$videoSliderItems,function(J,I){J.setAttribute("data-index",I)
})
}},{key:"initOwlCarousel",value:function r(){if(this.$isHideSlider==="1"){this.$el.querySelector(".video-showcase__slider-section").classList.add("hidden");
return
}var I=this.$videoSliderItems.length>3;
var J=this.$videoSliderItems.length>3?3:this.$videoSliderItems.length;
this.$owl.on("initialized.owl.carousel",function(){if(this.publishMode){f.initA11y.call(this);
f.stopVideoBySpaceA11y.call(this)
}this.$owl.on("refreshed.owl.carousel",function(){this.removeOwlAriaAttr();
f.reInitA11yAttr.call(this)
}.bind(this))
}.bind(this));
this.$owl.addClass("owl-item-count-"+J);
this.$owl.owlCarousel({nav:true,dots:false,items:J,responsive:false,mouseDrag:I,loop:I,navText:[this.prevIcon,this.nextIcon],navElement:"div"});
this.$owl[0].removeAttribute("style")
}},{key:"isSupportPlayer",value:function u(){if(g){this.$video.controls=false;
this.$controlSection.classList.remove("hidden");
c.updateVolumeIcon.call(this);
this.$normalProgressbarLength=this.$videoProgressBar.getBoundingClientRect().width;
this.$videoProgressBarLen=function(){return this.getBoundingClientRect().width
}.bind(this.$videoProgressBar)
}}},{key:"setDefaultVideo",value:function y(J){var I=J?J:this.$videoSliderItems[0];
if(I){this.changeActiveVideo(this.getVideoDataFromItem(I));
this.$video.load()
}}},{key:"delayPlayHandler",value:function q(){this.blackFrame.classList.add("hidden");
c.removeDelayPlay.call(this);
c.togglePlay.call(this)
}},{key:"sliderClickHandler",value:function x(I){var L=I.target;
var J=768;
if(this.isIE||L.tagName==="svg"||L.tagName==="use"||$(L).hasClass("video-showcase__img-wrapper-overlay")||$(L).hasClass("video-showcase__tray-text")||$(window).width()<J){var K=$(L).closest("."+e.SLIDER_IMG_WRAPPER);
if(K.length!==0){this.videoSlideClick(K.data().index,K[0])
}}}},{key:"videoSlideClick",value:function B(I,J){this.tileState=$(J).hasClass("active")||$(J).hasClass("pause");
!this.isFirstPlay&&c.saveVideoProgress.call(this);
this.activeVideoIndex=I;
this.activeItem=J;
this.fixPlayerHeight();
this.$video.classList.add("video-showcase__invincible");
this.changeActiveTile(J,I);
this.changeActiveVideo(this.getVideoDataFromItem(J));
this.$video.dispatchEvent(this.customNewLoadRequestEvent)
}},{key:"clearPlayerStyleProperties",value:function p(){this.$video.classList.remove("video-showcase__invincible");
this.$player.removeAttribute("style")
}},{key:"changeActiveTile",value:function k(L,I){var N=this.$el.querySelectorAll("."+e.SLIDER_IMG_WRAPPER);
for(var J=0;
J<N.length;
J++){N[J].classList.remove("active");
N[J].classList.remove("pause")
}var M=this.$el.querySelectorAll('[data-index="'+I+'"]');
for(var K=0;
K<M.length;
K++){M[K].classList.add("active")
}}},{key:"getVideoDataFromItem",value:function n(I){return I?{sources:I.querySelector("img").getAttribute("data-source"),poster:I.querySelector("img").getAttribute("poster-source"),title:I.dataset.title}:null
}},{key:"changeActiveVideo",value:function D(I){var K=this;
var J=I.sources,M=I.poster,L=I.title;
this.$video.innerHTML="";
if(this.isFirstPlay){this.$video.poster=M
}JSON.parse(J).forEach(function(N){var O=N.type,Q=N.src;
var P=document.createElement("source");
P.setAttribute("type",O);
P.setAttribute("src",Q);
K.$video.appendChild(P)
});
if(!L){this.$videoTitleActive.classList.add("hidden")
}else{this.$videoTitleActive.classList.remove("hidden");
if(this.$videoTitleActive){this.$videoTitleActive.textContent=L
}}}},{key:"initializeVideo",value:function C(){var I=this;
this.videoDuration=Math.floor(this.$video.duration);
var J=c.formatTime(this.videoDuration);
this.$duration.innerText=J.minutes+":"+J.seconds;
this.$duration.setAttribute("datetime",J.minutes+"m "+J.seconds+"s");
if(this.traySeek!==undefined){this.traySeek.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.setAttribute("max",this.videoDuration)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.setAttribute("max",this.videoDuration)
}if(!this.isFirstPlay&&!this.fromStart){c.applyVideoProgress.call(this)
}this.fromStart=false;
$.each(this.activeIndex,function(K,L){$(I.owlItems[L]).removeClass("hide-tray-seek")
})
}},{key:"loadMetadataCallback",value:function G(){this.initializeVideo();
this.clearPlayerStyleProperties()
}},{key:"updatePlayButton",value:function w(){this.$playButton.classList.toggle("play")
}},{key:"updateFullscreenButton",value:function v(){this.$fullscreenButton.classList.toggle("fullscreen")
}},{key:"videoBorderTracker",value:function t(){var I=this.$el.getBoundingClientRect().top;
var O=window.pageYOffset||document.documentElement.scrollTop;
var K=O+I;
var J=O+I+this.$video.offsetHeight;
var N=O;
var M=N+window.innerHeight;
var L=function(){if(!this.$video.paused){c.togglePlay.call(this)
}}.bind(this);
if(N>J){L();
return
}if(M<K){L();
return
}}},{key:"activeTraySeek",value:function m(){this.activeIndex=[];
this.owlItems=$(this.$el).find(".owl-item");
$.each(this.owlItems,function(I,K){var L=$(K).find("."+e.VIDEO_TITLE)[0];
if(L){K.dataset.title=L.textContent
}$(K).addClass("hide-tray-seek");
var J=$(K).find('[data-index="'+this.activeVideoIndex+'"]');
if(J.length!==0){this.activeIndex.push(I)
}}.bind(this));
if(this.owlItems[this.activeIndex[0]]!==undefined){this.traySeek=this.owlItems[this.activeIndex[0]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[1]]!==undefined){this.clonedTraySeekStart=this.owlItems[this.activeIndex[1]].querySelector("."+e.TRAY_SEEK)
}if(this.owlItems[this.activeIndex[2]]!==undefined){this.clonedTraySeekEnd=this.owlItems[this.activeIndex[2]].querySelector("."+e.TRAY_SEEK)
}}},{key:"mouseMove",value:function o(){this.$player.classList.add("mouse-move");
if(this.setTimeoutId!==undefined||this.setTimeoutId!==null){clearTimeout(this.setTimeoutId)
}this.setTimeoutId=setTimeout(function(){this.$player.classList.remove("mouse-move");
this.setTimeoutId=null
}.bind(this),15000)
}},{key:"fixPlayerHeight",value:function i(){var I=this.$player.getBoundingClientRect();
this.$player.setAttribute("style","height:"+I.height+"px")
}},{key:"resizeEventHandler",value:function l(){this.$owl.trigger("refresh.owl.carousel")
}},{key:"removeOwlAriaAttr",value:function H(){var J=this.$el.querySelectorAll('[role="tab"]');
for(var I=0;
I<J.length;
I++){J[I].removeAttribute("tabindex");
J[I].removeAttribute("aria-selected");
J[I].removeAttribute("role")
}}},{key:"customVideoEvents",value:function E(){this.$video.addEventListener("timeupdate",c.timeUpdate.bind(this));
this.$volume.addEventListener("input",c.updateVolume.bind(this));
this.$video.addEventListener("volumechange",c.updateVolumeIcon.bind(this));
this.$player.addEventListener("click",c.playerClick.bind(this));
this.$player.addEventListener("fullscreenchange",this.updateFullscreenButton.bind(this));
this.$player.addEventListener("mousemove",a.debounceExtend(this.mouseMove.bind(this),100))
}},{key:"initEventsHandlers",value:function j(){this.$video.addEventListener("timeupdate",c.updateTrayProgress.bind(this));
this.$video.addEventListener("ended",c.videoEnded.bind(this));
this.$video.addEventListener("loadedmetadata",this.loadMetadataCallback.bind(this));
this.$video.addEventListener("canplay",c.videoCanPlayEvent.bind(this));
this.$video.addEventListener("waiting",c.videoWaitEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_EVENT,c.handlePlayEvent.bind(this));
this.$video.addEventListener(e.events.PAUSE_EVENT,c.handlePauseEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_FROM_START,c.handlePlayFromStartEvent.bind(this));
this.$video.addEventListener(e.events.PLAY_TILE_EVENT,c.handlePLayTileEvent.bind(this));
this.$video.addEventListener(e.events.NEW_LOAD_REQUEST,c.handleNewLoadEvent.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("click",c.progressBarClickHandler.bind(this));
this.$owl[0].addEventListener("click",this.sliderClickHandler.bind(this));
window.addEventListener("scroll",a.debounceExtend(this.videoBorderTracker.bind(this),100));
window.addEventListener("resize",a.debounceExtend(this.resizeEventHandler.bind(this),300));
this.initMouseMoveEvents()
}},{key:"initMouseMoveEvents",value:function z(){this.$videoProgressBarHiddenArea.addEventListener("mousedown",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("mouseup",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mouseleave",c.changeMouseState.bind(this,false));
this.$videoProgressBarHiddenArea.addEventListener("mousemove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchmove",c.mouseMoveEventHandler.bind(this));
this.$videoProgressBarHiddenArea.addEventListener("touchstart",c.changeMouseState.bind(this,true));
this.$videoProgressBarHiddenArea.addEventListener("touchend",c.changeMouseState.bind(this,false))
}}]);
return A
}();
b.moduleName="Video Showcases 23";
b.selector=".video-showcase-ui-23";
return b
});
define("VideoShowcasesInitA11Y",["utils","VideoShowcasePlayerFunctions","VideoShowcaseA11y"],function(l,c,a){function b(m){if(this.$videoSliderItems.length>3){m(this);
this.$owl.trigger("to.owl.carousel",[this.currentSlide,0])
}}function k(){b.call(this,function(){if(this.$videoSliderItems.length-1>=this.currentSlideindex){this.currentSlideindex=0
}}.bind(this))
}function f(){b.call(this,function(){this.currentSlideindex--;
if(this.currentSlideindex<=0){this.currentSlideindex=this.$videoSliderItems.length-1
}}.bind(this))
}function d(n){var m=Number(n.querySelector(".video-showcase__img-wrapper").dataset.index);
if(this.activeVideoIndex===m){c.togglePlay.call(this);
return
}this.fixPlayerHeight();
this.videoSlideClick(m,n)
}function g(){$(this.$el).find(".owl-stage").addClass("a11y-navigation-panel");
a.init.call(this,{"list-item":"owl-item:not(.cloned)","move-forward-callback":k.bind(this),"move-downward-callback":f.bind(this),"enter-action":d.bind(this)})
}function h(){a.setSpecialAttribute.call(this)
}function i(){l.loadLottieFile({container:this.$waitForPlay,loop:true,autoplay:true,path:"/etc/designs/epam-com/json-animations/loading-balls.json"})
}function e(){this.delayAnimation=l.loadLottieFile({container:this.$delayPlayContainer,loop:false,autoplay:false,path:"/etc/designs/epam-com/json-animations/delay-play.json"});
this.delayAnimation.addEventListener("complete",this.delayPlayHandler.bind(this))
}function j(){var n=this;
var m=this.$el.querySelector(".video-showcase__video-progress");
m.addEventListener("keydown",function(o){var p=o.keyCode;
if(p===32){c.togglePlay.call(n)
}})
}return{loadWaitAnimation:i,loadDelayPlayIconAnimation:e,initA11y:g,reInitA11yAttr:h,stopVideoBySpaceA11y:j}
});
define("VideoShowcasePlayerFunctions",["VideoShowcasesClasses"],function(g){function k(){if(this.$video.paused||this.$video.ended){this.$video.dispatchEvent(this.customPlayEvent)
}else{this.$video.dispatchEvent(this.customPauseEvent)
}}function r(){this.$video.play();
v.call(this);
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add");
n.call(this,g.OVERLAY_PAUSE_ACTIVE,g.OVERLAY_PLAY_ACTIVE)
}function N(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.promisePending=false;
O.$video.load();
O.tileState?O.$video.dispatchEvent(O.customPlayFromStartEvent):O.$video.dispatchEvent(O.customTilePlayEvent);
O.isFirstPlay=false
})
}}}function E(){this.activeTraySeek();
this.$video.play();
v.call(this);
y.call(this);
J.call(this,"play");
B(this.$playButton,"Play (k)","Pause (k)");
i.call(this,"add")
}function h(){this.fromStart=true;
this.$video.play()
}function i(O){O==="add"?this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.add("active"):this.$el.querySelector('[data-index="'+this.activeVideoIndex+'"]').classList.remove("active")
}function f(){var O=this;
if(!this.promisePending){var P=this.$video.play();
this.promisePending=true;
if(P!==undefined){P.then(function(){O.$video.pause();
O.promisePending=false;
J.call(O);
n.call(O,g.OVERLAY_PLAY_ACTIVE,g.OVERLAY_PAUSE_ACTIVE);
B(O.$playButton,"Play (k)","Pause (k)");
i.call(O,"remove")
})
}}}function n(P,Q){var O=this;
this.overlayTimerId&&clearTimeout(this.overlayTimerId);
this.$overlayIcons.classList.remove("hidden");
this.$player.classList.remove(P);
this.$player.classList.add(Q);
this.overlayTimerId=setTimeout(function(){O.$overlayIcons.classList.add("hidden")
},1000)
}function B(P,Q,O){var R=P.getAttribute("title");
var S=R===Q?O:Q;
P.setAttribute("title",S)
}function C(){sessionStorage.removeItem("track"+this.activeVideoIndex)
}function M(){this.$video.muted=!this.$video.muted;
if(this.$video.muted){this.$volume.setAttribute("data-volume",this.$volume.value);
this.$volume.value=0
}else{this.$volume.value=this.$volume.dataset.volume
}}function u(O){if(this.$video.muted){this.$video.muted=false
}this.$video.volume=this.$volume.value;
O.stopPropagation()
}function D(P){if(!isNaN(P)){var O=new Date(P*1000).toISOString().substr(11,8);
return{minutes:O.substr(3,2),seconds:O.substr(6,2)}
}}function p(){var O=D(Math.floor(this.$video.currentTime));
this.$timeElapsed.innerText=O.minutes+":"+O.seconds;
this.$timeElapsed.setAttribute("datetime",O.minutes+"m "+O.seconds+"s")
}function j(){if(this.videoDuration&&this.$videoProgressBarLen()){var P=F.call(this);
this.videoCurPosPercent=Math.round(P/this.videoDuration*100);
var O=this.$videoProgressBarLen()*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}}function a(){var O=this.$normalProgressbarLength*this.videoCurPosPercent/100;
this.$videoProgressBarTrack.style.width=O+"px"
}function G(){p.call(this);
j.call(this)
}function F(){return this.$video?Math.floor(this.$video.currentTime):null
}function d(){if(this.traySeek!==undefined){this.traySeek.value=F.call(this)
}if(this.clonedTraySeekEnd!==undefined){this.clonedTraySeekEnd.value=F.call(this)
}if(this.clonedTraySeekStart!==undefined){this.clonedTraySeekStart.value=F.call(this)
}}function I(){if(document.fullscreenElement){a.call(this);
document.exitFullscreen()
}else{if(document.webkitFullscreenElement){a.call(this);
document.webkitExitFullscreen()
}else{if(this.$player.requestFullscreen){this.$player.requestFullscreen()
}else{if(this.$player.webkitRequestFullscreen){this.$player.webkitRequestFullscreen()
}else{if(this.$player.mozRequestFullScreen){this.$player.mozRequestFullScreen()
}else{if(this.$player.msRequestFullscreen){this.$player.msRequestFullscreen()
}}}}}}}function L(){if(this.timerId){clearTimeout(this.timerId)
}}function K(){L.call(this);
this.$waitForPlay.classList.add("hidden")
}function l(){var O=this;
L.call(this);
this.timerId=setTimeout(function(){O.$waitForPlay.classList.remove("hidden")
},1000)
}function e(){this.$volumeIcons.forEach(function(O){O.classList.add("hidden")
});
this.$volumeButton.setAttribute("data-title","Mute (m)");
if(this.$video.muted||this.$video.volume===0){this.$volumeMute.classList.remove("hidden");
this.$volumeButton.setAttribute("data-title","Unmute (m)")
}else{if(this.$video.volume>0&&this.$video.volume<=0.5){this.$volumeLow.classList.remove("hidden")
}else{this.$volumeHigh.classList.remove("hidden")
}}this.$volume.setAttribute("aria-valuetext",this.$video.volume*100+"% volume")
}function o(){this.blackFrame.classList.remove("hidden");
this.fromStart=true;
J.call(this);
B(this.$playButton,"Play (k)","Pause (k)");
C.call(this);
this.activeVideoIndex===this.$videoSliderItems.length-1?this.activeVideoIndex=0:this.activeVideoIndex+=1;
var P=this.$videoSliderItems[this.activeVideoIndex];
var O=P.querySelector("img").getAttribute("poster-source");
c.call(this,O);
this.changeActiveVideo(this.getVideoDataFromItem(P));
this.$video.load();
this.changeActiveTile(this.$videoSliderItems[this.activeVideoIndex],this.activeVideoIndex);
w.call(this);
this.$player.classList.add("delay-overlay");
this.$delayPlayContainer.classList.remove("hidden");
this.delayAnimation.goToAndPlay(0)
}function w(){this.$owl.trigger("next.owl.carousel");
this.activeTraySeek()
}function s(){if(this.$video.ended){return
}sessionStorage.setItem("track"+this.activeVideoIndex,this.$video.currentTime)
}function t(){var O=sessionStorage.getItem("track"+this.activeVideoIndex);
if(O){this.$video.currentTime=O
}}function v(){if(!this.isOverlayRemoved){this.$player.classList.remove("overlay");
this.$overlayIcons.classList.add("hidden");
this.isOverlayRemoved=true
}}function A(V){var S=V.target,Q=V.target.tagName;
var P=S.getAttribute("id");
var T=S;
var O=Q;
if($(T).hasClass("overlay")||O==="VIDEO"||P==="play"){k.call(this);
return
}if(P==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)");
return
}if(P==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)");
return
}if($(T).hasClass("delay-overlay")){y.call(this);
k.call(this);
return
}if(O==="use"){O="svg";
T=$(T).parent()[0]
}if(O==="svg"){var R=$(T).parent();
var U=R.attr("id");
if(U==="play"||U==="pause"||U==="overlay"||U==="play-overlay"){k.call(this)
}if(U==="fullscreen-button"){I.call(this);
B(this.$fullscreenButton,"Full screen (f)","Exit full screen (f)")
}if(U==="volume-button"){M.call(this);
B(this.$volumeButton,"Mute (m)","Unmute (m)")
}}}function J(O){O?this.$playButton.classList.add("play"):this.$playButton.classList.toggle("play")
}function y(){this.delayAnimation.stop();
this.$delayPlayContainer.classList.add("hidden");
this.$player.classList.remove("delay-overlay")
}function c(P){var Q=this;
var O=new Image();
O.onload=function(){Q.blackFrame.classList.add("hidden");
Q.$video.poster=P
};
O.src=P
}function x(P,R){var Q=R;
if(Q.touches){Q=Q.touches[0]
}var O=Math.round(Q.pageX-P.getBoundingClientRect().left);
var S=Math.round(Q.pageY-P.getBoundingClientRect().left);
return{x:O,y:S}
}function z(O){this.$videoProgressBarTrack.style.width=O+"px";
this.trackValue=O
}function q(){var P=Math.round(this.trackValue/this.$videoProgressBarLen()*100);
var O=this.videoDuration*P/100;
this.$video.currentTime=O
}function m(Q){var P=x(this.$videoProgressBar,Q),O=P.x;
z.call(this,O);
q.call(this)
}function b(Q){if(this.mousePressed){var P=x(this.$videoProgressBar,Q),O=P.x;
z.call(this,O);
q.call(this)
}}function H(O){this.mousePressed=O
}return{togglePlay:k,wipeVideoProgress:C,toggleMute:M,updateVolume:u,timeUpdate:G,updateTrayProgress:d,toggleFullScreen:I,formatTime:D,videoCanPlayEvent:K,videoWaitEvent:l,updateVolumeIcon:e,videoEnded:o,saveVideoProgress:s,applyVideoProgress:t,handlePlayEvent:r,handlePauseEvent:f,removeVideoOverlay:v,playerClick:A,handlePlayFromStartEvent:h,handlePLayTileEvent:E,removeDelayPlay:y,imageLoader:c,handleNewLoadEvent:N,progressBarClickHandler:m,mouseMoveEventHandler:b,changeMouseState:H}
});