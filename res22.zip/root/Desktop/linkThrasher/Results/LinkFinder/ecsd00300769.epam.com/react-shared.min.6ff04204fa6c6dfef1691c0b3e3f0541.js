define("SearchResults",["utils","utils-dust","utils-env","constants"],function(a,f,e,d){var g=$(window);
var c={form:".search-results__panel",container:".search-results__items",more:".search-results__view-more",exception:".search-results__exception-message",error:".search-results--error",emptyResult:".search-results--empty-result",counter:".search-results__counter",input:".search-results__input",titleLink:".search-results__title-link",autoCorrectMessage:".search-results__auto-correct-message",autoCorrectTotal:".search-results__auto-correct-total",autoCorrectTerm:".search-results__auto-correct-term"};
function b(h){this.$form=h.find(c.form);
this.$query=this.$form.find(c.input);
this.$container=h.find(c.container);
this.$counter=h.find(c.counter);
this.$preloader=h.find("."+d.Classes.preloader);
this.$viewMore=h.find(c.more);
this.$exceptionMessages=h.find(c.exception);
this.$autoCorrectMessage=h.find(c.autoCorrectMessage);
this.$autoCorrectTerm=this.$autoCorrectMessage.find(c.autoCorrectTerm);
this.$autoCorrectTotal=this.$autoCorrectMessage.find(c.autoCorrectTotal);
this.$errorMessage=this.$exceptionMessages.filter(c.error);
this.$emptyResultMessage=this.$exceptionMessages.filter(c.emptyResult);
this.isAuthor=e.isAuthor();
this.configPath=h.data("config-path");
this.$form.on("submit",this.submit.bind(this));
this.$viewMore.on("click",this.loadMoreResults.bind(this));
g.on("scroll",this.loadResultsOnScroll.bind(this));
g.on("popstate",this.refreshResult.bind(this));
this.init()
}b.prototype.refreshResult=function(){var i=this.getParameters().q;
var h=a.getQueryParameters(location.href.replace(location.hash,"")).q;
if(i!==h){this.cleanResult();
this.init()
}};
b.prototype.init=function(){this.updateForm();
this.loadResults(this.getParameters())
};
b.prototype.getParameters=function(h){return{q:this.$query.val().trim(),offset:h||0,config:this.configPath,bf:["events","news"]}
};
b.prototype.updateForm=function(){var h=window.location,i=a.getQueryParameters(h.href.replace(h.hash,"")).q||"";
this.$query.val(i)
};
b.prototype.loadResults=function(h){if(!h.q){this.$query.val("");
return
}$.ajax({url:this.config.searchUrl,data:h,beforeSend:this.toggleLoadingState.bind(this,true),complete:this.toggleLoadingState.bind(this,false),success:this.updateSearchResults.bind(this,h),error:this.showErrorMessage.bind(this)})
};
b.prototype.loadMoreResults=function(i){i&&i.preventDefault();
var j=this.$container.children().length,h=this.getParameters(j);
if(i){h.shouldFocusOnResult=true
}this.loadResults(h)
};
b.prototype.loadResultsOnScroll=function(){if(this.loading||!this.shouldLoadOnScroll){return
}var j=g.height(),i=g.scrollTop(),h=this.$container.children().last().offset().top;
if(j+i>h){this.loadMoreResults()
}};
b.prototype.toggleLoadingState=function(h){h&&this.$viewMore.addClass(d.Classes.hidden);
this.$preloader.toggleClass(d.Classes.hidden,!h);
this.loading=h
};
b.prototype.showErrorMessage=function(){this.$errorMessage.removeClass(d.Classes.hidden)
};
b.prototype.showAutoCorrectMessage=function(h){this.$autoCorrectMessage.removeClass(d.Classes.hidden);
this.$autoCorrectTotal.text(h.suggestedResultTotal);
this.$autoCorrectTerm.text(h.suggestedQuery);
this.$autoCorrectTerm.attr("href",this.getLink(h.suggestedQuery))
};
b.prototype.updateSearchResults=function(m,k){var l=k.total,j=k.result.length&&k.result||k.suggestedResult,i=m.offset===0,h=l>m.offset+this.config.limit;
this.shouldLoadOnScroll=i&&h;
i&&this.showResultMessage(m.q,l);
k.suggestedResultTotal&&this.showAutoCorrectMessage(k);
f.append("search-results",{items:j,isAuthor:this.isAuthor},this.$container);
this.$viewMore.toggleClass(d.Classes.hidden,i||!h);
m.shouldFocusOnResult&&this.$container.find(c.titleLink).eq(m.offset).focus()
};
b.prototype.showResultMessage=function(i,h){this.$counter.text(h?this.getResultMessage(i,h):"");
if(h){this.$counter.removeClass(d.Classes.hidden).focus();
return
}this.$emptyResultMessage.removeClass(d.Classes.hidden)
};
b.prototype.getResultMessage=function(j,i){var h=i===1?"component.search-results.found-single-result":"component.search-results.found-multiple-results";
return CQ.I18n.getMessage(h,[j,i])
};
b.prototype.submit=function(i){i.preventDefault();
this.cleanResult();
var h=this.getParameters();
this.updateUrl(h);
this.loadResults(h)
};
b.prototype.cleanResult=function(){this.$counter.addClass(d.Classes.hidden);
this.$container.empty();
this.$exceptionMessages.addClass(d.Classes.hidden);
this.$autoCorrectMessage.addClass(d.Classes.hidden);
this.$viewMore.addClass(d.Classes.hidden)
};
b.prototype.updateUrl=function(h){if(h.q!==a.getQueryParameters(window.location.href).q){window.history.pushState({},"",this.getLink(h.q))
}};
b.prototype.getLink=function(h){return window.location.pathname+"?q="+encodeURIComponent(h)
};
b.prototype.config={searchUrl:"/services/search/global",limit:10};
b.moduleName="Search Results";
b.selector=".search-results-ui";
return b
});
define("HeaderSearch",["Header","media","constants"],function(g,f,e){var b=$("html"),a=$("body").children("."+e.Classes.overlay).last();
var d={button:".header-search__button",panel:".header-search__panel",input:".header-search__input",submit:".header-search__submit",opened:"opened"};
function c(h){this.$el=h;
this.$button=this.$el.find(d.button);
this.$panel=this.$el.find(d.panel);
this.$input=this.$panel.find(d.input);
this.$submit=this.$panel.find(d.submit);
this.openPanel=this.openPanel.bind(this);
this.closePanel=this.closePanel.bind(this);
this.onShiftTabOnButton=this.onShiftTabOnButton.bind(this);
this.$button.one("click",this.triggerOpen);
this.$el.on("keyup",this.onEscPress.bind(this));
this.$submit.on("keydown",this.onTabOnSubmit.bind(this));
g.registerMenu({name:c.moduleName,hasOverlay:true,hasDisabledScroll:function(){return f.currentMode().lessThan(f.modes.Desktop)
},onOpen:this.openPanel,onClose:this.closePanel})
}c.prototype.onEscPress=function(h){if(h.key!==e.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
c.prototype.onTabOnSubmit=function(h){if(h.key!==e.Keys.tab||h.shiftKey){return
}h.preventDefault();
this.$button.focus()
};
c.prototype.onShiftTabOnButton=function(h){if(h.key!==e.Keys.tab||!h.shiftKey){return
}h.preventDefault();
this.$submit.focus()
};
c.prototype.triggerOpen=function(){b.trigger(e.Events.menuOpen,{opened:c.moduleName})
};
c.prototype.triggerClose=function(){b.trigger(e.Events.menuClose)
};
c.prototype.openPanel=function(){this.$panel.stop(true).slideDown().queue(function(){this.$input.focus();
this.$panel.addClass(d.opened)
}.bind(this));
this.$button.attr("aria-expanded",true).addClass(d.opened).one("click",this.triggerClose).on("keydown",this.onShiftTabOnButton);
a.one("click",this.triggerClose)
};
c.prototype.closePanel=function(){this.$input.blur();
this.$panel.removeClass(d.opened);
this.$panel.stop(true).slideUp();
a.off("click",this.triggerClose);
this.$button.attr("aria-expanded",false).removeClass(d.opened).off("click",this.triggerClose).one("click",this.triggerOpen).off("keydown",this.onShiftTabOnButton)
};
c.prototype.classes=d;
c.moduleName="Header Search";
c.selector=".header-search-ui";
return c
});
define("LocationSelector",["Header","utils-a11y","constants"],function(g,b,j){var d=$("html"),e=$("body"),h=e.children("."+j.Classes.overlay).last();
var c={button:".location-selector__button",locations:".location-selector__panel",link:".location-selector__link",opened:"opened"};
function a(){d.trigger(j.Events.menuOpen,{opened:i.moduleName})
}function f(){d.trigger(j.Events.menuClose)
}function i(k){this.$el=k;
this.$button=this.$el.find(c.button);
this.$locations=this.$el.find(c.locations);
this.$lastLink=this.$locations.find(c.link).last();
this.hideLocations=this.toggleLocations.bind(this,false);
this.showLocations=this.showLocations.bind(this);
this.$button.one("click",a);
this.$el.on("keyup",this.closeOnEsc.bind(this));
this.$lastLink.on("keydown",this.cycleForwardTabNavigation.bind(this));
g.registerMenu({name:i.moduleName,onOpen:this.showLocations,onClose:this.hideLocations,hasOverlay:true});
this.ariaLabelHidden=this.$button.attr("aria-label-hidden")
}i.prototype.closeOnEsc=function(k){if(k.key!==j.Keys.esc){return
}f();
this.$button.focus()
};
i.prototype.cycleForwardTabNavigation=function(k){if(k.key!==j.Keys.tab||k.shiftKey){return
}k.preventDefault();
this.$button.focus()
};
i.prototype.cycleBackwardTabNavigation=function(k){if(k.key!==j.Keys.tab||!k.shiftKey){return
}k.preventDefault();
this.$lastLink.focus()
};
i.prototype.showLocations=function(){this.toggleLocations(true);
this.$button.on("keydown",this.cycleBackwardTabNavigation.bind(this))
};
i.prototype.toggleLocations=function(k){this.$button.attr("aria-label",k?this.ariaLabelHidden:"");
this.$locations[k?"slideDown":"slideUp"]();
h[k?"one":"off"]("click",f);
this.$button.attr("aria-expanded",k).toggleClass(c.opened,k).off().one("click",k?f:a)
};
i.moduleName="Location Selector";
i.selector=".location-selector-ui";
return i
});
define("MobileLocationSelector",[],function(){var c=$(window);
var b={button:".mobile-location-selector__button",panel:".mobile-location-selector__panel"};
function a(d){this.$el=d;
this.$button=this.$el.find(b.button);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$button.one("click",this.openMenu)
}a.prototype.openMenu=function(){this.$el.addClass("opened");
this.$button.attr("aria-expanded",true).one("click",this.closeMenu);
c.on("click",this.closeMenu);
this.reApplyMenuButtonFocus();
return false
};
a.prototype.closeMenu=function(){this.$el.removeClass("opened");
this.$button.attr("aria-expanded",false).one("click",this.openMenu);
c.off("click",this.closeMenu);
this.reApplyMenuButtonFocus()
};
a.prototype.reApplyMenuButtonFocus=function(){this.$button.blur();
setTimeout(function(){this.$button.focus()
}.bind(this),100)
};
a.moduleName="Location Selector Mobile";
a.selector=".mobile-location-selector-ui";
return a
});
define("Header",["constants"],function(d){var b=$("html"),a=$("body").children("."+d.Classes.overlay).last(),e=10;
function c(f){this.$el=f;
this.$hamburgerMenu=this.$el.find(".hamburger-menu-ui");
$(window).on("scroll",this.shrinkMenu.bind(this));
b.on(d.Events.menuOpen,this.openMenu).on(d.Events.menuClose,this.closeMenu);
b.on("focusin",this.closeMenuWhenLooseFocus.bind(this))
}c.prototype.closeMenuWhenLooseFocus=function(f){if(!this.$hamburgerMenu.find(f.target).length){this.activeMenu="Hamburger Menu";
this.closeMenu()
}};
c.prototype.openMenu=function(i,h){if(!h){return
}var g=c.menus[h.opened];
this.activeMenu&&c.menus[this.activeMenu].onClose();
this.activeMenu=h.opened;
g.onOpen();
a.toggleClass(d.Classes.hidden,!g.hasOverlay);
var f=typeof g.hasDisabledScroll==="function"?g.hasDisabledScroll():!!g.hasDisabledScroll;
b.toggleClass(d.Classes.noscroll,f)
};
c.prototype.closeMenu=function(j,i){if(!this.activeMenu){return
}var h=c.menus[this.activeMenu],g=i&&i.couldBeIgnored&&h.ignoresWhenPossible,f=i&&i.closed&&this.activeMenu!==i.closed;
if(g||f){return
}h.onClose();
a.addClass(d.Classes.hidden);
b.removeClass(d.Classes.noscroll);
this.activeMenu=null
};
c.prototype.shrinkMenu=function(){var f=window.pageYOffset||document.documentElement.scrollTop;
this.$el.toggleClass(this.classes.shrink,f>=e);
$(document.body).toggleClass(this.classes.shrink,f>=e)
};
c.menus={};
c.registerMenu=function(f){c.menus[f.name]={onOpen:f.onOpen,onClose:f.onClose,hasOverlay:f.hasOverlay,hasDisabledScroll:f.hasDisabledScroll,ignoresWhenPossible:f.ignoresWhenPossible}
};
c.prototype.classes={shrink:"header--animated"};
c.moduleName="Header";
c.selector=".header-ui";
return c
});
define("HamburgerMenu",["Header","constants"],function(e,d){var a=$("html");
var c={button:".hamburger-menu__button",menu:".hamburger-menu__dropdown",accordeon:".item--collapsed",link:".hamburger-menu__link",expandedAccordeon:"item--expanded",menuExpanded:"hamburger-menu--expanded",child:"item--child",active:".active",expandChildButton:"hamburger-menu__sub-menu-toggle-button",clickableLink:"hamburger-menu__active-button",ctaButton:".cta-button-ui",openedArrowNode:'[aria-expanded="true"]',hamburgerMenuList:".hamburger-menu__list"};
function b(f){this.$el=f;
this.$button=this.$el.find(c.button);
this.$menu=this.$el.find(c.menu);
this.$hamburgerMenuList=this.$el.find(c.hamburgerMenuList);
this.$accordeon=this.$el.find(c.accordeon);
this.$link=this.$el.find(c.link);
var g=this.$el.find(c.ctaButton);
this.$lastLink=g.length&&g||this.$link.last();
this.$expandChildButton=f.find("."+c.expandChildButton);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$menu.on("keyup",this.keysPressHandler.bind(this));
this.$accordeon.on("click",this.onArrowClick.bind(this));
this.$link.on("click",function(h){h.stopPropagation()
});
this.$button.one("click",this.triggerOpen);
this.$expandChildButton.on("click",this.onRealArrowClick.bind(this));
this.$clickableLinks=f.find("."+c.clickableLink);
this.$clickableLinks.on("click",this.onClickableLinkHandler.bind(this));
e.registerMenu({name:b.moduleName,onOpen:this.openMenu,onClose:this.closeMenu,hasDisabledScroll:true,ignoresWhenPossible:true});
this.expandActiveDropdown()
}b.prototype.onEscPress=function(f){if(f.key!==d.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
b.prototype.triggerOpen=function(){a.trigger(d.Events.menuOpen,{opened:b.moduleName});
return false
};
b.prototype.triggerClose=function(){a.trigger(d.Events.menuClose,{closed:b.moduleName})
};
b.prototype.openMenu=function(){a.addClass(c.menuExpanded);
this.$menu.stop().slideDown();
this.$button.attr("aria-expanded",true).one("click",this.triggerClose)
};
b.prototype.closeMenu=function(){a.removeClass(c.menuExpanded);
this.$menu.stop().slideUp();
this.$button.attr("aria-expanded",false).off().one("click",this.triggerOpen)
};
b.prototype.onArrowClick=function(g){var f=$(g.target);
f.has("ul").length&&this.toggleDropdown(f,g);
return false
};
b.prototype.onRealArrowClick=function(g){var h=$(g.target);
var f=h.parent();
f.has("ul").length&&this.toggleDropdown(f,g)
};
b.prototype.closedOpenedHamburgerMenuItem=function(g){var f=this.$hamburgerMenuList.find(c.openedArrowNode);
if(f.length&&!g.is(f)){f.attr("aria-expanded","false")
}};
b.prototype.toggleAriaAttribute=function(f){f.attr("aria-expanded",function(g,h){return h==="false"
})
};
b.prototype.adjustAriaAttributes=function(f){if(f){var g=$(f.target);
this.closedOpenedHamburgerMenuItem(g);
this.toggleAriaAttribute(g)
}};
b.prototype.toggleDropdown=function(f,g){this.adjustAriaAttributes(g);
f.toggleClass(c.expandedAccordeon);
this.$accordeon.not(f).removeClass(c.expandedAccordeon)
};
b.prototype.expandActiveDropdown=function(){var f=this.$link.filter(c.active);
if(!f.parent().hasClass(c.child)){return
}this.toggleDropdown(f.parents(c.accordeon))
};
b.prototype.enterKeyPressHandler=function(g){var f=g.key;
var h=$(g.target);
if(f==="Enter"&&(h.hasClass(c.clickableLink)||h.hasClass(c.expandChildButton))){this.toggleDropdown(h.parent(),g)
}};
b.prototype.onClickableLinkHandler=function(f){var g=$(f.target);
this.toggleDropdown(g.parent(),f)
};
b.prototype.keysPressHandler=function(f){this.enterKeyPressHandler(f);
this.onEscPress(f)
};
b.prototype.classes=c;
b.moduleName="Hamburger Menu";
b.selector=".hamburger-menu-ui";
return b
});
define("TopNavigation",["constants"],function(d){var a=$("html");
var c={item:".top-navigation__item",dropdown:".top-navigation__flyout",openSubmenu:"js-opened",linkA11y:".top-navigation__item-link--a11y"};
function b(e){this.$el=e;
this.$items=this.$el.find(c.item);
this.$dropdowns=this.$el.find(c.dropdown);
this.$linkA11y=this.$el.find(c.linkA11y);
this.$itemsWithSubmenu=this.$items.filter(this.hasDropdown);
this.$lastSubLinks=$([]);
this.$dropdowns.each(function(g,f){this.$lastSubLinks=this.$lastSubLinks.add($(f).find("a").last())
}.bind(this));
this.$itemsWithSubmenu.on("mouseover",this.onItemHover.bind(this));
this.$itemsWithSubmenu.on("mouseleave",this.onItemLeave.bind(this));
this.$dropdowns.on("keydown",this.onEscOnItem.bind(this));
this.$linkA11y.on("click",this.openSubmenuA11y.bind(this));
this.$linkA11y.on("focus",this.closeAll.bind(this));
this.$lastSubLinks.on("keydown",this.closeAllWithoutShiftKey.bind(this));
$(document).on("click",this.closeAll.bind(this))
}b.prototype.closeAllWithoutShiftKey=function(e){if(e.shiftKey){return
}this.closeAll()
};
b.prototype.onItemHover=function(e){this.openSubmenu($(e.currentTarget))
};
b.prototype.onItemLeave=function(){this.closeAll()
};
b.prototype.openSubmenuA11y=function(e){e.stopPropagation();
var f=$(e.currentTarget).parents(c.item);
this.openSubmenu(f);
f.find("a").eq(1).focus()
};
b.prototype.onEscOnItem=function(e){if(e.key!==d.Keys.esc){return
}this.closeAll();
$(e.currentTarget).parent().find(c.linkA11y).focus()
};
b.prototype.openSubmenu=function(e){a.trigger(d.Events.menuClose,{couldBeIgnored:true});
e.addClass(c.openSubmenu)
};
b.prototype.closeAll=function(){this.$itemsWithSubmenu.removeClass(c.openSubmenu)
};
b.prototype.hasDropdown=function(){return $(this).children(c.dropdown).length>0
};
b.moduleName="Top Navigation";
b.selector=".top-navigation-ui";
return b
});
define("Breadcrumbs",["media","constants"],function(g,e){var f=5,b={shown:"shown",hidden:"hidden"},d={hidden:"breadcrumbs--hidden",lastBreadcrumbItemLink:".breadcrumbs__item:last > a"};
var h=$(window),a=$("html");
function c(i){this.$el=i;
this.lastScrollTop=0;
this.toggleBreadcrumbs=this.toggleBreadcrumbs.bind(this);
this.activateScroll();
this.addA11YAttributes();
a.on(e.Events.menuOpen,this.detach.bind(this)).on(e.Events.menuClose,this.activate.bind(this))
}c.prototype.addA11YAttributes=function(){var i=this.$el.find(d.lastBreadcrumbItemLink);
if(i.length){i.attr("aria-current","page")
}};
c.prototype.toggleBreadcrumbs=function(){var j=!g.currentMode().greaterThan(g.modes.Desktop),n=h.scrollTop(),m=Math.abs(this.lastScrollTop-n)<=f;
if(j||m){return
}var k=n>this.lastScrollTop&&n>=0,i=n+h.height()<$(document).height(),l=this.$el;
this.lastScrollTop=n;
if(k){l.addClass(d.hidden).on(e.Events.transitionEnd,function(){requestAnimationFrame(function(){l.addClass(e.Classes.hidden)
});
l.off(e.Events.transitionEnd)
});
return
}if(i){l.removeClass(e.Classes.hidden);
requestAnimationFrame(function(){l.removeClass(d.hidden).off(e.Events.transitionEnd)
})
}};
c.prototype.detach=function(){this.ignoreScroll();
this.previousState=this.$el.hasClass(this.classes.hidden)?b.hidden:b.shown;
this.$el.addClass(this.classes.hidden)
};
c.prototype.activate=function(k,j){var i=j&&j.couldBeIgnored;
if(!this.previousState||i){return
}this.activateScroll();
this.previousState===b.shown&&this.$el.removeClass(this.classes.hidden);
this.previousState=null
};
c.prototype.ignoreScroll=function(){h.off("scroll",this.toggleBreadcrumbs)
};
c.prototype.activateScroll=function(){h.on("scroll",this.toggleBreadcrumbs)
};
c.prototype.classes=d;
c.moduleName="Breadcrumbs";
c.selector=".breadcrumbs-ui";
return c
});
define("FrequentSearches",["constants"],function(c){var b={hidden:"frequent-searches--hidden",input:".frequent-searches__input",item:".frequent-searches__item",itemActive:"frequent-searches__item--active",footer:".footer-ui"};
var d=$(window);
function a(e){this.$el=e;
this.elHeight=e.height();
this.$input=e.siblings(b.input);
this.$items=e.find(b.item);
this.currentItemIndex=-1;
this.defaultPlaceholder=this.$input.attr("placeholder");
this.$footer=$(b.footer);
this.openEl=this.openEl.bind(this);
this.closeEl=this.closeEl.bind(this);
this.markActiveItem=this.markActiveItem.bind(this);
this.resetActiveItem=this.resetActiveItem.bind(this);
this.$input.attr("autocomplete","off");
this.initEvents();
this.updateHeight()
}a.prototype.initEvents=function(){this.$input.on("focus",this.openEl).on("keyup",this.openEl);
this.$items.on("click",this.onItemClick.bind(this));
d.on("resize",this.updateHeight.bind(this))
};
a.prototype.updateHeight=function(){var g=this.$footer.offset().top-20,e=this.$el.offset().top,f=e+this.elHeight;
this.$el.css("max-height",f>g?g-e:"none")
};
a.prototype.toggleEl=function(f){var e=this.$input.val().length;
if(f||e){this.resetActiveItem()
}this.$el.toggleClass(b.hidden,f||!!e);
this.updateElState(f);
if(this.$input.val().length){this.$input.removeAttr("aria-describedby")
}else{this.$input.attr("aria-describedby","search-label")
}};
a.prototype.openEl=function(){this.toggleEl(false);
d.on("click",this.closeEl)
};
a.prototype.closeEl=function(e){if(e&&this.$input.is(e.target)){return
}this.toggleEl(true);
d.off("click",this.closeEl)
};
a.prototype.updateElState=function(e){if(!e){this.$input.off("keydown");
this.$input.on("keydown",this.onKeyDown.bind(this));
this.updateHeight();
return
}this.clearElState()
};
a.prototype.clearElState=function(){this.$input.off("keydown");
this.currentItemIndex=-1;
this.$items.removeClass(b.itemActive);
this.resetActiveItem();
this.$input.attr("placeholder",this.defaultPlaceholder)
};
a.prototype.onItemClick=function(e){this.$input.val(e.target.innerText).focus();
this.closeEl()
};
a.prototype.resetActiveItem=function(){this.$input.removeAttr("aria-activedescendant");
this.$items.removeAttr("aria-selected id")
};
a.prototype.markActiveItem=function(e){var f="selected-option";
this.$input.attr("aria-activedescendant",f);
e.attr({"aria-selected":"true",id:f})
};
a.prototype.selectItem=function(e){this.activeItem=this.$items.eq(e);
this.$items.removeClass(b.itemActive);
this.activeItem.addClass(b.itemActive);
this.resetActiveItem();
this.markActiveItem(this.activeItem);
this.$input.attr("placeholder",this.activeItem[0].innerText);
this.currentItemIndex=e
};
a.prototype.selectPrev=function(){if(this.currentItemIndex<=0){this.selectItem(this.$items.length-1);
return
}this.selectItem(this.currentItemIndex-1)
};
a.prototype.selectNext=function(){if(this.currentItemIndex>=this.$items.length-1){this.selectItem(0);
return
}this.selectItem(this.currentItemIndex+1)
};
a.prototype.onKeyDown=function(e){switch(e.key){case c.Keys.arrowUp:this.selectPrev();
break;
case c.Keys.arrowDown:this.selectNext();
break;
case c.Keys.enter:this.$input.removeAttr("aria-describedby");
if(this.currentItemIndex>-1){e.preventDefault();
this.$input.val(this.$items.eq(this.currentItemIndex)[0].innerText);
this.clearElState()
}break;
case c.Keys.tab:this.closeEl();
break;
default:break
}};
a.prototype.classes=b;
a.moduleName="Frequent Searches";
a.selector=".frequent-searches-ui";
return a
});
define("Footer",["WeChatPopup","jquery-plugins"],function(b){function a(c){this.$el=c;
this.$linksContainer=this.$el.find("."+this.classes.linksContainer);
this.$weChatLink=this.$el.find("."+this.classes.link+'[data-type="wechat"]');
this.data={src:this.$el.data("wechatQrSrc"),id:this.$el.data("wechatId")};
$(window).on("resize",this.removeLinksDot.bind(this));
$.onFontLoad(this.removeLinksDot.bind(this));
this.$weChatLink.length&&this.initWeChatPopup()
}a.prototype.removeLinksDot=function(){var d=this.classes.pipe,c;
this.$linksContainer.each(function(){var e=$(this);
e.toggleClass(d,$.isOffsetEqual([c||e,e]));
c=e
})
};
a.prototype.initWeChatPopup=function(){this.$popup=new b();
this.$weChatLink.on("click",function(c){c.preventDefault();
this.$popup.open(this.data,this.$weChatLink)
}.bind(this))
};
a.prototype.classes={linksContainer:"footer__links-container",link:"footer__social-link",pipe:"item--piped"};
a.selector=".footer-ui";
a.moduleName="Footer";
return a
});
define("HeaderSearch23",["Header23","media","constants"],function(g,f,e){var b=$("html"),a=$("body").children("."+e.Classes.overlay).last();
var d={button:".header-search__button",panel:".header-search__panel",input:".header-search__input",submit:".header-search__submit",opened:"opened",frequentSearch:".frequent-searches-ui"};
function c(h){this.$el=h;
this.$button=this.$el.find(d.button);
this.$panel=this.$el.find(d.panel);
this.$input=this.$panel.find(d.input);
this.$submit=this.$panel.find(d.submit);
this.openPanel=this.openPanel.bind(this);
this.closePanel=this.closePanel.bind(this);
this.closeWhenClickedOutside=this.closeWhenClickedOutside.bind(this);
this.onShiftTabOnButton=this.onShiftTabOnButton.bind(this);
this.$button.one("click",this.triggerOpen);
this.$el.on("keyup",this.onEscPress.bind(this));
this.$submit.on("keydown",this.onTabOnSubmit.bind(this));
this.$el.on("click",this.onClickHandler.bind(this));
g.registerMenu({name:c.moduleName,hasOverlay:true,hasDisabledScroll:function(){return f.currentMode().lessThan(f.modes.Desktop)
},onOpen:this.openPanel,onClose:this.closePanel,closeWhenClickedOutside:this.closeWhenClickedOutside})
}c.prototype.onClickHandler=function(h){h.stopPropagation()
};
c.prototype.onEscPress=function(h){if(h.key!==e.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
c.prototype.onTabOnSubmit=function(h){if(h.key!==e.Keys.tab||h.shiftKey){return
}h.preventDefault();
this.$button.focus()
};
c.prototype.onShiftTabOnButton=function(h){if(h.key!==e.Keys.tab||!h.shiftKey){return
}h.preventDefault();
this.$submit.focus()
};
c.prototype.triggerOpen=function(){b.trigger(e.Events.menuOpen,{opened:c.moduleName})
};
c.prototype.triggerClose=function(){b.trigger(e.Events.menuClose)
};
c.prototype.openPanel=function(){this.$panel.stop(true).slideDown().queue(function(){this.$input.focus();
this.$panel.addClass(d.opened)
}.bind(this));
this.$button.attr("aria-expanded",true).addClass(d.opened).one("click",this.triggerClose).on("keydown",this.onShiftTabOnButton);
a.one("click",this.triggerClose)
};
c.prototype.closePanel=function(){this.$input.blur();
this.$panel.removeClass(d.opened);
this.$panel.stop(true).slideUp();
a.off("click",this.triggerClose);
this.$button.attr("aria-expanded",false).removeClass(d.opened).off("click",this.triggerClose).one("click",this.triggerOpen).off("keydown",this.onShiftTabOnButton)
};
c.prototype.closeWhenClickedOutside=function(){var h=this.$el.find(d.frequentSearch);
if(h.length===0){this.closePanel();
return
}if(h.length>0&&h.hasClass("frequent-searches--hidden")){this.closePanel()
}};
c.prototype.classes=d;
c.moduleName="Header Search 23";
c.selector=".header-search-ui-23";
return c
});
define("LocationSelector23",["Header23","utils-a11y","constants"],function(g,b,j){var d=$("html"),e=$("body"),h=e.children("."+j.Classes.overlay).last();
var c={button:".location-selector__button",locations:".location-selector__panel",link:".location-selector__link",opened:"opened"};
function a(){d.trigger(j.Events.menuOpen,{opened:i.moduleName})
}function f(){d.trigger(j.Events.menuClose)
}function i(k){this.$el=k;
this.$button=this.$el.find(c.button);
this.$locations=this.$el.find(c.locations);
this.$lastLink=this.$locations.find(c.link).last();
this.hideLocations=this.toggleLocations.bind(this,false);
this.showLocations=this.showLocations.bind(this);
this.$button.one("click",a);
this.$el.on("keyup",this.closeOnEsc.bind(this));
this.$lastLink.on("keydown",this.cycleForwardTabNavigation.bind(this));
g.registerMenu({name:i.moduleName,onOpen:this.showLocations,onClose:this.hideLocations,hasOverlay:true});
this.ariaLabelHidden=this.$button.attr("aria-label-hidden")
}i.prototype.closeOnEsc=function(k){if(k.key!==j.Keys.esc){return
}f();
this.$button.focus()
};
i.prototype.cycleForwardTabNavigation=function(k){if(k.key!==j.Keys.tab||k.shiftKey){return
}k.preventDefault();
this.$button.focus()
};
i.prototype.cycleBackwardTabNavigation=function(k){if(k.key!==j.Keys.tab||!k.shiftKey){return
}k.preventDefault();
this.$lastLink.focus()
};
i.prototype.showLocations=function(){this.toggleLocations(true);
this.$button.on("keydown",this.cycleBackwardTabNavigation.bind(this))
};
i.prototype.toggleLocations=function(k){this.$button.attr("aria-label",k?this.ariaLabelHidden:"");
this.$locations[k?"slideDown":"slideUp"]();
h[k?"one":"off"]("click",f);
this.$button.attr("aria-expanded",k).toggleClass(c.opened,k).off().one("click",k?f:a)
};
i.moduleName="Location Selector";
i.selector=".location-selector-ui-23";
return i
});
define("MobileLocationSelector23",[],function(){var c=$(window);
var b={button:".mobile-location-selector__button",panel:".mobile-location-selector__panel"};
function a(d){this.$el=d;
this.$button=this.$el.find(b.button);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$button.one("click",this.openMenu)
}a.prototype.openMenu=function(){this.$el.addClass("opened");
this.$button.attr("aria-expanded",true).one("click",this.closeMenu);
c.on("click",this.closeMenu);
this.reApplyMenuButtonFocus();
return false
};
a.prototype.closeMenu=function(){this.$el.removeClass("opened");
this.$button.attr("aria-expanded",false).one("click",this.openMenu);
c.off("click",this.closeMenu);
this.reApplyMenuButtonFocus()
};
a.prototype.reApplyMenuButtonFocus=function(){this.$button.blur();
setTimeout(function(){this.$button.focus()
}.bind(this),100)
};
a.moduleName="Location Selector Mobile";
a.selector=".mobile-location-selector-ui-23";
return a
});
define("Header23",["constants"],function(d){var b=$("html"),a=$("body").children("."+d.Classes.overlay).last(),e=10;
function c(f){this.$el=f;
this.$hamburgerMenu=this.$el.find(".hamburger-menu-ui-23");
$(window).on("scroll",this.shrinkMenu.bind(this));
b.on(d.Events.menuOpen,this.openMenu).on(d.Events.menuClose,this.closeMenu);
b.on("focusin",this.closeMenuWhenLooseFocus.bind(this));
$(document).on("click",this.bodyClickEventHandler.bind(this))
}c.prototype.closeMenuWhenLooseFocus=function(f){if(!this.$hamburgerMenu.find(f.target).length){this.activeMenu="Hamburger Menu 23";
this.closeMenu()
}};
c.prototype.bodyClickEventHandler=function(){var f=c.menus["Header Search 23"];
f.closeWhenClickedOutside()
};
c.prototype.openMenu=function(i,h){if(!h){return
}var g=c.menus[h.opened];
this.activeMenu&&c.menus[this.activeMenu].onClose();
this.activeMenu=h.opened;
g.onOpen();
a.toggleClass(d.Classes.hidden,!g.hasOverlay);
var f=typeof g.hasDisabledScroll==="function"?g.hasDisabledScroll():!!g.hasDisabledScroll;
b.toggleClass(d.Classes.noscroll,f)
};
c.prototype.closeMenu=function(j,i){if(!this.activeMenu){return
}var h=c.menus[this.activeMenu],g=i&&i.couldBeIgnored&&h.ignoresWhenPossible,f=i&&i.closed&&this.activeMenu!==i.closed;
if(g||f){return
}h.onClose();
a.addClass(d.Classes.hidden);
b.removeClass(d.Classes.noscroll);
this.activeMenu=null
};
c.prototype.shrinkMenu=function(){var f=window.pageYOffset||document.documentElement.scrollTop;
this.$el.toggleClass(this.classes.shrink,f>=e);
$(document.body).toggleClass(this.classes.shrink,f>=e)
};
c.menus={};
c.registerMenu=function(f){c.menus[f.name]={onOpen:f.onOpen,onClose:f.onClose,closeWhenClickedOutside:f.closeWhenClickedOutside,hasOverlay:f.hasOverlay,hasDisabledScroll:f.hasDisabledScroll,ignoresWhenPossible:f.ignoresWhenPossible}
};
c.prototype.classes={shrink:"header--animated"};
c.moduleName="Header23";
c.selector=".header-ui-23";
return c
});
define("HamburgerMenu23",["Header23","constants","media","utils"],function(h,f,g,c){var b=$("html");
var e={button:".hamburger-menu__button",menu:".hamburger-menu__dropdown",menuSection:".hamburger-menu__dropdown-section",accordeon:".item--collapsed",thirdLevelAccordion:"third-level-item--collapsed",link:".hamburger-menu__link",expandedAccordeon:"item--expanded",expandedThirdLevelAccordion:"third-level-item--expanded",menuExpanded:"hamburger-menu--expanded",child:"item--child",active:".active",expandChildButton:"hamburger-menu__sub-menu-toggle-button",clickableLink:"hamburger-menu__active-button",ctaButton:".cta-button-ui",openedArrowNode:'[aria-expanded="true"]',hamburgerMenuList:".hamburger-menu__list",thirdLevelSubMenuToggleButton:"hamburger-menu__third-level-sub-menu-toggle-button",thirdLevelItem:"hamburger-menu__third-level-item",firstLevelLink:"first-level-link",fixedSidePanelPosition:"fixed-position"};
var a={sidePanelFixPositionQuery:"(min-width: 1920px)"};
function d(i){this.$el=i;
this.$button=this.$el.find(e.button);
this.$menu=this.$el.find(e.menu);
this.$menuSection=this.$el.find(e.menuSection);
this.$hamburgerMenuList=this.$el.find(e.hamburgerMenuList);
this.$accordeon=this.$el.find(e.accordeon);
this.$thirdLevelAccordions=this.$el.find("."+e.thirdLevelAccordion);
this.$link=this.$el.find(e.link);
var j=this.$el.find(e.ctaButton);
this.$lastLink=j.length&&j||this.$link.last();
this.$expandChildButton=i.find("."+e.expandChildButton);
this.$expandThirdLevelChildButton=i.find("."+e.thirdLevelSubMenuToggleButton);
this.openMenu=this.openMenu.bind(this);
this.closeMenu=this.closeMenu.bind(this);
this.$menu.on("keyup",this.keysPressHandler.bind(this));
this.$link.on("click",function(k){k.stopPropagation()
});
this.$button.one("click",this.triggerOpen);
this.$accordeon.on("click",this.onArrowClick.bind(this));
this.$expandChildButton.on("click",this.onRealArrowClick.bind(this));
this.$expandThirdLevelChildButton.on("click",this.onRealArrowClick.bind(this));
this.$clickableLinks=i.find("."+e.clickableLink);
this.$clickableLinks.on("click",this.onClickableLinkHandler.bind(this));
h.registerMenu({name:d.moduleName,onOpen:this.openMenu,onClose:this.closeMenu,hasDisabledScroll:true,ignoresWhenPossible:true});
this.expandActiveDropdown();
this.init()
}d.prototype.init=function(){if(this.mediaQuery().isDesktop()){$(window).on("resize",c.debounce(this.resizeHandler.bind(this),200));
this.adjustSidePanelPositions()
}};
d.prototype.resizeHandler=function(){this.adjustSidePanelPositions()
};
d.prototype.adjustSidePanelPositions=function(){if(this.mediaQuery().fixedSidePanel()){this.$menuSection.addClass(e.fixedSidePanelPosition)
}else{this.$menuSection.removeClass(e.fixedSidePanelPosition)
}};
d.prototype.onEscPress=function(i){if(i.key!==f.Keys.esc){return
}this.triggerClose();
this.$button.focus()
};
d.prototype.triggerOpen=function(){b.trigger(f.Events.menuOpen,{opened:d.moduleName});
return false
};
d.prototype.triggerClose=function(){b.trigger(f.Events.menuClose,{closed:d.moduleName})
};
d.prototype.toggleMenu=function(i){if(i==="openMenu"){this.$menu.stop().slideDown()
}else{this.$menu.stop().slideUp()
}};
d.prototype.mediaQuery=function(){return{isDesktop:function(){return g.currentMode().greaterThan(g.modes.Tablet)
},fixedSidePanel:function(){return window.matchMedia(a.sidePanelFixPositionQuery).matches
}}
};
d.prototype.menuToggleProxy=function(j){var i=this.mediaQuery().isDesktop();
if(i){if(j==="openMenu"){b.toggleClass(f.Classes.noscroll);
this.$menu.css("display","flex")
}}else{b.removeClass(f.Classes.noscroll);
this.toggleMenu(j)
}};
d.prototype.openMenu=function(){b.addClass(e.menuExpanded);
this.menuToggleProxy("openMenu");
this.$button.attr("aria-expanded",true).one("click",this.triggerClose)
};
d.prototype.closeMenu=function(){b.removeClass(e.menuExpanded);
this.menuToggleProxy("closeMenu");
this.$button.attr("aria-expanded",false).off().one("click",this.triggerOpen)
};
d.prototype.onArrowClick=function(j){var i=$(j.target);
if(i.hasClass(e.thirdLevelAccordion)){i.has("ul").length&&this.toggleThirdLevelDropdown(i,j)
}else{i.has("ul").length&&this.toggleDropdown(i,j)
}return false
};
d.prototype.onRealArrowClick=function(j){var k=$(j.target);
var i=k.parent();
if(k.hasClass(e.thirdLevelSubMenuToggleButton)){i.has("ul").length&&this.toggleThirdLevelDropdown(i,j)
}else{i.has("ul").length&&this.toggleDropdown(i,j)
}};
d.prototype.closedOpenedHamburgerMenuItem=function(j){var i=this.$hamburgerMenuList.find(e.openedArrowNode);
if(i.length&&!j.is(i)){i.attr("aria-expanded","false")
}};
d.prototype.toggleAriaAttribute=function(i){i.attr("aria-expanded",function(j,k){return k==="false"
})
};
d.prototype.adjustAriaAttributes=function(i){if(i){var j=$(i.target);
this.closedOpenedHamburgerMenuItem(j);
this.toggleAriaAttribute(j)
}};
d.prototype.toggleDropdown=function(i,j){this.adjustAriaAttributes(j);
i.toggleClass(e.expandedAccordeon);
this.$accordeon.not(i).removeClass(e.expandedAccordeon)
};
d.prototype.toggleThirdLevelDropdown=function(i,j){this.adjustAriaAttributes(j);
i.toggleClass(e.expandedThirdLevelAccordion);
this.$thirdLevelAccordions.not(i).removeClass(e.expandedThirdLevelAccordion)
};
d.prototype.expandActiveDropdown=function(){var j=this.$link.filter(e.active);
var i=j.parent();
if(j.hasClass(e.firstLevelLink)){return
}if(i.hasClass(e.thirdLevelItem)){this.toggleThirdLevelDropdown(j.parents("."+e.thirdLevelAccordion))
}this.toggleDropdown(j.parents(e.accordeon))
};
d.prototype.enterKeyPressHandler=function(j){var i=j.key;
var k=$(j.target);
if(i==="Enter"&&(k.hasClass(e.clickableLink)||k.hasClass(e.expandChildButton))){this.toggleDropdown(k.parent(),j)
}};
d.prototype.onClickableLinkHandler=function(i){var j=$(i.target);
this.toggleDropdown(j.parent(),i)
};
d.prototype.keysPressHandler=function(i){this.enterKeyPressHandler(i);
this.onEscPress(i)
};
d.prototype.classes=e;
d.moduleName="Hamburger Menu 23";
d.selector=".hamburger-menu-ui-23";
return d
});
define("TopNavigation23",["constants"],function(d){var a=$("html");
var c={item:".top-navigation__item",dropdown:".top-navigation__flyout",openSubmenu:"js-opened",linkA11y:".top-navigation__item-link--a11y",flyout:".top-navigation__flyout-inner-section"};
function b(e){this.$el=e;
this.$items=this.$el.find(c.item);
this.$dropdowns=this.$el.find(c.dropdown);
this.$linkA11y=this.$el.find(c.linkA11y);
this.$flyout=this.$el.find(c.flyout);
this.$itemsWithSubmenu=this.$items.filter(this.hasDropdown);
this.$lastSubLinks=$([]);
this.$dropdowns.each(function(g,f){this.$lastSubLinks=this.$lastSubLinks.add($(f).find("a").last())
}.bind(this));
this.$itemsWithSubmenu.on("mouseover",this.onItemHover.bind(this));
this.$itemsWithSubmenu.on("mouseleave",this.onItemLeave.bind(this));
this.$flyout.on("mouseleave",this.subItemsMouseLeave.bind(this));
this.$dropdowns.on("keydown",this.onEscOnItem.bind(this));
this.$linkA11y.on("click",this.openSubmenuA11y.bind(this));
this.$linkA11y.on("focus",this.closeAll.bind(this));
this.$lastSubLinks.on("keydown",this.closeAllWithoutShiftKey.bind(this));
$(document).on("click",this.closeAll.bind(this))
}b.prototype.subItemsMouseLeave=function(g){var f=$(g.target).parents("."+c.openSubmenu);
if(f.length>0){setTimeout(function(){f.removeClass(c.openSubmenu)
},20)
}};
b.prototype.closeAllWithoutShiftKey=function(e){if(e.shiftKey){return
}this.closeAll()
};
b.prototype.onItemHover=function(e){this.openSubmenu($(e.currentTarget))
};
b.prototype.onItemLeave=function(){this.closeAll()
};
b.prototype.openSubmenuA11y=function(e){e.stopPropagation();
var f=$(e.currentTarget).parents(c.item);
this.openSubmenu(f);
f.find("a").eq(1).focus()
};
b.prototype.onEscOnItem=function(e){if(e.key!==d.Keys.esc){return
}this.closeAll();
$(e.currentTarget).parent().find(c.linkA11y).focus()
};
b.prototype.openSubmenu=function(e){a.trigger(d.Events.menuClose,{couldBeIgnored:true});
e.addClass(c.openSubmenu)
};
b.prototype.closeAll=function(){this.$itemsWithSubmenu.removeClass(c.openSubmenu)
};
b.prototype.hasDropdown=function(){return $(this).children(c.dropdown).length>0
};
b.moduleName="Top Navigation 23";
b.selector=".top-navigation-ui-23";
return b
});
define("Breadcrumbs",["media","constants"],function(g,e){var f=5,b={shown:"shown",hidden:"hidden"},d={hidden:"breadcrumbs--hidden",lastBreadcrumbItemLink:".breadcrumbs__item:last > a"};
var h=$(window),a=$("html");
function c(i){this.$el=i;
this.lastScrollTop=0;
this.toggleBreadcrumbs=this.toggleBreadcrumbs.bind(this);
this.activateScroll();
this.addA11YAttributes();
a.on(e.Events.menuOpen,this.detach.bind(this)).on(e.Events.menuClose,this.activate.bind(this))
}c.prototype.addA11YAttributes=function(){var i=this.$el.find(d.lastBreadcrumbItemLink);
if(i.length){i.attr("aria-current","page")
}};
c.prototype.toggleBreadcrumbs=function(){var j=!g.currentMode().greaterThan(g.modes.Desktop),n=h.scrollTop(),m=Math.abs(this.lastScrollTop-n)<=f;
if(j||m){return
}var k=n>this.lastScrollTop&&n>=0,i=n+h.height()<$(document).height(),l=this.$el;
this.lastScrollTop=n;
if(k){l.addClass(d.hidden).on(e.Events.transitionEnd,function(){requestAnimationFrame(function(){l.addClass(e.Classes.hidden)
});
l.off(e.Events.transitionEnd)
});
return
}if(i){l.removeClass(e.Classes.hidden);
requestAnimationFrame(function(){l.removeClass(d.hidden).off(e.Events.transitionEnd)
})
}};
c.prototype.detach=function(){this.ignoreScroll();
this.previousState=this.$el.hasClass(this.classes.hidden)?b.hidden:b.shown;
this.$el.addClass(this.classes.hidden)
};
c.prototype.activate=function(k,j){var i=j&&j.couldBeIgnored;
if(!this.previousState||i){return
}this.activateScroll();
this.previousState===b.shown&&this.$el.removeClass(this.classes.hidden);
this.previousState=null
};
c.prototype.ignoreScroll=function(){h.off("scroll",this.toggleBreadcrumbs)
};
c.prototype.activateScroll=function(){h.on("scroll",this.toggleBreadcrumbs)
};
c.prototype.classes=d;
c.moduleName="Breadcrumbs";
c.selector=".breadcrumbs-ui";
return c
});
define("FrequentSearches23",["constants"],function(c){var b={frequentSearches:".frequent-searches-ui-23",hidden:"frequent-searches-23--hidden",input:".frequent-searches__input",headerSearchInput:".header-search__input",headerSearchField:".header-search__field",searchInput:".search__input",searchResultsInput:".search-results__input",item:".frequent-searches__item",itemActive:"frequent-searches__item--active",footer:".footer-ui-23"};
var d=$(window);
function a(e){this.$el=e;
this.elHeight=e.height();
this.$input=$(document).find(b.input);
this.$headerSearchField=$(document).find(b.headerSearchField);
this.$headerSearchInput=$(document).find(b.headerSearchInput);
this.$searchResultsInput=$(document).find(b.searchResultsInput);
this.$searchInput=$(document).find(b.searchInput);
this.$items=e.find(b.item);
this.currentItemIndex=-1;
this.defaultPlaceholder=this.$input.attr("placeholder");
this.$footer=$(b.footer);
this.openEl=this.openEl.bind(this);
this.closeEl=this.closeEl.bind(this);
this.markActiveItem=this.markActiveItem.bind(this);
this.resetActiveItem=this.resetActiveItem.bind(this);
this.$input.attr("autocomplete","off");
this.initEvents();
this.updateHeight()
}a.prototype.initEvents=function(){this.$input.on("focus",this.openEl).on("keyup",this.openEl);
this.$items.on("click",this.onItemClick.bind(this));
d.on("resize",this.updateHeight.bind(this))
};
a.prototype.updateHeight=function(){var g=this.$footer.offset().top-20,e=this.$el.offset().top,f=e+this.elHeight;
this.$el.css("max-height",f>g?g-e:"none")
};
a.prototype.toggleEl=function(e){if($(".header-search__button").hasClass("opened")){if(e||!!this.$headerSearchInput.val().length){this.resetActiveItem()
}this.$headerSearchField.children(b.frequentSearches).toggleClass(b.hidden,e||!!this.$headerSearchInput.val().length);
return
}if(this.$searchInput.length!==0){if(e||!!this.$searchInput.val().length){this.resetActiveItem()
}this.$el.toggleClass(b.hidden,e||!!this.$searchInput.val().length);
return
}if(this.$searchResultsInput.length!==0){if(e||!!this.$searchResultsInput.val().length){this.resetActiveItem()
}this.$el.toggleClass(b.hidden,e||!!this.$searchResultsInput.val().length);
return
}this.updateElState(e);
if(this.$input.val().length){this.$input.removeAttr("aria-describedby")
}else{this.$input.attr("aria-describedby","search-label")
}};
a.prototype.openEl=function(){this.toggleEl(false);
d.on("click",this.closeEl)
};
a.prototype.closeEl=function(e){if(e&&this.$input.is(e.target)){return
}this.toggleEl(true);
d.off("click",this.closeEl)
};
a.prototype.updateElState=function(e){if(!e){this.$input.off("keydown");
this.$input.on("keydown",this.onKeyDown.bind(this));
this.updateHeight();
return
}this.clearElState()
};
a.prototype.clearElState=function(){this.$input.off("keydown");
this.currentItemIndex=-1;
this.$items.removeClass(b.itemActive);
this.resetActiveItem();
this.$input.attr("placeholder",this.defaultPlaceholder)
};
a.prototype.onItemClick=function(e){this.$input.val(e.target.innerText).focus();
this.closeEl()
};
a.prototype.resetActiveItem=function(){this.$input.removeAttr("aria-activedescendant");
this.$items.removeAttr("aria-selected id")
};
a.prototype.markActiveItem=function(e){var f="selected-option";
this.$input.attr("aria-activedescendant",f);
e.attr({"aria-selected":"true",id:f})
};
a.prototype.selectItem=function(e){this.activeItem=this.$items.eq(e);
this.$items.removeClass(b.itemActive);
this.activeItem.addClass(b.itemActive);
this.resetActiveItem();
this.markActiveItem(this.activeItem);
this.$input.attr("placeholder",this.activeItem[0].innerText);
this.currentItemIndex=e
};
a.prototype.selectPrev=function(){if(this.currentItemIndex<=0){this.selectItem(this.$items.length-1);
return
}this.selectItem(this.currentItemIndex-1)
};
a.prototype.selectNext=function(){if(this.currentItemIndex>=this.$items.length-1){this.selectItem(0);
return
}this.selectItem(this.currentItemIndex+1)
};
a.prototype.onKeyDown=function(e){switch(e.key){case c.Keys.arrowUp:this.selectPrev();
break;
case c.Keys.arrowDown:this.selectNext();
break;
case c.Keys.enter:this.$input.removeAttr("aria-describedby");
if(this.currentItemIndex>-1){e.preventDefault();
this.$input.val(this.$items.eq(this.currentItemIndex)[0].innerText);
this.clearElState()
}break;
case c.Keys.tab:this.closeEl();
break;
default:break
}};
a.prototype.classes=b;
a.moduleName="Frequent Searches 23";
a.selector=".frequent-searches-ui-23";
return a
});
define("Footer23",["WeChatPopup","jquery-plugins"],function(b){function a(c){this.$el=c;
this.$linksContainer=this.$el.find("."+this.classes.linksContainer);
this.$weChatLink=this.$el.find("."+this.classes.link+'[data-type="wechat"]');
this.data={src:this.$el.data("wechatQrSrc"),id:this.$el.data("wechatId")};
$(window).on("resize",this.removeLinksDot.bind(this));
$.onFontLoad(this.removeLinksDot.bind(this));
this.$weChatLink.length&&this.initWeChatPopup();
$("#scroll-top").click(function(){$("html, body").animate({scrollTop:0},1000)
})
}a.prototype.removeLinksDot=function(){var d=this.classes.pipe,c;
this.$linksContainer.each(function(){var e=$(this);
e.toggleClass(d,$.isOffsetEqual([c||e,e]));
c=e
})
};
a.prototype.initWeChatPopup=function(){this.$popup=new b();
this.$weChatLink.on("click",function(c){c.preventDefault();
this.$popup.open(this.data,this.$weChatLink)
}.bind(this))
};
a.prototype.classes={linksContainer:"social-links",link:"social-link",pipe:"item--piped"};
a.selector=".footer-ui-23";
a.moduleName="Footer23";
return a
});
define("CookieDisclaimer",["utils"],function(h){var e="epam:cookiesAccepted";
var d=182;
var a=6;
var b=4;
var f=100;
var c=56;
var g="data-cookies-consent";
function i(j){this.$el=j;
this.$html=$("html");
this.$isCookieConsent=$(j).attr(g);
this.$description=$(j).find("."+this.classes.description);
if($.cookie(e)==="true"||!this.isCookieEnable()){this.destroy();
return
}this.$el.on("click","."+this.classes.button,this.cookiesAccepted.bind(this)).on("click",this.toggleExpand.bind(this));
$(window).on("resize",h.debounceExtend(this.hideExtraContent.bind(this),f));
if(this.$isCookieConsent==="true"){$(window).unload(this.clearAllCookies.bind(this))
}this.$el.removeClass("hidden");
$(window).bind("load",function(){this.hideExtraContent();
this.$el.removeClass(this.classes.invisible)
}.bind(this))
}i.prototype.cookiesAccepted=function(){$.cookie(e,"true",{expires:d,path:"/"});
this.destroy();
return false
};
i.prototype.destroy=function(){this.$el.remove()
};
i.prototype.toggleExpand=function(){this.$el.toggleClass(this.classes.expanded);
this.addScroll();
this.scrollToTop(this.$description[0])
};
i.prototype.hideExtraContent=function(){$(this.$el).removeClass(this.classes.shortView);
$(this.$el).addClass(this.classes.longView);
var j=Modernizr.mq(this.mediaMode.mobile)?b:a;
if(this.getAmountOfLine()>j){$(this.$el).addClass(this.classes.longView);
$(this.$el).removeClass(this.classes.shortView);
return
}$(this.$el).addClass(this.classes.shortView);
$(this.$el).removeClass(this.classes.longView)
};
i.prototype.descriptionHeight=function(){var j=0;
var l=this.$description.children();
for(var k=0;
k<l.length;
k++){j+=l[k].getBoundingClientRect().height
}return j
};
i.prototype.descriptionMaxHeight=function(){return Math.ceil($(window).height()*c/100)
};
i.prototype.descriptionLineHeight=function(){return parseInt($(this.$description).css(this.properties.lineHeight))
};
i.prototype.getAmountOfLine=function(){return Math.round(this.descriptionHeight()/this.descriptionLineHeight())
};
i.prototype.clearAllCookies=function(){if($.cookie(e)!=="true"){var k=document.cookie.split(";");
for(var j=0;
j<k.length;
j++){document.cookie=k[j]+"; path=/"
}}};
i.prototype.isCookieEnable=function(){return navigator&&navigator.cookieEnabled
};
i.prototype.scrollToTop=function(j){j.scrollTop=0
};
i.prototype.addScroll=function(){if(this.descriptionHeight()>this.descriptionMaxHeight()&&$(this.$el).hasClass(this.classes.expanded)){$(this.$description).addClass(this.classes.descriptionScroll)
}else{$(this.$description).removeClass(this.classes.descriptionScroll)
}};
i.prototype.classes={button:"cookie-disclaimer__button",expanded:"cookie-disclaimer--expanded",description:"cookie-disclaimer__description",descriptionScroll:"cookie-disclaimer__description--scroll",descriptionWrapper:"cookie-disclaimer-description-wrapper",readMoreButton:"cookie-disclaimer__read-more",shortView:"cookie-disclaimer--short-view",longView:"cookie-disclaimer--long-view",invisible:"invisible"};
i.prototype.properties={lineHeight:"line-height",height:"height"};
i.prototype.mediaMode={mobile:"(max-width: 767px)"};
i.moduleName="Cookie Disclaimer";
i.selector=".cookie-disclaimer-ui";
return i
});