var globalTimoutInterval = 180000;
var gatewayTimoutInterval = 1800000;
          
//============================================================
// Retrieve session
//============================================================
function sessionTimeoutCheck(timedoutCallbackFn)
{
  sessionCheck(timedoutCallbackFn, true);
}

//============================================================
// Retrieve session
//============================================================
function sessionCheck(timedoutCallbackFn, saveTinValue)
{
  if (typeof(timedoutCallbackFn) != "function") {
    return;
  }

  if( ( r = getHTTPRequestObject() ) !== null ){
    r.onreadystatechange = function(rObj,timedoutCallbackFn, saveTinValue){ return function(){ timeoutHandler(rObj,timedoutCallbackFn,saveTinValue); } }(r,timedoutCallbackFn,saveTinValue);
    r.open( 'GET', '/vdesk/timeoutagent-i.php', true );
    r.send("");
  }
}

//============================================================
// Callback function 
//============================================================
function timeoutHandler(r,timedoutCallbackFn,saveTinValue)
{
  if(r.readyState != 4){ return; }
  if(r.status < 400 && (( match = document.cookie.match( /TIN=(\d+)[;]?/ ) ) != null) && (( expirationTimeout = parseInt( match[1] ) ) > 0) ){
    if(saveTinValue) {
      globalTimoutInterval = expirationTimeout;
    }
    window.setTimeout( function(fn,saveTinValue) { return function() { sessionCheck(fn,saveTinValue); } }(timedoutCallbackFn, saveTinValue), globalTimoutInterval );
  } else {
    timedoutCallbackFn();
  }
}

function getHTTPRequestObject()
{
  var res = null;;
  try {
    res = new XMLHttpRequest();
  }catch(e){ try {
      res = new ActiveXObject('Msxml2.XMLHTTP');
    }catch(e){ try {
        res = new ActiveXObject('Microsoft.XMLHTTP');
      }catch(e){
        res = null;
      }
    }
  }
  return res;
}