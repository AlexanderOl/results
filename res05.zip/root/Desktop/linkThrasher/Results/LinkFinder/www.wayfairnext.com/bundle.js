(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.reactImpressjs = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
  'use strict';
  
  module.exports = require('./lib');
  },{"./lib":6}],2:[function(require,module,exports){
  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('react');
  
  var _react2 = _interopRequireDefault(_react);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var Hint = function (_Component) {
    _inherits(Hint, _Component);
  
    function Hint() {
      _classCallCheck(this, Hint);
  
      return _possibleConstructorReturn(this, (Hint.__proto__ || Object.getPrototypeOf(Hint)).apply(this, arguments));
    }
  
    _createClass(Hint, [{
      key: 'render',
      value: function render() {
        var _props = this.props,
            hint = _props.hint,
            stepsData = _props.stepsData,
            activeStep = _props.activeStep,
            hintMessage = _props.hintMessage;
  
        var ua = navigator.userAgent.toLowerCase();
        var isMobile = ua.search(/(iphone)|(ipod)|(android)/) === -1;
  
        // Swipe-right from www.flaticon.com
        var swipeRight = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAACVVBMVEUAAAA+Rk8+SFI+SVI+SFI+SFI+SFI+SFI7Tk49SVE+SFI/SVA+SFE+SFI+SFE9SFE+SFI+SFI9SFFASFE+SVI/R1JARlNASVI/SFI+SVJJSUkrVVU+SFI+SFI9SFI/R1Q+SFI/SVNDQ1E+SFI7SFU+R1M+SVJAQEBASlM+SlI+SFI/SFI3SVs+SFI+RVMzM2Y+SFI/SVJCSlI+R1I+R1M/R1I+RlU+SFIzTU0+R1IAgIA9R1I+SFI9SVI+SFI+SVM+SFI9SVI6RlE+SFI7RU4+SFI+SFM9R1M+SFE/SFJAR1E+SFI+SFE8R1E+SFI5R1U9R1E9SFE+SFI+SFI+SVE+SFM/SFE+SFM+SFI+SFM+SVE+SVRAQFVCSVA7R1M+SFJGRl0+SFI+SVE9R1M/R1E9R1I8SlM+SFI+SFI9R1EAAAA+SFI+SVI+R1M+SFI9SVJERFU+SFE9SFI+SFJAUFA9SFQ+SFI+SVE+SVNVVVU+SFI9SFM+SFJAQGA/SVM+SFI9SFE9SFI+SFM9SVU9R1I+SFI5VVU8RFU+SFI+R1E/SFI9R1E+SFI+SVM+R1I+R1I9SFM+SFI+SFJASFQ9SFJASlA/SFE+SFE/SVFAR1U9SFM+SFI9R1I9SVI/R1I+SFI+SVE+RlQ/SFE/R1I9SVI+SFFAR1M+SFI+SFM9R1BCTFU8SlE/SFM9SVI/SFI+S1E+Sk8+SFI/SFM/SFFDQ04+SFI+SFI+R1M+R1I9SFE9R1I+SFI+SFI+SFI/R1I8S0s/SFI+R1I9SFI+R1I+SFM+SFIAAADsccMoAAAAxXRSTlMAHWel4+vEfw0/tEnxyYdx/PeNPNpdKDiG6AcGsaS7Pf1pE/gniNMEND7XNQ75JQXbbR/WtnYhxQrvAmTHcNFi5zsW/hq9eJrCakjevC/7EoGmgM5elFXSfLB3RgwjK/YLsnRTYRk38L5oAeRXb8aJD7nc+hBD3VsxA8tc7QhN9L95rSp99Qke2Z3QT817oah15k5AYDBu1WUkLuWWhXriQjqjr1SgROmLNhsmjp6fKS2ZcjkXY7VWWlgy8+yuQRHUc7eP7tmoxvwAAAABYktHRACIBR1IAAAACXBIWXMAAA3XAAAN1wFCKJt4AAAAB3RJTUUH4QQMERcOUUUbKQAAA3pJREFUWMOVlvdfFFcUxZ9GLMGydhSRVSOIYLAFFUTRtSsYRVQSy5oikTWJCooFxUTB3tHEJJqY2DuWGHvL9//K3XVWhux782bPL3M+7+w5O3Nfu0q50K79Bx1SOnbqrDTo8mF7ZUNqV2JISdWI3aC7xd8jgIOeXRLVXtgSessv+vTt1z9tAHQYmCCnD7IlZMDg2NdnBmGISjph6DACH72jwyErRrJH9HchZ6RnQi50c2jeKPhYnvmjScQYU8BYGBfn4+ETeRRo/EwwBUyESYUOL4LJ0Wdxx8luTIkGTDV+QwlMc+j0IKEZiX8xU/yzzFWcDb3ifA7MTdav5sH8OC+GBcn6Vbos5NLWipYtbCt/avMrtQgWx3k5LGmrVlj9aiksi/PlUNlWXfjZ5xa/WtETVjp8FawO2wwJWANfxHkf+DLpgK9c60z2Q0bSAUMDhL52+Fqoyldq4Krc9CQSvoF1Dq2OwPpvs2RnD/vu+w1+A8bAxjivcG2gTaU+A9pBTa3DN8eswS3Logfd6uK6oq3bfCRshx0Oza6HSNFOpcK76t+9R8Nu+7z8AD/GeXeynIruiTifEtprC+gHjU0OLyx9/877KvevOXBQCkpG2JIgx94hk1YrBxVlh494ZqTBUaOYfyz2ISV1HgEjoD7bqBYePxGbmkPmgJOin/J6xYnNm2Q+TpvkM0FbgJRC6vSTQWsWe+RnZcHZKvhF/3q/ylIO2/xK/QbntMJ5+H2n3a/+gNFaQS6OZh9+tS0F9mjGwwGCnf0ERJuNC5rhTNeh6o350FszXOS1CtugAXI0w3Ik/unL3ySzXaAZr4O/fAXIvVWvG9/c2mJ446I0Q7rx2hA1YT8Bl2C4VtgPl334q69Aqla5Cot8BFyDAfotf30UgRv2ALnobxqkW3DbHlDe2kf8H3dClBXY/HfhoFGshBZbgFxZ94ziBQjc9/aHu1L2wCwvkE7Le0c+hL895LFVth0lt98jL/0f2SiPPfQn0tB6n1rS9TfmmuUWa5nzZEFfMc7liqf6w8iNs89gpknMgS3KhkxpKe4atB3w3Bqgnpu/84h5H7jwQur4Ui9JDc/YA9QreK1X3nj0Dy6sk1IVapVx5p3oRljW4y6dUC0H+gYfAeqt9IbTEofz78EJP361719M8DEJUZyqMfhf5fkLUJktkUR3cGRaQgX+A9+U00T4J6SQAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE3LTA0LTEyVDE3OjIzOjE0KzAyOjAwNwWLpwAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxNy0wNC0xMlQxNzoyMzoxNCswMjowMEZYMxsAAAAZdEVYdFNvZnR3YXJlAHd3dy5pbmtzY2FwZS5vcmeb7jwaAAAAAElFTkSuQmCC';
  
        // If current Step is first one, let hint show up.
        var isFirstStep = Object.keys(stepsData).findIndex(function (s) {
          return s === activeStep.id;
        }) === 0;
  
        return _react2.default.createElement(
          'div',
          { className: isFirstStep ? 'show' : '',
            style: { display: hint ? 'block' : 'none' } },
          isMobile ? _react2.default.createElement(
            'div',
            { className: 'hint' },
            hintMessage
          ) : _react2.default.createElement(
            'div',
            { className: 'mobile-hint' },
            _react2.default.createElement('img', { src: swipeRight, role: 'presentation' }),
            _react2.default.createElement(
              'span',
              null,
              _react2.default.createElement(
                'b',
                null,
                'Swipe'
              ),
              ' to navigate'
            )
          )
        );
      }
    }]);
  
    return Hint;
  }(_react.Component);
  
  exports.default = Hint;
  
  },{"react":133}],3:[function(require,module,exports){
  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('react');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _update = require('react/lib/update');
  
  var _update2 = _interopRequireDefault(_update);
  
  var _propTypes = require('prop-types');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _util = require('./util');
  
  var _Progress = require('./Progress');
  
  var _Progress2 = _interopRequireDefault(_Progress);
  
  var _Hint = require('./Hint');
  
  var _Hint2 = _interopRequireDefault(_Hint);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var html = document.documentElement,
      body = document.body;
  
  var _lastHash = '',
      _stepsData = {},
      _activeStep = void 0,
      _idHelper = 1;
  
  var Impress = function (_Component) {
    _inherits(Impress, _Component);
  
    function Impress(props) {
      _classCallCheck(this, Impress);
  
      var _this = _possibleConstructorReturn(this, (Impress.__proto__ || Object.getPrototypeOf(Impress)).call(this, props));
  
      var rootData = props.rootData,
          hint = props.hint,
          hintMessage = props.hintMessage,
          fallbackMessage = props.fallbackMessage,
          progress = props.progress;
  
      var rootStyles = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transformOrigin: 'top left',
        transition: 'all 0s ease-in-out',
        transformStyle: 'preserve-3d'
      };
      var defaultData = {
        x: 0, y: 0, z: 0,
        rotateX: 0, rotateY: 0, rotateZ: 0,
        scale: 1
      };
  
      // <Impress /> State
      _this.state = {
        /** Impress Config **/
        rootStyles: rootStyles,
        windowScale: null,
        config: null,
        impressSupported: false,
  
        /** Step Status **/
        activeStep: {
          data: defaultData
        },
  
        /** Camera Status **/
        cameraStyles: rootStyles,
  
        /** Public attributes provide to use **/
        rootData: rootData, // (not recommended)
        hint: hint,
        hintMessage: hintMessage,
        fallbackMessage: fallbackMessage,
        progress: progress,
  
        /** For touch event **/
        startX: 0,
        deltaX: 0
      };
      return _this;
    }
  
    _createClass(Impress, [{
      key: 'componentWillMount',
      value: function componentWillMount() {
        // Init impress
        this.init();
      }
    }, {
      key: 'componentDidMount',
      value: function componentDidMount() {
        var _this2 = this;
  
        var impressSupported = this.state.impressSupported;
  
        // 2017/2/28 暫時想不到好方法
  
        if (impressSupported) this.goto(_activeStep, 500);
  
        // Listener for keyboard event
        document.addEventListener('keyup', (0, _util.throttle)(function (e) {
          if (e.keyCode === 9 || e.keyCode >= 32 && e.keyCode <= 40) {
            switch (e.keyCode) {
              case 35:
                // End
                _this2.end();
                break;
              case 36:
                // Home
                _this2.home();
                break;
              case 33: // Page up
              case 37: // Left
              case 38:
                // Up
                _this2.prev();
                break;
              case 9: // Tab
              case 32: // Space
              case 34: // Page down
              case 39: // Right
              case 40:
                // Down
                _this2.next();
                break;
              default:
                break;
            }
          }
        }, 250), false);
  
      }
    }, {
      key: 'componentWillReceiveProps',
      value: function componentWillReceiveProps(nextPorps) {
        this.setState({
          fallbackMessage: nextPorps.fallbackMessage,
          hint: nextPorps.hint,
          hintMessage: nextPorps.hintMessage
        });
      }
    }, {
      key: 'componentWillUnmount',
      value: function componentWillUnmount() {
        document.removeEventListener('keydown', function (event) {
          console.log(event.keyCode);
        }, false);
      }
  
      /**
       * Initialize Impress.
       */
  
    }, {
      key: 'init',
      value: function init() {
        var rootData = this.state.rootData;
  
  
        var defaults = {
          width: 1024,
          height: 768,
          maxScale: 1,
          minScale: 0,
          perspective: 1000,
          transitionDuration: 1000
        };
  
        // const ua = navigator.userAgent.toLowerCase()
  
        // Check impress support or not.
        var impressSupported =
        // Browser should support CSS 3D transtorms
        (0, _util.pfx)('perspective') !== null
        // But some mobile devices need to be blacklisted,
        // because their CSS 3D support or hardware is not
        // good enough to run impress.js properly, sorry...
        //( ua.search( /(iphone)|(ipod)|(android)/ ) === -1 );
  
        // Config
        var config = {
          width: (0, _util.toNumber)(rootData.width, defaults.width),
          height: (0, _util.toNumber)(rootData.height, defaults.height),
          maxScale: (0, _util.toNumber)(rootData.maxScale, defaults.maxScale),
          minScale: (0, _util.toNumber)(rootData.minScale, defaults.minScale),
          perspective: (0, _util.toNumber)(rootData.perspective, defaults.perspective),
          transitionDuration: (0, _util.toNumber)(rootData.transitionDuration, defaults.transitionDuration)
        };
        // Window Scale
        var windowScale = (0, _util.computeWindowScale)(config);
        // HTML height
        (0, _util.css)(html, {
          height: '100vh',
          overflow: 'hidden'
        });
        // Body style
        (0, _util.css)(document.body, {
          height: '100vh',
          overflow: 'hidden',
  
          // mobile devise supported
          position: 'relative'
        });
  
        this.setState((0, _update2.default)(this.state, {
          windowScale: {
            $set: windowScale
          },
          config: {
            $set: config
          },
          impressSupported: {
            $set: impressSupported
          },
          rootStyles: {
            $merge: {
              'transform': (0, _util.perspective)(config.perspective / windowScale) + (0, _util.scale)(windowScale)
            }
          }
        }));
      }
  
      /**
       * Initialize Steps.
       *
       * @param {Step} step init every Steps in Impress.
       */
  
    }, {
      key: 'goto',
  
  
      /**
       * Navigate to the SPECIFY Step.
       *
       * @param {Step} step you want to navigate to.
       * @param {number} duration 1000 speed of navigation.
       */
      value: function goto(step) {
        var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1000;
        var extraDelay = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
        var extraDepth = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
  
        if (this.props.impressWillTransition) {
          this.props.impressWillTransition(step, duration);
        }
        var _state = this.state,
            config = _state.config,
            activeStep = _state.activeStep;
        var windowScale = this.state.windowScale;
  
  
        window.scrollTo(0, 0);
  
        var target = {
          x: -step.data.x,
          y: -step.data.y,
          z: -step.data.z + extraDepth,
          rotateX: -step.data.rotateX,
          rotateY: -step.data.rotateY,
          rotateZ: -step.data.rotateZ,
          scale: 1 / step.data.scale
        };
  
        // Check scale for zoom-in
        var zoomin = target.scale >= 1 / activeStep.data.scale;
  
        duration = (0, _util.toNumber)(duration, config.transitionDuration);
        var delay = duration / 2;
  
        if (step.id === activeStep.id) windowScale = (0, _util.computeWindowScale)(config);
  
        var targetScale = target.scale * windowScale;
  
        this.setState((0, _update2.default)(this.state, {
          activeStep: {
            $set: step
          },
          rootStyles: {
            transform: {
              $set: (0, _util.perspective)(config.perspective / targetScale) + (0, _util.scale)(targetScale)
            },
            transitionDuration: {
              $set: duration + 'ms'
            },
            transitionDelay: {
              $set: (zoomin ? delay : 0) + 'ms'
            }, 
            transitionProperty: {
              $set: "transform"
            }
          },
          cameraStyles: {
            transform: {
              $set: (0, _util.rotate)(target, true) + (0, _util.translate)(target)
            },
            transitionDuration: {
              $set: duration + 'ms'
            },
            transitionDelay: {
              $set: (zoomin ? 0 + extraDelay : delay) + 'ms'
            }, 
            transitionProperty: {
              $set: "transform"
            }
          }
        }));
  
        window.location.hash = _lastHash = '#/' + step.id;
        if (this.props.impressDidTransition) {
          this.props.impressDidTransition(step, duration);
        }
      }
  
      // Navigate to the PREVIOUS Step.
  
    }, {
      key: 'prev',
      value: function prev() {
        var activeStep = this.state.activeStep;
  
        /**
         * 2017.04.10
         * Why we don't use Object.entries() or Object.values() any more ?
         * Cause the browser of iOS device (Chrome, Safari...) and some of Android devise
         * DOES'NT supported Object.entries() and Object.values() now...
         */
        // const stepsDataEntries = Object.entries( _stepsData );
        // let prev = stepsDataEntries.findIndex( ([k, v]) => { return k === activeStep.id } ) - 1;
        // prev = prev >= 0 ? stepsDataEntries[ prev ][1] : stepsDataEntries[ stepsDataEntries.length - 1 ][1];
  
        var stepsDataKeys = Object.keys(_stepsData);
        // get index of previous
        var prev = stepsDataKeys.findIndex(function (k) {
          return k === activeStep.id;
        }) - 1;
  
        // get id via index from stepsData
        prev = prev >= 0 ? stepsDataKeys[prev] : stepsDataKeys[stepsDataKeys.length - 1];
  
        // get previous step
        prev = _stepsData[prev];
  
        this.goto(prev, prev.duration);
      }
    }, {
      key: 'getStepsData',
      value: function getStepsData() {
        return _stepsData;
      }
  
      // Navigate to the NEXT Step.
  
    }, {
      key: 'next',
      value: function next() {
        var activeStep = this.state.activeStep;
  
        var stepsDataKeys = Object.keys(_stepsData);
        var next = stepsDataKeys.findIndex(function (k) {
          return k === activeStep.id;
        }) + 1;
        next = next < stepsDataKeys.length ? stepsDataKeys[next] : stepsDataKeys[0];
        next = _stepsData[next];
  
        this.goto(next, next.duration);
      }
  
      // Navigate to the FIRST Step.
  
    }, {
      key: 'home',
      value: function home() {
        var stepsDataEntries = Object.entries(_stepsData);
        var firstStep = stepsDataEntries[0][1];
  
        this.goto(firstStep, firstStep.duration);
      }
  
      // Navigate to the LAST Step.
  
    }, {
      key: 'end',
      value: function end() {
        var stepsDataEntries = Object.entries(_stepsData);
        var lastStep = stepsDataEntries[stepsDataEntries.length - 1][1];
  
        this.goto(lastStep, lastStep.duration);
      }
  
      // Touch Start( record start position: startX )
  
    }, {
      key: 'handleTouchStart',
      value: function handleTouchStart(e) {
        this.setState({
          startX: e.touches[0].clientX
        });
      }
  
      // Touch Move( Calculate touch move path: deltaX )
  
    }, {
      key: 'handleTouchMove',
      value: function handleTouchMove(e) {
        e.preventDefault();
        this.setState({
          deltaX: this.state.startX - e.touches[0].clientX
        });
      }
  
      // Touch End( decide navigate previous or next Step via 'deltaX' )
  
    }, {
      key: 'handleTouchEnd',
      value: function handleTouchEnd(e) {
        if (this.state.deltaX > 0) // slide left
          this.next();else if (this.state.deltaX < 0) // slide right
          this.prev();
  
        // reset
        this.setState({
          deltaX: 0
        });
      }
  
      /**
       * Create <Step />
       *
       * @return {Step} to render children.
       */
  
    }, {
      key: 'stepComponent',
      value: function stepComponent(step, index) {
        var activeStep = this.state.activeStep;
  
  
        return _react2.default.cloneElement(step, {
          key: index,
          idHelper: step.props.id ? '' : _idHelper++,
          activeStep: activeStep,
          initStep: Impress.initStep.bind(this),
          goto: this.goto.bind(this)
        }, step.props.children);
      }
    }, {
      key: 'render',
      value: function render() {
        var _state2 = this.state,
            impressSupported = _state2.impressSupported,
            rootStyles = _state2.rootStyles,
            cameraStyles = _state2.cameraStyles,
            activeStep = _state2.activeStep,
            hint = _state2.hint,
            hintMessage = _state2.hintMessage,
            fallbackMessage = _state2.fallbackMessage,
            progress = _state2.progress;
  
        var steps = _react2.default.Children.map(this.props.children, this.stepComponent.bind(this));
        var stepsTotal = _react2.default.Children.count(this.props.children);
  
        return _react2.default.createElement(
          'div',
          { id: 'react-impressjs',
            className: (impressSupported ? 'impress-supported' : 'impress-not-supported') + (activeStep ? ' impress-on-' + activeStep.id : '') + ' impress-enabled',
            onTouchStart: this.handleTouchStart.bind(this),
            onTouchMove: this.handleTouchMove.bind(this),
            onTouchEnd: this.handleTouchEnd.bind(this) },
          _react2.default.createElement(
            'div',
            { id: 'impress', style: rootStyles },
            _react2.default.createElement(
              'div',
              { style: cameraStyles },
              impressSupported ? steps : _react2.default.createElement(
                'div',
                { className: 'fallback-message' },
                fallbackMessage
              )
            )
          ),
          _react2.default.createElement(_Hint2.default, {
            hint: hint,
            stepsData: _stepsData,
            activeStep: activeStep,
            hintMessage: hintMessage }),
          _react2.default.createElement(_Progress2.default, {
            progress: progress,
            stepsData: _stepsData,
            activeStep: activeStep,
            stepsTotal: stepsTotal })
        );
      }
    }], [{
      key: 'initStep',
      value: function initStep(step) {
        // Set first Step as enter Step.
        if (!_activeStep) _activeStep = step;
  
        _stepsData = (0, _update2.default)(_stepsData, {
          $merge: _defineProperty({}, step.id, {
            id: step.id,
            className: step.className,
            data: step.data,
            duration: step.duration
          })
        });
      }
    }]);
  
    return Impress;
  }(_react.Component);
  
  exports.default = Impress;
  
  
  Impress.propTypes = {
    /**
     * Impress basic config
     */
    rootData: _propTypes2.default.object,
  
    /**
     * Whether to display hint or not
     */
    hint: _propTypes2.default.bool,
  
    /**
     * Hint for presentation
     */
    hintMessage: _propTypes2.default.oneOfType([_propTypes2.default.object, _propTypes2.default.string]),
  
    /**
     * Fallback message is only visible when there is impress-not-supported
     */
    fallbackMessage: _propTypes2.default.oneOfType([_propTypes2.default.object, _propTypes2.default.string]),
  
    /**
     * Progress of presentation
     */
    progress: _propTypes2.default.bool
  };
  
  Impress.defaultProps = {
    rootData: {},
    hint: true,
    hintMessage: _react2.default.createElement(
      'p',
      null,
      'Use ',
      _react2.default.createElement(
        'b',
        null,
        'Spacebar'
      ),
      ' or ',
      _react2.default.createElement(
        'b',
        null,
        'Arrow keys'
      ),
      ' to navigate'
    ),
    fallbackMessage: _react2.default.createElement(
      'p',
      null,
      'Your browser ',
      _react2.default.createElement(
        'b',
        null,
        'doesn\'t support the features required'
      ),
      ' by React-impressJS, so you are presented with a simplified version of this presentation.'
    ),
    progress: false
  };
  
  },{"./Hint":2,"./Progress":4,"./util":7,"prop-types":101,"react":133,"react/lib/update":132}],4:[function(require,module,exports){
  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('react');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _rcProgress = require('rc-progress');
  
  var _propTypes = require('prop-types');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var Progress = function (_Component) {
    _inherits(Progress, _Component);
  
    function Progress() {
      _classCallCheck(this, Progress);
  
      return _possibleConstructorReturn(this, (Progress.__proto__ || Object.getPrototypeOf(Progress)).apply(this, arguments));
    }
  
    _createClass(Progress, [{
      key: 'render',
      value: function render() {
        var _props = this.props,
            progress = _props.progress,
            stepsData = _props.stepsData,
            activeStep = _props.activeStep,
            stepsTotal = _props.stepsTotal;
  
        var color_gold = '#e5b560',
            color_gray = '#3e4852';
        var ua = navigator.userAgent.toLowerCase();
        var progressWidth = ua.search(/(iphone)|(ipod)|(android)/) === -1 ? 0.2 : 1;
        var currentStepIndex = Object.keys(stepsData).findIndex(function (s) {
          return s === activeStep.id;
        }) + 1;
        var percent = parseInt(currentStepIndex / stepsTotal * 100, 10);
  
        return _react2.default.createElement(
          'div',
          { style: {
              position: 'fixed',
              bottom: '-3px',
              width: '100%',
              display: progress ? 'block' : 'none'
            } },
          _react2.default.createElement(
            'p',
            { style: {
                fontSize: 20,
                color: color_gray,
                textAlign: 'center',
                opacity: .5
              } },
            _react2.default.createElement(
              'span',
              null,
              currentStepIndex,
              _react2.default.createElement(
                'span',
                { style: { paddingLeft: 1, fontSize: 13 } },
                '/' + stepsTotal
              )
            )
          ),
          _react2.default.createElement(_rcProgress.Line, { percent: percent,
            strokeLinecap: 'square',
            strokeWidth: progressWidth, strokeColor: color_gold,
            trailWidth: progressWidth, trailColor: color_gray })
        );
      }
    }]);
  
    return Progress;
  }(_react.Component);
  
  exports.default = Progress;
  
  
  Progress.propTypes = {
    /**
     * Progress of presentation
     */
    progress: _propTypes2.default.bool,
  
    /**
     * Steps data
     */
    stepsData: _propTypes2.default.object,
  
    /**
     * Object representing current step
     */
    activeStep: _propTypes2.default.shape({
      id: _propTypes2.default.string
    }),
  
    /**
     * Amount of steps
     */
    stepsTotal: _propTypes2.default.number
  };
  
  },{"prop-types":101,"rc-progress":106,"react":133}],5:[function(require,module,exports){
  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('react');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _update = require('react/lib/update');
  
  var _update2 = _interopRequireDefault(_update);
  
  var _util = require('./util');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var defaultData = {
    x: 0,
    y: 0,
    z: 0,
    rotateX: 0,
    rotateY: 0,
    rotateZ: 0,
    scale: 1
  };
  
  var Step = function (_Component) {
    _inherits(Step, _Component);
  
    function Step(props) {
      _classCallCheck(this, Step);
  
      var _this = _possibleConstructorReturn(this, (Step.__proto__ || Object.getPrototypeOf(Step)).call(this, props));
  
      var _this$props = _this.props,
          className = _this$props.className,
          duration = _this$props.duration;
  
  
      _this.state = {
        id: _this.gtepID(),
        className: className ? 'step ' + className : 'step',
        data: _this.getData(),
        duration: duration ? duration : 1000,
        isPresented: false
      };
      return _this;
    }
  
    _createClass(Step, [{
      key: 'componentDidMount',
      value: function componentDidMount() {
        var initStep = this.props.initStep;
  
  
        initStep(this.state);
      }
    }, {
      key: 'componentWillReceiveProps',
      value: function componentWillReceiveProps(nextProps) {
        var _state = this.state,
            id = _state.id,
            isPresented = _state.isPresented;
  
  
        if (id === nextProps.activeStep.id && !isPresented) this.setState((0, _update2.default)(this.state, {
          isPresented: {
            $set: true
          }
        }));
      }
  
      // Step's Event
  
    }, {
      key: 'handleClick',
      value: function handleClick(e) {
        var goto = this.props.goto;
  
        var target = e.target;
  
        while (!target.classList.contains('step') && !target.classList.contains('active') && !target.classList.contains('oi-step-element') && target !== document.documentElement) {
          target = target.parentNode;
        }
  
        if (target !== document.documentElement) if (target.classList.contains('step')) goto(this.state, this.state.duration);
      }
  
      // Step's ID, ClassName, Style
  
    }, {
      key: 'gtepID',
      value: function gtepID() {
        var _props = this.props,
            id = _props.id,
            idHelper = _props.idHelper;
  
  
        return id || 'step-' + idHelper;
      }
    }, {
      key: 'getClassName',
      value: function getClassName() {
        var activeStep = this.props.activeStep;
        var _state2 = this.state,
            id = _state2.id,
            className = _state2.className,
            isPresented = _state2.isPresented;
  
  
        if (id === activeStep.id) return className + ' active present';else if (isPresented) return className + ' past';else return className + ' future';
      }
    }, {
      key: 'getData',
      value: function getData() {
        var data = this.props.data;
  
  
        return data ? {
          x: (0, _util.toNumber)(data.x),
          y: (0, _util.toNumber)(data.y),
          z: (0, _util.toNumber)(data.z),
          rotateX: (0, _util.toNumber)(data.rotateX),
          rotateY: (0, _util.toNumber)(data.rotateY),
          rotateZ: (0, _util.toNumber)(data.rotateZ || data.rotate),
          scale: (0, _util.toNumber)(data.scale, 1)
        } : defaultData;
      }
    }, {
      key: 'getStyle',
      value: function getStyle() {
        var data = this.state.data;
  
  
        var _stepStyle = {
          position: 'absolute',
          transform: 'translate(-50%, -50%) ',
          transformStyle: 'preserve-3d',
          transitionProperty: 'transform'
        };
  
        _stepStyle.transform += (0, _util.translate)(data ? data : defaultData) + (0, _util.rotate)(data ? data : defaultData) + (0, _util.scale)(data.scale ? data.scale : defaultData);
  
        return _stepStyle;
      }
    }, {
      key: 'render',
      value: function render() {
        var children = this.props.children;
        var id = this.state.id;
  
  
        var _stepClassName = this.getClassName();
        var _stepStyle = this.getStyle();
  
        return _react2.default.createElement(
          'div',
          { id: id,
            className: _stepClassName,
            style: _stepStyle,
            onClick: this.handleClick.bind(this) },
          children
        );
      }
    }]);
  
    return Step;
  }(_react.Component);
  
  exports.default = Step;
  
  },{"./util":7,"react":133,"react/lib/update":132}],6:[function(require,module,exports){
  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  
  var _Impress = require('./Impress');
  
  Object.defineProperty(exports, 'Impress', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Impress).default;
    }
  });
  
  var _Step = require('./Step');
  
  Object.defineProperty(exports, 'Step', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Step).default;
    }
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  },{"./Impress":3,"./Step":5}],7:[function(require,module,exports){
  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.toNumber = toNumber;
  exports.translate = translate;
  exports.rotate = rotate;
  exports.scale = scale;
  exports.perspective = perspective;
  exports.computeWindowScale = computeWindowScale;
  exports.css = css;
  exports.throttle = throttle;
  exports.getElementFromHash = getElementFromHash;
  function toNumber(numeric, fallback) {
    return isNaN(numeric) ? fallback || 0 : Number(numeric);
  }
  
  function translate(data) {
    return ' translate3d(' + toNumber(data.x) + 'px, ' + toNumber(data.y) + 'px, ' + toNumber(data.z) + 'px)';
  }
  
  function rotate(data, revert) {
    var rX = ' rotateX(' + toNumber(data.rotateX) + 'deg) ',
        rY = ' rotateY(' + toNumber(data.rotateY) + 'deg) ',
        rZ = ' rotateZ(' + toNumber(data.rotateZ) + 'deg) ';
  
    return revert ? rZ + rY + rX : rX + rY + rZ;
  }
  
  function scale(data) {
    return ' scale(' + toNumber(data, 1) + ')';
  }
  
  function perspective(p) {
    return ' perspective(' + p + 'px) ';
  }
  
  function computeWindowScale(config) {
    var hScale = window.innerHeight / config.height,
        wScale = window.innerWidth / config.width,
        scale = hScale > wScale ? wScale : hScale;
  
    if (config.maxScale && scale > config.maxScale) {
      scale = config.maxScale;
    }
  
    if (config.minScale && scale < config.minScale) {
      scale = config.minScale;
    }
  
    return scale;
  }
  
  var pfx = exports.pfx = function () {
    var style = document.createElement('dummy').style,
        prefixes = 'Webkit Moz O ms Khtml'.split(' '),
        memory = {};
  
    return function (prop) {
      if (typeof memory[prop] === 'undefined') {
        var ucProp = prop.charAt(0).toUpperCase() + prop.substr(1),
            props = (prop + ' ' + prefixes.join(ucProp + ' ') + ucProp).split(' ');
  
        memory[prop] = null;
        for (var i in props) {
          if (style[props[i]] !== undefined) {
            memory[prop] = props[i];
            break;
          }
        }
      }
  
      return memory[prop];
    };
  }();
  
  function css(el, props) {
    for (var key in props) {
      if (props.hasOwnProperty(key)) {
        var pkey = pfx(key);
        if (pkey !== null) {
          el.style[pkey] = props[key];
        }
      }
    }
    return el;
  }
  
  function throttle(fn, delay) {
    var timer = null;
    return function () {
      var context = this,
          args = arguments;
      clearTimeout(timer);
      timer = setTimeout(function () {
        fn.apply(context, args);
      }, delay);
    };
  }
  
  function getElementFromHash(stepsData) {
    var id = window.location.hash.replace(/^#\/?/, '');
    return stepsData[id];
  }
  
  },{}],8:[function(require,module,exports){
  module.exports = { "default": require("core-js/library/fn/object/assign"), __esModule: true };
  },{"core-js/library/fn/object/assign":19}],9:[function(require,module,exports){
  module.exports = { "default": require("core-js/library/fn/object/create"), __esModule: true };
  },{"core-js/library/fn/object/create":20}],10:[function(require,module,exports){
  module.exports = { "default": require("core-js/library/fn/object/set-prototype-of"), __esModule: true };
  },{"core-js/library/fn/object/set-prototype-of":21}],11:[function(require,module,exports){
  module.exports = { "default": require("core-js/library/fn/symbol"), __esModule: true };
  },{"core-js/library/fn/symbol":22}],12:[function(require,module,exports){
  module.exports = { "default": require("core-js/library/fn/symbol/iterator"), __esModule: true };
  },{"core-js/library/fn/symbol/iterator":23}],13:[function(require,module,exports){
  "use strict";
  
  exports.__esModule = true;
  
  exports.default = function (instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  };
  },{}],14:[function(require,module,exports){
  "use strict";
  
  exports.__esModule = true;
  
  var _assign = require("../core-js/object/assign");
  
  var _assign2 = _interopRequireDefault(_assign);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  exports.default = _assign2.default || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
  
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
  
    return target;
  };
  },{"../core-js/object/assign":8}],15:[function(require,module,exports){
  "use strict";
  
  exports.__esModule = true;
  
  var _setPrototypeOf = require("../core-js/object/set-prototype-of");
  
  var _setPrototypeOf2 = _interopRequireDefault(_setPrototypeOf);
  
  var _create = require("../core-js/object/create");
  
  var _create2 = _interopRequireDefault(_create);
  
  var _typeof2 = require("../helpers/typeof");
  
  var _typeof3 = _interopRequireDefault(_typeof2);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  exports.default = function (subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + (typeof superClass === "undefined" ? "undefined" : (0, _typeof3.default)(superClass)));
    }
  
    subClass.prototype = (0, _create2.default)(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf2.default ? (0, _setPrototypeOf2.default)(subClass, superClass) : subClass.__proto__ = superClass;
  };
  },{"../core-js/object/create":9,"../core-js/object/set-prototype-of":10,"../helpers/typeof":18}],16:[function(require,module,exports){
  "use strict";
  
  exports.__esModule = true;
  
  exports.default = function (obj, keys) {
    var target = {};
  
    for (var i in obj) {
      if (keys.indexOf(i) >= 0) continue;
      if (!Object.prototype.hasOwnProperty.call(obj, i)) continue;
      target[i] = obj[i];
    }
  
    return target;
  };
  },{}],17:[function(require,module,exports){
  "use strict";
  
  exports.__esModule = true;
  
  var _typeof2 = require("../helpers/typeof");
  
  var _typeof3 = _interopRequireDefault(_typeof2);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  exports.default = function (self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
  
    return call && ((typeof call === "undefined" ? "undefined" : (0, _typeof3.default)(call)) === "object" || typeof call === "function") ? call : self;
  };
  },{"../helpers/typeof":18}],18:[function(require,module,exports){
  "use strict";
  
  exports.__esModule = true;
  
  var _iterator = require("../core-js/symbol/iterator");
  
  var _iterator2 = _interopRequireDefault(_iterator);
  
  var _symbol = require("../core-js/symbol");
  
  var _symbol2 = _interopRequireDefault(_symbol);
  
  var _typeof = typeof _symbol2.default === "function" && typeof _iterator2.default === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj; };
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  exports.default = typeof _symbol2.default === "function" && _typeof(_iterator2.default) === "symbol" ? function (obj) {
    return typeof obj === "undefined" ? "undefined" : _typeof(obj);
  } : function (obj) {
    return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj === "undefined" ? "undefined" : _typeof(obj);
  };
  },{"../core-js/symbol":11,"../core-js/symbol/iterator":12}],19:[function(require,module,exports){
  require('../../modules/es6.object.assign');
  module.exports = require('../../modules/_core').Object.assign;
  
  },{"../../modules/_core":29,"../../modules/es6.object.assign":82}],20:[function(require,module,exports){
  require('../../modules/es6.object.create');
  var $Object = require('../../modules/_core').Object;
  module.exports = function create(P, D) {
    return $Object.create(P, D);
  };
  
  },{"../../modules/_core":29,"../../modules/es6.object.create":83}],21:[function(require,module,exports){
  require('../../modules/es6.object.set-prototype-of');
  module.exports = require('../../modules/_core').Object.setPrototypeOf;
  
  },{"../../modules/_core":29,"../../modules/es6.object.set-prototype-of":84}],22:[function(require,module,exports){
  require('../../modules/es6.symbol');
  require('../../modules/es6.object.to-string');
  require('../../modules/es7.symbol.async-iterator');
  require('../../modules/es7.symbol.observable');
  module.exports = require('../../modules/_core').Symbol;
  
  },{"../../modules/_core":29,"../../modules/es6.object.to-string":85,"../../modules/es6.symbol":87,"../../modules/es7.symbol.async-iterator":88,"../../modules/es7.symbol.observable":89}],23:[function(require,module,exports){
  require('../../modules/es6.string.iterator');
  require('../../modules/web.dom.iterable');
  module.exports = require('../../modules/_wks-ext').f('iterator');
  
  },{"../../modules/_wks-ext":79,"../../modules/es6.string.iterator":86,"../../modules/web.dom.iterable":90}],24:[function(require,module,exports){
  module.exports = function (it) {
    if (typeof it != 'function') throw TypeError(it + ' is not a function!');
    return it;
  };
  
  },{}],25:[function(require,module,exports){
  module.exports = function () { /* empty */ };
  
  },{}],26:[function(require,module,exports){
  var isObject = require('./_is-object');
  module.exports = function (it) {
    if (!isObject(it)) throw TypeError(it + ' is not an object!');
    return it;
  };
  
  },{"./_is-object":45}],27:[function(require,module,exports){
  // false -> Array#indexOf
  // true  -> Array#includes
  var toIObject = require('./_to-iobject');
  var toLength = require('./_to-length');
  var toAbsoluteIndex = require('./_to-absolute-index');
  module.exports = function (IS_INCLUDES) {
    return function ($this, el, fromIndex) {
      var O = toIObject($this);
      var length = toLength(O.length);
      var index = toAbsoluteIndex(fromIndex, length);
      var value;
      // Array#includes uses SameValueZero equality algorithm
      // eslint-disable-next-line no-self-compare
      if (IS_INCLUDES && el != el) while (length > index) {
        value = O[index++];
        // eslint-disable-next-line no-self-compare
        if (value != value) return true;
      // Array#indexOf ignores holes, Array#includes - not
      } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
        if (O[index] === el) return IS_INCLUDES || index || 0;
      } return !IS_INCLUDES && -1;
    };
  };
  
  },{"./_to-absolute-index":71,"./_to-iobject":73,"./_to-length":74}],28:[function(require,module,exports){
  var toString = {}.toString;
  
  module.exports = function (it) {
    return toString.call(it).slice(8, -1);
  };
  
  },{}],29:[function(require,module,exports){
  var core = module.exports = { version: '2.5.7' };
  if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef
  
  },{}],30:[function(require,module,exports){
  // optional / simple context binding
  var aFunction = require('./_a-function');
  module.exports = function (fn, that, length) {
    aFunction(fn);
    if (that === undefined) return fn;
    switch (length) {
      case 1: return function (a) {
        return fn.call(that, a);
      };
      case 2: return function (a, b) {
        return fn.call(that, a, b);
      };
      case 3: return function (a, b, c) {
        return fn.call(that, a, b, c);
      };
    }
    return function (/* ...args */) {
      return fn.apply(that, arguments);
    };
  };
  
  },{"./_a-function":24}],31:[function(require,module,exports){
  // 7.2.1 RequireObjectCoercible(argument)
  module.exports = function (it) {
    if (it == undefined) throw TypeError("Can't call method on  " + it);
    return it;
  };
  
  },{}],32:[function(require,module,exports){
  // Thank's IE8 for his funny defineProperty
  module.exports = !require('./_fails')(function () {
    return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
  });
  
  },{"./_fails":37}],33:[function(require,module,exports){
  var isObject = require('./_is-object');
  var document = require('./_global').document;
  // typeof document.createElement is 'object' in old IE
  var is = isObject(document) && isObject(document.createElement);
  module.exports = function (it) {
    return is ? document.createElement(it) : {};
  };
  
  },{"./_global":38,"./_is-object":45}],34:[function(require,module,exports){
  // IE 8- don't enum bug keys
  module.exports = (
    'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
  ).split(',');
  
  },{}],35:[function(require,module,exports){
  // all enumerable object keys, includes symbols
  var getKeys = require('./_object-keys');
  var gOPS = require('./_object-gops');
  var pIE = require('./_object-pie');
  module.exports = function (it) {
    var result = getKeys(it);
    var getSymbols = gOPS.f;
    if (getSymbols) {
      var symbols = getSymbols(it);
      var isEnum = pIE.f;
      var i = 0;
      var key;
      while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
    } return result;
  };
  
  },{"./_object-gops":59,"./_object-keys":62,"./_object-pie":63}],36:[function(require,module,exports){
  var global = require('./_global');
  var core = require('./_core');
  var ctx = require('./_ctx');
  var hide = require('./_hide');
  var has = require('./_has');
  var PROTOTYPE = 'prototype';
  
  var $export = function (type, name, source) {
    var IS_FORCED = type & $export.F;
    var IS_GLOBAL = type & $export.G;
    var IS_STATIC = type & $export.S;
    var IS_PROTO = type & $export.P;
    var IS_BIND = type & $export.B;
    var IS_WRAP = type & $export.W;
    var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
    var expProto = exports[PROTOTYPE];
    var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
    var key, own, out;
    if (IS_GLOBAL) source = name;
    for (key in source) {
      // contains in native
      own = !IS_FORCED && target && target[key] !== undefined;
      if (own && has(exports, key)) continue;
      // export native or passed
      out = own ? target[key] : source[key];
      // prevent global pollution for namespaces
      exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
      // bind timers to global for call from export context
      : IS_BIND && own ? ctx(out, global)
      // wrap global constructors for prevent change them in library
      : IS_WRAP && target[key] == out ? (function (C) {
        var F = function (a, b, c) {
          if (this instanceof C) {
            switch (arguments.length) {
              case 0: return new C();
              case 1: return new C(a);
              case 2: return new C(a, b);
            } return new C(a, b, c);
          } return C.apply(this, arguments);
        };
        F[PROTOTYPE] = C[PROTOTYPE];
        return F;
      // make static versions for prototype methods
      })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
      // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
      if (IS_PROTO) {
        (exports.virtual || (exports.virtual = {}))[key] = out;
        // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
        if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
      }
    }
  };
  // type bitmap
  $export.F = 1;   // forced
  $export.G = 2;   // global
  $export.S = 4;   // static
  $export.P = 8;   // proto
  $export.B = 16;  // bind
  $export.W = 32;  // wrap
  $export.U = 64;  // safe
  $export.R = 128; // real proto method for `library`
  module.exports = $export;
  
  },{"./_core":29,"./_ctx":30,"./_global":38,"./_has":39,"./_hide":40}],37:[function(require,module,exports){
  module.exports = function (exec) {
    try {
      return !!exec();
    } catch (e) {
      return true;
    }
  };
  
  },{}],38:[function(require,module,exports){
  // https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
  var global = module.exports = typeof window != 'undefined' && window.Math == Math
    ? window : typeof self != 'undefined' && self.Math == Math ? self
    // eslint-disable-next-line no-new-func
    : Function('return this')();
  if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef
  
  },{}],39:[function(require,module,exports){
  var hasOwnProperty = {}.hasOwnProperty;
  module.exports = function (it, key) {
    return hasOwnProperty.call(it, key);
  };
  
  },{}],40:[function(require,module,exports){
  var dP = require('./_object-dp');
  var createDesc = require('./_property-desc');
  module.exports = require('./_descriptors') ? function (object, key, value) {
    return dP.f(object, key, createDesc(1, value));
  } : function (object, key, value) {
    object[key] = value;
    return object;
  };
  
  },{"./_descriptors":32,"./_object-dp":54,"./_property-desc":64}],41:[function(require,module,exports){
  var document = require('./_global').document;
  module.exports = document && document.documentElement;
  
  },{"./_global":38}],42:[function(require,module,exports){
  module.exports = !require('./_descriptors') && !require('./_fails')(function () {
    return Object.defineProperty(require('./_dom-create')('div'), 'a', { get: function () { return 7; } }).a != 7;
  });
  
  },{"./_descriptors":32,"./_dom-create":33,"./_fails":37}],43:[function(require,module,exports){
  // fallback for non-array-like ES3 and non-enumerable old V8 strings
  var cof = require('./_cof');
  // eslint-disable-next-line no-prototype-builtins
  module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
    return cof(it) == 'String' ? it.split('') : Object(it);
  };
  
  },{"./_cof":28}],44:[function(require,module,exports){
  // 7.2.2 IsArray(argument)
  var cof = require('./_cof');
  module.exports = Array.isArray || function isArray(arg) {
    return cof(arg) == 'Array';
  };
  
  },{"./_cof":28}],45:[function(require,module,exports){
  module.exports = function (it) {
    return typeof it === 'object' ? it !== null : typeof it === 'function';
  };
  
  },{}],46:[function(require,module,exports){
  'use strict';
  var create = require('./_object-create');
  var descriptor = require('./_property-desc');
  var setToStringTag = require('./_set-to-string-tag');
  var IteratorPrototype = {};
  
  // 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
  require('./_hide')(IteratorPrototype, require('./_wks')('iterator'), function () { return this; });
  
  module.exports = function (Constructor, NAME, next) {
    Constructor.prototype = create(IteratorPrototype, { next: descriptor(1, next) });
    setToStringTag(Constructor, NAME + ' Iterator');
  };
  
  },{"./_hide":40,"./_object-create":53,"./_property-desc":64,"./_set-to-string-tag":67,"./_wks":80}],47:[function(require,module,exports){
  'use strict';
  var LIBRARY = require('./_library');
  var $export = require('./_export');
  var redefine = require('./_redefine');
  var hide = require('./_hide');
  var Iterators = require('./_iterators');
  var $iterCreate = require('./_iter-create');
  var setToStringTag = require('./_set-to-string-tag');
  var getPrototypeOf = require('./_object-gpo');
  var ITERATOR = require('./_wks')('iterator');
  var BUGGY = !([].keys && 'next' in [].keys()); // Safari has buggy iterators w/o `next`
  var FF_ITERATOR = '@@iterator';
  var KEYS = 'keys';
  var VALUES = 'values';
  
  var returnThis = function () { return this; };
  
  module.exports = function (Base, NAME, Constructor, next, DEFAULT, IS_SET, FORCED) {
    $iterCreate(Constructor, NAME, next);
    var getMethod = function (kind) {
      if (!BUGGY && kind in proto) return proto[kind];
      switch (kind) {
        case KEYS: return function keys() { return new Constructor(this, kind); };
        case VALUES: return function values() { return new Constructor(this, kind); };
      } return function entries() { return new Constructor(this, kind); };
    };
    var TAG = NAME + ' Iterator';
    var DEF_VALUES = DEFAULT == VALUES;
    var VALUES_BUG = false;
    var proto = Base.prototype;
    var $native = proto[ITERATOR] || proto[FF_ITERATOR] || DEFAULT && proto[DEFAULT];
    var $default = $native || getMethod(DEFAULT);
    var $entries = DEFAULT ? !DEF_VALUES ? $default : getMethod('entries') : undefined;
    var $anyNative = NAME == 'Array' ? proto.entries || $native : $native;
    var methods, key, IteratorPrototype;
    // Fix native
    if ($anyNative) {
      IteratorPrototype = getPrototypeOf($anyNative.call(new Base()));
      if (IteratorPrototype !== Object.prototype && IteratorPrototype.next) {
        // Set @@toStringTag to native iterators
        setToStringTag(IteratorPrototype, TAG, true);
        // fix for some old engines
        if (!LIBRARY && typeof IteratorPrototype[ITERATOR] != 'function') hide(IteratorPrototype, ITERATOR, returnThis);
      }
    }
    // fix Array#{values, @@iterator}.name in V8 / FF
    if (DEF_VALUES && $native && $native.name !== VALUES) {
      VALUES_BUG = true;
      $default = function values() { return $native.call(this); };
    }
    // Define iterator
    if ((!LIBRARY || FORCED) && (BUGGY || VALUES_BUG || !proto[ITERATOR])) {
      hide(proto, ITERATOR, $default);
    }
    // Plug for library
    Iterators[NAME] = $default;
    Iterators[TAG] = returnThis;
    if (DEFAULT) {
      methods = {
        values: DEF_VALUES ? $default : getMethod(VALUES),
        keys: IS_SET ? $default : getMethod(KEYS),
        entries: $entries
      };
      if (FORCED) for (key in methods) {
        if (!(key in proto)) redefine(proto, key, methods[key]);
      } else $export($export.P + $export.F * (BUGGY || VALUES_BUG), NAME, methods);
    }
    return methods;
  };
  
  },{"./_export":36,"./_hide":40,"./_iter-create":46,"./_iterators":49,"./_library":50,"./_object-gpo":60,"./_redefine":65,"./_set-to-string-tag":67,"./_wks":80}],48:[function(require,module,exports){
  module.exports = function (done, value) {
    return { value: value, done: !!done };
  };
  
  },{}],49:[function(require,module,exports){
  module.exports = {};
  
  },{}],50:[function(require,module,exports){
  module.exports = true;
  
  },{}],51:[function(require,module,exports){
  var META = require('./_uid')('meta');
  var isObject = require('./_is-object');
  var has = require('./_has');
  var setDesc = require('./_object-dp').f;
  var id = 0;
  var isExtensible = Object.isExtensible || function () {
    return true;
  };
  var FREEZE = !require('./_fails')(function () {
    return isExtensible(Object.preventExtensions({}));
  });
  var setMeta = function (it) {
    setDesc(it, META, { value: {
      i: 'O' + ++id, // object ID
      w: {}          // weak collections IDs
    } });
  };
  var fastKey = function (it, create) {
    // return primitive with prefix
    if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
    if (!has(it, META)) {
      // can't set metadata to uncaught frozen object
      if (!isExtensible(it)) return 'F';
      // not necessary to add metadata
      if (!create) return 'E';
      // add missing metadata
      setMeta(it);
    // return object ID
    } return it[META].i;
  };
  var getWeak = function (it, create) {
    if (!has(it, META)) {
      // can't set metadata to uncaught frozen object
      if (!isExtensible(it)) return true;
      // not necessary to add metadata
      if (!create) return false;
      // add missing metadata
      setMeta(it);
    // return hash weak collections IDs
    } return it[META].w;
  };
  // add metadata on freeze-family methods calling
  var onFreeze = function (it) {
    if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
    return it;
  };
  var meta = module.exports = {
    KEY: META,
    NEED: false,
    fastKey: fastKey,
    getWeak: getWeak,
    onFreeze: onFreeze
  };
  
  },{"./_fails":37,"./_has":39,"./_is-object":45,"./_object-dp":54,"./_uid":77}],52:[function(require,module,exports){
  'use strict';
  // 19.1.2.1 Object.assign(target, source, ...)
  var getKeys = require('./_object-keys');
  var gOPS = require('./_object-gops');
  var pIE = require('./_object-pie');
  var toObject = require('./_to-object');
  var IObject = require('./_iobject');
  var $assign = Object.assign;
  
  // should work with symbols and should have deterministic property order (V8 bug)
  module.exports = !$assign || require('./_fails')(function () {
    var A = {};
    var B = {};
    // eslint-disable-next-line no-undef
    var S = Symbol();
    var K = 'abcdefghijklmnopqrst';
    A[S] = 7;
    K.split('').forEach(function (k) { B[k] = k; });
    return $assign({}, A)[S] != 7 || Object.keys($assign({}, B)).join('') != K;
  }) ? function assign(target, source) { // eslint-disable-line no-unused-vars
    var T = toObject(target);
    var aLen = arguments.length;
    var index = 1;
    var getSymbols = gOPS.f;
    var isEnum = pIE.f;
    while (aLen > index) {
      var S = IObject(arguments[index++]);
      var keys = getSymbols ? getKeys(S).concat(getSymbols(S)) : getKeys(S);
      var length = keys.length;
      var j = 0;
      var key;
      while (length > j) if (isEnum.call(S, key = keys[j++])) T[key] = S[key];
    } return T;
  } : $assign;
  
  },{"./_fails":37,"./_iobject":43,"./_object-gops":59,"./_object-keys":62,"./_object-pie":63,"./_to-object":75}],53:[function(require,module,exports){
  // 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
  var anObject = require('./_an-object');
  var dPs = require('./_object-dps');
  var enumBugKeys = require('./_enum-bug-keys');
  var IE_PROTO = require('./_shared-key')('IE_PROTO');
  var Empty = function () { /* empty */ };
  var PROTOTYPE = 'prototype';
  
  // Create object with fake `null` prototype: use iframe Object with cleared prototype
  var createDict = function () {
    // Thrash, waste and sodomy: IE GC bug
    var iframe = require('./_dom-create')('iframe');
    var i = enumBugKeys.length;
    var lt = '<';
    var gt = '>';
    var iframeDocument;
    iframe.style.display = 'none';
    require('./_html').appendChild(iframe);
    iframe.src = 'javascript:'; // eslint-disable-line no-script-url
    // createDict = iframe.contentWindow.Object;
    // html.removeChild(iframe);
    iframeDocument = iframe.contentWindow.document;
    iframeDocument.open();
    iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
    iframeDocument.close();
    createDict = iframeDocument.F;
    while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
    return createDict();
  };
  
  module.exports = Object.create || function create(O, Properties) {
    var result;
    if (O !== null) {
      Empty[PROTOTYPE] = anObject(O);
      result = new Empty();
      Empty[PROTOTYPE] = null;
      // add "__proto__" for Object.getPrototypeOf polyfill
      result[IE_PROTO] = O;
    } else result = createDict();
    return Properties === undefined ? result : dPs(result, Properties);
  };
  
  },{"./_an-object":26,"./_dom-create":33,"./_enum-bug-keys":34,"./_html":41,"./_object-dps":55,"./_shared-key":68}],54:[function(require,module,exports){
  var anObject = require('./_an-object');
  var IE8_DOM_DEFINE = require('./_ie8-dom-define');
  var toPrimitive = require('./_to-primitive');
  var dP = Object.defineProperty;
  
  exports.f = require('./_descriptors') ? Object.defineProperty : function defineProperty(O, P, Attributes) {
    anObject(O);
    P = toPrimitive(P, true);
    anObject(Attributes);
    if (IE8_DOM_DEFINE) try {
      return dP(O, P, Attributes);
    } catch (e) { /* empty */ }
    if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
    if ('value' in Attributes) O[P] = Attributes.value;
    return O;
  };
  
  },{"./_an-object":26,"./_descriptors":32,"./_ie8-dom-define":42,"./_to-primitive":76}],55:[function(require,module,exports){
  var dP = require('./_object-dp');
  var anObject = require('./_an-object');
  var getKeys = require('./_object-keys');
  
  module.exports = require('./_descriptors') ? Object.defineProperties : function defineProperties(O, Properties) {
    anObject(O);
    var keys = getKeys(Properties);
    var length = keys.length;
    var i = 0;
    var P;
    while (length > i) dP.f(O, P = keys[i++], Properties[P]);
    return O;
  };
  
  },{"./_an-object":26,"./_descriptors":32,"./_object-dp":54,"./_object-keys":62}],56:[function(require,module,exports){
  var pIE = require('./_object-pie');
  var createDesc = require('./_property-desc');
  var toIObject = require('./_to-iobject');
  var toPrimitive = require('./_to-primitive');
  var has = require('./_has');
  var IE8_DOM_DEFINE = require('./_ie8-dom-define');
  var gOPD = Object.getOwnPropertyDescriptor;
  
  exports.f = require('./_descriptors') ? gOPD : function getOwnPropertyDescriptor(O, P) {
    O = toIObject(O);
    P = toPrimitive(P, true);
    if (IE8_DOM_DEFINE) try {
      return gOPD(O, P);
    } catch (e) { /* empty */ }
    if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
  };
  
  },{"./_descriptors":32,"./_has":39,"./_ie8-dom-define":42,"./_object-pie":63,"./_property-desc":64,"./_to-iobject":73,"./_to-primitive":76}],57:[function(require,module,exports){
  // fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
  var toIObject = require('./_to-iobject');
  var gOPN = require('./_object-gopn').f;
  var toString = {}.toString;
  
  var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
    ? Object.getOwnPropertyNames(window) : [];
  
  var getWindowNames = function (it) {
    try {
      return gOPN(it);
    } catch (e) {
      return windowNames.slice();
    }
  };
  
  module.exports.f = function getOwnPropertyNames(it) {
    return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
  };
  
  },{"./_object-gopn":58,"./_to-iobject":73}],58:[function(require,module,exports){
  // 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
  var $keys = require('./_object-keys-internal');
  var hiddenKeys = require('./_enum-bug-keys').concat('length', 'prototype');
  
  exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
    return $keys(O, hiddenKeys);
  };
  
  },{"./_enum-bug-keys":34,"./_object-keys-internal":61}],59:[function(require,module,exports){
  exports.f = Object.getOwnPropertySymbols;
  
  },{}],60:[function(require,module,exports){
  // 19.1.2.9 / 15.2.3.2 Object.getPrototypeOf(O)
  var has = require('./_has');
  var toObject = require('./_to-object');
  var IE_PROTO = require('./_shared-key')('IE_PROTO');
  var ObjectProto = Object.prototype;
  
  module.exports = Object.getPrototypeOf || function (O) {
    O = toObject(O);
    if (has(O, IE_PROTO)) return O[IE_PROTO];
    if (typeof O.constructor == 'function' && O instanceof O.constructor) {
      return O.constructor.prototype;
    } return O instanceof Object ? ObjectProto : null;
  };
  
  },{"./_has":39,"./_shared-key":68,"./_to-object":75}],61:[function(require,module,exports){
  var has = require('./_has');
  var toIObject = require('./_to-iobject');
  var arrayIndexOf = require('./_array-includes')(false);
  var IE_PROTO = require('./_shared-key')('IE_PROTO');
  
  module.exports = function (object, names) {
    var O = toIObject(object);
    var i = 0;
    var result = [];
    var key;
    for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
    // Don't enum bug & hidden keys
    while (names.length > i) if (has(O, key = names[i++])) {
      ~arrayIndexOf(result, key) || result.push(key);
    }
    return result;
  };
  
  },{"./_array-includes":27,"./_has":39,"./_shared-key":68,"./_to-iobject":73}],62:[function(require,module,exports){
  // 19.1.2.14 / 15.2.3.14 Object.keys(O)
  var $keys = require('./_object-keys-internal');
  var enumBugKeys = require('./_enum-bug-keys');
  
  module.exports = Object.keys || function keys(O) {
    return $keys(O, enumBugKeys);
  };
  
  },{"./_enum-bug-keys":34,"./_object-keys-internal":61}],63:[function(require,module,exports){
  exports.f = {}.propertyIsEnumerable;
  
  },{}],64:[function(require,module,exports){
  module.exports = function (bitmap, value) {
    return {
      enumerable: !(bitmap & 1),
      configurable: !(bitmap & 2),
      writable: !(bitmap & 4),
      value: value
    };
  };
  
  },{}],65:[function(require,module,exports){
  module.exports = require('./_hide');
  
  },{"./_hide":40}],66:[function(require,module,exports){
  // Works with __proto__ only. Old v8 can't work with null proto objects.
  /* eslint-disable no-proto */
  var isObject = require('./_is-object');
  var anObject = require('./_an-object');
  var check = function (O, proto) {
    anObject(O);
    if (!isObject(proto) && proto !== null) throw TypeError(proto + ": can't set as prototype!");
  };
  module.exports = {
    set: Object.setPrototypeOf || ('__proto__' in {} ? // eslint-disable-line
      function (test, buggy, set) {
        try {
          set = require('./_ctx')(Function.call, require('./_object-gopd').f(Object.prototype, '__proto__').set, 2);
          set(test, []);
          buggy = !(test instanceof Array);
        } catch (e) { buggy = true; }
        return function setPrototypeOf(O, proto) {
          check(O, proto);
          if (buggy) O.__proto__ = proto;
          else set(O, proto);
          return O;
        };
      }({}, false) : undefined),
    check: check
  };
  
  },{"./_an-object":26,"./_ctx":30,"./_is-object":45,"./_object-gopd":56}],67:[function(require,module,exports){
  var def = require('./_object-dp').f;
  var has = require('./_has');
  var TAG = require('./_wks')('toStringTag');
  
  module.exports = function (it, tag, stat) {
    if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
  };
  
  },{"./_has":39,"./_object-dp":54,"./_wks":80}],68:[function(require,module,exports){
  var shared = require('./_shared')('keys');
  var uid = require('./_uid');
  module.exports = function (key) {
    return shared[key] || (shared[key] = uid(key));
  };
  
  },{"./_shared":69,"./_uid":77}],69:[function(require,module,exports){
  var core = require('./_core');
  var global = require('./_global');
  var SHARED = '__core-js_shared__';
  var store = global[SHARED] || (global[SHARED] = {});
  
  (module.exports = function (key, value) {
    return store[key] || (store[key] = value !== undefined ? value : {});
  })('versions', []).push({
    version: core.version,
    mode: require('./_library') ? 'pure' : 'global',
    copyright: '© 2018 Denis Pushkarev (zloirock.ru)'
  });
  
  },{"./_core":29,"./_global":38,"./_library":50}],70:[function(require,module,exports){
  var toInteger = require('./_to-integer');
  var defined = require('./_defined');
  // true  -> String#at
  // false -> String#codePointAt
  module.exports = function (TO_STRING) {
    return function (that, pos) {
      var s = String(defined(that));
      var i = toInteger(pos);
      var l = s.length;
      var a, b;
      if (i < 0 || i >= l) return TO_STRING ? '' : undefined;
      a = s.charCodeAt(i);
      return a < 0xd800 || a > 0xdbff || i + 1 === l || (b = s.charCodeAt(i + 1)) < 0xdc00 || b > 0xdfff
        ? TO_STRING ? s.charAt(i) : a
        : TO_STRING ? s.slice(i, i + 2) : (a - 0xd800 << 10) + (b - 0xdc00) + 0x10000;
    };
  };
  
  },{"./_defined":31,"./_to-integer":72}],71:[function(require,module,exports){
  var toInteger = require('./_to-integer');
  var max = Math.max;
  var min = Math.min;
  module.exports = function (index, length) {
    index = toInteger(index);
    return index < 0 ? max(index + length, 0) : min(index, length);
  };
  
  },{"./_to-integer":72}],72:[function(require,module,exports){
  // 7.1.4 ToInteger
  var ceil = Math.ceil;
  var floor = Math.floor;
  module.exports = function (it) {
    return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
  };
  
  },{}],73:[function(require,module,exports){
  // to indexed object, toObject with fallback for non-array-like ES3 strings
  var IObject = require('./_iobject');
  var defined = require('./_defined');
  module.exports = function (it) {
    return IObject(defined(it));
  };
  
  },{"./_defined":31,"./_iobject":43}],74:[function(require,module,exports){
  // 7.1.15 ToLength
  var toInteger = require('./_to-integer');
  var min = Math.min;
  module.exports = function (it) {
    return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
  };
  
  },{"./_to-integer":72}],75:[function(require,module,exports){
  // 7.1.13 ToObject(argument)
  var defined = require('./_defined');
  module.exports = function (it) {
    return Object(defined(it));
  };
  
  },{"./_defined":31}],76:[function(require,module,exports){
  // 7.1.1 ToPrimitive(input [, PreferredType])
  var isObject = require('./_is-object');
  // instead of the ES6 spec version, we didn't implement @@toPrimitive case
  // and the second argument - flag - preferred type is a string
  module.exports = function (it, S) {
    if (!isObject(it)) return it;
    var fn, val;
    if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
    if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
    if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
    throw TypeError("Can't convert object to primitive value");
  };
  
  },{"./_is-object":45}],77:[function(require,module,exports){
  var id = 0;
  var px = Math.random();
  module.exports = function (key) {
    return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
  };
  
  },{}],78:[function(require,module,exports){
  var global = require('./_global');
  var core = require('./_core');
  var LIBRARY = require('./_library');
  var wksExt = require('./_wks-ext');
  var defineProperty = require('./_object-dp').f;
  module.exports = function (name) {
    var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
    if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
  };
  
  },{"./_core":29,"./_global":38,"./_library":50,"./_object-dp":54,"./_wks-ext":79}],79:[function(require,module,exports){
  exports.f = require('./_wks');
  
  },{"./_wks":80}],80:[function(require,module,exports){
  var store = require('./_shared')('wks');
  var uid = require('./_uid');
  var Symbol = require('./_global').Symbol;
  var USE_SYMBOL = typeof Symbol == 'function';
  
  var $exports = module.exports = function (name) {
    return store[name] || (store[name] =
      USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
  };
  
  $exports.store = store;
  
  },{"./_global":38,"./_shared":69,"./_uid":77}],81:[function(require,module,exports){
  'use strict';
  var addToUnscopables = require('./_add-to-unscopables');
  var step = require('./_iter-step');
  var Iterators = require('./_iterators');
  var toIObject = require('./_to-iobject');
  
  // 22.1.3.4 Array.prototype.entries()
  // 22.1.3.13 Array.prototype.keys()
  // 22.1.3.29 Array.prototype.values()
  // 22.1.3.30 Array.prototype[@@iterator]()
  module.exports = require('./_iter-define')(Array, 'Array', function (iterated, kind) {
    this._t = toIObject(iterated); // target
    this._i = 0;                   // next index
    this._k = kind;                // kind
  // 22.1.5.2.1 %ArrayIteratorPrototype%.next()
  }, function () {
    var O = this._t;
    var kind = this._k;
    var index = this._i++;
    if (!O || index >= O.length) {
      this._t = undefined;
      return step(1);
    }
    if (kind == 'keys') return step(0, index);
    if (kind == 'values') return step(0, O[index]);
    return step(0, [index, O[index]]);
  }, 'values');
  
  // argumentsList[@@iterator] is %ArrayProto_values% (9.4.4.6, 9.4.4.7)
  Iterators.Arguments = Iterators.Array;
  
  addToUnscopables('keys');
  addToUnscopables('values');
  addToUnscopables('entries');
  
  },{"./_add-to-unscopables":25,"./_iter-define":47,"./_iter-step":48,"./_iterators":49,"./_to-iobject":73}],82:[function(require,module,exports){
  // 19.1.3.1 Object.assign(target, source)
  var $export = require('./_export');
  
  $export($export.S + $export.F, 'Object', { assign: require('./_object-assign') });
  
  },{"./_export":36,"./_object-assign":52}],83:[function(require,module,exports){
  var $export = require('./_export');
  // 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
  $export($export.S, 'Object', { create: require('./_object-create') });
  
  },{"./_export":36,"./_object-create":53}],84:[function(require,module,exports){
  // 19.1.3.19 Object.setPrototypeOf(O, proto)
  var $export = require('./_export');
  $export($export.S, 'Object', { setPrototypeOf: require('./_set-proto').set });
  
  },{"./_export":36,"./_set-proto":66}],85:[function(require,module,exports){
  
  },{}],86:[function(require,module,exports){
  'use strict';
  var $at = require('./_string-at')(true);
  
  // 21.1.3.27 String.prototype[@@iterator]()
  require('./_iter-define')(String, 'String', function (iterated) {
    this._t = String(iterated); // target
    this._i = 0;                // next index
  // 21.1.5.2.1 %StringIteratorPrototype%.next()
  }, function () {
    var O = this._t;
    var index = this._i;
    var point;
    if (index >= O.length) return { value: undefined, done: true };
    point = $at(O, index);
    this._i += point.length;
    return { value: point, done: false };
  });
  
  },{"./_iter-define":47,"./_string-at":70}],87:[function(require,module,exports){
  'use strict';
  // ECMAScript 6 symbols shim
  var global = require('./_global');
  var has = require('./_has');
  var DESCRIPTORS = require('./_descriptors');
  var $export = require('./_export');
  var redefine = require('./_redefine');
  var META = require('./_meta').KEY;
  var $fails = require('./_fails');
  var shared = require('./_shared');
  var setToStringTag = require('./_set-to-string-tag');
  var uid = require('./_uid');
  var wks = require('./_wks');
  var wksExt = require('./_wks-ext');
  var wksDefine = require('./_wks-define');
  var enumKeys = require('./_enum-keys');
  var isArray = require('./_is-array');
  var anObject = require('./_an-object');
  var isObject = require('./_is-object');
  var toIObject = require('./_to-iobject');
  var toPrimitive = require('./_to-primitive');
  var createDesc = require('./_property-desc');
  var _create = require('./_object-create');
  var gOPNExt = require('./_object-gopn-ext');
  var $GOPD = require('./_object-gopd');
  var $DP = require('./_object-dp');
  var $keys = require('./_object-keys');
  var gOPD = $GOPD.f;
  var dP = $DP.f;
  var gOPN = gOPNExt.f;
  var $Symbol = global.Symbol;
  var $JSON = global.JSON;
  var _stringify = $JSON && $JSON.stringify;
  var PROTOTYPE = 'prototype';
  var HIDDEN = wks('_hidden');
  var TO_PRIMITIVE = wks('toPrimitive');
  var isEnum = {}.propertyIsEnumerable;
  var SymbolRegistry = shared('symbol-registry');
  var AllSymbols = shared('symbols');
  var OPSymbols = shared('op-symbols');
  var ObjectProto = Object[PROTOTYPE];
  var USE_NATIVE = typeof $Symbol == 'function';
  var QObject = global.QObject;
  // Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
  var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;
  
  // fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
  var setSymbolDesc = DESCRIPTORS && $fails(function () {
    return _create(dP({}, 'a', {
      get: function () { return dP(this, 'a', { value: 7 }).a; }
    })).a != 7;
  }) ? function (it, key, D) {
    var protoDesc = gOPD(ObjectProto, key);
    if (protoDesc) delete ObjectProto[key];
    dP(it, key, D);
    if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
  } : dP;
  
  var wrap = function (tag) {
    var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
    sym._k = tag;
    return sym;
  };
  
  var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
    return typeof it == 'symbol';
  } : function (it) {
    return it instanceof $Symbol;
  };
  
  var $defineProperty = function defineProperty(it, key, D) {
    if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
    anObject(it);
    key = toPrimitive(key, true);
    anObject(D);
    if (has(AllSymbols, key)) {
      if (!D.enumerable) {
        if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
        it[HIDDEN][key] = true;
      } else {
        if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
        D = _create(D, { enumerable: createDesc(0, false) });
      } return setSymbolDesc(it, key, D);
    } return dP(it, key, D);
  };
  var $defineProperties = function defineProperties(it, P) {
    anObject(it);
    var keys = enumKeys(P = toIObject(P));
    var i = 0;
    var l = keys.length;
    var key;
    while (l > i) $defineProperty(it, key = keys[i++], P[key]);
    return it;
  };
  var $create = function create(it, P) {
    return P === undefined ? _create(it) : $defineProperties(_create(it), P);
  };
  var $propertyIsEnumerable = function propertyIsEnumerable(key) {
    var E = isEnum.call(this, key = toPrimitive(key, true));
    if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
    return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
  };
  var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
    it = toIObject(it);
    key = toPrimitive(key, true);
    if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
    var D = gOPD(it, key);
    if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
    return D;
  };
  var $getOwnPropertyNames = function getOwnPropertyNames(it) {
    var names = gOPN(toIObject(it));
    var result = [];
    var i = 0;
    var key;
    while (names.length > i) {
      if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
    } return result;
  };
  var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
    var IS_OP = it === ObjectProto;
    var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
    var result = [];
    var i = 0;
    var key;
    while (names.length > i) {
      if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
    } return result;
  };
  
  // 19.4.1.1 Symbol([description])
  if (!USE_NATIVE) {
    $Symbol = function Symbol() {
      if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
      var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
      var $set = function (value) {
        if (this === ObjectProto) $set.call(OPSymbols, value);
        if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
        setSymbolDesc(this, tag, createDesc(1, value));
      };
      if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
      return wrap(tag);
    };
    redefine($Symbol[PROTOTYPE], 'toString', function toString() {
      return this._k;
    });
  
    $GOPD.f = $getOwnPropertyDescriptor;
    $DP.f = $defineProperty;
    require('./_object-gopn').f = gOPNExt.f = $getOwnPropertyNames;
    require('./_object-pie').f = $propertyIsEnumerable;
    require('./_object-gops').f = $getOwnPropertySymbols;
  
    if (DESCRIPTORS && !require('./_library')) {
      redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
    }
  
    wksExt.f = function (name) {
      return wrap(wks(name));
    };
  }
  
  $export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });
  
  for (var es6Symbols = (
    // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
    'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
  ).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);
  
  for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);
  
  $export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
    // 19.4.2.1 Symbol.for(key)
    'for': function (key) {
      return has(SymbolRegistry, key += '')
        ? SymbolRegistry[key]
        : SymbolRegistry[key] = $Symbol(key);
    },
    // 19.4.2.5 Symbol.keyFor(sym)
    keyFor: function keyFor(sym) {
      if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
      for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
    },
    useSetter: function () { setter = true; },
    useSimple: function () { setter = false; }
  });
  
  $export($export.S + $export.F * !USE_NATIVE, 'Object', {
    // 19.1.2.2 Object.create(O [, Properties])
    create: $create,
    // 19.1.2.4 Object.defineProperty(O, P, Attributes)
    defineProperty: $defineProperty,
    // 19.1.2.3 Object.defineProperties(O, Properties)
    defineProperties: $defineProperties,
    // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
    getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
    // 19.1.2.7 Object.getOwnPropertyNames(O)
    getOwnPropertyNames: $getOwnPropertyNames,
    // 19.1.2.8 Object.getOwnPropertySymbols(O)
    getOwnPropertySymbols: $getOwnPropertySymbols
  });
  
  // 24.3.2 JSON.stringify(value [, replacer [, space]])
  $JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
    var S = $Symbol();
    // MS Edge converts symbol values to JSON as {}
    // WebKit converts symbol values to JSON as null
    // V8 throws on boxed symbols
    return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
  })), 'JSON', {
    stringify: function stringify(it) {
      var args = [it];
      var i = 1;
      var replacer, $replacer;
      while (arguments.length > i) args.push(arguments[i++]);
      $replacer = replacer = args[1];
      if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
      if (!isArray(replacer)) replacer = function (key, value) {
        if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
        if (!isSymbol(value)) return value;
      };
      args[1] = replacer;
      return _stringify.apply($JSON, args);
    }
  });
  
  // 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
  $Symbol[PROTOTYPE][TO_PRIMITIVE] || require('./_hide')($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
  // 19.4.3.5 Symbol.prototype[@@toStringTag]
  setToStringTag($Symbol, 'Symbol');
  // 20.2.1.9 Math[@@toStringTag]
  setToStringTag(Math, 'Math', true);
  // 24.3.3 JSON[@@toStringTag]
  setToStringTag(global.JSON, 'JSON', true);
  
  },{"./_an-object":26,"./_descriptors":32,"./_enum-keys":35,"./_export":36,"./_fails":37,"./_global":38,"./_has":39,"./_hide":40,"./_is-array":44,"./_is-object":45,"./_library":50,"./_meta":51,"./_object-create":53,"./_object-dp":54,"./_object-gopd":56,"./_object-gopn":58,"./_object-gopn-ext":57,"./_object-gops":59,"./_object-keys":62,"./_object-pie":63,"./_property-desc":64,"./_redefine":65,"./_set-to-string-tag":67,"./_shared":69,"./_to-iobject":73,"./_to-primitive":76,"./_uid":77,"./_wks":80,"./_wks-define":78,"./_wks-ext":79}],88:[function(require,module,exports){
  require('./_wks-define')('asyncIterator');
  
  },{"./_wks-define":78}],89:[function(require,module,exports){
  require('./_wks-define')('observable');
  
  },{"./_wks-define":78}],90:[function(require,module,exports){
  require('./es6.array.iterator');
  var global = require('./_global');
  var hide = require('./_hide');
  var Iterators = require('./_iterators');
  var TO_STRING_TAG = require('./_wks')('toStringTag');
  
  var DOMIterables = ('CSSRuleList,CSSStyleDeclaration,CSSValueList,ClientRectList,DOMRectList,DOMStringList,' +
    'DOMTokenList,DataTransferItemList,FileList,HTMLAllCollection,HTMLCollection,HTMLFormElement,HTMLSelectElement,' +
    'MediaList,MimeTypeArray,NamedNodeMap,NodeList,PaintRequestList,Plugin,PluginArray,SVGLengthList,SVGNumberList,' +
    'SVGPathSegList,SVGPointList,SVGStringList,SVGTransformList,SourceBufferList,StyleSheetList,TextTrackCueList,' +
    'TextTrackList,TouchList').split(',');
  
  for (var i = 0; i < DOMIterables.length; i++) {
    var NAME = DOMIterables[i];
    var Collection = global[NAME];
    var proto = Collection && Collection.prototype;
    if (proto && !proto[TO_STRING_TAG]) hide(proto, TO_STRING_TAG, NAME);
    Iterators[NAME] = Iterators.Array;
  }
  
  },{"./_global":38,"./_hide":40,"./_iterators":49,"./_wks":80,"./es6.array.iterator":81}],91:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _assign = require('object-assign');
  
  var emptyObject = require('fbjs/lib/emptyObject');
  var _invariant = require('fbjs/lib/invariant');
  
  if (process.env.NODE_ENV !== 'production') {
    var warning = require('fbjs/lib/warning');
  }
  
  var MIXINS_KEY = 'mixins';
  
  // Helper function to allow the creation of anonymous functions which do not
  // have .name set to the name of the variable being assigned to.
  function identity(fn) {
    return fn;
  }
  
  var ReactPropTypeLocationNames;
  if (process.env.NODE_ENV !== 'production') {
    ReactPropTypeLocationNames = {
      prop: 'prop',
      context: 'context',
      childContext: 'child context'
    };
  } else {
    ReactPropTypeLocationNames = {};
  }
  
  function factory(ReactComponent, isValidElement, ReactNoopUpdateQueue) {
    /**
     * Policies that describe methods in `ReactClassInterface`.
     */
  
    var injectedMixins = [];
  
    /**
     * Composite components are higher-level components that compose other composite
     * or host components.
     *
     * To create a new type of `ReactClass`, pass a specification of
     * your new class to `React.createClass`. The only requirement of your class
     * specification is that you implement a `render` method.
     *
     *   var MyComponent = React.createClass({
     *     render: function() {
     *       return <div>Hello World</div>;
     *     }
     *   });
     *
     * The class specification supports a specific protocol of methods that have
     * special meaning (e.g. `render`). See `ReactClassInterface` for
     * more the comprehensive protocol. Any other properties and methods in the
     * class specification will be available on the prototype.
     *
     * @interface ReactClassInterface
     * @internal
     */
    var ReactClassInterface = {
      /**
       * An array of Mixin objects to include when defining your component.
       *
       * @type {array}
       * @optional
       */
      mixins: 'DEFINE_MANY',
  
      /**
       * An object containing properties and methods that should be defined on
       * the component's constructor instead of its prototype (static methods).
       *
       * @type {object}
       * @optional
       */
      statics: 'DEFINE_MANY',
  
      /**
       * Definition of prop types for this component.
       *
       * @type {object}
       * @optional
       */
      propTypes: 'DEFINE_MANY',
  
      /**
       * Definition of context types for this component.
       *
       * @type {object}
       * @optional
       */
      contextTypes: 'DEFINE_MANY',
  
      /**
       * Definition of context types this component sets for its children.
       *
       * @type {object}
       * @optional
       */
      childContextTypes: 'DEFINE_MANY',
  
      // ==== Definition methods ====
  
      /**
       * Invoked when the component is mounted. Values in the mapping will be set on
       * `this.props` if that prop is not specified (i.e. using an `in` check).
       *
       * This method is invoked before `getInitialState` and therefore cannot rely
       * on `this.state` or use `this.setState`.
       *
       * @return {object}
       * @optional
       */
      getDefaultProps: 'DEFINE_MANY_MERGED',
  
      /**
       * Invoked once before the component is mounted. The return value will be used
       * as the initial value of `this.state`.
       *
       *   getInitialState: function() {
       *     return {
       *       isOn: false,
       *       fooBaz: new BazFoo()
       *     }
       *   }
       *
       * @return {object}
       * @optional
       */
      getInitialState: 'DEFINE_MANY_MERGED',
  
      /**
       * @return {object}
       * @optional
       */
      getChildContext: 'DEFINE_MANY_MERGED',
  
      /**
       * Uses props from `this.props` and state from `this.state` to render the
       * structure of the component.
       *
       * No guarantees are made about when or how often this method is invoked, so
       * it must not have side effects.
       *
       *   render: function() {
       *     var name = this.props.name;
       *     return <div>Hello, {name}!</div>;
       *   }
       *
       * @return {ReactComponent}
       * @required
       */
      render: 'DEFINE_ONCE',
  
      // ==== Delegate methods ====
  
      /**
       * Invoked when the component is initially created and about to be mounted.
       * This may have side effects, but any external subscriptions or data created
       * by this method must be cleaned up in `componentWillUnmount`.
       *
       * @optional
       */
      componentWillMount: 'DEFINE_MANY',
  
      /**
       * Invoked when the component has been mounted and has a DOM representation.
       * However, there is no guarantee that the DOM node is in the document.
       *
       * Use this as an opportunity to operate on the DOM when the component has
       * been mounted (initialized and rendered) for the first time.
       *
       * @param {DOMElement} rootNode DOM element representing the component.
       * @optional
       */
      componentDidMount: 'DEFINE_MANY',
  
      /**
       * Invoked before the component receives new props.
       *
       * Use this as an opportunity to react to a prop transition by updating the
       * state using `this.setState`. Current props are accessed via `this.props`.
       *
       *   componentWillReceiveProps: function(nextProps, nextContext) {
       *     this.setState({
       *       likesIncreasing: nextProps.likeCount > this.props.likeCount
       *     });
       *   }
       *
       * NOTE: There is no equivalent `componentWillReceiveState`. An incoming prop
       * transition may cause a state change, but the opposite is not true. If you
       * need it, you are probably looking for `componentWillUpdate`.
       *
       * @param {object} nextProps
       * @optional
       */
      componentWillReceiveProps: 'DEFINE_MANY',
  
      /**
       * Invoked while deciding if the component should be updated as a result of
       * receiving new props, state and/or context.
       *
       * Use this as an opportunity to `return false` when you're certain that the
       * transition to the new props/state/context will not require a component
       * update.
       *
       *   shouldComponentUpdate: function(nextProps, nextState, nextContext) {
       *     return !equal(nextProps, this.props) ||
       *       !equal(nextState, this.state) ||
       *       !equal(nextContext, this.context);
       *   }
       *
       * @param {object} nextProps
       * @param {?object} nextState
       * @param {?object} nextContext
       * @return {boolean} True if the component should update.
       * @optional
       */
      shouldComponentUpdate: 'DEFINE_ONCE',
  
      /**
       * Invoked when the component is about to update due to a transition from
       * `this.props`, `this.state` and `this.context` to `nextProps`, `nextState`
       * and `nextContext`.
       *
       * Use this as an opportunity to perform preparation before an update occurs.
       *
       * NOTE: You **cannot** use `this.setState()` in this method.
       *
       * @param {object} nextProps
       * @param {?object} nextState
       * @param {?object} nextContext
       * @param {ReactReconcileTransaction} transaction
       * @optional
       */
      componentWillUpdate: 'DEFINE_MANY',
  
      /**
       * Invoked when the component's DOM representation has been updated.
       *
       * Use this as an opportunity to operate on the DOM when the component has
       * been updated.
       *
       * @param {object} prevProps
       * @param {?object} prevState
       * @param {?object} prevContext
       * @param {DOMElement} rootNode DOM element representing the component.
       * @optional
       */
      componentDidUpdate: 'DEFINE_MANY',
  
      /**
       * Invoked when the component is about to be removed from its parent and have
       * its DOM representation destroyed.
       *
       * Use this as an opportunity to deallocate any external resources.
       *
       * NOTE: There is no `componentDidUnmount` since your component will have been
       * destroyed by that point.
       *
       * @optional
       */
      componentWillUnmount: 'DEFINE_MANY',
  
      /**
       * Replacement for (deprecated) `componentWillMount`.
       *
       * @optional
       */
      UNSAFE_componentWillMount: 'DEFINE_MANY',
  
      /**
       * Replacement for (deprecated) `componentWillReceiveProps`.
       *
       * @optional
       */
      UNSAFE_componentWillReceiveProps: 'DEFINE_MANY',
  
      /**
       * Replacement for (deprecated) `componentWillUpdate`.
       *
       * @optional
       */
      UNSAFE_componentWillUpdate: 'DEFINE_MANY',
  
      // ==== Advanced methods ====
  
      /**
       * Updates the component's currently mounted DOM representation.
       *
       * By default, this implements React's rendering and reconciliation algorithm.
       * Sophisticated clients may wish to override this.
       *
       * @param {ReactReconcileTransaction} transaction
       * @internal
       * @overridable
       */
      updateComponent: 'OVERRIDE_BASE'
    };
  
    /**
     * Similar to ReactClassInterface but for static methods.
     */
    var ReactClassStaticInterface = {
      /**
       * This method is invoked after a component is instantiated and when it
       * receives new props. Return an object to update state in response to
       * prop changes. Return null to indicate no change to state.
       *
       * If an object is returned, its keys will be merged into the existing state.
       *
       * @return {object || null}
       * @optional
       */
      getDerivedStateFromProps: 'DEFINE_MANY_MERGED'
    };
  
    /**
     * Mapping from class specification keys to special processing functions.
     *
     * Although these are declared like instance properties in the specification
     * when defining classes using `React.createClass`, they are actually static
     * and are accessible on the constructor instead of the prototype. Despite
     * being static, they must be defined outside of the "statics" key under
     * which all other static methods are defined.
     */
    var RESERVED_SPEC_KEYS = {
      displayName: function(Constructor, displayName) {
        Constructor.displayName = displayName;
      },
      mixins: function(Constructor, mixins) {
        if (mixins) {
          for (var i = 0; i < mixins.length; i++) {
            mixSpecIntoComponent(Constructor, mixins[i]);
          }
        }
      },
      childContextTypes: function(Constructor, childContextTypes) {
        if (process.env.NODE_ENV !== 'production') {
          validateTypeDef(Constructor, childContextTypes, 'childContext');
        }
        Constructor.childContextTypes = _assign(
          {},
          Constructor.childContextTypes,
          childContextTypes
        );
      },
      contextTypes: function(Constructor, contextTypes) {
        if (process.env.NODE_ENV !== 'production') {
          validateTypeDef(Constructor, contextTypes, 'context');
        }
        Constructor.contextTypes = _assign(
          {},
          Constructor.contextTypes,
          contextTypes
        );
      },
      /**
       * Special case getDefaultProps which should move into statics but requires
       * automatic merging.
       */
      getDefaultProps: function(Constructor, getDefaultProps) {
        if (Constructor.getDefaultProps) {
          Constructor.getDefaultProps = createMergedResultFunction(
            Constructor.getDefaultProps,
            getDefaultProps
          );
        } else {
          Constructor.getDefaultProps = getDefaultProps;
        }
      },
      propTypes: function(Constructor, propTypes) {
        if (process.env.NODE_ENV !== 'production') {
          validateTypeDef(Constructor, propTypes, 'prop');
        }
        Constructor.propTypes = _assign({}, Constructor.propTypes, propTypes);
      },
      statics: function(Constructor, statics) {
        mixStaticSpecIntoComponent(Constructor, statics);
      },
      autobind: function() {}
    };
  
    function validateTypeDef(Constructor, typeDef, location) {
      for (var propName in typeDef) {
        if (typeDef.hasOwnProperty(propName)) {
          // use a warning instead of an _invariant so components
          // don't show up in prod but only in __DEV__
          if (process.env.NODE_ENV !== 'production') {
            warning(
              typeof typeDef[propName] === 'function',
              '%s: %s type `%s` is invalid; it must be a function, usually from ' +
                'React.PropTypes.',
              Constructor.displayName || 'ReactClass',
              ReactPropTypeLocationNames[location],
              propName
            );
          }
        }
      }
    }
  
    function validateMethodOverride(isAlreadyDefined, name) {
      var specPolicy = ReactClassInterface.hasOwnProperty(name)
        ? ReactClassInterface[name]
        : null;
  
      // Disallow overriding of base class methods unless explicitly allowed.
      if (ReactClassMixin.hasOwnProperty(name)) {
        _invariant(
          specPolicy === 'OVERRIDE_BASE',
          'ReactClassInterface: You are attempting to override ' +
            '`%s` from your class specification. Ensure that your method names ' +
            'do not overlap with React methods.',
          name
        );
      }
  
      // Disallow defining methods more than once unless explicitly allowed.
      if (isAlreadyDefined) {
        _invariant(
          specPolicy === 'DEFINE_MANY' || specPolicy === 'DEFINE_MANY_MERGED',
          'ReactClassInterface: You are attempting to define ' +
            '`%s` on your component more than once. This conflict may be due ' +
            'to a mixin.',
          name
        );
      }
    }
  
    /**
     * Mixin helper which handles policy validation and reserved
     * specification keys when building React classes.
     */
    function mixSpecIntoComponent(Constructor, spec) {
      if (!spec) {
        if (process.env.NODE_ENV !== 'production') {
          var typeofSpec = typeof spec;
          var isMixinValid = typeofSpec === 'object' && spec !== null;
  
          if (process.env.NODE_ENV !== 'production') {
            warning(
              isMixinValid,
              "%s: You're attempting to include a mixin that is either null " +
                'or not an object. Check the mixins included by the component, ' +
                'as well as any mixins they include themselves. ' +
                'Expected object but got %s.',
              Constructor.displayName || 'ReactClass',
              spec === null ? null : typeofSpec
            );
          }
        }
  
        return;
      }
  
      _invariant(
        typeof spec !== 'function',
        "ReactClass: You're attempting to " +
          'use a component class or function as a mixin. Instead, just use a ' +
          'regular object.'
      );
      _invariant(
        !isValidElement(spec),
        "ReactClass: You're attempting to " +
          'use a component as a mixin. Instead, just use a regular object.'
      );
  
      var proto = Constructor.prototype;
      var autoBindPairs = proto.__reactAutoBindPairs;
  
      // By handling mixins before any other properties, we ensure the same
      // chaining order is applied to methods with DEFINE_MANY policy, whether
      // mixins are listed before or after these methods in the spec.
      if (spec.hasOwnProperty(MIXINS_KEY)) {
        RESERVED_SPEC_KEYS.mixins(Constructor, spec.mixins);
      }
  
      for (var name in spec) {
        if (!spec.hasOwnProperty(name)) {
          continue;
        }
  
        if (name === MIXINS_KEY) {
          // We have already handled mixins in a special case above.
          continue;
        }
  
        var property = spec[name];
        var isAlreadyDefined = proto.hasOwnProperty(name);
        validateMethodOverride(isAlreadyDefined, name);
  
        if (RESERVED_SPEC_KEYS.hasOwnProperty(name)) {
          RESERVED_SPEC_KEYS[name](Constructor, property);
        } else {
          // Setup methods on prototype:
          // The following member methods should not be automatically bound:
          // 1. Expected ReactClass methods (in the "interface").
          // 2. Overridden methods (that were mixed in).
          var isReactClassMethod = ReactClassInterface.hasOwnProperty(name);
          var isFunction = typeof property === 'function';
          var shouldAutoBind =
            isFunction &&
            !isReactClassMethod &&
            !isAlreadyDefined &&
            spec.autobind !== false;
  
          if (shouldAutoBind) {
            autoBindPairs.push(name, property);
            proto[name] = property;
          } else {
            if (isAlreadyDefined) {
              var specPolicy = ReactClassInterface[name];
  
              // These cases should already be caught by validateMethodOverride.
              _invariant(
                isReactClassMethod &&
                  (specPolicy === 'DEFINE_MANY_MERGED' ||
                    specPolicy === 'DEFINE_MANY'),
                'ReactClass: Unexpected spec policy %s for key %s ' +
                  'when mixing in component specs.',
                specPolicy,
                name
              );
  
              // For methods which are defined more than once, call the existing
              // methods before calling the new property, merging if appropriate.
              if (specPolicy === 'DEFINE_MANY_MERGED') {
                proto[name] = createMergedResultFunction(proto[name], property);
              } else if (specPolicy === 'DEFINE_MANY') {
                proto[name] = createChainedFunction(proto[name], property);
              }
            } else {
              proto[name] = property;
              if (process.env.NODE_ENV !== 'production') {
                // Add verbose displayName to the function, which helps when looking
                // at profiling tools.
                if (typeof property === 'function' && spec.displayName) {
                  proto[name].displayName = spec.displayName + '_' + name;
                }
              }
            }
          }
        }
      }
    }
  
    function mixStaticSpecIntoComponent(Constructor, statics) {
      if (!statics) {
        return;
      }
  
      for (var name in statics) {
        var property = statics[name];
        if (!statics.hasOwnProperty(name)) {
          continue;
        }
  
        var isReserved = name in RESERVED_SPEC_KEYS;
        _invariant(
          !isReserved,
          'ReactClass: You are attempting to define a reserved ' +
            'property, `%s`, that shouldn\'t be on the "statics" key. Define it ' +
            'as an instance property instead; it will still be accessible on the ' +
            'constructor.',
          name
        );
  
        var isAlreadyDefined = name in Constructor;
        if (isAlreadyDefined) {
          var specPolicy = ReactClassStaticInterface.hasOwnProperty(name)
            ? ReactClassStaticInterface[name]
            : null;
  
          _invariant(
            specPolicy === 'DEFINE_MANY_MERGED',
            'ReactClass: You are attempting to define ' +
              '`%s` on your component more than once. This conflict may be ' +
              'due to a mixin.',
            name
          );
  
          Constructor[name] = createMergedResultFunction(Constructor[name], property);
  
          return;
        }
  
        Constructor[name] = property;
      }
    }
  
    /**
     * Merge two objects, but throw if both contain the same key.
     *
     * @param {object} one The first object, which is mutated.
     * @param {object} two The second object
     * @return {object} one after it has been mutated to contain everything in two.
     */
    function mergeIntoWithNoDuplicateKeys(one, two) {
      _invariant(
        one && two && typeof one === 'object' && typeof two === 'object',
        'mergeIntoWithNoDuplicateKeys(): Cannot merge non-objects.'
      );
  
      for (var key in two) {
        if (two.hasOwnProperty(key)) {
          _invariant(
            one[key] === undefined,
            'mergeIntoWithNoDuplicateKeys(): ' +
              'Tried to merge two objects with the same key: `%s`. This conflict ' +
              'may be due to a mixin; in particular, this may be caused by two ' +
              'getInitialState() or getDefaultProps() methods returning objects ' +
              'with clashing keys.',
            key
          );
          one[key] = two[key];
        }
      }
      return one;
    }
  
    /**
     * Creates a function that invokes two functions and merges their return values.
     *
     * @param {function} one Function to invoke first.
     * @param {function} two Function to invoke second.
     * @return {function} Function that invokes the two argument functions.
     * @private
     */
    function createMergedResultFunction(one, two) {
      return function mergedResult() {
        var a = one.apply(this, arguments);
        var b = two.apply(this, arguments);
        if (a == null) {
          return b;
        } else if (b == null) {
          return a;
        }
        var c = {};
        mergeIntoWithNoDuplicateKeys(c, a);
        mergeIntoWithNoDuplicateKeys(c, b);
        return c;
      };
    }
  
    /**
     * Creates a function that invokes two functions and ignores their return vales.
     *
     * @param {function} one Function to invoke first.
     * @param {function} two Function to invoke second.
     * @return {function} Function that invokes the two argument functions.
     * @private
     */
    function createChainedFunction(one, two) {
      return function chainedFunction() {
        one.apply(this, arguments);
        two.apply(this, arguments);
      };
    }
  
    /**
     * Binds a method to the component.
     *
     * @param {object} component Component whose method is going to be bound.
     * @param {function} method Method to be bound.
     * @return {function} The bound method.
     */
    function bindAutoBindMethod(component, method) {
      var boundMethod = method.bind(component);
      if (process.env.NODE_ENV !== 'production') {
        boundMethod.__reactBoundContext = component;
        boundMethod.__reactBoundMethod = method;
        boundMethod.__reactBoundArguments = null;
        var componentName = component.constructor.displayName;
        var _bind = boundMethod.bind;
        boundMethod.bind = function(newThis) {
          for (
            var _len = arguments.length,
              args = Array(_len > 1 ? _len - 1 : 0),
              _key = 1;
            _key < _len;
            _key++
          ) {
            args[_key - 1] = arguments[_key];
          }
  
          // User is trying to bind() an autobound method; we effectively will
          // ignore the value of "this" that the user is trying to use, so
          // let's warn.
          if (newThis !== component && newThis !== null) {
            if (process.env.NODE_ENV !== 'production') {
              warning(
                false,
                'bind(): React component methods may only be bound to the ' +
                  'component instance. See %s',
                componentName
              );
            }
          } else if (!args.length) {
            if (process.env.NODE_ENV !== 'production') {
              warning(
                false,
                'bind(): You are binding a component method to the component. ' +
                  'React does this for you automatically in a high-performance ' +
                  'way, so you can safely remove this call. See %s',
                componentName
              );
            }
            return boundMethod;
          }
          var reboundMethod = _bind.apply(boundMethod, arguments);
          reboundMethod.__reactBoundContext = component;
          reboundMethod.__reactBoundMethod = method;
          reboundMethod.__reactBoundArguments = args;
          return reboundMethod;
        };
      }
      return boundMethod;
    }
  
    /**
     * Binds all auto-bound methods in a component.
     *
     * @param {object} component Component whose method is going to be bound.
     */
    function bindAutoBindMethods(component) {
      var pairs = component.__reactAutoBindPairs;
      for (var i = 0; i < pairs.length; i += 2) {
        var autoBindKey = pairs[i];
        var method = pairs[i + 1];
        component[autoBindKey] = bindAutoBindMethod(component, method);
      }
    }
  
    var IsMountedPreMixin = {
      componentDidMount: function() {
        this.__isMounted = true;
      }
    };
  
    var IsMountedPostMixin = {
      componentWillUnmount: function() {
        this.__isMounted = false;
      }
    };
  
    /**
     * Add more to the ReactClass base class. These are all legacy features and
     * therefore not already part of the modern ReactComponent.
     */
    var ReactClassMixin = {
      /**
       * TODO: This will be deprecated because state should always keep a consistent
       * type signature and the only use case for this, is to avoid that.
       */
      replaceState: function(newState, callback) {
        this.updater.enqueueReplaceState(this, newState, callback);
      },
  
      /**
       * Checks whether or not this composite component is mounted.
       * @return {boolean} True if mounted, false otherwise.
       * @protected
       * @final
       */
      isMounted: function() {
        if (process.env.NODE_ENV !== 'production') {
          warning(
            this.__didWarnIsMounted,
            '%s: isMounted is deprecated. Instead, make sure to clean up ' +
              'subscriptions and pending requests in componentWillUnmount to ' +
              'prevent memory leaks.',
            (this.constructor && this.constructor.displayName) ||
              this.name ||
              'Component'
          );
          this.__didWarnIsMounted = true;
        }
        return !!this.__isMounted;
      }
    };
  
    var ReactClassComponent = function() {};
    _assign(
      ReactClassComponent.prototype,
      ReactComponent.prototype,
      ReactClassMixin
    );
  
    /**
     * Creates a composite component class given a class specification.
     * See https://facebook.github.io/react/docs/top-level-api.html#react.createclass
     *
     * @param {object} spec Class specification (which must define `render`).
     * @return {function} Component constructor function.
     * @public
     */
    function createClass(spec) {
      // To keep our warnings more understandable, we'll use a little hack here to
      // ensure that Constructor.name !== 'Constructor'. This makes sure we don't
      // unnecessarily identify a class without displayName as 'Constructor'.
      var Constructor = identity(function(props, context, updater) {
        // This constructor gets overridden by mocks. The argument is used
        // by mocks to assert on what gets mounted.
  
        if (process.env.NODE_ENV !== 'production') {
          warning(
            this instanceof Constructor,
            'Something is calling a React component directly. Use a factory or ' +
              'JSX instead. See: https://fb.me/react-legacyfactory'
          );
        }
  
        // Wire up auto-binding
        if (this.__reactAutoBindPairs.length) {
          bindAutoBindMethods(this);
        }
  
        this.props = props;
        this.context = context;
        this.refs = emptyObject;
        this.updater = updater || ReactNoopUpdateQueue;
  
        this.state = null;
  
        // ReactClasses doesn't have constructors. Instead, they use the
        // getInitialState and componentWillMount methods for initialization.
  
        var initialState = this.getInitialState ? this.getInitialState() : null;
        if (process.env.NODE_ENV !== 'production') {
          // We allow auto-mocks to proceed as if they're returning null.
          if (
            initialState === undefined &&
            this.getInitialState._isMockFunction
          ) {
            // This is probably bad practice. Consider warning here and
            // deprecating this convenience.
            initialState = null;
          }
        }
        _invariant(
          typeof initialState === 'object' && !Array.isArray(initialState),
          '%s.getInitialState(): must return an object or null',
          Constructor.displayName || 'ReactCompositeComponent'
        );
  
        this.state = initialState;
      });
      Constructor.prototype = new ReactClassComponent();
      Constructor.prototype.constructor = Constructor;
      Constructor.prototype.__reactAutoBindPairs = [];
  
      injectedMixins.forEach(mixSpecIntoComponent.bind(null, Constructor));
  
      mixSpecIntoComponent(Constructor, IsMountedPreMixin);
      mixSpecIntoComponent(Constructor, spec);
      mixSpecIntoComponent(Constructor, IsMountedPostMixin);
  
      // Initialize the defaultProps property after all mixins have been merged.
      if (Constructor.getDefaultProps) {
        Constructor.defaultProps = Constructor.getDefaultProps();
      }
  
      if (process.env.NODE_ENV !== 'production') {
        // This is a tag to indicate that the use of these method names is ok,
        // since it's used with createClass. If it's not, then it's likely a
        // mistake so we'll warn you to use the static property, property
        // initializer or constructor respectively.
        if (Constructor.getDefaultProps) {
          Constructor.getDefaultProps.isReactClassApproved = {};
        }
        if (Constructor.prototype.getInitialState) {
          Constructor.prototype.getInitialState.isReactClassApproved = {};
        }
      }
  
      _invariant(
        Constructor.prototype.render,
        'createClass(...): Class specification must implement a `render` method.'
      );
  
      if (process.env.NODE_ENV !== 'production') {
        warning(
          !Constructor.prototype.componentShouldUpdate,
          '%s has a method called ' +
            'componentShouldUpdate(). Did you mean shouldComponentUpdate()? ' +
            'The name is phrased as a question because the function is ' +
            'expected to return a value.',
          spec.displayName || 'A component'
        );
        warning(
          !Constructor.prototype.componentWillRecieveProps,
          '%s has a method called ' +
            'componentWillRecieveProps(). Did you mean componentWillReceiveProps()?',
          spec.displayName || 'A component'
        );
        warning(
          !Constructor.prototype.UNSAFE_componentWillRecieveProps,
          '%s has a method called UNSAFE_componentWillRecieveProps(). ' +
            'Did you mean UNSAFE_componentWillReceiveProps()?',
          spec.displayName || 'A component'
        );
      }
  
      // Reduce time spent doing lookups by setting these on the prototype.
      for (var methodName in ReactClassInterface) {
        if (!Constructor.prototype[methodName]) {
          Constructor.prototype[methodName] = null;
        }
      }
  
      return Constructor;
    }
  
    return createClass;
  }
  
  module.exports = factory;
  
  }).call(this,require('_process'))
  },{"_process":134,"fbjs/lib/emptyObject":93,"fbjs/lib/invariant":94,"fbjs/lib/warning":95,"object-assign":96}],92:[function(require,module,exports){
  "use strict";
  
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  function makeEmptyFunction(arg) {
    return function () {
      return arg;
    };
  }
  
  /**
   * This function accepts and discards inputs; it has no side effects. This is
   * primarily useful idiomatically for overridable function endpoints which
   * always need to be callable, since JS lacks a null-call idiom ala Cocoa.
   */
  var emptyFunction = function emptyFunction() {};
  
  emptyFunction.thatReturns = makeEmptyFunction;
  emptyFunction.thatReturnsFalse = makeEmptyFunction(false);
  emptyFunction.thatReturnsTrue = makeEmptyFunction(true);
  emptyFunction.thatReturnsNull = makeEmptyFunction(null);
  emptyFunction.thatReturnsThis = function () {
    return this;
  };
  emptyFunction.thatReturnsArgument = function (arg) {
    return arg;
  };
  
  module.exports = emptyFunction;
  },{}],93:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var emptyObject = {};
  
  if (process.env.NODE_ENV !== 'production') {
    Object.freeze(emptyObject);
  }
  
  module.exports = emptyObject;
  }).call(this,require('_process'))
  },{"_process":134}],94:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  /**
   * Use invariant() to assert state which your program assumes to be true.
   *
   * Provide sprintf-style format (only %s is supported) and arguments
   * to provide information about what broke and what you were
   * expecting.
   *
   * The invariant message will be stripped in production, but the invariant
   * will remain to ensure logic does not differ in production.
   */
  
  var validateFormat = function validateFormat(format) {};
  
  if (process.env.NODE_ENV !== 'production') {
    validateFormat = function validateFormat(format) {
      if (format === undefined) {
        throw new Error('invariant requires an error message argument');
      }
    };
  }
  
  function invariant(condition, format, a, b, c, d, e, f) {
    validateFormat(format);
  
    if (!condition) {
      var error;
      if (format === undefined) {
        error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
      } else {
        var args = [a, b, c, d, e, f];
        var argIndex = 0;
        error = new Error(format.replace(/%s/g, function () {
          return args[argIndex++];
        }));
        error.name = 'Invariant Violation';
      }
  
      error.framesToPop = 1; // we don't care about invariant's own frame
      throw error;
    }
  }
  
  module.exports = invariant;
  }).call(this,require('_process'))
  },{"_process":134}],95:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2014-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var emptyFunction = require('./emptyFunction');
  
  /**
   * Similar to invariant but only logs a warning if the condition is not met.
   * This can be used to log issues in development environments in critical
   * paths. Removing the logging code for production environments will keep the
   * same logic and follow the same code paths.
   */
  
  var warning = emptyFunction;
  
  if (process.env.NODE_ENV !== 'production') {
    var printWarning = function printWarning(format) {
      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
  
      var argIndex = 0;
      var message = 'Warning: ' + format.replace(/%s/g, function () {
        return args[argIndex++];
      });
      if (typeof console !== 'undefined') {
        console.error(message);
      }
      try {
        // --- Welcome to debugging React ---
        // This error was thrown as a convenience so that you can use this stack
        // to find the callsite that caused this warning to fire.
        throw new Error(message);
      } catch (x) {}
    };
  
    warning = function warning(condition, format) {
      if (format === undefined) {
        throw new Error('`warning(condition, format, ...args)` requires a warning ' + 'message argument');
      }
  
      if (format.indexOf('Failed Composite propType: ') === 0) {
        return; // Ignore CompositeComponent proptype check.
      }
  
      if (!condition) {
        for (var _len2 = arguments.length, args = Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
          args[_key2 - 2] = arguments[_key2];
        }
  
        printWarning.apply(undefined, [format].concat(args));
      }
    };
  }
  
  module.exports = warning;
  }).call(this,require('_process'))
  },{"./emptyFunction":92,"_process":134}],96:[function(require,module,exports){
  /*
  object-assign
  (c) Sindre Sorhus
  @license MIT
  */
  
  'use strict';
  /* eslint-disable no-unused-vars */
  var getOwnPropertySymbols = Object.getOwnPropertySymbols;
  var hasOwnProperty = Object.prototype.hasOwnProperty;
  var propIsEnumerable = Object.prototype.propertyIsEnumerable;
  
  function toObject(val) {
    if (val === null || val === undefined) {
      throw new TypeError('Object.assign cannot be called with null or undefined');
    }
  
    return Object(val);
  }
  
  function shouldUseNative() {
    try {
      if (!Object.assign) {
        return false;
      }
  
      // Detect buggy property enumeration order in older V8 versions.
  
      // https://bugs.chromium.org/p/v8/issues/detail?id=4118
      var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
      test1[5] = 'de';
      if (Object.getOwnPropertyNames(test1)[0] === '5') {
        return false;
      }
  
      // https://bugs.chromium.org/p/v8/issues/detail?id=3056
      var test2 = {};
      for (var i = 0; i < 10; i++) {
        test2['_' + String.fromCharCode(i)] = i;
      }
      var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
        return test2[n];
      });
      if (order2.join('') !== '0123456789') {
        return false;
      }
  
      // https://bugs.chromium.org/p/v8/issues/detail?id=3056
      var test3 = {};
      'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
        test3[letter] = letter;
      });
      if (Object.keys(Object.assign({}, test3)).join('') !==
          'abcdefghijklmnopqrst') {
        return false;
      }
  
      return true;
    } catch (err) {
      // We don't expect any of the above to throw, but better to be safe.
      return false;
    }
  }
  
  module.exports = shouldUseNative() ? Object.assign : function (target, source) {
    var from;
    var to = toObject(target);
    var symbols;
  
    for (var s = 1; s < arguments.length; s++) {
      from = Object(arguments[s]);
  
      for (var key in from) {
        if (hasOwnProperty.call(from, key)) {
          to[key] = from[key];
        }
      }
  
      if (getOwnPropertySymbols) {
        symbols = getOwnPropertySymbols(from);
        for (var i = 0; i < symbols.length; i++) {
          if (propIsEnumerable.call(from, symbols[i])) {
            to[symbols[i]] = from[symbols[i]];
          }
        }
      }
    }
  
    return to;
  };
  
  },{}],97:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  
  'use strict';
  
  var printWarning = function() {};
  
  if (process.env.NODE_ENV !== 'production') {
    var ReactPropTypesSecret = require('./lib/ReactPropTypesSecret');
    var loggedTypeFailures = {};
  
    printWarning = function(text) {
      var message = 'Warning: ' + text;
      if (typeof console !== 'undefined') {
        console.error(message);
      }
      try {
        // --- Welcome to debugging React ---
        // This error was thrown as a convenience so that you can use this stack
        // to find the callsite that caused this warning to fire.
        throw new Error(message);
      } catch (x) {}
    };
  }
  
  /**
   * Assert that the values match with the type specs.
   * Error messages are memorized and will only be shown once.
   *
   * @param {object} typeSpecs Map of name to a ReactPropType
   * @param {object} values Runtime values that need to be type-checked
   * @param {string} location e.g. "prop", "context", "child context"
   * @param {string} componentName Name of the component for error messages.
   * @param {?Function} getStack Returns the component stack.
   * @private
   */
  function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
    if (process.env.NODE_ENV !== 'production') {
      for (var typeSpecName in typeSpecs) {
        if (typeSpecs.hasOwnProperty(typeSpecName)) {
          var error;
          // Prop type validation may throw. In case they do, we don't want to
          // fail the render phase where it didn't fail before. So we log it.
          // After these have been cleaned up, we'll let them throw.
          try {
            // This is intentionally an invariant that gets caught. It's the same
            // behavior as without this statement except with a better message.
            if (typeof typeSpecs[typeSpecName] !== 'function') {
              var err = Error(
                (componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' +
                'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.'
              );
              err.name = 'Invariant Violation';
              throw err;
            }
            error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
          } catch (ex) {
            error = ex;
          }
          if (error && !(error instanceof Error)) {
            printWarning(
              (componentName || 'React class') + ': type specification of ' +
              location + ' `' + typeSpecName + '` is invalid; the type checker ' +
              'function must return `null` or an `Error` but returned a ' + typeof error + '. ' +
              'You may have forgotten to pass an argument to the type checker ' +
              'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' +
              'shape all require an argument).'
            )
  
          }
          if (error instanceof Error && !(error.message in loggedTypeFailures)) {
            // Only monitor this failure once because there tends to be a lot of the
            // same error.
            loggedTypeFailures[error.message] = true;
  
            var stack = getStack ? getStack() : '';
  
            printWarning(
              'Failed ' + location + ' type: ' + error.message + (stack != null ? stack : '')
            );
          }
        }
      }
    }
  }
  
  module.exports = checkPropTypes;
  
  }).call(this,require('_process'))
  },{"./lib/ReactPropTypesSecret":102,"_process":134}],98:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  
  'use strict';
  
  // React 15.5 references this module, and assumes PropTypes are still callable in production.
  // Therefore we re-export development-only version with all the PropTypes checks here.
  // However if one is migrating to the `prop-types` npm library, they will go through the
  // `index.js` entry point, and it will branch depending on the environment.
  var factory = require('./factoryWithTypeCheckers');
  module.exports = function(isValidElement) {
    // It is still allowed in 15.5.
    var throwOnDirectAccess = false;
    return factory(isValidElement, throwOnDirectAccess);
  };
  
  },{"./factoryWithTypeCheckers":100}],99:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  
  'use strict';
  
  var ReactPropTypesSecret = require('./lib/ReactPropTypesSecret');
  
  function emptyFunction() {}
  
  module.exports = function() {
    function shim(props, propName, componentName, location, propFullName, secret) {
      if (secret === ReactPropTypesSecret) {
        // It is still safe when called from React.
        return;
      }
      var err = new Error(
        'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
        'Use PropTypes.checkPropTypes() to call them. ' +
        'Read more at http://fb.me/use-check-prop-types'
      );
      err.name = 'Invariant Violation';
      throw err;
    };
    shim.isRequired = shim;
    function getShim() {
      return shim;
    };
    // Important!
    // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
    var ReactPropTypes = {
      array: shim,
      bool: shim,
      func: shim,
      number: shim,
      object: shim,
      string: shim,
      symbol: shim,
  
      any: shim,
      arrayOf: getShim,
      element: shim,
      instanceOf: getShim,
      node: shim,
      objectOf: getShim,
      oneOf: getShim,
      oneOfType: getShim,
      shape: getShim,
      exact: getShim
    };
  
    ReactPropTypes.checkPropTypes = emptyFunction;
    ReactPropTypes.PropTypes = ReactPropTypes;
  
    return ReactPropTypes;
  };
  
  },{"./lib/ReactPropTypesSecret":102}],100:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  
  'use strict';
  
  var assign = require('object-assign');
  
  var ReactPropTypesSecret = require('./lib/ReactPropTypesSecret');
  var checkPropTypes = require('./checkPropTypes');
  
  var printWarning = function() {};
  
  if (process.env.NODE_ENV !== 'production') {
    printWarning = function(text) {
      var message = 'Warning: ' + text;
      if (typeof console !== 'undefined') {
        console.error(message);
      }
      try {
        // --- Welcome to debugging React ---
        // This error was thrown as a convenience so that you can use this stack
        // to find the callsite that caused this warning to fire.
        throw new Error(message);
      } catch (x) {}
    };
  }
  
  function emptyFunctionThatReturnsNull() {
    return null;
  }
  
  module.exports = function(isValidElement, throwOnDirectAccess) {
    /* global Symbol */
    var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
    var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.
  
    /**
     * Returns the iterator method function contained on the iterable object.
     *
     * Be sure to invoke the function with the iterable as context:
     *
     *     var iteratorFn = getIteratorFn(myIterable);
     *     if (iteratorFn) {
     *       var iterator = iteratorFn.call(myIterable);
     *       ...
     *     }
     *
     * @param {?object} maybeIterable
     * @return {?function}
     */
    function getIteratorFn(maybeIterable) {
      var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
      if (typeof iteratorFn === 'function') {
        return iteratorFn;
      }
    }
  
    /**
     * Collection of methods that allow declaration and validation of props that are
     * supplied to React components. Example usage:
     *
     *   var Props = require('ReactPropTypes');
     *   var MyArticle = React.createClass({
     *     propTypes: {
     *       // An optional string prop named "description".
     *       description: Props.string,
     *
     *       // A required enum prop named "category".
     *       category: Props.oneOf(['News','Photos']).isRequired,
     *
     *       // A prop named "dialog" that requires an instance of Dialog.
     *       dialog: Props.instanceOf(Dialog).isRequired
     *     },
     *     render: function() { ... }
     *   });
     *
     * A more formal specification of how these methods are used:
     *
     *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
     *   decl := ReactPropTypes.{type}(.isRequired)?
     *
     * Each and every declaration produces a function with the same signature. This
     * allows the creation of custom validation functions. For example:
     *
     *  var MyLink = React.createClass({
     *    propTypes: {
     *      // An optional string or URI prop named "href".
     *      href: function(props, propName, componentName) {
     *        var propValue = props[propName];
     *        if (propValue != null && typeof propValue !== 'string' &&
     *            !(propValue instanceof URI)) {
     *          return new Error(
     *            'Expected a string or an URI for ' + propName + ' in ' +
     *            componentName
     *          );
     *        }
     *      }
     *    },
     *    render: function() {...}
     *  });
     *
     * @internal
     */
  
    var ANONYMOUS = '<<anonymous>>';
  
    // Important!
    // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
    var ReactPropTypes = {
      array: createPrimitiveTypeChecker('array'),
      bool: createPrimitiveTypeChecker('boolean'),
      func: createPrimitiveTypeChecker('function'),
      number: createPrimitiveTypeChecker('number'),
      object: createPrimitiveTypeChecker('object'),
      string: createPrimitiveTypeChecker('string'),
      symbol: createPrimitiveTypeChecker('symbol'),
  
      any: createAnyTypeChecker(),
      arrayOf: createArrayOfTypeChecker,
      element: createElementTypeChecker(),
      instanceOf: createInstanceTypeChecker,
      node: createNodeChecker(),
      objectOf: createObjectOfTypeChecker,
      oneOf: createEnumTypeChecker,
      oneOfType: createUnionTypeChecker,
      shape: createShapeTypeChecker,
      exact: createStrictShapeTypeChecker,
    };
  
    /**
     * inlined Object.is polyfill to avoid requiring consumers ship their own
     * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
     */
    /*eslint-disable no-self-compare*/
    function is(x, y) {
      // SameValue algorithm
      if (x === y) {
        // Steps 1-5, 7-10
        // Steps 6.b-6.e: +0 != -0
        return x !== 0 || 1 / x === 1 / y;
      } else {
        // Step 6.a: NaN == NaN
        return x !== x && y !== y;
      }
    }
    /*eslint-enable no-self-compare*/
  
    /**
     * We use an Error-like object for backward compatibility as people may call
     * PropTypes directly and inspect their output. However, we don't use real
     * Errors anymore. We don't inspect their stack anyway, and creating them
     * is prohibitively expensive if they are created too often, such as what
     * happens in oneOfType() for any type before the one that matched.
     */
    function PropTypeError(message) {
      this.message = message;
      this.stack = '';
    }
    // Make `instanceof Error` still work for returned errors.
    PropTypeError.prototype = Error.prototype;
  
    function createChainableTypeChecker(validate) {
      if (process.env.NODE_ENV !== 'production') {
        var manualPropTypeCallCache = {};
        var manualPropTypeWarningCount = 0;
      }
      function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
        componentName = componentName || ANONYMOUS;
        propFullName = propFullName || propName;
  
        if (secret !== ReactPropTypesSecret) {
          if (throwOnDirectAccess) {
            // New behavior only for users of `prop-types` package
            var err = new Error(
              'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
              'Use `PropTypes.checkPropTypes()` to call them. ' +
              'Read more at http://fb.me/use-check-prop-types'
            );
            err.name = 'Invariant Violation';
            throw err;
          } else if (process.env.NODE_ENV !== 'production' && typeof console !== 'undefined') {
            // Old behavior for people using React.PropTypes
            var cacheKey = componentName + ':' + propName;
            if (
              !manualPropTypeCallCache[cacheKey] &&
              // Avoid spamming the console because they are often not actionable except for lib authors
              manualPropTypeWarningCount < 3
            ) {
              printWarning(
                'You are manually calling a React.PropTypes validation ' +
                'function for the `' + propFullName + '` prop on `' + componentName  + '`. This is deprecated ' +
                'and will throw in the standalone `prop-types` package. ' +
                'You may be seeing this warning due to a third-party PropTypes ' +
                'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.'
              );
              manualPropTypeCallCache[cacheKey] = true;
              manualPropTypeWarningCount++;
            }
          }
        }
        if (props[propName] == null) {
          if (isRequired) {
            if (props[propName] === null) {
              return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
            }
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
          }
          return null;
        } else {
          return validate(props, propName, componentName, location, propFullName);
        }
      }
  
      var chainedCheckType = checkType.bind(null, false);
      chainedCheckType.isRequired = checkType.bind(null, true);
  
      return chainedCheckType;
    }
  
    function createPrimitiveTypeChecker(expectedType) {
      function validate(props, propName, componentName, location, propFullName, secret) {
        var propValue = props[propName];
        var propType = getPropType(propValue);
        if (propType !== expectedType) {
          // `propValue` being instance of, say, date/regexp, pass the 'object'
          // check, but we can offer a more precise error message here rather than
          // 'of type `object`'.
          var preciseType = getPreciseType(propValue);
  
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'));
        }
        return null;
      }
      return createChainableTypeChecker(validate);
    }
  
    function createAnyTypeChecker() {
      return createChainableTypeChecker(emptyFunctionThatReturnsNull);
    }
  
    function createArrayOfTypeChecker(typeChecker) {
      function validate(props, propName, componentName, location, propFullName) {
        if (typeof typeChecker !== 'function') {
          return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
        }
        var propValue = props[propName];
        if (!Array.isArray(propValue)) {
          var propType = getPropType(propValue);
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
        }
        for (var i = 0; i < propValue.length; i++) {
          var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
        return null;
      }
      return createChainableTypeChecker(validate);
    }
  
    function createElementTypeChecker() {
      function validate(props, propName, componentName, location, propFullName) {
        var propValue = props[propName];
        if (!isValidElement(propValue)) {
          var propType = getPropType(propValue);
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
        }
        return null;
      }
      return createChainableTypeChecker(validate);
    }
  
    function createInstanceTypeChecker(expectedClass) {
      function validate(props, propName, componentName, location, propFullName) {
        if (!(props[propName] instanceof expectedClass)) {
          var expectedClassName = expectedClass.name || ANONYMOUS;
          var actualClassName = getClassName(props[propName]);
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
        }
        return null;
      }
      return createChainableTypeChecker(validate);
    }
  
    function createEnumTypeChecker(expectedValues) {
      if (!Array.isArray(expectedValues)) {
        process.env.NODE_ENV !== 'production' ? printWarning('Invalid argument supplied to oneOf, expected an instance of array.') : void 0;
        return emptyFunctionThatReturnsNull;
      }
  
      function validate(props, propName, componentName, location, propFullName) {
        var propValue = props[propName];
        for (var i = 0; i < expectedValues.length; i++) {
          if (is(propValue, expectedValues[i])) {
            return null;
          }
        }
  
        var valuesString = JSON.stringify(expectedValues);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + propValue + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
      }
      return createChainableTypeChecker(validate);
    }
  
    function createObjectOfTypeChecker(typeChecker) {
      function validate(props, propName, componentName, location, propFullName) {
        if (typeof typeChecker !== 'function') {
          return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
        }
        var propValue = props[propName];
        var propType = getPropType(propValue);
        if (propType !== 'object') {
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
        }
        for (var key in propValue) {
          if (propValue.hasOwnProperty(key)) {
            var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
            if (error instanceof Error) {
              return error;
            }
          }
        }
        return null;
      }
      return createChainableTypeChecker(validate);
    }
  
    function createUnionTypeChecker(arrayOfTypeCheckers) {
      if (!Array.isArray(arrayOfTypeCheckers)) {
        process.env.NODE_ENV !== 'production' ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : void 0;
        return emptyFunctionThatReturnsNull;
      }
  
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        if (typeof checker !== 'function') {
          printWarning(
            'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
            'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.'
          );
          return emptyFunctionThatReturnsNull;
        }
      }
  
      function validate(props, propName, componentName, location, propFullName) {
        for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
          var checker = arrayOfTypeCheckers[i];
          if (checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret) == null) {
            return null;
          }
        }
  
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`.'));
      }
      return createChainableTypeChecker(validate);
    }
  
    function createNodeChecker() {
      function validate(props, propName, componentName, location, propFullName) {
        if (!isNode(props[propName])) {
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
        }
        return null;
      }
      return createChainableTypeChecker(validate);
    }
  
    function createShapeTypeChecker(shapeTypes) {
      function validate(props, propName, componentName, location, propFullName) {
        var propValue = props[propName];
        var propType = getPropType(propValue);
        if (propType !== 'object') {
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
        }
        for (var key in shapeTypes) {
          var checker = shapeTypes[key];
          if (!checker) {
            continue;
          }
          var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error) {
            return error;
          }
        }
        return null;
      }
      return createChainableTypeChecker(validate);
    }
  
    function createStrictShapeTypeChecker(shapeTypes) {
      function validate(props, propName, componentName, location, propFullName) {
        var propValue = props[propName];
        var propType = getPropType(propValue);
        if (propType !== 'object') {
          return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
        }
        // We need to check all keys in case some are required but missing from
        // props.
        var allKeys = assign({}, props[propName], shapeTypes);
        for (var key in allKeys) {
          var checker = shapeTypes[key];
          if (!checker) {
            return new PropTypeError(
              'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
              '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
              '\nValid keys: ' +  JSON.stringify(Object.keys(shapeTypes), null, '  ')
            );
          }
          var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error) {
            return error;
          }
        }
        return null;
      }
  
      return createChainableTypeChecker(validate);
    }
  
    function isNode(propValue) {
      switch (typeof propValue) {
        case 'number':
        case 'string':
        case 'undefined':
          return true;
        case 'boolean':
          return !propValue;
        case 'object':
          if (Array.isArray(propValue)) {
            return propValue.every(isNode);
          }
          if (propValue === null || isValidElement(propValue)) {
            return true;
          }
  
          var iteratorFn = getIteratorFn(propValue);
          if (iteratorFn) {
            var iterator = iteratorFn.call(propValue);
            var step;
            if (iteratorFn !== propValue.entries) {
              while (!(step = iterator.next()).done) {
                if (!isNode(step.value)) {
                  return false;
                }
              }
            } else {
              // Iterator will provide entry [k,v] tuples rather than values.
              while (!(step = iterator.next()).done) {
                var entry = step.value;
                if (entry) {
                  if (!isNode(entry[1])) {
                    return false;
                  }
                }
              }
            }
          } else {
            return false;
          }
  
          return true;
        default:
          return false;
      }
    }
  
    function isSymbol(propType, propValue) {
      // Native Symbol.
      if (propType === 'symbol') {
        return true;
      }
  
      // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
      if (propValue['@@toStringTag'] === 'Symbol') {
        return true;
      }
  
      // Fallback for non-spec compliant Symbols which are polyfilled.
      if (typeof Symbol === 'function' && propValue instanceof Symbol) {
        return true;
      }
  
      return false;
    }
  
    // Equivalent of `typeof` but with special handling for array and regexp.
    function getPropType(propValue) {
      var propType = typeof propValue;
      if (Array.isArray(propValue)) {
        return 'array';
      }
      if (propValue instanceof RegExp) {
        // Old webkits (at least until Android 4.0) return 'function' rather than
        // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
        // passes PropTypes.object.
        return 'object';
      }
      if (isSymbol(propType, propValue)) {
        return 'symbol';
      }
      return propType;
    }
  
    // This handles more types than `getPropType`. Only used for error messages.
    // See `createPrimitiveTypeChecker`.
    function getPreciseType(propValue) {
      if (typeof propValue === 'undefined' || propValue === null) {
        return '' + propValue;
      }
      var propType = getPropType(propValue);
      if (propType === 'object') {
        if (propValue instanceof Date) {
          return 'date';
        } else if (propValue instanceof RegExp) {
          return 'regexp';
        }
      }
      return propType;
    }
  
    // Returns a string that is postfixed to a warning about an invalid type.
    // For example, "undefined" or "of type array"
    function getPostfixForTypeWarning(value) {
      var type = getPreciseType(value);
      switch (type) {
        case 'array':
        case 'object':
          return 'an ' + type;
        case 'boolean':
        case 'date':
        case 'regexp':
          return 'a ' + type;
        default:
          return type;
      }
    }
  
    // Returns class name of the object, if any.
    function getClassName(propValue) {
      if (!propValue.constructor || !propValue.constructor.name) {
        return ANONYMOUS;
      }
      return propValue.constructor.name;
    }
  
    ReactPropTypes.checkPropTypes = checkPropTypes;
    ReactPropTypes.PropTypes = ReactPropTypes;
  
    return ReactPropTypes;
  };
  
  }).call(this,require('_process'))
  },{"./checkPropTypes":97,"./lib/ReactPropTypesSecret":102,"_process":134,"object-assign":96}],101:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  
  if (process.env.NODE_ENV !== 'production') {
    var REACT_ELEMENT_TYPE = (typeof Symbol === 'function' &&
      Symbol.for &&
      Symbol.for('react.element')) ||
      0xeac7;
  
    var isValidElement = function(object) {
      return typeof object === 'object' &&
        object !== null &&
        object.$$typeof === REACT_ELEMENT_TYPE;
    };
  
    // By explicitly using `prop-types` you are opting into new development behavior.
    // http://fb.me/prop-types-in-prod
    var throwOnDirectAccess = true;
    module.exports = require('./factoryWithTypeCheckers')(isValidElement, throwOnDirectAccess);
  } else {
    // By explicitly using `prop-types` you are opting into new production behavior.
    // http://fb.me/prop-types-in-prod
    module.exports = require('./factoryWithThrowingShims')();
  }
  
  }).call(this,require('_process'))
  },{"./factoryWithThrowingShims":99,"./factoryWithTypeCheckers":100,"_process":134}],102:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  
  'use strict';
  
  var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';
  
  module.exports = ReactPropTypesSecret;
  
  },{}],103:[function(require,module,exports){
  'use strict';
  
  exports.__esModule = true;
  
  var _extends2 = require('babel-runtime/helpers/extends');
  
  var _extends3 = _interopRequireDefault(_extends2);
  
  var _objectWithoutProperties2 = require('babel-runtime/helpers/objectWithoutProperties');
  
  var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);
  
  var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');
  
  var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);
  
  var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');
  
  var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);
  
  var _inherits2 = require('babel-runtime/helpers/inherits');
  
  var _inherits3 = _interopRequireDefault(_inherits2);
  
  var _react = require('react');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('prop-types');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _enhancer = require('./enhancer');
  
  var _enhancer2 = _interopRequireDefault(_enhancer);
  
  var _types = require('./types');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  /* eslint react/prop-types: 0 */
  var Circle = function (_Component) {
    (0, _inherits3['default'])(Circle, _Component);
  
    function Circle() {
      (0, _classCallCheck3['default'])(this, Circle);
      return (0, _possibleConstructorReturn3['default'])(this, _Component.apply(this, arguments));
    }
  
    Circle.prototype.getPathStyles = function getPathStyles() {
      var _props = this.props,
          percent = _props.percent,
          strokeWidth = _props.strokeWidth,
          _props$gapDegree = _props.gapDegree,
          gapDegree = _props$gapDegree === undefined ? 0 : _props$gapDegree,
          gapPosition = _props.gapPosition;
  
      var radius = 50 - strokeWidth / 2;
      var beginPositionX = 0;
      var beginPositionY = -radius;
      var endPositionX = 0;
      var endPositionY = -2 * radius;
      switch (gapPosition) {
        case 'left':
          beginPositionX = -radius;
          beginPositionY = 0;
          endPositionX = 2 * radius;
          endPositionY = 0;
          break;
        case 'right':
          beginPositionX = radius;
          beginPositionY = 0;
          endPositionX = -2 * radius;
          endPositionY = 0;
          break;
        case 'bottom':
          beginPositionY = radius;
          endPositionY = 2 * radius;
          break;
        default:
      }
      var pathString = 'M 50,50 m ' + beginPositionX + ',' + beginPositionY + '\n     a ' + radius + ',' + radius + ' 0 1 1 ' + endPositionX + ',' + -endPositionY + '\n     a ' + radius + ',' + radius + ' 0 1 1 ' + -endPositionX + ',' + endPositionY;
      var len = Math.PI * 2 * radius;
      var trailPathStyle = {
        strokeDasharray: len - gapDegree + 'px ' + len + 'px',
        strokeDashoffset: '-' + gapDegree / 2 + 'px',
        transition: 'stroke-dashoffset .3s ease 0s, stroke-dasharray .3s ease 0s, stroke .3s'
      };
      var strokePathStyle = {
        strokeDasharray: percent / 100 * (len - gapDegree) + 'px ' + len + 'px',
        strokeDashoffset: '-' + gapDegree / 2 + 'px',
        transition: 'stroke-dashoffset .3s ease 0s, stroke-dasharray .3s ease 0s, stroke .3s, stroke-width .06s ease .3s' // eslint-disable-line
      };
      return { pathString: pathString, trailPathStyle: trailPathStyle, strokePathStyle: strokePathStyle };
    };
  
    Circle.prototype.render = function render() {
      var _this2 = this;
  
      var _props2 = this.props,
          prefixCls = _props2.prefixCls,
          strokeWidth = _props2.strokeWidth,
          trailWidth = _props2.trailWidth,
          strokeColor = _props2.strokeColor,
          percent = _props2.percent,
          trailColor = _props2.trailColor,
          strokeLinecap = _props2.strokeLinecap,
          style = _props2.style,
          className = _props2.className,
          restProps = (0, _objectWithoutProperties3['default'])(_props2, ['prefixCls', 'strokeWidth', 'trailWidth', 'strokeColor', 'percent', 'trailColor', 'strokeLinecap', 'style', 'className']);
  
      var _getPathStyles = this.getPathStyles(),
          pathString = _getPathStyles.pathString,
          trailPathStyle = _getPathStyles.trailPathStyle,
          strokePathStyle = _getPathStyles.strokePathStyle;
  
      delete restProps.percent;
      delete restProps.gapDegree;
      delete restProps.gapPosition;
      return _react2['default'].createElement(
        'svg',
        (0, _extends3['default'])({
          className: prefixCls + '-circle ' + className,
          viewBox: '0 0 100 100',
          style: style
        }, restProps),
        _react2['default'].createElement('path', {
          className: prefixCls + '-circle-trail',
          d: pathString,
          stroke: trailColor,
          strokeWidth: trailWidth || strokeWidth,
          fillOpacity: '0',
          style: trailPathStyle
        }),
        _react2['default'].createElement('path', {
          className: prefixCls + '-circle-path',
          d: pathString,
          strokeLinecap: strokeLinecap,
          stroke: strokeColor,
          strokeWidth: this.props.percent === 0 ? 0 : strokeWidth,
          fillOpacity: '0',
          ref: function ref(path) {
            _this2.path = path;
          },
          style: strokePathStyle
        })
      );
    };
  
    return Circle;
  }(_react.Component);
  
  Circle.propTypes = (0, _extends3['default'])({}, _types.propTypes, {
    gapPosition: _propTypes2['default'].oneOf(['top', 'bottom', 'left', 'right'])
  });
  
  Circle.defaultProps = (0, _extends3['default'])({}, _types.defaultProps, {
    gapPosition: 'top'
  });
  
  exports['default'] = (0, _enhancer2['default'])(Circle);
  module.exports = exports['default'];
  },{"./enhancer":105,"./types":107,"babel-runtime/helpers/classCallCheck":13,"babel-runtime/helpers/extends":14,"babel-runtime/helpers/inherits":15,"babel-runtime/helpers/objectWithoutProperties":16,"babel-runtime/helpers/possibleConstructorReturn":17,"prop-types":101,"react":133}],104:[function(require,module,exports){
  'use strict';
  
  exports.__esModule = true;
  
  var _extends2 = require('babel-runtime/helpers/extends');
  
  var _extends3 = _interopRequireDefault(_extends2);
  
  var _objectWithoutProperties2 = require('babel-runtime/helpers/objectWithoutProperties');
  
  var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);
  
  var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');
  
  var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);
  
  var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');
  
  var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);
  
  var _inherits2 = require('babel-runtime/helpers/inherits');
  
  var _inherits3 = _interopRequireDefault(_inherits2);
  
  var _react = require('react');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _enhancer = require('./enhancer');
  
  var _enhancer2 = _interopRequireDefault(_enhancer);
  
  var _types = require('./types');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var Line = function (_Component) {
    (0, _inherits3['default'])(Line, _Component);
  
    function Line() {
      (0, _classCallCheck3['default'])(this, Line);
      return (0, _possibleConstructorReturn3['default'])(this, _Component.apply(this, arguments));
    }
  
    Line.prototype.render = function render() {
      var _this2 = this;
  
      var _props = this.props,
          className = _props.className,
          percent = _props.percent,
          prefixCls = _props.prefixCls,
          strokeColor = _props.strokeColor,
          strokeLinecap = _props.strokeLinecap,
          strokeWidth = _props.strokeWidth,
          style = _props.style,
          trailColor = _props.trailColor,
          trailWidth = _props.trailWidth,
          restProps = (0, _objectWithoutProperties3['default'])(_props, ['className', 'percent', 'prefixCls', 'strokeColor', 'strokeLinecap', 'strokeWidth', 'style', 'trailColor', 'trailWidth']);
  
  
      delete restProps.gapPosition;
  
      var pathStyle = {
        strokeDasharray: '100px, 100px',
        strokeDashoffset: 100 - percent + 'px',
        transition: 'stroke-dashoffset 0.3s ease 0s, stroke 0.3s linear'
      };
  
      var center = strokeWidth / 2;
      var right = 100 - strokeWidth / 2;
      var pathString = 'M ' + (strokeLinecap === 'round' ? center : 0) + ',' + center + '\n           L ' + (strokeLinecap === 'round' ? right : 100) + ',' + center;
      var viewBoxString = '0 0 100 ' + strokeWidth;
  
      return _react2['default'].createElement(
        'svg',
        (0, _extends3['default'])({
          className: prefixCls + '-line ' + className,
          viewBox: viewBoxString,
          preserveAspectRatio: 'none',
          style: style
        }, restProps),
        _react2['default'].createElement('path', {
          className: prefixCls + '-line-trail',
          d: pathString,
          strokeLinecap: strokeLinecap,
          stroke: trailColor,
          strokeWidth: trailWidth || strokeWidth,
          fillOpacity: '0'
        }),
        _react2['default'].createElement('path', {
          className: prefixCls + '-line-path',
          d: pathString,
          strokeLinecap: strokeLinecap,
          stroke: strokeColor,
          strokeWidth: strokeWidth,
          fillOpacity: '0',
          ref: function ref(path) {
            _this2.path = path;
          },
          style: pathStyle
        })
      );
    };
  
    return Line;
  }(_react.Component);
  
  Line.propTypes = _types.propTypes;
  
  Line.defaultProps = _types.defaultProps;
  
  exports['default'] = (0, _enhancer2['default'])(Line);
  module.exports = exports['default'];
  },{"./enhancer":105,"./types":107,"babel-runtime/helpers/classCallCheck":13,"babel-runtime/helpers/extends":14,"babel-runtime/helpers/inherits":15,"babel-runtime/helpers/objectWithoutProperties":16,"babel-runtime/helpers/possibleConstructorReturn":17,"react":133}],105:[function(require,module,exports){
  'use strict';
  
  exports.__esModule = true;
  
  var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');
  
  var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);
  
  var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');
  
  var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);
  
  var _inherits2 = require('babel-runtime/helpers/inherits');
  
  var _inherits3 = _interopRequireDefault(_inherits2);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var enhancer = function enhancer(WrappedComponent) {
    return function (_WrappedComponent) {
      (0, _inherits3['default'])(Progress, _WrappedComponent);
  
      function Progress() {
        (0, _classCallCheck3['default'])(this, Progress);
        return (0, _possibleConstructorReturn3['default'])(this, _WrappedComponent.apply(this, arguments));
      }
  
      Progress.prototype.componentDidUpdate = function componentDidUpdate() {
        if (!this.path) {
          return;
        }
        var pathStyle = this.path.style;
        pathStyle.transitionDuration = '.3s, .3s, .3s, .06s';
        var now = Date.now();
        if (this.prevTimeStamp && now - this.prevTimeStamp < 100) {
          pathStyle.transitionDuration = '0s, 0s';
        }
        this.prevTimeStamp = Date.now();
      };
  
      Progress.prototype.render = function render() {
        return _WrappedComponent.prototype.render.call(this);
      };
  
      return Progress;
    }(WrappedComponent);
  };
  
  exports['default'] = enhancer;
  module.exports = exports['default'];
  },{"babel-runtime/helpers/classCallCheck":13,"babel-runtime/helpers/inherits":15,"babel-runtime/helpers/possibleConstructorReturn":17}],106:[function(require,module,exports){
  'use strict';
  
  exports.__esModule = true;
  exports.Circle = exports.Line = undefined;
  
  var _Line = require('./Line');
  
  var _Line2 = _interopRequireDefault(_Line);
  
  var _Circle = require('./Circle');
  
  var _Circle2 = _interopRequireDefault(_Circle);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  exports.Line = _Line2['default'];
  exports.Circle = _Circle2['default'];
  exports['default'] = {
    Line: _Line2['default'],
    Circle: _Circle2['default']
  };
  },{"./Circle":103,"./Line":104}],107:[function(require,module,exports){
  'use strict';
  
  exports.__esModule = true;
  exports.propTypes = exports.defaultProps = undefined;
  
  var _propTypes = require('prop-types');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var defaultProps = exports.defaultProps = {
    className: '',
    percent: 0,
    prefixCls: 'rc-progress',
    strokeColor: '#2db7f5',
    strokeLinecap: 'round',
    strokeWidth: 1,
    style: {},
    trailColor: '#D9D9D9',
    trailWidth: 1
  };
  
  var propTypes = exports.propTypes = {
    className: _propTypes2['default'].string,
    percent: _propTypes2['default'].oneOfType([_propTypes2['default'].number, _propTypes2['default'].string]),
    prefixCls: _propTypes2['default'].string,
    strokeColor: _propTypes2['default'].string,
    strokeLinecap: _propTypes2['default'].oneOf(['butt', 'round', 'square']),
    strokeWidth: _propTypes2['default'].oneOfType([_propTypes2['default'].number, _propTypes2['default'].string]),
    style: _propTypes2['default'].object,
    trailColor: _propTypes2['default'].string,
    trailWidth: _propTypes2['default'].oneOfType([_propTypes2['default'].number, _propTypes2['default'].string])
  };
  },{"prop-types":101}],108:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  /**
   * Escape and wrap key so it is safe to use as a reactid
   *
   * @param {string} key to be escaped.
   * @return {string} the escaped key.
   */
  
  function escape(key) {
    var escapeRegex = /[=:]/g;
    var escaperLookup = {
      '=': '=0',
      ':': '=2'
    };
    var escapedString = ('' + key).replace(escapeRegex, function (match) {
      return escaperLookup[match];
    });
  
    return '$' + escapedString;
  }
  
  /**
   * Unescape and unwrap key for human-readable display
   *
   * @param {string} key to unescape.
   * @return {string} the unescaped key.
   */
  function unescape(key) {
    var unescapeRegex = /(=0|=2)/g;
    var unescaperLookup = {
      '=0': '=',
      '=2': ':'
    };
    var keySubstring = key[0] === '.' && key[1] === '$' ? key.substring(2) : key.substring(1);
  
    return ('' + keySubstring).replace(unescapeRegex, function (match) {
      return unescaperLookup[match];
    });
  }
  
  var KeyEscapeUtils = {
    escape: escape,
    unescape: unescape
  };
  
  module.exports = KeyEscapeUtils;
  },{}],109:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  var _prodInvariant = require('./reactProdInvariant');
  
  var invariant = require('fbjs/lib/invariant');
  
  /**
   * Static poolers. Several custom versions for each potential number of
   * arguments. A completely generic pooler is easy to implement, but would
   * require accessing the `arguments` object. In each of these, `this` refers to
   * the Class itself, not an instance. If any others are needed, simply add them
   * here, or in their own files.
   */
  var oneArgumentPooler = function (copyFieldsFrom) {
    var Klass = this;
    if (Klass.instancePool.length) {
      var instance = Klass.instancePool.pop();
      Klass.call(instance, copyFieldsFrom);
      return instance;
    } else {
      return new Klass(copyFieldsFrom);
    }
  };
  
  var twoArgumentPooler = function (a1, a2) {
    var Klass = this;
    if (Klass.instancePool.length) {
      var instance = Klass.instancePool.pop();
      Klass.call(instance, a1, a2);
      return instance;
    } else {
      return new Klass(a1, a2);
    }
  };
  
  var threeArgumentPooler = function (a1, a2, a3) {
    var Klass = this;
    if (Klass.instancePool.length) {
      var instance = Klass.instancePool.pop();
      Klass.call(instance, a1, a2, a3);
      return instance;
    } else {
      return new Klass(a1, a2, a3);
    }
  };
  
  var fourArgumentPooler = function (a1, a2, a3, a4) {
    var Klass = this;
    if (Klass.instancePool.length) {
      var instance = Klass.instancePool.pop();
      Klass.call(instance, a1, a2, a3, a4);
      return instance;
    } else {
      return new Klass(a1, a2, a3, a4);
    }
  };
  
  var standardReleaser = function (instance) {
    var Klass = this;
    !(instance instanceof Klass) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Trying to release an instance into a pool of a different type.') : _prodInvariant('25') : void 0;
    instance.destructor();
    if (Klass.instancePool.length < Klass.poolSize) {
      Klass.instancePool.push(instance);
    }
  };
  
  var DEFAULT_POOL_SIZE = 10;
  var DEFAULT_POOLER = oneArgumentPooler;
  
  /**
   * Augments `CopyConstructor` to be a poolable class, augmenting only the class
   * itself (statically) not adding any prototypical fields. Any CopyConstructor
   * you give this may have a `poolSize` property, and will look for a
   * prototypical `destructor` on instances.
   *
   * @param {Function} CopyConstructor Constructor that can be used to reset.
   * @param {Function} pooler Customizable pooler.
   */
  var addPoolingTo = function (CopyConstructor, pooler) {
    // Casting as any so that flow ignores the actual implementation and trusts
    // it to match the type we declared
    var NewKlass = CopyConstructor;
    NewKlass.instancePool = [];
    NewKlass.getPooled = pooler || DEFAULT_POOLER;
    if (!NewKlass.poolSize) {
      NewKlass.poolSize = DEFAULT_POOL_SIZE;
    }
    NewKlass.release = standardReleaser;
    return NewKlass;
  };
  
  var PooledClass = {
    addPoolingTo: addPoolingTo,
    oneArgumentPooler: oneArgumentPooler,
    twoArgumentPooler: twoArgumentPooler,
    threeArgumentPooler: threeArgumentPooler,
    fourArgumentPooler: fourArgumentPooler
  };
  
  module.exports = PooledClass;
  }).call(this,require('_process'))
  },{"./reactProdInvariant":130,"_process":134,"fbjs/lib/invariant":94}],110:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _assign = require('object-assign');
  
  var ReactBaseClasses = require('./ReactBaseClasses');
  var ReactChildren = require('./ReactChildren');
  var ReactDOMFactories = require('./ReactDOMFactories');
  var ReactElement = require('./ReactElement');
  var ReactPropTypes = require('./ReactPropTypes');
  var ReactVersion = require('./ReactVersion');
  
  var createReactClass = require('./createClass');
  var onlyChild = require('./onlyChild');
  
  var createElement = ReactElement.createElement;
  var createFactory = ReactElement.createFactory;
  var cloneElement = ReactElement.cloneElement;
  
  if (process.env.NODE_ENV !== 'production') {
    var lowPriorityWarning = require('./lowPriorityWarning');
    var canDefineProperty = require('./canDefineProperty');
    var ReactElementValidator = require('./ReactElementValidator');
    var didWarnPropTypesDeprecated = false;
    createElement = ReactElementValidator.createElement;
    createFactory = ReactElementValidator.createFactory;
    cloneElement = ReactElementValidator.cloneElement;
  }
  
  var __spread = _assign;
  var createMixin = function (mixin) {
    return mixin;
  };
  
  if (process.env.NODE_ENV !== 'production') {
    var warnedForSpread = false;
    var warnedForCreateMixin = false;
    __spread = function () {
      lowPriorityWarning(warnedForSpread, 'React.__spread is deprecated and should not be used. Use ' + 'Object.assign directly or another helper function with similar ' + 'semantics. You may be seeing this warning due to your compiler. ' + 'See https://fb.me/react-spread-deprecation for more details.');
      warnedForSpread = true;
      return _assign.apply(null, arguments);
    };
  
    createMixin = function (mixin) {
      lowPriorityWarning(warnedForCreateMixin, 'React.createMixin is deprecated and should not be used. ' + 'In React v16.0, it will be removed. ' + 'You can use this mixin directly instead. ' + 'See https://fb.me/createmixin-was-never-implemented for more info.');
      warnedForCreateMixin = true;
      return mixin;
    };
  }
  
  var React = {
    // Modern
  
    Children: {
      map: ReactChildren.map,
      forEach: ReactChildren.forEach,
      count: ReactChildren.count,
      toArray: ReactChildren.toArray,
      only: onlyChild
    },
  
    Component: ReactBaseClasses.Component,
    PureComponent: ReactBaseClasses.PureComponent,
  
    createElement: createElement,
    cloneElement: cloneElement,
    isValidElement: ReactElement.isValidElement,
  
    // Classic
  
    PropTypes: ReactPropTypes,
    createClass: createReactClass,
    createFactory: createFactory,
    createMixin: createMixin,
  
    // This looks DOM specific but these are actually isomorphic helpers
    // since they are just generating DOM strings.
    DOM: ReactDOMFactories,
  
    version: ReactVersion,
  
    // Deprecated hook for JSX spread, don't use this for anything.
    __spread: __spread
  };
  
  if (process.env.NODE_ENV !== 'production') {
    var warnedForCreateClass = false;
    if (canDefineProperty) {
      Object.defineProperty(React, 'PropTypes', {
        get: function () {
          lowPriorityWarning(didWarnPropTypesDeprecated, 'Accessing PropTypes via the main React package is deprecated,' + ' and will be removed in  React v16.0.' + ' Use the latest available v15.* prop-types package from npm instead.' + ' For info on usage, compatibility, migration and more, see ' + 'https://fb.me/prop-types-docs');
          didWarnPropTypesDeprecated = true;
          return ReactPropTypes;
        }
      });
  
      Object.defineProperty(React, 'createClass', {
        get: function () {
          lowPriorityWarning(warnedForCreateClass, 'Accessing createClass via the main React package is deprecated,' + ' and will be removed in React v16.0.' + " Use a plain JavaScript class instead. If you're not yet " + 'ready to migrate, create-react-class v15.* is available ' + 'on npm as a temporary, drop-in replacement. ' + 'For more info see https://fb.me/react-create-class');
          warnedForCreateClass = true;
          return createReactClass;
        }
      });
    }
  
    // React.DOM factories are deprecated. Wrap these methods so that
    // invocations of the React.DOM namespace and alert users to switch
    // to the `react-dom-factories` package.
    React.DOM = {};
    var warnedForFactories = false;
    Object.keys(ReactDOMFactories).forEach(function (factory) {
      React.DOM[factory] = function () {
        if (!warnedForFactories) {
          lowPriorityWarning(false, 'Accessing factories like React.DOM.%s has been deprecated ' + 'and will be removed in v16.0+. Use the ' + 'react-dom-factories package instead. ' + ' Version 1.0 provides a drop-in replacement.' + ' For more info, see https://fb.me/react-dom-factories', factory);
          warnedForFactories = true;
        }
        return ReactDOMFactories[factory].apply(ReactDOMFactories, arguments);
      };
    });
  }
  
  module.exports = React;
  }).call(this,require('_process'))
  },{"./ReactBaseClasses":111,"./ReactChildren":112,"./ReactDOMFactories":115,"./ReactElement":116,"./ReactElementValidator":118,"./ReactPropTypes":121,"./ReactVersion":123,"./canDefineProperty":124,"./createClass":126,"./lowPriorityWarning":128,"./onlyChild":129,"_process":134,"object-assign":96}],111:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _prodInvariant = require('./reactProdInvariant'),
      _assign = require('object-assign');
  
  var ReactNoopUpdateQueue = require('./ReactNoopUpdateQueue');
  
  var canDefineProperty = require('./canDefineProperty');
  var emptyObject = require('fbjs/lib/emptyObject');
  var invariant = require('fbjs/lib/invariant');
  var lowPriorityWarning = require('./lowPriorityWarning');
  
  /**
   * Base class helpers for the updating state of a component.
   */
  function ReactComponent(props, context, updater) {
    this.props = props;
    this.context = context;
    this.refs = emptyObject;
    // We initialize the default updater but the real one gets injected by the
    // renderer.
    this.updater = updater || ReactNoopUpdateQueue;
  }
  
  ReactComponent.prototype.isReactComponent = {};
  
  /**
   * Sets a subset of the state. Always use this to mutate
   * state. You should treat `this.state` as immutable.
   *
   * There is no guarantee that `this.state` will be immediately updated, so
   * accessing `this.state` after calling this method may return the old value.
   *
   * There is no guarantee that calls to `setState` will run synchronously,
   * as they may eventually be batched together.  You can provide an optional
   * callback that will be executed when the call to setState is actually
   * completed.
   *
   * When a function is provided to setState, it will be called at some point in
   * the future (not synchronously). It will be called with the up to date
   * component arguments (state, props, context). These values can be different
   * from this.* because your function may be called after receiveProps but before
   * shouldComponentUpdate, and this new state, props, and context will not yet be
   * assigned to this.
   *
   * @param {object|function} partialState Next partial state or function to
   *        produce next partial state to be merged with current state.
   * @param {?function} callback Called after state is updated.
   * @final
   * @protected
   */
  ReactComponent.prototype.setState = function (partialState, callback) {
    !(typeof partialState === 'object' || typeof partialState === 'function' || partialState == null) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'setState(...): takes an object of state variables to update or a function which returns an object of state variables.') : _prodInvariant('85') : void 0;
    this.updater.enqueueSetState(this, partialState);
    if (callback) {
      this.updater.enqueueCallback(this, callback, 'setState');
    }
  };
  
  /**
   * Forces an update. This should only be invoked when it is known with
   * certainty that we are **not** in a DOM transaction.
   *
   * You may want to call this when you know that some deeper aspect of the
   * component's state has changed but `setState` was not called.
   *
   * This will not invoke `shouldComponentUpdate`, but it will invoke
   * `componentWillUpdate` and `componentDidUpdate`.
   *
   * @param {?function} callback Called after update is complete.
   * @final
   * @protected
   */
  ReactComponent.prototype.forceUpdate = function (callback) {
    this.updater.enqueueForceUpdate(this);
    if (callback) {
      this.updater.enqueueCallback(this, callback, 'forceUpdate');
    }
  };
  
  /**
   * Deprecated APIs. These APIs used to exist on classic React classes but since
   * we would like to deprecate them, we're not going to move them over to this
   * modern base class. Instead, we define a getter that warns if it's accessed.
   */
  if (process.env.NODE_ENV !== 'production') {
    var deprecatedAPIs = {
      isMounted: ['isMounted', 'Instead, make sure to clean up subscriptions and pending requests in ' + 'componentWillUnmount to prevent memory leaks.'],
      replaceState: ['replaceState', 'Refactor your code to use setState instead (see ' + 'https://github.com/facebook/react/issues/3236).']
    };
    var defineDeprecationWarning = function (methodName, info) {
      if (canDefineProperty) {
        Object.defineProperty(ReactComponent.prototype, methodName, {
          get: function () {
            lowPriorityWarning(false, '%s(...) is deprecated in plain JavaScript React classes. %s', info[0], info[1]);
            return undefined;
          }
        });
      }
    };
    for (var fnName in deprecatedAPIs) {
      if (deprecatedAPIs.hasOwnProperty(fnName)) {
        defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
      }
    }
  }
  
  /**
   * Base class helpers for the updating state of a component.
   */
  function ReactPureComponent(props, context, updater) {
    // Duplicated from ReactComponent.
    this.props = props;
    this.context = context;
    this.refs = emptyObject;
    // We initialize the default updater but the real one gets injected by the
    // renderer.
    this.updater = updater || ReactNoopUpdateQueue;
  }
  
  function ComponentDummy() {}
  ComponentDummy.prototype = ReactComponent.prototype;
  ReactPureComponent.prototype = new ComponentDummy();
  ReactPureComponent.prototype.constructor = ReactPureComponent;
  // Avoid an extra prototype jump for these methods.
  _assign(ReactPureComponent.prototype, ReactComponent.prototype);
  ReactPureComponent.prototype.isPureReactComponent = true;
  
  module.exports = {
    Component: ReactComponent,
    PureComponent: ReactPureComponent
  };
  }).call(this,require('_process'))
  },{"./ReactNoopUpdateQueue":119,"./canDefineProperty":124,"./lowPriorityWarning":128,"./reactProdInvariant":130,"_process":134,"fbjs/lib/emptyObject":93,"fbjs/lib/invariant":94,"object-assign":96}],112:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var PooledClass = require('./PooledClass');
  var ReactElement = require('./ReactElement');
  
  var emptyFunction = require('fbjs/lib/emptyFunction');
  var traverseAllChildren = require('./traverseAllChildren');
  
  var twoArgumentPooler = PooledClass.twoArgumentPooler;
  var fourArgumentPooler = PooledClass.fourArgumentPooler;
  
  var userProvidedKeyEscapeRegex = /\/+/g;
  function escapeUserProvidedKey(text) {
    return ('' + text).replace(userProvidedKeyEscapeRegex, '$&/');
  }
  
  /**
   * PooledClass representing the bookkeeping associated with performing a child
   * traversal. Allows avoiding binding callbacks.
   *
   * @constructor ForEachBookKeeping
   * @param {!function} forEachFunction Function to perform traversal with.
   * @param {?*} forEachContext Context to perform context with.
   */
  function ForEachBookKeeping(forEachFunction, forEachContext) {
    this.func = forEachFunction;
    this.context = forEachContext;
    this.count = 0;
  }
  ForEachBookKeeping.prototype.destructor = function () {
    this.func = null;
    this.context = null;
    this.count = 0;
  };
  PooledClass.addPoolingTo(ForEachBookKeeping, twoArgumentPooler);
  
  function forEachSingleChild(bookKeeping, child, name) {
    var func = bookKeeping.func,
        context = bookKeeping.context;
  
    func.call(context, child, bookKeeping.count++);
  }
  
  /**
   * Iterates through children that are typically specified as `props.children`.
   *
   * See https://facebook.github.io/react/docs/top-level-api.html#react.children.foreach
   *
   * The provided forEachFunc(child, index) will be called for each
   * leaf child.
   *
   * @param {?*} children Children tree container.
   * @param {function(*, int)} forEachFunc
   * @param {*} forEachContext Context for forEachContext.
   */
  function forEachChildren(children, forEachFunc, forEachContext) {
    if (children == null) {
      return children;
    }
    var traverseContext = ForEachBookKeeping.getPooled(forEachFunc, forEachContext);
    traverseAllChildren(children, forEachSingleChild, traverseContext);
    ForEachBookKeeping.release(traverseContext);
  }
  
  /**
   * PooledClass representing the bookkeeping associated with performing a child
   * mapping. Allows avoiding binding callbacks.
   *
   * @constructor MapBookKeeping
   * @param {!*} mapResult Object containing the ordered map of results.
   * @param {!function} mapFunction Function to perform mapping with.
   * @param {?*} mapContext Context to perform mapping with.
   */
  function MapBookKeeping(mapResult, keyPrefix, mapFunction, mapContext) {
    this.result = mapResult;
    this.keyPrefix = keyPrefix;
    this.func = mapFunction;
    this.context = mapContext;
    this.count = 0;
  }
  MapBookKeeping.prototype.destructor = function () {
    this.result = null;
    this.keyPrefix = null;
    this.func = null;
    this.context = null;
    this.count = 0;
  };
  PooledClass.addPoolingTo(MapBookKeeping, fourArgumentPooler);
  
  function mapSingleChildIntoContext(bookKeeping, child, childKey) {
    var result = bookKeeping.result,
        keyPrefix = bookKeeping.keyPrefix,
        func = bookKeeping.func,
        context = bookKeeping.context;
  
  
    var mappedChild = func.call(context, child, bookKeeping.count++);
    if (Array.isArray(mappedChild)) {
      mapIntoWithKeyPrefixInternal(mappedChild, result, childKey, emptyFunction.thatReturnsArgument);
    } else if (mappedChild != null) {
      if (ReactElement.isValidElement(mappedChild)) {
        mappedChild = ReactElement.cloneAndReplaceKey(mappedChild,
        // Keep both the (mapped) and old keys if they differ, just as
        // traverseAllChildren used to do for objects as children
        keyPrefix + (mappedChild.key && (!child || child.key !== mappedChild.key) ? escapeUserProvidedKey(mappedChild.key) + '/' : '') + childKey);
      }
      result.push(mappedChild);
    }
  }
  
  function mapIntoWithKeyPrefixInternal(children, array, prefix, func, context) {
    var escapedPrefix = '';
    if (prefix != null) {
      escapedPrefix = escapeUserProvidedKey(prefix) + '/';
    }
    var traverseContext = MapBookKeeping.getPooled(array, escapedPrefix, func, context);
    traverseAllChildren(children, mapSingleChildIntoContext, traverseContext);
    MapBookKeeping.release(traverseContext);
  }
  
  /**
   * Maps children that are typically specified as `props.children`.
   *
   * See https://facebook.github.io/react/docs/top-level-api.html#react.children.map
   *
   * The provided mapFunction(child, key, index) will be called for each
   * leaf child.
   *
   * @param {?*} children Children tree container.
   * @param {function(*, int)} func The map function.
   * @param {*} context Context for mapFunction.
   * @return {object} Object containing the ordered map of results.
   */
  function mapChildren(children, func, context) {
    if (children == null) {
      return children;
    }
    var result = [];
    mapIntoWithKeyPrefixInternal(children, result, null, func, context);
    return result;
  }
  
  function forEachSingleChildDummy(traverseContext, child, name) {
    return null;
  }
  
  /**
   * Count the number of children that are typically specified as
   * `props.children`.
   *
   * See https://facebook.github.io/react/docs/top-level-api.html#react.children.count
   *
   * @param {?*} children Children tree container.
   * @return {number} The number of children.
   */
  function countChildren(children, context) {
    return traverseAllChildren(children, forEachSingleChildDummy, null);
  }
  
  /**
   * Flatten a children object (typically specified as `props.children`) and
   * return an array with appropriately re-keyed children.
   *
   * See https://facebook.github.io/react/docs/top-level-api.html#react.children.toarray
   */
  function toArray(children) {
    var result = [];
    mapIntoWithKeyPrefixInternal(children, result, null, emptyFunction.thatReturnsArgument);
    return result;
  }
  
  var ReactChildren = {
    forEach: forEachChildren,
    map: mapChildren,
    mapIntoWithKeyPrefixInternal: mapIntoWithKeyPrefixInternal,
    count: countChildren,
    toArray: toArray
  };
  
  module.exports = ReactChildren;
  },{"./PooledClass":109,"./ReactElement":116,"./traverseAllChildren":131,"fbjs/lib/emptyFunction":92}],113:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2016-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  var _prodInvariant = require('./reactProdInvariant');
  
  var ReactCurrentOwner = require('./ReactCurrentOwner');
  
  var invariant = require('fbjs/lib/invariant');
  var warning = require('fbjs/lib/warning');
  
  function isNative(fn) {
    // Based on isNative() from Lodash
    var funcToString = Function.prototype.toString;
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var reIsNative = RegExp('^' + funcToString
    // Take an example native function source for comparison
    .call(hasOwnProperty
    // Strip regex characters so we can use it for regex
    ).replace(/[\\^$.*+?()[\]{}|]/g, '\\$&'
    // Remove hasOwnProperty from the template to make it generic
    ).replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$');
    try {
      var source = funcToString.call(fn);
      return reIsNative.test(source);
    } catch (err) {
      return false;
    }
  }
  
  var canUseCollections =
  // Array.from
  typeof Array.from === 'function' &&
  // Map
  typeof Map === 'function' && isNative(Map) &&
  // Map.prototype.keys
  Map.prototype != null && typeof Map.prototype.keys === 'function' && isNative(Map.prototype.keys) &&
  // Set
  typeof Set === 'function' && isNative(Set) &&
  // Set.prototype.keys
  Set.prototype != null && typeof Set.prototype.keys === 'function' && isNative(Set.prototype.keys);
  
  var setItem;
  var getItem;
  var removeItem;
  var getItemIDs;
  var addRoot;
  var removeRoot;
  var getRootIDs;
  
  if (canUseCollections) {
    var itemMap = new Map();
    var rootIDSet = new Set();
  
    setItem = function (id, item) {
      itemMap.set(id, item);
    };
    getItem = function (id) {
      return itemMap.get(id);
    };
    removeItem = function (id) {
      itemMap['delete'](id);
    };
    getItemIDs = function () {
      return Array.from(itemMap.keys());
    };
  
    addRoot = function (id) {
      rootIDSet.add(id);
    };
    removeRoot = function (id) {
      rootIDSet['delete'](id);
    };
    getRootIDs = function () {
      return Array.from(rootIDSet.keys());
    };
  } else {
    var itemByKey = {};
    var rootByKey = {};
  
    // Use non-numeric keys to prevent V8 performance issues:
    // https://github.com/facebook/react/pull/7232
    var getKeyFromID = function (id) {
      return '.' + id;
    };
    var getIDFromKey = function (key) {
      return parseInt(key.substr(1), 10);
    };
  
    setItem = function (id, item) {
      var key = getKeyFromID(id);
      itemByKey[key] = item;
    };
    getItem = function (id) {
      var key = getKeyFromID(id);
      return itemByKey[key];
    };
    removeItem = function (id) {
      var key = getKeyFromID(id);
      delete itemByKey[key];
    };
    getItemIDs = function () {
      return Object.keys(itemByKey).map(getIDFromKey);
    };
  
    addRoot = function (id) {
      var key = getKeyFromID(id);
      rootByKey[key] = true;
    };
    removeRoot = function (id) {
      var key = getKeyFromID(id);
      delete rootByKey[key];
    };
    getRootIDs = function () {
      return Object.keys(rootByKey).map(getIDFromKey);
    };
  }
  
  var unmountedIDs = [];
  
  function purgeDeep(id) {
    var item = getItem(id);
    if (item) {
      var childIDs = item.childIDs;
  
      removeItem(id);
      childIDs.forEach(purgeDeep);
    }
  }
  
  function describeComponentFrame(name, source, ownerName) {
    return '\n    in ' + (name || 'Unknown') + (source ? ' (at ' + source.fileName.replace(/^.*[\\\/]/, '') + ':' + source.lineNumber + ')' : ownerName ? ' (created by ' + ownerName + ')' : '');
  }
  
  function getDisplayName(element) {
    if (element == null) {
      return '#empty';
    } else if (typeof element === 'string' || typeof element === 'number') {
      return '#text';
    } else if (typeof element.type === 'string') {
      return element.type;
    } else {
      return element.type.displayName || element.type.name || 'Unknown';
    }
  }
  
  function describeID(id) {
    var name = ReactComponentTreeHook.getDisplayName(id);
    var element = ReactComponentTreeHook.getElement(id);
    var ownerID = ReactComponentTreeHook.getOwnerID(id);
    var ownerName;
    if (ownerID) {
      ownerName = ReactComponentTreeHook.getDisplayName(ownerID);
    }
    process.env.NODE_ENV !== 'production' ? warning(element, 'ReactComponentTreeHook: Missing React element for debugID %s when ' + 'building stack', id) : void 0;
    return describeComponentFrame(name, element && element._source, ownerName);
  }
  
  var ReactComponentTreeHook = {
    onSetChildren: function (id, nextChildIDs) {
      var item = getItem(id);
      !item ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Item must have been set') : _prodInvariant('144') : void 0;
      item.childIDs = nextChildIDs;
  
      for (var i = 0; i < nextChildIDs.length; i++) {
        var nextChildID = nextChildIDs[i];
        var nextChild = getItem(nextChildID);
        !nextChild ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Expected hook events to fire for the child before its parent includes it in onSetChildren().') : _prodInvariant('140') : void 0;
        !(nextChild.childIDs != null || typeof nextChild.element !== 'object' || nextChild.element == null) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Expected onSetChildren() to fire for a container child before its parent includes it in onSetChildren().') : _prodInvariant('141') : void 0;
        !nextChild.isMounted ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Expected onMountComponent() to fire for the child before its parent includes it in onSetChildren().') : _prodInvariant('71') : void 0;
        if (nextChild.parentID == null) {
          nextChild.parentID = id;
          // TODO: This shouldn't be necessary but mounting a new root during in
          // componentWillMount currently causes not-yet-mounted components to
          // be purged from our tree data so their parent id is missing.
        }
        !(nextChild.parentID === id) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Expected onBeforeMountComponent() parent and onSetChildren() to be consistent (%s has parents %s and %s).', nextChildID, nextChild.parentID, id) : _prodInvariant('142', nextChildID, nextChild.parentID, id) : void 0;
      }
    },
    onBeforeMountComponent: function (id, element, parentID) {
      var item = {
        element: element,
        parentID: parentID,
        text: null,
        childIDs: [],
        isMounted: false,
        updateCount: 0
      };
      setItem(id, item);
    },
    onBeforeUpdateComponent: function (id, element) {
      var item = getItem(id);
      if (!item || !item.isMounted) {
        // We may end up here as a result of setState() in componentWillUnmount().
        // In this case, ignore the element.
        return;
      }
      item.element = element;
    },
    onMountComponent: function (id) {
      var item = getItem(id);
      !item ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Item must have been set') : _prodInvariant('144') : void 0;
      item.isMounted = true;
      var isRoot = item.parentID === 0;
      if (isRoot) {
        addRoot(id);
      }
    },
    onUpdateComponent: function (id) {
      var item = getItem(id);
      if (!item || !item.isMounted) {
        // We may end up here as a result of setState() in componentWillUnmount().
        // In this case, ignore the element.
        return;
      }
      item.updateCount++;
    },
    onUnmountComponent: function (id) {
      var item = getItem(id);
      if (item) {
        // We need to check if it exists.
        // `item` might not exist if it is inside an error boundary, and a sibling
        // error boundary child threw while mounting. Then this instance never
        // got a chance to mount, but it still gets an unmounting event during
        // the error boundary cleanup.
        item.isMounted = false;
        var isRoot = item.parentID === 0;
        if (isRoot) {
          removeRoot(id);
        }
      }
      unmountedIDs.push(id);
    },
    purgeUnmountedComponents: function () {
      if (ReactComponentTreeHook._preventPurging) {
        // Should only be used for testing.
        return;
      }
  
      for (var i = 0; i < unmountedIDs.length; i++) {
        var id = unmountedIDs[i];
        purgeDeep(id);
      }
      unmountedIDs.length = 0;
    },
    isMounted: function (id) {
      var item = getItem(id);
      return item ? item.isMounted : false;
    },
    getCurrentStackAddendum: function (topElement) {
      var info = '';
      if (topElement) {
        var name = getDisplayName(topElement);
        var owner = topElement._owner;
        info += describeComponentFrame(name, topElement._source, owner && owner.getName());
      }
  
      var currentOwner = ReactCurrentOwner.current;
      var id = currentOwner && currentOwner._debugID;
  
      info += ReactComponentTreeHook.getStackAddendumByID(id);
      return info;
    },
    getStackAddendumByID: function (id) {
      var info = '';
      while (id) {
        info += describeID(id);
        id = ReactComponentTreeHook.getParentID(id);
      }
      return info;
    },
    getChildIDs: function (id) {
      var item = getItem(id);
      return item ? item.childIDs : [];
    },
    getDisplayName: function (id) {
      var element = ReactComponentTreeHook.getElement(id);
      if (!element) {
        return null;
      }
      return getDisplayName(element);
    },
    getElement: function (id) {
      var item = getItem(id);
      return item ? item.element : null;
    },
    getOwnerID: function (id) {
      var element = ReactComponentTreeHook.getElement(id);
      if (!element || !element._owner) {
        return null;
      }
      return element._owner._debugID;
    },
    getParentID: function (id) {
      var item = getItem(id);
      return item ? item.parentID : null;
    },
    getSource: function (id) {
      var item = getItem(id);
      var element = item ? item.element : null;
      var source = element != null ? element._source : null;
      return source;
    },
    getText: function (id) {
      var element = ReactComponentTreeHook.getElement(id);
      if (typeof element === 'string') {
        return element;
      } else if (typeof element === 'number') {
        return '' + element;
      } else {
        return null;
      }
    },
    getUpdateCount: function (id) {
      var item = getItem(id);
      return item ? item.updateCount : 0;
    },
  
  
    getRootIDs: getRootIDs,
    getRegisteredIDs: getItemIDs,
  
    pushNonStandardWarningStack: function (isCreatingElement, currentSource) {
      if (typeof console.reactStack !== 'function') {
        return;
      }
  
      var stack = [];
      var currentOwner = ReactCurrentOwner.current;
      var id = currentOwner && currentOwner._debugID;
  
      try {
        if (isCreatingElement) {
          stack.push({
            name: id ? ReactComponentTreeHook.getDisplayName(id) : null,
            fileName: currentSource ? currentSource.fileName : null,
            lineNumber: currentSource ? currentSource.lineNumber : null
          });
        }
  
        while (id) {
          var element = ReactComponentTreeHook.getElement(id);
          var parentID = ReactComponentTreeHook.getParentID(id);
          var ownerID = ReactComponentTreeHook.getOwnerID(id);
          var ownerName = ownerID ? ReactComponentTreeHook.getDisplayName(ownerID) : null;
          var source = element && element._source;
          stack.push({
            name: ownerName,
            fileName: source ? source.fileName : null,
            lineNumber: source ? source.lineNumber : null
          });
          id = parentID;
        }
      } catch (err) {
        // Internal state is messed up.
        // Stop building the stack (it's just a nice to have).
      }
  
      console.reactStack(stack);
    },
    popNonStandardWarningStack: function () {
      if (typeof console.reactStackEnd !== 'function') {
        return;
      }
      console.reactStackEnd();
    }
  };
  
  module.exports = ReactComponentTreeHook;
  }).call(this,require('_process'))
  },{"./ReactCurrentOwner":114,"./reactProdInvariant":130,"_process":134,"fbjs/lib/invariant":94,"fbjs/lib/warning":95}],114:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  /**
   * Keeps track of the current owner.
   *
   * The current owner is the component who should own any components that are
   * currently being constructed.
   */
  var ReactCurrentOwner = {
    /**
     * @internal
     * @type {ReactComponent}
     */
    current: null
  };
  
  module.exports = ReactCurrentOwner;
  },{}],115:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var ReactElement = require('./ReactElement');
  
  /**
   * Create a factory that creates HTML tag elements.
   *
   * @private
   */
  var createDOMFactory = ReactElement.createFactory;
  if (process.env.NODE_ENV !== 'production') {
    var ReactElementValidator = require('./ReactElementValidator');
    createDOMFactory = ReactElementValidator.createFactory;
  }
  
  /**
   * Creates a mapping from supported HTML tags to `ReactDOMComponent` classes.
   *
   * @public
   */
  var ReactDOMFactories = {
    a: createDOMFactory('a'),
    abbr: createDOMFactory('abbr'),
    address: createDOMFactory('address'),
    area: createDOMFactory('area'),
    article: createDOMFactory('article'),
    aside: createDOMFactory('aside'),
    audio: createDOMFactory('audio'),
    b: createDOMFactory('b'),
    base: createDOMFactory('base'),
    bdi: createDOMFactory('bdi'),
    bdo: createDOMFactory('bdo'),
    big: createDOMFactory('big'),
    blockquote: createDOMFactory('blockquote'),
    body: createDOMFactory('body'),
    br: createDOMFactory('br'),
    button: createDOMFactory('button'),
    canvas: createDOMFactory('canvas'),
    caption: createDOMFactory('caption'),
    cite: createDOMFactory('cite'),
    code: createDOMFactory('code'),
    col: createDOMFactory('col'),
    colgroup: createDOMFactory('colgroup'),
    data: createDOMFactory('data'),
    datalist: createDOMFactory('datalist'),
    dd: createDOMFactory('dd'),
    del: createDOMFactory('del'),
    details: createDOMFactory('details'),
    dfn: createDOMFactory('dfn'),
    dialog: createDOMFactory('dialog'),
    div: createDOMFactory('div'),
    dl: createDOMFactory('dl'),
    dt: createDOMFactory('dt'),
    em: createDOMFactory('em'),
    embed: createDOMFactory('embed'),
    fieldset: createDOMFactory('fieldset'),
    figcaption: createDOMFactory('figcaption'),
    figure: createDOMFactory('figure'),
    footer: createDOMFactory('footer'),
    form: createDOMFactory('form'),
    h1: createDOMFactory('h1'),
    h2: createDOMFactory('h2'),
    h3: createDOMFactory('h3'),
    h4: createDOMFactory('h4'),
    h5: createDOMFactory('h5'),
    h6: createDOMFactory('h6'),
    head: createDOMFactory('head'),
    header: createDOMFactory('header'),
    hgroup: createDOMFactory('hgroup'),
    hr: createDOMFactory('hr'),
    html: createDOMFactory('html'),
    i: createDOMFactory('i'),
    iframe: createDOMFactory('iframe'),
    img: createDOMFactory('img'),
    input: createDOMFactory('input'),
    ins: createDOMFactory('ins'),
    kbd: createDOMFactory('kbd'),
    keygen: createDOMFactory('keygen'),
    label: createDOMFactory('label'),
    legend: createDOMFactory('legend'),
    li: createDOMFactory('li'),
    link: createDOMFactory('link'),
    main: createDOMFactory('main'),
    map: createDOMFactory('map'),
    mark: createDOMFactory('mark'),
    menu: createDOMFactory('menu'),
    menuitem: createDOMFactory('menuitem'),
    meta: createDOMFactory('meta'),
    meter: createDOMFactory('meter'),
    nav: createDOMFactory('nav'),
    noscript: createDOMFactory('noscript'),
    object: createDOMFactory('object'),
    ol: createDOMFactory('ol'),
    optgroup: createDOMFactory('optgroup'),
    option: createDOMFactory('option'),
    output: createDOMFactory('output'),
    p: createDOMFactory('p'),
    param: createDOMFactory('param'),
    picture: createDOMFactory('picture'),
    pre: createDOMFactory('pre'),
    progress: createDOMFactory('progress'),
    q: createDOMFactory('q'),
    rp: createDOMFactory('rp'),
    rt: createDOMFactory('rt'),
    ruby: createDOMFactory('ruby'),
    s: createDOMFactory('s'),
    samp: createDOMFactory('samp'),
    script: createDOMFactory('script'),
    section: createDOMFactory('section'),
    select: createDOMFactory('select'),
    small: createDOMFactory('small'),
    source: createDOMFactory('source'),
    span: createDOMFactory('span'),
    strong: createDOMFactory('strong'),
    style: createDOMFactory('style'),
    sub: createDOMFactory('sub'),
    summary: createDOMFactory('summary'),
    sup: createDOMFactory('sup'),
    table: createDOMFactory('table'),
    tbody: createDOMFactory('tbody'),
    td: createDOMFactory('td'),
    textarea: createDOMFactory('textarea'),
    tfoot: createDOMFactory('tfoot'),
    th: createDOMFactory('th'),
    thead: createDOMFactory('thead'),
    time: createDOMFactory('time'),
    title: createDOMFactory('title'),
    tr: createDOMFactory('tr'),
    track: createDOMFactory('track'),
    u: createDOMFactory('u'),
    ul: createDOMFactory('ul'),
    'var': createDOMFactory('var'),
    video: createDOMFactory('video'),
    wbr: createDOMFactory('wbr'),
  
    // SVG
    circle: createDOMFactory('circle'),
    clipPath: createDOMFactory('clipPath'),
    defs: createDOMFactory('defs'),
    ellipse: createDOMFactory('ellipse'),
    g: createDOMFactory('g'),
    image: createDOMFactory('image'),
    line: createDOMFactory('line'),
    linearGradient: createDOMFactory('linearGradient'),
    mask: createDOMFactory('mask'),
    path: createDOMFactory('path'),
    pattern: createDOMFactory('pattern'),
    polygon: createDOMFactory('polygon'),
    polyline: createDOMFactory('polyline'),
    radialGradient: createDOMFactory('radialGradient'),
    rect: createDOMFactory('rect'),
    stop: createDOMFactory('stop'),
    svg: createDOMFactory('svg'),
    text: createDOMFactory('text'),
    tspan: createDOMFactory('tspan')
  };
  
  module.exports = ReactDOMFactories;
  }).call(this,require('_process'))
  },{"./ReactElement":116,"./ReactElementValidator":118,"_process":134}],116:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2014-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _assign = require('object-assign');
  
  var ReactCurrentOwner = require('./ReactCurrentOwner');
  
  var warning = require('fbjs/lib/warning');
  var canDefineProperty = require('./canDefineProperty');
  var hasOwnProperty = Object.prototype.hasOwnProperty;
  
  var REACT_ELEMENT_TYPE = require('./ReactElementSymbol');
  
  var RESERVED_PROPS = {
    key: true,
    ref: true,
    __self: true,
    __source: true
  };
  
  var specialPropKeyWarningShown, specialPropRefWarningShown;
  
  function hasValidRef(config) {
    if (process.env.NODE_ENV !== 'production') {
      if (hasOwnProperty.call(config, 'ref')) {
        var getter = Object.getOwnPropertyDescriptor(config, 'ref').get;
        if (getter && getter.isReactWarning) {
          return false;
        }
      }
    }
    return config.ref !== undefined;
  }
  
  function hasValidKey(config) {
    if (process.env.NODE_ENV !== 'production') {
      if (hasOwnProperty.call(config, 'key')) {
        var getter = Object.getOwnPropertyDescriptor(config, 'key').get;
        if (getter && getter.isReactWarning) {
          return false;
        }
      }
    }
    return config.key !== undefined;
  }
  
  function defineKeyPropWarningGetter(props, displayName) {
    var warnAboutAccessingKey = function () {
      if (!specialPropKeyWarningShown) {
        specialPropKeyWarningShown = true;
        process.env.NODE_ENV !== 'production' ? warning(false, '%s: `key` is not a prop. Trying to access it will result ' + 'in `undefined` being returned. If you need to access the same ' + 'value within the child component, you should pass it as a different ' + 'prop. (https://fb.me/react-special-props)', displayName) : void 0;
      }
    };
    warnAboutAccessingKey.isReactWarning = true;
    Object.defineProperty(props, 'key', {
      get: warnAboutAccessingKey,
      configurable: true
    });
  }
  
  function defineRefPropWarningGetter(props, displayName) {
    var warnAboutAccessingRef = function () {
      if (!specialPropRefWarningShown) {
        specialPropRefWarningShown = true;
        process.env.NODE_ENV !== 'production' ? warning(false, '%s: `ref` is not a prop. Trying to access it will result ' + 'in `undefined` being returned. If you need to access the same ' + 'value within the child component, you should pass it as a different ' + 'prop. (https://fb.me/react-special-props)', displayName) : void 0;
      }
    };
    warnAboutAccessingRef.isReactWarning = true;
    Object.defineProperty(props, 'ref', {
      get: warnAboutAccessingRef,
      configurable: true
    });
  }
  
  /**
   * Factory method to create a new React element. This no longer adheres to
   * the class pattern, so do not use new to call it. Also, no instanceof check
   * will work. Instead test $$typeof field against Symbol.for('react.element') to check
   * if something is a React Element.
   *
   * @param {*} type
   * @param {*} key
   * @param {string|object} ref
   * @param {*} self A *temporary* helper to detect places where `this` is
   * different from the `owner` when React.createElement is called, so that we
   * can warn. We want to get rid of owner and replace string `ref`s with arrow
   * functions, and as long as `this` and owner are the same, there will be no
   * change in behavior.
   * @param {*} source An annotation object (added by a transpiler or otherwise)
   * indicating filename, line number, and/or other information.
   * @param {*} owner
   * @param {*} props
   * @internal
   */
  var ReactElement = function (type, key, ref, self, source, owner, props) {
    var element = {
      // This tag allow us to uniquely identify this as a React Element
      $$typeof: REACT_ELEMENT_TYPE,
  
      // Built-in properties that belong on the element
      type: type,
      key: key,
      ref: ref,
      props: props,
  
      // Record the component responsible for creating this element.
      _owner: owner
    };
  
    if (process.env.NODE_ENV !== 'production') {
      // The validation flag is currently mutative. We put it on
      // an external backing store so that we can freeze the whole object.
      // This can be replaced with a WeakMap once they are implemented in
      // commonly used development environments.
      element._store = {};
  
      // To make comparing ReactElements easier for testing purposes, we make
      // the validation flag non-enumerable (where possible, which should
      // include every environment we run tests in), so the test framework
      // ignores it.
      if (canDefineProperty) {
        Object.defineProperty(element._store, 'validated', {
          configurable: false,
          enumerable: false,
          writable: true,
          value: false
        });
        // self and source are DEV only properties.
        Object.defineProperty(element, '_self', {
          configurable: false,
          enumerable: false,
          writable: false,
          value: self
        });
        // Two elements created in two different places should be considered
        // equal for testing purposes and therefore we hide it from enumeration.
        Object.defineProperty(element, '_source', {
          configurable: false,
          enumerable: false,
          writable: false,
          value: source
        });
      } else {
        element._store.validated = false;
        element._self = self;
        element._source = source;
      }
      if (Object.freeze) {
        Object.freeze(element.props);
        Object.freeze(element);
      }
    }
  
    return element;
  };
  
  /**
   * Create and return a new ReactElement of the given type.
   * See https://facebook.github.io/react/docs/top-level-api.html#react.createelement
   */
  ReactElement.createElement = function (type, config, children) {
    var propName;
  
    // Reserved names are extracted
    var props = {};
  
    var key = null;
    var ref = null;
    var self = null;
    var source = null;
  
    if (config != null) {
      if (hasValidRef(config)) {
        ref = config.ref;
      }
      if (hasValidKey(config)) {
        key = '' + config.key;
      }
  
      self = config.__self === undefined ? null : config.__self;
      source = config.__source === undefined ? null : config.__source;
      // Remaining properties are added to a new props object
      for (propName in config) {
        if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) {
          props[propName] = config[propName];
        }
      }
    }
  
    // Children can be more than one argument, and those are transferred onto
    // the newly allocated props object.
    var childrenLength = arguments.length - 2;
    if (childrenLength === 1) {
      props.children = children;
    } else if (childrenLength > 1) {
      var childArray = Array(childrenLength);
      for (var i = 0; i < childrenLength; i++) {
        childArray[i] = arguments[i + 2];
      }
      if (process.env.NODE_ENV !== 'production') {
        if (Object.freeze) {
          Object.freeze(childArray);
        }
      }
      props.children = childArray;
    }
  
    // Resolve default props
    if (type && type.defaultProps) {
      var defaultProps = type.defaultProps;
      for (propName in defaultProps) {
        if (props[propName] === undefined) {
          props[propName] = defaultProps[propName];
        }
      }
    }
    if (process.env.NODE_ENV !== 'production') {
      if (key || ref) {
        if (typeof props.$$typeof === 'undefined' || props.$$typeof !== REACT_ELEMENT_TYPE) {
          var displayName = typeof type === 'function' ? type.displayName || type.name || 'Unknown' : type;
          if (key) {
            defineKeyPropWarningGetter(props, displayName);
          }
          if (ref) {
            defineRefPropWarningGetter(props, displayName);
          }
        }
      }
    }
    return ReactElement(type, key, ref, self, source, ReactCurrentOwner.current, props);
  };
  
  /**
   * Return a function that produces ReactElements of a given type.
   * See https://facebook.github.io/react/docs/top-level-api.html#react.createfactory
   */
  ReactElement.createFactory = function (type) {
    var factory = ReactElement.createElement.bind(null, type);
    // Expose the type on the factory and the prototype so that it can be
    // easily accessed on elements. E.g. `<Foo />.type === Foo`.
    // This should not be named `constructor` since this may not be the function
    // that created the element, and it may not even be a constructor.
    // Legacy hook TODO: Warn if this is accessed
    factory.type = type;
    return factory;
  };
  
  ReactElement.cloneAndReplaceKey = function (oldElement, newKey) {
    var newElement = ReactElement(oldElement.type, newKey, oldElement.ref, oldElement._self, oldElement._source, oldElement._owner, oldElement.props);
  
    return newElement;
  };
  
  /**
   * Clone and return a new ReactElement using element as the starting point.
   * See https://facebook.github.io/react/docs/top-level-api.html#react.cloneelement
   */
  ReactElement.cloneElement = function (element, config, children) {
    var propName;
  
    // Original props are copied
    var props = _assign({}, element.props);
  
    // Reserved names are extracted
    var key = element.key;
    var ref = element.ref;
    // Self is preserved since the owner is preserved.
    var self = element._self;
    // Source is preserved since cloneElement is unlikely to be targeted by a
    // transpiler, and the original source is probably a better indicator of the
    // true owner.
    var source = element._source;
  
    // Owner will be preserved, unless ref is overridden
    var owner = element._owner;
  
    if (config != null) {
      if (hasValidRef(config)) {
        // Silently steal the ref from the parent.
        ref = config.ref;
        owner = ReactCurrentOwner.current;
      }
      if (hasValidKey(config)) {
        key = '' + config.key;
      }
  
      // Remaining properties override existing props
      var defaultProps;
      if (element.type && element.type.defaultProps) {
        defaultProps = element.type.defaultProps;
      }
      for (propName in config) {
        if (hasOwnProperty.call(config, propName) && !RESERVED_PROPS.hasOwnProperty(propName)) {
          if (config[propName] === undefined && defaultProps !== undefined) {
            // Resolve default props
            props[propName] = defaultProps[propName];
          } else {
            props[propName] = config[propName];
          }
        }
      }
    }
  
    // Children can be more than one argument, and those are transferred onto
    // the newly allocated props object.
    var childrenLength = arguments.length - 2;
    if (childrenLength === 1) {
      props.children = children;
    } else if (childrenLength > 1) {
      var childArray = Array(childrenLength);
      for (var i = 0; i < childrenLength; i++) {
        childArray[i] = arguments[i + 2];
      }
      props.children = childArray;
    }
  
    return ReactElement(element.type, key, ref, self, source, owner, props);
  };
  
  /**
   * Verifies the object is a ReactElement.
   * See https://facebook.github.io/react/docs/top-level-api.html#react.isvalidelement
   * @param {?object} object
   * @return {boolean} True if `object` is a valid component.
   * @final
   */
  ReactElement.isValidElement = function (object) {
    return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
  };
  
  module.exports = ReactElement;
  }).call(this,require('_process'))
  },{"./ReactCurrentOwner":114,"./ReactElementSymbol":117,"./canDefineProperty":124,"_process":134,"fbjs/lib/warning":95,"object-assign":96}],117:[function(require,module,exports){
  /**
   * Copyright (c) 2014-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  // The Symbol used to tag the ReactElement type. If there is no native Symbol
  // nor polyfill, then a plain number is used for performance.
  
  var REACT_ELEMENT_TYPE = typeof Symbol === 'function' && Symbol['for'] && Symbol['for']('react.element') || 0xeac7;
  
  module.exports = REACT_ELEMENT_TYPE;
  },{}],118:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2014-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  /**
   * ReactElementValidator provides a wrapper around a element factory
   * which validates the props passed to the element. This is intended to be
   * used only in DEV and could be replaced by a static type checker for languages
   * that support it.
   */
  
  'use strict';
  
  var ReactCurrentOwner = require('./ReactCurrentOwner');
  var ReactComponentTreeHook = require('./ReactComponentTreeHook');
  var ReactElement = require('./ReactElement');
  
  var checkReactTypeSpec = require('./checkReactTypeSpec');
  
  var canDefineProperty = require('./canDefineProperty');
  var getIteratorFn = require('./getIteratorFn');
  var warning = require('fbjs/lib/warning');
  var lowPriorityWarning = require('./lowPriorityWarning');
  
  function getDeclarationErrorAddendum() {
    if (ReactCurrentOwner.current) {
      var name = ReactCurrentOwner.current.getName();
      if (name) {
        return ' Check the render method of `' + name + '`.';
      }
    }
    return '';
  }
  
  function getSourceInfoErrorAddendum(elementProps) {
    if (elementProps !== null && elementProps !== undefined && elementProps.__source !== undefined) {
      var source = elementProps.__source;
      var fileName = source.fileName.replace(/^.*[\\\/]/, '');
      var lineNumber = source.lineNumber;
      return ' Check your code at ' + fileName + ':' + lineNumber + '.';
    }
    return '';
  }
  
  /**
   * Warn if there's no key explicitly set on dynamic arrays of children or
   * object keys are not valid. This allows us to keep track of children between
   * updates.
   */
  var ownerHasKeyUseWarning = {};
  
  function getCurrentComponentErrorInfo(parentType) {
    var info = getDeclarationErrorAddendum();
  
    if (!info) {
      var parentName = typeof parentType === 'string' ? parentType : parentType.displayName || parentType.name;
      if (parentName) {
        info = ' Check the top-level render call using <' + parentName + '>.';
      }
    }
    return info;
  }
  
  /**
   * Warn if the element doesn't have an explicit key assigned to it.
   * This element is in an array. The array could grow and shrink or be
   * reordered. All children that haven't already been validated are required to
   * have a "key" property assigned to it. Error statuses are cached so a warning
   * will only be shown once.
   *
   * @internal
   * @param {ReactElement} element Element that requires a key.
   * @param {*} parentType element's parent's type.
   */
  function validateExplicitKey(element, parentType) {
    if (!element._store || element._store.validated || element.key != null) {
      return;
    }
    element._store.validated = true;
  
    var memoizer = ownerHasKeyUseWarning.uniqueKey || (ownerHasKeyUseWarning.uniqueKey = {});
  
    var currentComponentErrorInfo = getCurrentComponentErrorInfo(parentType);
    if (memoizer[currentComponentErrorInfo]) {
      return;
    }
    memoizer[currentComponentErrorInfo] = true;
  
    // Usually the current owner is the offender, but if it accepts children as a
    // property, it may be the creator of the child that's responsible for
    // assigning it a key.
    var childOwner = '';
    if (element && element._owner && element._owner !== ReactCurrentOwner.current) {
      // Give the component that originally created this child.
      childOwner = ' It was passed a child from ' + element._owner.getName() + '.';
    }
  
    process.env.NODE_ENV !== 'production' ? warning(false, 'Each child in an array or iterator should have a unique "key" prop.' + '%s%s See https://fb.me/react-warning-keys for more information.%s', currentComponentErrorInfo, childOwner, ReactComponentTreeHook.getCurrentStackAddendum(element)) : void 0;
  }
  
  /**
   * Ensure that every element either is passed in a static location, in an
   * array with an explicit keys property defined, or in an object literal
   * with valid key property.
   *
   * @internal
   * @param {ReactNode} node Statically passed child of any type.
   * @param {*} parentType node's parent's type.
   */
  function validateChildKeys(node, parentType) {
    if (typeof node !== 'object') {
      return;
    }
    if (Array.isArray(node)) {
      for (var i = 0; i < node.length; i++) {
        var child = node[i];
        if (ReactElement.isValidElement(child)) {
          validateExplicitKey(child, parentType);
        }
      }
    } else if (ReactElement.isValidElement(node)) {
      // This element was passed in a valid location.
      if (node._store) {
        node._store.validated = true;
      }
    } else if (node) {
      var iteratorFn = getIteratorFn(node);
      // Entry iterators provide implicit keys.
      if (iteratorFn) {
        if (iteratorFn !== node.entries) {
          var iterator = iteratorFn.call(node);
          var step;
          while (!(step = iterator.next()).done) {
            if (ReactElement.isValidElement(step.value)) {
              validateExplicitKey(step.value, parentType);
            }
          }
        }
      }
    }
  }
  
  /**
   * Given an element, validate that its props follow the propTypes definition,
   * provided by the type.
   *
   * @param {ReactElement} element
   */
  function validatePropTypes(element) {
    var componentClass = element.type;
    if (typeof componentClass !== 'function') {
      return;
    }
    var name = componentClass.displayName || componentClass.name;
    if (componentClass.propTypes) {
      checkReactTypeSpec(componentClass.propTypes, element.props, 'prop', name, element, null);
    }
    if (typeof componentClass.getDefaultProps === 'function') {
      process.env.NODE_ENV !== 'production' ? warning(componentClass.getDefaultProps.isReactClassApproved, 'getDefaultProps is only used on classic React.createClass ' + 'definitions. Use a static property named `defaultProps` instead.') : void 0;
    }
  }
  
  var ReactElementValidator = {
    createElement: function (type, props, children) {
      var validType = typeof type === 'string' || typeof type === 'function';
      // We warn in this case but don't throw. We expect the element creation to
      // succeed and there will likely be errors in render.
      if (!validType) {
        if (typeof type !== 'function' && typeof type !== 'string') {
          var info = '';
          if (type === undefined || typeof type === 'object' && type !== null && Object.keys(type).length === 0) {
            info += ' You likely forgot to export your component from the file ' + "it's defined in.";
          }
  
          var sourceInfo = getSourceInfoErrorAddendum(props);
          if (sourceInfo) {
            info += sourceInfo;
          } else {
            info += getDeclarationErrorAddendum();
          }
  
          info += ReactComponentTreeHook.getCurrentStackAddendum();
  
          var currentSource = props !== null && props !== undefined && props.__source !== undefined ? props.__source : null;
          ReactComponentTreeHook.pushNonStandardWarningStack(true, currentSource);
          process.env.NODE_ENV !== 'production' ? warning(false, 'React.createElement: type is invalid -- expected a string (for ' + 'built-in components) or a class/function (for composite ' + 'components) but got: %s.%s', type == null ? type : typeof type, info) : void 0;
          ReactComponentTreeHook.popNonStandardWarningStack();
        }
      }
  
      var element = ReactElement.createElement.apply(this, arguments);
  
      // The result can be nullish if a mock or a custom function is used.
      // TODO: Drop this when these are no longer allowed as the type argument.
      if (element == null) {
        return element;
      }
  
      // Skip key warning if the type isn't valid since our key validation logic
      // doesn't expect a non-string/function type and can throw confusing errors.
      // We don't want exception behavior to differ between dev and prod.
      // (Rendering will throw with a helpful message and as soon as the type is
      // fixed, the key warnings will appear.)
      if (validType) {
        for (var i = 2; i < arguments.length; i++) {
          validateChildKeys(arguments[i], type);
        }
      }
  
      validatePropTypes(element);
  
      return element;
    },
  
    createFactory: function (type) {
      var validatedFactory = ReactElementValidator.createElement.bind(null, type);
      // Legacy hook TODO: Warn if this is accessed
      validatedFactory.type = type;
  
      if (process.env.NODE_ENV !== 'production') {
        if (canDefineProperty) {
          Object.defineProperty(validatedFactory, 'type', {
            enumerable: false,
            get: function () {
              lowPriorityWarning(false, 'Factory.type is deprecated. Access the class directly ' + 'before passing it to createFactory.');
              Object.defineProperty(this, 'type', {
                value: type
              });
              return type;
            }
          });
        }
      }
  
      return validatedFactory;
    },
  
    cloneElement: function (element, props, children) {
      var newElement = ReactElement.cloneElement.apply(this, arguments);
      for (var i = 2; i < arguments.length; i++) {
        validateChildKeys(arguments[i], newElement.type);
      }
      validatePropTypes(newElement);
      return newElement;
    }
  };
  
  module.exports = ReactElementValidator;
  }).call(this,require('_process'))
  },{"./ReactComponentTreeHook":113,"./ReactCurrentOwner":114,"./ReactElement":116,"./canDefineProperty":124,"./checkReactTypeSpec":125,"./getIteratorFn":127,"./lowPriorityWarning":128,"_process":134,"fbjs/lib/warning":95}],119:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2015-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var warning = require('fbjs/lib/warning');
  
  function warnNoop(publicInstance, callerName) {
    if (process.env.NODE_ENV !== 'production') {
      var constructor = publicInstance.constructor;
      process.env.NODE_ENV !== 'production' ? warning(false, '%s(...): Can only update a mounted or mounting component. ' + 'This usually means you called %s() on an unmounted component. ' + 'This is a no-op. Please check the code for the %s component.', callerName, callerName, constructor && (constructor.displayName || constructor.name) || 'ReactClass') : void 0;
    }
  }
  
  /**
   * This is the abstract API for an update queue.
   */
  var ReactNoopUpdateQueue = {
    /**
     * Checks whether or not this composite component is mounted.
     * @param {ReactClass} publicInstance The instance we want to test.
     * @return {boolean} True if mounted, false otherwise.
     * @protected
     * @final
     */
    isMounted: function (publicInstance) {
      return false;
    },
  
    /**
     * Enqueue a callback that will be executed after all the pending updates
     * have processed.
     *
     * @param {ReactClass} publicInstance The instance to use as `this` context.
     * @param {?function} callback Called after state is updated.
     * @internal
     */
    enqueueCallback: function (publicInstance, callback) {},
  
    /**
     * Forces an update. This should only be invoked when it is known with
     * certainty that we are **not** in a DOM transaction.
     *
     * You may want to call this when you know that some deeper aspect of the
     * component's state has changed but `setState` was not called.
     *
     * This will not invoke `shouldComponentUpdate`, but it will invoke
     * `componentWillUpdate` and `componentDidUpdate`.
     *
     * @param {ReactClass} publicInstance The instance that should rerender.
     * @internal
     */
    enqueueForceUpdate: function (publicInstance) {
      warnNoop(publicInstance, 'forceUpdate');
    },
  
    /**
     * Replaces all of the state. Always use this or `setState` to mutate state.
     * You should treat `this.state` as immutable.
     *
     * There is no guarantee that `this.state` will be immediately updated, so
     * accessing `this.state` after calling this method may return the old value.
     *
     * @param {ReactClass} publicInstance The instance that should rerender.
     * @param {object} completeState Next state.
     * @internal
     */
    enqueueReplaceState: function (publicInstance, completeState) {
      warnNoop(publicInstance, 'replaceState');
    },
  
    /**
     * Sets a subset of the state. This only exists because _pendingState is
     * internal. This provides a merging strategy that is not available to deep
     * properties which is confusing. TODO: Expose pendingState or don't use it
     * during the merge.
     *
     * @param {ReactClass} publicInstance The instance that should rerender.
     * @param {object} partialState Next partial state to be merged with state.
     * @internal
     */
    enqueueSetState: function (publicInstance, partialState) {
      warnNoop(publicInstance, 'setState');
    }
  };
  
  module.exports = ReactNoopUpdateQueue;
  }).call(this,require('_process'))
  },{"_process":134,"fbjs/lib/warning":95}],120:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  var ReactPropTypeLocationNames = {};
  
  if (process.env.NODE_ENV !== 'production') {
    ReactPropTypeLocationNames = {
      prop: 'prop',
      context: 'context',
      childContext: 'child context'
    };
  }
  
  module.exports = ReactPropTypeLocationNames;
  }).call(this,require('_process'))
  },{"_process":134}],121:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _require = require('./ReactElement'),
      isValidElement = _require.isValidElement;
  
  var factory = require('prop-types/factory');
  
  module.exports = factory(isValidElement);
  },{"./ReactElement":116,"prop-types/factory":98}],122:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';
  
  module.exports = ReactPropTypesSecret;
  },{}],123:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  module.exports = '15.6.2';
  },{}],124:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  var canDefineProperty = false;
  if (process.env.NODE_ENV !== 'production') {
    try {
      // $FlowFixMe https://github.com/facebook/flow/issues/285
      Object.defineProperty({}, 'x', { get: function () {} });
      canDefineProperty = true;
    } catch (x) {
      // IE will fail on defineProperty
    }
  }
  
  module.exports = canDefineProperty;
  }).call(this,require('_process'))
  },{"_process":134}],125:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _prodInvariant = require('./reactProdInvariant');
  
  var ReactPropTypeLocationNames = require('./ReactPropTypeLocationNames');
  var ReactPropTypesSecret = require('./ReactPropTypesSecret');
  
  var invariant = require('fbjs/lib/invariant');
  var warning = require('fbjs/lib/warning');
  
  var ReactComponentTreeHook;
  
  if (typeof process !== 'undefined' && process.env && process.env.NODE_ENV === 'test') {
    // Temporary hack.
    // Inline requires don't work well with Jest:
    // https://github.com/facebook/react/issues/7240
    // Remove the inline requires when we don't need them anymore:
    // https://github.com/facebook/react/pull/7178
    ReactComponentTreeHook = require('./ReactComponentTreeHook');
  }
  
  var loggedTypeFailures = {};
  
  /**
   * Assert that the values match with the type specs.
   * Error messages are memorized and will only be shown once.
   *
   * @param {object} typeSpecs Map of name to a ReactPropType
   * @param {object} values Runtime values that need to be type-checked
   * @param {string} location e.g. "prop", "context", "child context"
   * @param {string} componentName Name of the component for error messages.
   * @param {?object} element The React element that is being type-checked
   * @param {?number} debugID The React component instance that is being type-checked
   * @private
   */
  function checkReactTypeSpec(typeSpecs, values, location, componentName, element, debugID) {
    for (var typeSpecName in typeSpecs) {
      if (typeSpecs.hasOwnProperty(typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          !(typeof typeSpecs[typeSpecName] === 'function') ? process.env.NODE_ENV !== 'production' ? invariant(false, '%s: %s type `%s` is invalid; it must be a function, usually from React.PropTypes.', componentName || 'React class', ReactPropTypeLocationNames[location], typeSpecName) : _prodInvariant('84', componentName || 'React class', ReactPropTypeLocationNames[location], typeSpecName) : void 0;
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        process.env.NODE_ENV !== 'production' ? warning(!error || error instanceof Error, '%s: type specification of %s `%s` is invalid; the type checker ' + 'function must return `null` or an `Error` but returned a %s. ' + 'You may have forgotten to pass an argument to the type checker ' + 'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' + 'shape all require an argument).', componentName || 'React class', ReactPropTypeLocationNames[location], typeSpecName, typeof error) : void 0;
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;
  
          var componentStackInfo = '';
  
          if (process.env.NODE_ENV !== 'production') {
            if (!ReactComponentTreeHook) {
              ReactComponentTreeHook = require('./ReactComponentTreeHook');
            }
            if (debugID !== null) {
              componentStackInfo = ReactComponentTreeHook.getStackAddendumByID(debugID);
            } else if (element !== null) {
              componentStackInfo = ReactComponentTreeHook.getCurrentStackAddendum(element);
            }
          }
  
          process.env.NODE_ENV !== 'production' ? warning(false, 'Failed %s type: %s%s', location, error.message, componentStackInfo) : void 0;
        }
      }
    }
  }
  
  module.exports = checkReactTypeSpec;
  }).call(this,require('_process'))
  },{"./ReactComponentTreeHook":113,"./ReactPropTypeLocationNames":120,"./ReactPropTypesSecret":122,"./reactProdInvariant":130,"_process":134,"fbjs/lib/invariant":94,"fbjs/lib/warning":95}],126:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _require = require('./ReactBaseClasses'),
      Component = _require.Component;
  
  var _require2 = require('./ReactElement'),
      isValidElement = _require2.isValidElement;
  
  var ReactNoopUpdateQueue = require('./ReactNoopUpdateQueue');
  var factory = require('create-react-class/factory');
  
  module.exports = factory(Component, isValidElement, ReactNoopUpdateQueue);
  },{"./ReactBaseClasses":111,"./ReactElement":116,"./ReactNoopUpdateQueue":119,"create-react-class/factory":91}],127:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  
  'use strict';
  
  /* global Symbol */
  
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.
  
  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }
  
  module.exports = getIteratorFn;
  },{}],128:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2014-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  /**
   * Forked from fbjs/warning:
   * https://github.com/facebook/fbjs/blob/e66ba20ad5be433eb54423f2b097d829324d9de6/packages/fbjs/src/__forks__/warning.js
   *
   * Only change is we use console.warn instead of console.error,
   * and do nothing when 'console' is not supported.
   * This really simplifies the code.
   * ---
   * Similar to invariant but only logs a warning if the condition is not met.
   * This can be used to log issues in development environments in critical
   * paths. Removing the logging code for production environments will keep the
   * same logic and follow the same code paths.
   */
  
  var lowPriorityWarning = function () {};
  
  if (process.env.NODE_ENV !== 'production') {
    var printWarning = function (format) {
      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
  
      var argIndex = 0;
      var message = 'Warning: ' + format.replace(/%s/g, function () {
        return args[argIndex++];
      });
      if (typeof console !== 'undefined') {
        console.warn(message);
      }
      try {
        // --- Welcome to debugging React ---
        // This error was thrown as a convenience so that you can use this stack
        // to find the callsite that caused this warning to fire.
        throw new Error(message);
      } catch (x) {}
    };
  
    lowPriorityWarning = function (condition, format) {
      if (format === undefined) {
        throw new Error('`warning(condition, format, ...args)` requires a warning ' + 'message argument');
      }
      if (!condition) {
        for (var _len2 = arguments.length, args = Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
          args[_key2 - 2] = arguments[_key2];
        }
  
        printWarning.apply(undefined, [format].concat(args));
      }
    };
  }
  
  module.exports = lowPriorityWarning;
  }).call(this,require('_process'))
  },{"_process":134}],129:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  'use strict';
  
  var _prodInvariant = require('./reactProdInvariant');
  
  var ReactElement = require('./ReactElement');
  
  var invariant = require('fbjs/lib/invariant');
  
  /**
   * Returns the first child in a collection of children and verifies that there
   * is only one child in the collection.
   *
   * See https://facebook.github.io/react/docs/top-level-api.html#react.children.only
   *
   * The current implementation of this function assumes that a single child gets
   * passed without a wrapper, but the purpose of this helper function is to
   * abstract away the particular structure of children.
   *
   * @param {?object} children Child collection structure.
   * @return {ReactElement} The first and only `ReactElement` contained in the
   * structure.
   */
  function onlyChild(children) {
    !ReactElement.isValidElement(children) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'React.Children.only expected to receive a single React element child.') : _prodInvariant('143') : void 0;
    return children;
  }
  
  module.exports = onlyChild;
  }).call(this,require('_process'))
  },{"./ReactElement":116,"./reactProdInvariant":130,"_process":134,"fbjs/lib/invariant":94}],130:[function(require,module,exports){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  'use strict';
  
  /**
   * WARNING: DO NOT manually require this module.
   * This is a replacement for `invariant(...)` used by the error code system
   * and will _only_ be required by the corresponding babel pass.
   * It always throws.
   */
  
  function reactProdInvariant(code) {
    var argCount = arguments.length - 1;
  
    var message = 'Minified React error #' + code + '; visit ' + 'http://facebook.github.io/react/docs/error-decoder.html?invariant=' + code;
  
    for (var argIdx = 0; argIdx < argCount; argIdx++) {
      message += '&args[]=' + encodeURIComponent(arguments[argIdx + 1]);
    }
  
    message += ' for the full message or use the non-minified dev environment' + ' for full errors and additional helpful warnings.';
  
    var error = new Error(message);
    error.name = 'Invariant Violation';
    error.framesToPop = 1; // we don't care about reactProdInvariant's own frame
  
    throw error;
  }
  
  module.exports = reactProdInvariant;
  },{}],131:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  'use strict';
  
  var _prodInvariant = require('./reactProdInvariant');
  
  var ReactCurrentOwner = require('./ReactCurrentOwner');
  var REACT_ELEMENT_TYPE = require('./ReactElementSymbol');
  
  var getIteratorFn = require('./getIteratorFn');
  var invariant = require('fbjs/lib/invariant');
  var KeyEscapeUtils = require('./KeyEscapeUtils');
  var warning = require('fbjs/lib/warning');
  
  var SEPARATOR = '.';
  var SUBSEPARATOR = ':';
  
  /**
   * This is inlined from ReactElement since this file is shared between
   * isomorphic and renderers. We could extract this to a
   *
   */
  
  /**
   * TODO: Test that a single child and an array with one item have the same key
   * pattern.
   */
  
  var didWarnAboutMaps = false;
  
  /**
   * Generate a key string that identifies a component within a set.
   *
   * @param {*} component A component that could contain a manual key.
   * @param {number} index Index that is used if a manual key is not provided.
   * @return {string}
   */
  function getComponentKey(component, index) {
    // Do some typechecking here since we call this blindly. We want to ensure
    // that we don't block potential future ES APIs.
    if (component && typeof component === 'object' && component.key != null) {
      // Explicit key
      return KeyEscapeUtils.escape(component.key);
    }
    // Implicit key determined by the index in the set
    return index.toString(36);
  }
  
  /**
   * @param {?*} children Children tree container.
   * @param {!string} nameSoFar Name of the key path so far.
   * @param {!function} callback Callback to invoke with each child found.
   * @param {?*} traverseContext Used to pass information throughout the traversal
   * process.
   * @return {!number} The number of children in this subtree.
   */
  function traverseAllChildrenImpl(children, nameSoFar, callback, traverseContext) {
    var type = typeof children;
  
    if (type === 'undefined' || type === 'boolean') {
      // All of the above are perceived as null.
      children = null;
    }
  
    if (children === null || type === 'string' || type === 'number' ||
    // The following is inlined from ReactElement. This means we can optimize
    // some checks. React Fiber also inlines this logic for similar purposes.
    type === 'object' && children.$$typeof === REACT_ELEMENT_TYPE) {
      callback(traverseContext, children,
      // If it's the only child, treat the name as if it was wrapped in an array
      // so that it's consistent if the number of children grows.
      nameSoFar === '' ? SEPARATOR + getComponentKey(children, 0) : nameSoFar);
      return 1;
    }
  
    var child;
    var nextName;
    var subtreeCount = 0; // Count of children found in the current subtree.
    var nextNamePrefix = nameSoFar === '' ? SEPARATOR : nameSoFar + SUBSEPARATOR;
  
    if (Array.isArray(children)) {
      for (var i = 0; i < children.length; i++) {
        child = children[i];
        nextName = nextNamePrefix + getComponentKey(child, i);
        subtreeCount += traverseAllChildrenImpl(child, nextName, callback, traverseContext);
      }
    } else {
      var iteratorFn = getIteratorFn(children);
      if (iteratorFn) {
        var iterator = iteratorFn.call(children);
        var step;
        if (iteratorFn !== children.entries) {
          var ii = 0;
          while (!(step = iterator.next()).done) {
            child = step.value;
            nextName = nextNamePrefix + getComponentKey(child, ii++);
            subtreeCount += traverseAllChildrenImpl(child, nextName, callback, traverseContext);
          }
        } else {
          if (process.env.NODE_ENV !== 'production') {
            var mapsAsChildrenAddendum = '';
            if (ReactCurrentOwner.current) {
              var mapsAsChildrenOwnerName = ReactCurrentOwner.current.getName();
              if (mapsAsChildrenOwnerName) {
                mapsAsChildrenAddendum = ' Check the render method of `' + mapsAsChildrenOwnerName + '`.';
              }
            }
            process.env.NODE_ENV !== 'production' ? warning(didWarnAboutMaps, 'Using Maps as children is not yet fully supported. It is an ' + 'experimental feature that might be removed. Convert it to a ' + 'sequence / iterable of keyed ReactElements instead.%s', mapsAsChildrenAddendum) : void 0;
            didWarnAboutMaps = true;
          }
          // Iterator will provide entry [k,v] tuples rather than values.
          while (!(step = iterator.next()).done) {
            var entry = step.value;
            if (entry) {
              child = entry[1];
              nextName = nextNamePrefix + KeyEscapeUtils.escape(entry[0]) + SUBSEPARATOR + getComponentKey(child, 0);
              subtreeCount += traverseAllChildrenImpl(child, nextName, callback, traverseContext);
            }
          }
        }
      } else if (type === 'object') {
        var addendum = '';
        if (process.env.NODE_ENV !== 'production') {
          addendum = ' If you meant to render a collection of children, use an array ' + 'instead or wrap the object using createFragment(object) from the ' + 'React add-ons.';
          if (children._isReactElement) {
            addendum = " It looks like you're using an element created by a different " + 'version of React. Make sure to use only one copy of React.';
          }
          if (ReactCurrentOwner.current) {
            var name = ReactCurrentOwner.current.getName();
            if (name) {
              addendum += ' Check the render method of `' + name + '`.';
            }
          }
        }
        var childrenString = String(children);
        !false ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Objects are not valid as a React child (found: %s).%s', childrenString === '[object Object]' ? 'object with keys {' + Object.keys(children).join(', ') + '}' : childrenString, addendum) : _prodInvariant('31', childrenString === '[object Object]' ? 'object with keys {' + Object.keys(children).join(', ') + '}' : childrenString, addendum) : void 0;
      }
    }
  
    return subtreeCount;
  }
  
  /**
   * Traverses children that are typically specified as `props.children`, but
   * might also be specified through attributes:
   *
   * - `traverseAllChildren(this.props.children, ...)`
   * - `traverseAllChildren(this.props.leftPanelChildren, ...)`
   *
   * The `traverseContext` is an optional argument that is passed through the
   * entire traversal. It can be used to store accumulations or anything else that
   * the callback might find relevant.
   *
   * @param {?*} children Children tree object.
   * @param {!function} callback To invoke upon traversing each child.
   * @param {?*} traverseContext Context for traversal.
   * @return {!number} The number of children in this subtree.
   */
  function traverseAllChildren(children, callback, traverseContext) {
    if (children == null) {
      return 0;
    }
  
    return traverseAllChildrenImpl(children, '', callback, traverseContext);
  }
  
  module.exports = traverseAllChildren;
  }).call(this,require('_process'))
  },{"./KeyEscapeUtils":108,"./ReactCurrentOwner":114,"./ReactElementSymbol":117,"./getIteratorFn":127,"./reactProdInvariant":130,"_process":134,"fbjs/lib/invariant":94,"fbjs/lib/warning":95}],132:[function(require,module,exports){
  (function (process){
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   */
  
  /* global hasOwnProperty:true */
  
  'use strict';
  
  var _prodInvariant = require('./reactProdInvariant'),
      _assign = require('object-assign');
  
  var invariant = require('fbjs/lib/invariant');
  var hasOwnProperty = {}.hasOwnProperty;
  
  function shallowCopy(x) {
    if (Array.isArray(x)) {
      return x.concat();
    } else if (x && typeof x === 'object') {
      return _assign(new x.constructor(), x);
    } else {
      return x;
    }
  }
  
  var COMMAND_PUSH = '$push';
  var COMMAND_UNSHIFT = '$unshift';
  var COMMAND_SPLICE = '$splice';
  var COMMAND_SET = '$set';
  var COMMAND_MERGE = '$merge';
  var COMMAND_APPLY = '$apply';
  
  var ALL_COMMANDS_LIST = [COMMAND_PUSH, COMMAND_UNSHIFT, COMMAND_SPLICE, COMMAND_SET, COMMAND_MERGE, COMMAND_APPLY];
  
  var ALL_COMMANDS_SET = {};
  
  ALL_COMMANDS_LIST.forEach(function (command) {
    ALL_COMMANDS_SET[command] = true;
  });
  
  function invariantArrayCase(value, spec, command) {
    !Array.isArray(value) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): expected target of %s to be an array; got %s.', command, value) : _prodInvariant('1', command, value) : void 0;
    var specValue = spec[command];
    !Array.isArray(specValue) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): expected spec of %s to be an array; got %s. Did you forget to wrap your parameter in an array?', command, specValue) : _prodInvariant('2', command, specValue) : void 0;
  }
  
  /**
   * Returns a updated shallow copy of an object without mutating the original.
   * See https://facebook.github.io/react/docs/update.html for details.
   */
  function update(value, spec) {
    !(typeof spec === 'object') ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): You provided a key path to update() that did not contain one of %s. Did you forget to include {%s: ...}?', ALL_COMMANDS_LIST.join(', '), COMMAND_SET) : _prodInvariant('3', ALL_COMMANDS_LIST.join(', '), COMMAND_SET) : void 0;
  
    if (hasOwnProperty.call(spec, COMMAND_SET)) {
      !(Object.keys(spec).length === 1) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Cannot have more than one key in an object with %s', COMMAND_SET) : _prodInvariant('4', COMMAND_SET) : void 0;
  
      return spec[COMMAND_SET];
    }
  
    var nextValue = shallowCopy(value);
  
    if (hasOwnProperty.call(spec, COMMAND_MERGE)) {
      var mergeObj = spec[COMMAND_MERGE];
      !(mergeObj && typeof mergeObj === 'object') ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): %s expects a spec of type \'object\'; got %s', COMMAND_MERGE, mergeObj) : _prodInvariant('5', COMMAND_MERGE, mergeObj) : void 0;
      !(nextValue && typeof nextValue === 'object') ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): %s expects a target of type \'object\'; got %s', COMMAND_MERGE, nextValue) : _prodInvariant('6', COMMAND_MERGE, nextValue) : void 0;
      _assign(nextValue, spec[COMMAND_MERGE]);
    }
  
    if (hasOwnProperty.call(spec, COMMAND_PUSH)) {
      invariantArrayCase(value, spec, COMMAND_PUSH);
      spec[COMMAND_PUSH].forEach(function (item) {
        nextValue.push(item);
      });
    }
  
    if (hasOwnProperty.call(spec, COMMAND_UNSHIFT)) {
      invariantArrayCase(value, spec, COMMAND_UNSHIFT);
      spec[COMMAND_UNSHIFT].forEach(function (item) {
        nextValue.unshift(item);
      });
    }
  
    if (hasOwnProperty.call(spec, COMMAND_SPLICE)) {
      !Array.isArray(value) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'Expected %s target to be an array; got %s', COMMAND_SPLICE, value) : _prodInvariant('7', COMMAND_SPLICE, value) : void 0;
      !Array.isArray(spec[COMMAND_SPLICE]) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): expected spec of %s to be an array of arrays; got %s. Did you forget to wrap your parameters in an array?', COMMAND_SPLICE, spec[COMMAND_SPLICE]) : _prodInvariant('8', COMMAND_SPLICE, spec[COMMAND_SPLICE]) : void 0;
      spec[COMMAND_SPLICE].forEach(function (args) {
        !Array.isArray(args) ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): expected spec of %s to be an array of arrays; got %s. Did you forget to wrap your parameters in an array?', COMMAND_SPLICE, spec[COMMAND_SPLICE]) : _prodInvariant('8', COMMAND_SPLICE, spec[COMMAND_SPLICE]) : void 0;
        nextValue.splice.apply(nextValue, args);
      });
    }
  
    if (hasOwnProperty.call(spec, COMMAND_APPLY)) {
      !(typeof spec[COMMAND_APPLY] === 'function') ? process.env.NODE_ENV !== 'production' ? invariant(false, 'update(): expected spec of %s to be a function; got %s.', COMMAND_APPLY, spec[COMMAND_APPLY]) : _prodInvariant('9', COMMAND_APPLY, spec[COMMAND_APPLY]) : void 0;
      nextValue = spec[COMMAND_APPLY](nextValue);
    }
  
    for (var k in spec) {
      if (!(ALL_COMMANDS_SET.hasOwnProperty(k) && ALL_COMMANDS_SET[k])) {
        nextValue[k] = update(value[k], spec[k]);
      }
    }
  
    return nextValue;
  }
  
  module.exports = update;
  }).call(this,require('_process'))
  },{"./reactProdInvariant":130,"_process":134,"fbjs/lib/invariant":94,"object-assign":96}],133:[function(require,module,exports){
  'use strict';
  
  module.exports = require('./lib/React');
  
  },{"./lib/React":110}],134:[function(require,module,exports){
  // shim for using process in browser
  var process = module.exports = {};
  
  // cached from whatever global is present so that test runners that stub it
  // don't break things.  But we need to wrap it in a try catch in case it is
  // wrapped in strict mode code which doesn't define any globals.  It's inside a
  // function because try/catches deoptimize in certain engines.
  
  var cachedSetTimeout;
  var cachedClearTimeout;
  
  function defaultSetTimout() {
      throw new Error('setTimeout has not been defined');
  }
  function defaultClearTimeout () {
      throw new Error('clearTimeout has not been defined');
  }
  (function () {
      try {
          if (typeof setTimeout === 'function') {
              cachedSetTimeout = setTimeout;
          } else {
              cachedSetTimeout = defaultSetTimout;
          }
      } catch (e) {
          cachedSetTimeout = defaultSetTimout;
      }
      try {
          if (typeof clearTimeout === 'function') {
              cachedClearTimeout = clearTimeout;
          } else {
              cachedClearTimeout = defaultClearTimeout;
          }
      } catch (e) {
          cachedClearTimeout = defaultClearTimeout;
      }
  } ())
  function runTimeout(fun) {
      if (cachedSetTimeout === setTimeout) {
          //normal enviroments in sane situations
          return setTimeout(fun, 0);
      }
      // if setTimeout wasn't available but was latter defined
      if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
          cachedSetTimeout = setTimeout;
          return setTimeout(fun, 0);
      }
      try {
          // when when somebody has screwed with setTimeout but no I.E. maddness
          return cachedSetTimeout(fun, 0);
      } catch(e){
          try {
              // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
              return cachedSetTimeout.call(null, fun, 0);
          } catch(e){
              // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
              return cachedSetTimeout.call(this, fun, 0);
          }
      }
  
  
  }
  function runClearTimeout(marker) {
      if (cachedClearTimeout === clearTimeout) {
          //normal enviroments in sane situations
          return clearTimeout(marker);
      }
      // if clearTimeout wasn't available but was latter defined
      if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
          cachedClearTimeout = clearTimeout;
          return clearTimeout(marker);
      }
      try {
          // when when somebody has screwed with setTimeout but no I.E. maddness
          return cachedClearTimeout(marker);
      } catch (e){
          try {
              // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
              return cachedClearTimeout.call(null, marker);
          } catch (e){
              // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
              // Some versions of I.E. have different rules for clearTimeout vs setTimeout
              return cachedClearTimeout.call(this, marker);
          }
      }
  
  
  
  }
  var queue = [];
  var draining = false;
  var currentQueue;
  var queueIndex = -1;
  
  function cleanUpNextTick() {
      if (!draining || !currentQueue) {
          return;
      }
      draining = false;
      if (currentQueue.length) {
          queue = currentQueue.concat(queue);
      } else {
          queueIndex = -1;
      }
      if (queue.length) {
          drainQueue();
      }
  }
  
  function drainQueue() {
      if (draining) {
          return;
      }
      var timeout = runTimeout(cleanUpNextTick);
      draining = true;
  
      var len = queue.length;
      while(len) {
          currentQueue = queue;
          queue = [];
          while (++queueIndex < len) {
              if (currentQueue) {
                  currentQueue[queueIndex].run();
              }
          }
          queueIndex = -1;
          len = queue.length;
      }
      currentQueue = null;
      draining = false;
      runClearTimeout(timeout);
  }
  
  process.nextTick = function (fun) {
      var args = new Array(arguments.length - 1);
      if (arguments.length > 1) {
          for (var i = 1; i < arguments.length; i++) {
              args[i - 1] = arguments[i];
          }
      }
      queue.push(new Item(fun, args));
      if (queue.length === 1 && !draining) {
          runTimeout(drainQueue);
      }
  };
  
  // v8 likes predictible objects
  function Item(fun, array) {
      this.fun = fun;
      this.array = array;
  }
  Item.prototype.run = function () {
      this.fun.apply(null, this.array);
  };
  process.title = 'browser';
  process.browser = true;
  process.env = {};
  process.argv = [];
  process.version = ''; // empty string to avoid regexp issues
  process.versions = {};
  
  function noop() {}
  
  process.on = noop;
  process.addListener = noop;
  process.once = noop;
  process.off = noop;
  process.removeListener = noop;
  process.removeAllListeners = noop;
  process.emit = noop;
  process.prependListener = noop;
  process.prependOnceListener = noop;
  
  process.listeners = function (name) { return [] }
  
  process.binding = function (name) {
      throw new Error('process.binding is not supported');
  };
  
  process.cwd = function () { return '/' };
  process.chdir = function (dir) {
      throw new Error('process.chdir is not supported');
  };
  process.umask = function() { return 0; };
  
  },{}]},{},[1])(1)
  });
  