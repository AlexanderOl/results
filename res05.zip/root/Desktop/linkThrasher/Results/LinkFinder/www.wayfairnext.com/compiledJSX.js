"use strict";

class BackButton extends React.Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {}
    render() {

        return React.createElement(
            "div",
            { className: "mr-experience-back-button-container" },
            React.createElement(
                "svg",
                { className: "mr-experience-back-button Icon-svg", role: "img", transform: "rotate(180,0,0)", "aria-label": "play-circle-hollow" },
                React.createElement(
                    "svg",
                    { id: "wf-icon-play-circle-hollow", viewBox: "0 0 28 28", width: "100%", height: "100%" },
                    React.createElement("path", { d: "M14 5c-5 0-9 4-9 9s4 9 9 9 9-4 9-9-4-9-9-9zm0 16c-3.9 0-7-3.1-7-7s3.1-7 7-7 7 3.1 7 7-3.1 7-7 7z" }),
                    React.createElement("path", { d: "M16.8 13.6L13 11.2c-.6-.4-1-.2-1 .5v4.6c0 .7.4.9 1 .5l3.8-2.5c.3-.1.3-.5 0-.7z" })
                ),
                React.createElement("use", { xmlnsXlink: "http://www.w3.org/1999/xlink", xlinkHref: "#wf-icon-play-circle-hollow" })
            )
        );
    }
}

"use strict";

class FastLaneDescriptionView extends React.Component {
  constructor(props) {
    super(props);
    this.mlModel = React.createRef();
    this.pixelsToMetersSize = this.pixelsToMetersSize.bind(this);
    this.state = {
      activeModel: {}
    };
  }

  pixelsToMetersSize(value) {
    /* Remove volume's padding from both sides. */
    try {
      let viewportWidthInMeters = window.mlWorld.browserWidth - 0.1;
      let viewportWidthInPixels = window.outerWidth;
      let inputWidthPercentage = parseFloat(value) / viewportWidthInPixels;
      return Math.fround(inputWidthPercentage * viewportWidthInMeters);
    } catch (error) {
      console.log(error);
    }
  }

  metersToPixelSize(value) {
    try {
      let viewportWidthInMeters = window.mlWorld.browserWidth - 0.1;
      let viewportWidthInPixels = window.outerWidth;
      let inputMeterWithPercentage = parseFloat(value) / viewportWidthInMeters;
      return Math.fround(inputMeterWithPercentage * viewportWidthInPixels);
    } catch (error) {
      console.log(error);
    }
  }

  render() {
    const activeScene = this.props.activeItem;
    const skuInfo = activeScene.sceneComposition != undefined ? activeScene.sceneComposition[this.props.focusedSkuID] : undefined;
    const slideIn = skuInfo != undefined && this.props.shouldShowMRDetail;
    let slideClass = "fast-lane-description-state";
    let orientationClass = slideClass + "-right";

    return React.createElement(
      "div",
      { className: slideClass + " " + orientationClass + " " + (slideIn ? orientationClass + "-slide-in" : "") },
      React.createElement(
        "div",
        { className: "fast-lane-description-state-grid-container" },
        React.createElement(
          "div",
          { className: "fast-lane-description-interaction-view" },
          React.createElement(ProductDescriptionSideBar, { skuInfo: skuInfo, toggleProductDetail: this.props.toggleProductDetail, isProductDetailsMinimized: this.props.isProductDetailsMinimized })
        )
      )
    );
  }
}

FastLaneDescriptionView.defaultProps = {
  activeItem: {},
  shouldShowMRDetail: {},
  focusedSkuID: {},
  isProductDetailsMinimized: {}
};

"use strict";

class FastLaneSelectionState extends React.Component {
  constructor(props) {
    super(props);
    this.fastLaneSelectionImageClicked = this.fastLaneSelectionImageClicked.bind(this);
    this.onMouseLeaveFunction = this.onMouseLeaveFunction.bind(this);
    this.onMouseEnterFunction = this.onMouseEnterFunction.bind(this);
  }

  fastLaneSelectionImageClicked(imageArgs, event) {
    this.props.fastLaneDescriptionViewClickedCallBack(imageArgs, event);
  }

  onMouseLeaveFunction(e, t) {
    // show ml model?
    this.props.onMouseLeaveFunction(e, t);
  }

  onMouseEnterFunction(e, t) {
    this.props.onMouseEnterFunction(e, t);
  }

  render() {
    const heroImage = React.createElement(FastLaneSelectionStateHeroImage, { shouldShowMRDetail: this.props.shouldShowMRDetail,
      shouldFadeHeroImage: this.props.shouldFadeHeroImage,
      sceneData: this.props.sceneData[this.props.activeIndex > 0 ? this.props.activeIndex : 0],
      onImageClicked: this.fastLaneSelectionImageClicked,
      pointerEventsEnabled: this.props.pointerEventsEnabled,
      onMouseEnterFunction: this.onMouseEnterFunction,
      onMouseLeaveFunction: this.onMouseLeaveFunction });
    return React.createElement(
      "div",
      { className: "fast-lane-scene-selection-state" },
      heroImage
    );
  }
}

"use strict";

class FastLaneSelectionStateHeroImage extends React.Component {
    constructor(props) {
        super(props);
        this.imageClicked = this.imageClicked.bind(this);
        this.mapElementClicked = this.mapElementClicked.bind(this);
        this.createImageMap = this.createImageMap.bind(this);
        this.onMouseLeaveFunction = this.onMouseLeaveFunction.bind(this);
        this.onMouseEnterFunction = this.onMouseEnterFunction.bind(this);
    }

    imageClicked(e) {}

    mapElementClicked(e) {
        let args = { productKey: e.target.alt, sku: e.target.title };
        this.props.onImageClicked(args, e);
    }

    onMouseLeaveFunction(e, t) {
        // show ml model?
        let map = e.currentTarget.getElementsByClassName("fast-lane-selection-state-hero-image-map")[0];
        e.skuId = map ? map.alt : "";
        this.props.onMouseLeaveFunction(e, t);
    }

    onMouseEnterFunction(e, t) {
        let map = e.currentTarget.getElementsByClassName("fast-lane-selection-state-hero-image-map")[0];
        e.skuId = map ? map.alt : "";
        this.props.onMouseEnterFunction(e, t);
    }

    createImageMap(key, index) {
        ImageMap('img[usemap]');
        const imageComposition = this.props.sceneData.sceneComposition[key];
        return React.createElement("area", {
            className: "fast-lane-selection-state-hero-image-map",
            target: "",
            key: index,
            alt: key,
            "product-sku": imageComposition.sku,
            "data-coords": imageComposition.mappingCoordinates,
            shape: "poly",
            onClick: this.mapElementClicked });
    }

    render() {
        const pointerEventsEnabled = this.props.pointerEventsEnabled;
        const imageAreas = Object.keys(this.props.sceneData.sceneComposition).map(this.createImageMap);
        const styleOpacity = { opacity: this.props.shouldFadeHeroImage ? 0 : 1, transform: this.props.shouldFadeHeroImage ? "scale(0.2)" : "" };
        const imageContainerClass = "fast-lane-selection-state-hero-image-container";
        return React.createElement(
            "div",
            { className: imageContainerClass + " " + (pointerEventsEnabled ? imageContainerClass + "-pointer-enabled" : ""),
                onClick: this.imageClicked,
                onMouseLeave: this.onMouseLeaveFunction,
                onMouseEnter: this.onMouseEnterFunction
            },
            React.createElement("img", { style: styleOpacity, className: "fast-lane-selection-state-hero-image",
                src: this.props.sceneData.sceneImage,
                useMap: "#image-map" }),
            React.createElement(
                "map",
                { name: "image-map", style: { pointerEvents: "none" } },
                imageAreas
            )
        );
    }
}

"use strict";

class FastLaneView extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {}
  render() {
    const visibilityCSS = this.props.fadeOutImage ? " hidden" : " visible";
    var firstSKU = this.props.sceneData.sceneComposition[Object.keys(this.props.sceneData.sceneComposition)[0]];
    return React.createElement(
      "div",
      { className: "fast-lane-view-layout override-impress",
        onClick: this.props.fastLaneViewClickedCallback.bind(this, this.props.index) },
      React.createElement(
        "div",
        { className: "fast-lane-view-layout-content" },
        React.createElement("img", { className: visibilityCSS, src: "./images/" + this.props.sceneData.sceneID + "/" + this.props.sceneData.sceneID + ".jpg" }),
        React.createElement(
          "div",
          { className: "product-info " + (this.props.fadeOut ? "product-info-fade-out" : "") },
          React.createElement(
            "div",
            { className: "name" },
            firstSKU.productName
          ),
          React.createElement(
            "div",
            { className: "product-price-review" },
            React.createElement(
              "div",
              { className: "price" },
              "$",
              firstSKU.productPrice
            ),
            React.createElement(
              "div",
              { className: "product-rating" },
              React.createElement(
                "div",
                null,
                React.createElement(
                  "svg",
                  { className: "ReviewStars-scale" },
                  React.createElement(
                    "svg",
                    { id: "wf-icon-review-stars", viewBox: "0 0 78 13", width: "25%", height: "25%" },
                    React.createElement("path", { d: "M6.64 10.94L3.7 12.48c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7L4.3 3.7 5.75.76c.5-1 1.28-1 1.77 0L9 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L21.75.76c.5-1 1.28-1 1.77 0L25 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L37.75.76c.5-1 1.28-1 1.77 0L41 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L53.75.76c.5-1 1.28-1 1.77 0L57 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L69.75.76c.5-1 1.28-1 1.77 0L73 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54z" })
                  )
                )
              ),
              React.createElement(
                "div",
                { className: "ReviewStars-rating", style: { width: firstSKU.productRating / 5 * 100 + "%" } },
                React.createElement(
                  "svg",
                  { className: "ReviewStars-scale is-filled" },
                  React.createElement(
                    "svg",
                    { id: "wf-icon-review-stars", viewBox: "0 0 78 13", width: "25%", height: "25%" },
                    React.createElement("path", { d: "M6.64 10.94L3.7 12.48c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7L4.3 3.7 5.75.76c.5-1 1.28-1 1.77 0L9 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L21.75.76c.5-1 1.28-1 1.77 0L25 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L37.75.76c.5-1 1.28-1 1.77 0L41 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L53.75.76c.5-1 1.28-1 1.77 0L57 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L69.75.76c.5-1 1.28-1 1.77 0L73 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54z" })
                  )
                )
              )
            )
          )
        )
      )
    );
  }
}

"use strict";

class MRExperience extends React.Component {
  constructor(props) {
    super(props);
    this.fastLaneAvatarSelected = this.fastLaneAvatarSelected.bind(this);
    this.stateComponent = this.stateComponent.bind(this);
    this.moveHighlightImageLeft = this.moveHighlightImageLeft.bind(this);
    this.state = {
      experienceState: MRExperience.defaultProps.experienceState,
      shouldAnimateView: true,
      activeItem: -1,
      focusedSkuID: "",
      shouldShowMRDetail: false,
      shouldFadeHeroImage: false,
      state2PointerEvents: false,
      descriptionMouseEventFired: false,
      fallingAnimationFinished: false,
      isProductDetailsMinimized: false,
      shouldHideLoadingScreen: false
    };
    this.fastLaneDescriptionViewClickedCallBack = this.fastLaneDescriptionViewClickedCallBack.bind(this);
    this.backgroundClicked = this.backgroundClicked.bind(this);
    this.impressive = React.createRef();
    this.sceneData = Utils.sceneData();
    this.descriptionStateMouseLeaveFunction = this.descriptionStateMouseLeaveFunction.bind(this);
    this.descriptionStateMouseEnterFunction = this.descriptionStateMouseEnterFunction.bind(this);
    this.impressDidTransition = this.impressDidTransition.bind(this);
    this.fastFowardFunction = this.fastFowardFunction.bind(this);
    this.disableMouseTimeoutFunction = this.disableMouseTimeoutFunction.bind(this);
    this.flashBackwardsTimeoutFunction = this.flashBackwardsTimeoutFunction.bind(this);
    this.backButtonPressed = this.backButtonPressed.bind(this);
    this.lastHash = "";
    this.modelsFinishedLoaded = this.modelsFinishedLoaded.bind(this);
  }

  stateComponent(experienceState) {
    switch (experienceState) {
      case 0:
        return React.createElement(RoomLayout, { experienceState: this.state.experienceState,
          data: { x: 0, y: 0, scale: 1 },
          sceneData: this.sceneData,
          fastLaneViewClickedCallback: this.fastLaneAvatarSelected });
      case 1:
        return React.createElement(FastLaneSelectionState, { sceneData: this.sceneData,
          activeIndex: this.state.activeItem,
          shouldFadeHeroImage: this.state.shouldFadeHeroImage,
          fastLaneDescriptionViewClickedCallBack: this.fastLaneDescriptionViewClickedCallBack,
          pointerEventsEnabled: this.state.state2PointerEvents,
          onMouseEnterFunction: this.descriptionStateMouseEnterFunction,
          onMouseLeaveFunction: this.descriptionStateMouseLeaveFunction });
      case 2:
        return React.createElement(FastLaneDescriptionView, { activeItem: this.sceneData[this.state.activeItem],
          shouldShowMRDetail: this.state.shouldShowMRDetail,
          focusedSkuID: this.state.focusedSkuID,
          toggleProductDetail: this.toggleProductDetail.bind(this),
          isProductDetailsMinimized: this.state.isProductDetailsMinimized });
      default:
        return React.createElement(RoomLayout, { experienceState: this.state.experienceState, fastLaneViewClickedCallback: this.fastLaneAvatarSelected });
    }
  }

  backgroundClicked(e) {
    if (e && e.target && e.target.id == "pdpLink") {
      return;
    }
    const stepsData = this.impressive.current.getStepsData();
    const prevKey = "step-" + (this.state.experienceState > 0 ? this.state.experienceState : 1);
    const step = stepsData[prevKey];
    const step2 = document.getElementById("step-2");
    if (prevKey == "step-2") {
      this.impressive.current.goto(step, 800, 0, -600);
      const newStyle = step2.style.transform.replace("translate(-85%, -50%)", "translate(-50%, -50%)");
      step2.style.transition = "0.4s ease";
      step2.style.transform = newStyle;
      setTimeout(this.flashBackwardsTimeoutFunction, 300);
    } else {
      step2.style.transition = "";
      this.impressive.current.goto(step, 800, 0, 0);
    }

    this.setState({
      experienceState: this.state.experienceState - 1 >= 0 ? this.state.experienceState - 1 : 0,
      shouldShowMRDetail: false,
      focusedSkuID: "",
      shouldFadeHeroImage: false,
      state2PointerEvents: false,
      descriptionMouseEventFired: false,
      fallingAnimationFinished: false,
      isProductDetailsMinimized: false
    });
  }

  toggleProductDetail() {
    this.setState({
      isProductDetailsMinimized: !this.state.isProductDetailsMinimized
    });
  }

  flashBackwardsTimeoutFunction() {
    this.backgroundClicked();
  }

  fastLaneDescriptionViewClickedCallBack(args, event) {
    event.stopPropagation();
    const selectedSKU = args.productKey;
    this.setState({
      experienceState: 2,
      focusedSkuID: selectedSKU,
      shouldShowMRDetail: true
    });
    this.moveHighlightImageLeft();
  }

  moveHighlightImageLeft() {
    const step2 = document.getElementById("step-2");
    const newStyle = step2.style.transform.replace("translate(-50%, -50%)", "translate(-85%, -50%)");
    step2.style.transform = newStyle;
    step2.style.transition = "0.4s ease";
  }

  descriptionStateMouseLeaveFunction(e, t) {
    //needed?
  }

  descriptionStateMouseEnterFunction(e, t) {
    if (!this.state.shouldFadeHeroImage && this.state.experienceState == 2) {
      let mlElement = document.getElementById(e.skuId);

      var mouseOutEvent = new MouseEvent("mouseout", { bubbles: true, cancelable: true });
      mlElement.dispatchEvent(mouseOutEvent);

      mlElement._model.setAnchorPosition(new Float32Array([0, 0, 0]));
      mlElement._model.setLocalPosition(new Float32Array([0, 0, 0]));
      mlElement._transform.setLocalPosition(new Float32Array([0, 0, 0]));

      mlElement.extractable = false;

      //listen for animation end event once
      mlElement.addEventListener('transform-animation-end', e => {
        if (e.detail.track === 1) {
          mlElement.extractable = true;
        }
      }, { once: true });

      //animation
      mlElement.moveBy = `axes: 0 -${mlElement.clientHeight / 2}px 0; duration: 1s; track: 1`;
      setTimeout(function () {
        this.setState({
          fallingAnimationFinished: true
        });
      }.bind(this), 1500);

      this.setState({
        focusedSkuID: e.skuId,
        shouldFadeHeroImage: true,
        descriptionMouseEventFired: true
      });
    }
  }

  fastLaneAvatarSelected(index, event) {
    event.stopPropagation();
    const stepsData = this.impressive.current.getStepsData();
    const step2 = stepsData["step-2"];

    var xOffsetR = 1049;
    var xOffsetL = 1025;
    var yBottomOffset = 529;
    var yTopOffset = 509;
    var center = 12;

    switch (index) {
      case 0:
        step2.data.x = -xOffsetL;
        step2.data.y = -yTopOffset;
        break;
      case 1:
        step2.data.x = center;
        step2.data.y = -yTopOffset;
        break;
      case 2:
        step2.data.x = xOffsetR;
        step2.data.y = -yTopOffset;
        break;
      case 3:
        step2.data.x = -xOffsetL;
        step2.data.y = yBottomOffset;
        break;
      case 4:
        step2.data.x = center;
        step2.data.y = yBottomOffset;
        break;
      case 5:
        step2.data.x = xOffsetR;
        step2.data.y = yBottomOffset;
        break;
      default:
        step2.data.x = -xOffsetL;
        step2.data.y = -yTopOffset;
        break;
    }

    //step2.data.y = index * 500;
    this.impressive.current.goto(step2, 800, 400, -600);

    this.setState({
      activeItem: index,
      experienceState: 1,
      focusedSkuID: ""
    });

    setTimeout(this.disableMouseTimeoutFunction.bind(null, index), 2400);

    setTimeout(this.fastFowardFunction.bind(null, index), 1300);
  }

  fastFowardFunction(index) {
    if (this.state.experienceState == 1) {
      var firstSKU = Object.keys(this.sceneData[index].sceneComposition)[0];
      this.setState({
        experienceState: 2,
        focusedSkuID: firstSKU,
        shouldShowMRDetail: true
      });
      this.moveHighlightImageLeft();
    }
  }

  disableMouseTimeoutFunction(index) {
    if (this.state.experienceState == 2) {
      this.setState({
        state2PointerEvents: true
      });
    } else {
      this.setState({
        state2PointerEvents: false
      });
    }
  }

  impressDidTransition(step, duration) {
    if (step.id == "step-2") {
      // move model back up to behind the image

    }
  }

  componentDidMount() {
    if (window.mlWorld === undefined) {
      document.body.style.backgroundColor = "black";
    }
    const step2 = document.getElementById("step-2");
    step2.style.transition = "";

    // URL hash change
    window.addEventListener('hashchange', this.backButtonPressed, false);
  }

  getElementFromHash(hash) {
    let id = hash.replace(/^#\/step-?/, '');
    return id;
  }

  backButtonPressed() {
    let hashIndex = this.getElementFromHash(window.location.hash);
    let lastHashIndex = this.getElementFromHash(this.lastHash);
    if (hashIndex < lastHashIndex) {
      this.backgroundClicked();
    }
    this.lastHash = window.location.hash;
  }

  modelsFinishedLoaded() {
    this.setState({
      shouldHideLoadingScreen: true
    });
  }

  render() {
    //const shouldShow = this.
    // const classes = item-wrapper `${}`
    let urls = ["KMDS3246", "LGLY3171", "THRE2933", "KMDS3246_1", "LGLY3171_1", "THRE2933_1"];
    const Impress = reactImpressjs.Impress;
    const Step = reactImpressjs.Step;
    return React.createElement(
      "div",
      null,
      React.createElement(
        "div",
        { className: this.state.shouldHideLoadingScreen ? "experience-loading-screen-hide" : "experience-loading-screen" },
        React.createElement(
          "div",
          { className: "experience-loading-icon" },
          React.createElement(
            "div",
            { className: "loading" },
            "Loading..."
          )
        )
      ),
      React.createElement(
        "div",
        { className: "experience-container" + (this.state.shouldHideLoadingScreen ? "-show" : "-hide"), onClick: this.backgroundClicked },
        this.state.experienceState == 1 || this.state.experienceState == 2 ? React.createElement(BackButton, { onClick: this.backgroundClicked }) : undefined,
        React.createElement(
          Impress,
          {
            className: "impressStuff",
            progress: false,
            hint: false,
            ref: this.impressive,
            impressDidTransition: this.impressDidTransition,
            fallbackMessage: React.createElement(
              "p",
              null,
              "Sorry, your ",
              React.createElement(
                "b",
                null,
                "device or browser"
              ),
              " couldn't support well."
            )
          },
          React.createElement(
            Step,
            { className: "mr-experience-container", data: { x: 0,
                y: 0,
                z: 0,
                scale: 1
              }, ref: this.step1 },
            this.stateComponent(0)
          ),
          React.createElement(
            Step,
            { className: "mr-experience-container", data: {
                x: -1025,
                y: -509,
                z: -2400,
                scale: 1
              }, ref: this.step2
            },
            this.stateComponent(1)
          )
        ),
        this.stateComponent(2),
        React.createElement(MRModels, { sceneData: this.sceneData,
          modelsFinishedLoaded: this.modelsFinishedLoaded,
          fallingAnimationFinished: this.state.fallingAnimationFinished,
          mouseEventFired: this.state.descriptionMouseEventFired,
          focusedSkuID: this.state.focusedSkuID })
      )
    );
  }
}

MRExperience.defaultProps = {
  activeImage: -1,
  experienceState: 0
};

"use strict";

class MRModels extends React.Component {
    constructor(props) {
        super(props);
        this.sceneArray = this.sceneArray.bind(this);
        this.createModelHashMap = this.createModelHashMap.bind(this);
        this.masterCompositionList = {};
        this.containerDiv = React.createRef();
        this.modelDidLoad = this.modelDidLoad.bind(this);
    }

    createModelHashMap(start, end) {
        this.masterCompositionList = {};
        let sceneData = this.props.sceneData;

        for (let i = start; i < end; i++) {
            const scene = sceneData[i];
            let sceneComposition = Object.keys(scene.sceneComposition);
            for (let j = 0; j < sceneComposition.length; j++) {
                this.masterCompositionList[sceneComposition[j]] = scene.sceneComposition[sceneComposition[j]];
            }
        }
    }

    modelDidLoad(el) {
        if (el.target.className == "ml-description-model") {
            el.target.className += "-loaded";
        } else if (el.target.className == "ml-description-model-box") {
            setTimeout(() => {
                this.props.modelsFinishedLoaded();
            }, 200);
        } else {}
    }

    componentDidMount() {
        // add event listeners
        let mlModels = this.containerDiv.current.getElementsByClassName("ml-description-model");
        let mlModelsArray = Array.from(mlModels);
        mlModelsArray.map(el => {
            el.addEventListener("model-displayed", this.modelDidLoad);
            el.addEventListener("extracting-node", function (e) {
                el._model.setAnchorPosition(new Float32Array([el._resource.center.x, el._resource.center.y, el._resource.center.z]));
            });

            el.addEventListener("node-extracted", function (e) {
                el._model.setAnchorPosition(new Float32Array([0, 0, 0]));
            });
        });

        let mlModelBox = this.containerDiv.current.getElementsByClassName("ml-description-model-box");
        let mlModelBoxArray = Array.from(mlModelBox);
        mlModelBoxArray.map(el => {
            el.addEventListener("model-displayed", this.modelDidLoad);
        });
    }

    componentWillUnmount() {
        // remove event listeners
        let mlModels = this.containerDiv.current.getElementsByClassName("ml-description-model");
        let mlModelsArray = Array.from(mlModels);
        mlModelsArray.map(el => {
            el.removeEventListener("model-displayed", this.modelDidLoad);
            el.removeEventListener("extracting-node");
            el.removeEventListener("node-extracted");
            el.removeEventListener("mltransformanimation");
        });

        let mlModelBox = this.containerDiv.current.getElementsByClassName("ml-description-model-box");
        let mlModelBoxArray = Array.from(mlModelBox);
        mlModelBoxArray.map(el => {
            el.removeEventListener("model-displayed", this.modelDidLoad);
        });
    }

    componentWillMount() {
        this.createModelHashMap(0, 6);
    }

    metersToPixelSize(value) {
        try {
            let viewportWidthInMeters = window.mlWorld.browserWidth - 0.1;
            let viewportWidthInPixels = window.outerWidth;
            let inputMeterWithPercentage = parseFloat(value) / viewportWidthInMeters;
            return Math.fround(inputMeterWithPercentage * viewportWidthInPixels);
        } catch (error) {
            console.log(error);
        }
    }

    sceneArray(sceneObject, index) {
        const realScale = [this.masterCompositionList[sceneObject].dimX * 0.0254, this.masterCompositionList[sceneObject].dimY * 0.0254, this.masterCompositionList[sceneObject].dimZ * 0.0254];
        let visible = this.props.focusedSkuID == sceneObject && this.props.mouseEventFired;

        let objectSize = {
            height: "100%",
            width: "515px",
            breadth: "515px",
            //pointerEvents : "none"
            pointerEvents: visible && this.props.fallingAnimationFinished ? "auto" : "none"
        };

        let scaleDownFactor = 0.19602151215076447;
        let roomDimensions = {
            x: 4.826,
            y: 3.161,
            z: 4.062
        };

        let placementOffset = 1.651;
        return React.createElement(
            "div",
            { key: index },
            React.createElement("ml-model", {
                style: objectSize,
                "class": "ml-description-model",
                breadth: objectSize.breadth,
                visibility: visible ? "visible" : "hidden",
                src: this.masterCompositionList[sceneObject].modelURL,
                observable: "false",
                "prism-rotation": this.masterCompositionList[sceneObject].spawnRotation,
                extractable: "true",
                "z-offset": -this.metersToPixelSize(placementOffset * scaleDownFactor),
                "extracted-size": `${parseFloat(realScale[0])}, ${parseFloat(realScale[1])}, ${parseFloat(realScale[2])}`,
                "respect-mesh-units": "true",
                "model-scale": "0.38740997335289706 0.38740997335289706 0.38740997335289706",
                id: sceneObject,
                unbounded: "true" })
        );
    }

    render() {

        let mlModels = Object.keys(this.masterCompositionList).map(this.sceneArray);
        let objectSize = {
            height: "110%",
            width: "110%"
        };
        let scaleDownFactor = 0.19602151215076447;
        let roomDimensions = {
            x: 4.826,
            y: 3.161,
            z: 4.062
        };
        return React.createElement(
            "div",
            { ref: this.containerDiv },
            React.createElement("ml-model", {
                id: "box",
                fill: "true",
                style: objectSize,
                "class": "ml-description-model-box",
                visibility: "visible",
                src: "./models/box_with_transform.fbx"
                //src={"./models/fireAnimationAnim.fbx"}
                , "model-animation": "fireAnimation, false, -1",
                "model-animation-speed": "1",
                observable: "false",
                extractable: "false",
                "z-offset": -this.metersToPixelSize(roomDimensions.z * 0.5 * scaleDownFactor),
                "extracted-size": 0.0254,
                "respect-mesh-units": "true",
                "model-scale": "1 1 1",
                unbounded: "true" }),
            mlModels
        );
    }
}

"use strict";

class Placeholder extends React.Component {
  constructor(props) {
    super(props);
  }

  goToBlog() {
    window.location.replace("https://tech.wayfair.com/category/wayfair-next/");
  }

  render() {

    return React.createElement(
      "div",
      { className: "mixed-reality-not-supported-placeholder", onClick: this.goToBlog },
      React.createElement("img", { className: "logo", src: "images/wayfair-logo.png" }),
      React.createElement(
        "div",
        null,
        React.createElement("img", { src: "images/wayfair-mixed-reality.jpg" }),
        React.createElement(
          "p",
          null,
          "This experience is best viewed on Helio - Magic Leap's web browser",
          React.createElement("br", null),
          React.createElement("br", null),
          "Click to see a preview and learn more."
        )
      )
    );
  }
}

"use strict";

class ProductDescriptionSideBar extends React.Component {
  constructor(props) {
    super(props);
  }

  minimizedClicked(e) {
    this.props.toggleProductDetail();
    e.preventDefault();
    e.stopPropagation();
  }

  render() {
    return React.createElement(
      "div",
      null,
      React.createElement(
        "div",
        { className: "fast-lane-description-side-bar " + (this.props.isProductDetailsMinimized ? "minimized" : "") },
        React.createElement(
          "div",
          { className: "description-component" },
          React.createElement(
            "div",
            { className: "minimize-icon", onClick: this.minimizedClicked.bind(this) },
            this.props.isProductDetailsMinimized ? React.createElement(
              "svg",
              { id: "wf-icon-chevron-up", viewBox: "0 0 28 28", width: "100%", height: "100%" },
              React.createElement("path", { d: "M8.9 16.8c.4.4 1 .4 1.4.1l3.8-3.5 3.8 3.4c.4.4 1 .3 1.4-.1.4-.4.3-1-.1-1.4l-4.5-4c-.2-.2-.4-.3-.7-.3s-.5.1-.7.3l-4.5 4c-.3.4-.3 1.1.1 1.5z" })
            ) : React.createElement(
              "svg",
              { id: "wf-icon-chevron-down", viewBox: "0 0 28 28", width: "100%", height: "100%" },
              React.createElement("path", { d: "M19.2 11.3c-.4-.4-1-.4-1.4-.1L14 14.7l-3.8-3.4c-.4-.4-1-.3-1.4.1-.4.4-.3 1 .1 1.4l4.5 4c.2.2.4.3.7.3s.5-.1.7-.3l4.5-4c.3-.4.3-1.1-.1-1.5z" })
            )
          ),
          React.createElement(
            "div",
            { className: "product-name" },
            " ",
            this.props.skuInfo.productName,
            " "
          ),
          React.createElement(
            "div",
            { className: "product-manu" },
            " by ",
            this.props.skuInfo.productManu,
            " "
          ),
          React.createElement(
            "div",
            { className: "product-rating" },
            React.createElement(
              "div",
              null,
              React.createElement(
                "svg",
                { className: "ReviewStars-scale" },
                React.createElement(
                  "svg",
                  { id: "wf-icon-review-stars", viewBox: "0 0 78 13", width: "100%", height: "100%" },
                  React.createElement("path", { d: "M6.64 10.94L3.7 12.48c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7L4.3 3.7 5.75.76c.5-1 1.28-1 1.77 0L9 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L21.75.76c.5-1 1.28-1 1.77 0L25 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L37.75.76c.5-1 1.28-1 1.77 0L41 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L53.75.76c.5-1 1.28-1 1.77 0L57 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L69.75.76c.5-1 1.28-1 1.77 0L73 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54z" })
                )
              )
            ),
            React.createElement(
              "div",
              { className: "ReviewStars-rating", style: { width: this.props.skuInfo.productRating / 5 * 100 + "%" } },
              React.createElement(
                "svg",
                { className: "ReviewStars-scale is-filled" },
                React.createElement(
                  "svg",
                  { id: "wf-icon-review-stars", viewBox: "0 0 78 13", width: "100%", height: "100%" },
                  React.createElement("path", { d: "M6.64 10.94L3.7 12.48c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7L4.3 3.7 5.75.76c.5-1 1.28-1 1.77 0L9 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L21.75.76c.5-1 1.28-1 1.77 0L25 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L37.75.76c.5-1 1.28-1 1.77 0L41 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L53.75.76c.5-1 1.28-1 1.77 0L57 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54zm16 0l-2.93 1.54c-.97.52-1.6.05-1.43-1.04l.56-3.26-2.36-2.3c-.8-.78-.55-1.54.54-1.7l3.28-.47L69.75.76c.5-1 1.28-1 1.77 0L73 3.7l3.26.48c1.1.16 1.34.92.55 1.7l-2.36 2.3.56 3.26c.2 1.1-.46 1.56-1.44 1.04l-2.92-1.54z" })
                )
              )
            ),
            React.createElement(
              "div",
              { className: "Review-count" },
              this.props.skuInfo.productReviews
            )
          ),
          React.createElement(
            "div",
            { className: "product-price" },
            "$",
            this.props.skuInfo.productPrice,
            " "
          ),
          React.createElement(
            "div",
            { className: "margin-55" },
            React.createElement("img", { src: this.props.skuInfo ? this.props.skuInfo.skuImageURL : "" }),
            React.createElement(
              "a",
              { id: "pdpLink", href: this.props.skuInfo.pdpLink, target: "_blank", className: "product-link" },
              "View on Wayfair"
            ),
            React.createElement("div", { className: "product-description", dangerouslySetInnerHTML: { __html: this.props.skuInfo.productDescription } })
          )
        )
      )
    );
  }
}

ProductDescriptionSideBar.defaultProps = {
  skuInfo: {},
  isProductDetailsMinimized: {}
};

"use strict";

class RoomLayout extends React.Component {

    constructor(props) {
        super(props);
        this.mapFunction = this.mapFunction.bind(this);
        this.clickFunction = this.clickFunction.bind(this);
        this.clickedDown = this.clickedDown.bind(this);
        this.clickedUp = this.clickedUp.bind(this);
        this.state = { focusIndex: -1 };
    }

    clickFunction(index, event) {
        this.setState({
            focusIndex: index
        });
        this.props.fastLaneViewClickedCallback(index, event);
    }

    clickedDown() {}

    clickedUp() {}

    mapFunction(sceneObject, index) {
        if (this.state.focusIndex < 0) {
            return React.createElement(FastLaneView, { key: sceneObject.sceneID,
                fadeOut: false,
                fastLaneViewClickedCallback: this.clickFunction,
                index: index,
                sceneData: sceneObject });
        } else {
            return React.createElement(FastLaneView, { key: sceneObject.sceneID,
                fadeOut: index == this.state.focusIndex && this.props.experienceState != 0,
                fadeOutImage: index == this.state.focusIndex,
                fastLaneViewClickedCallback: this.clickFunction,
                index: index,
                sceneData: sceneObject });
        }
    }

    render() {
        var roomSquares = this.props.sceneData.map(this.mapFunction);
        return React.createElement(
            "div",
            { className: "room-layout-container-div" },
            React.createElement(
                "div",
                { style: { width: "7%", margin: "auto" }, onClick: this.clickedUp },
                React.createElement(
                    "svg",
                    { className: "u-icon", role: "presentation" },
                    React.createElement(
                        "use",
                        { xmlnsXlink: "http://www.w3.org/1999/xlink", xlinkHref: "#wf-icon-chevron-up" },
                        React.createElement(
                            "svg",
                            { id: "wf-icon-chevron-up", viewBox: "0 0 28 28", width: "100%", height: "100%" },
                            React.createElement("path", { d: "M8.9 16.8c.4.4 1 .4 1.4.1l3.8-3.5 3.8 3.4c.4.4 1 .3 1.4-.1.4-.4.3-1-.1-1.4l-4.5-4c-.2-.2-.4-.3-.7-.3s-.5.1-.7.3l-4.5 4c-.3.4-.3 1.1.1 1.5z" })
                        )
                    )
                )
            ),
            React.createElement(
                "div",
                { className: "room-layout" },
                roomSquares
            ),
            React.createElement(
                "div",
                { style: { width: "7%", margin: "auto" }, onClick: this.clickedDown },
                React.createElement(
                    "svg",
                    { className: "u-icon", role: "presentation" },
                    React.createElement(
                        "use",
                        { xmlnsXlink: "http://www.w3.org/1999/xlink", xlinkHref: "#wf-icon-chevron-down" },
                        React.createElement(
                            "svg",
                            { id: "wf-icon-chevron-down", viewBox: "0 0 28 28", width: "100%", height: "100%" },
                            React.createElement("path", { d: "M19.2 11.3c-.4-.4-1-.4-1.4-.1L14 14.7l-3.8-3.4c-.4-.4-1-.3-1.4.1-.4.4-.3 1 .1 1.4l4.5 4c.2.2.4.3.7.3s.5-.1.7-.3l4.5-4c.3-.4.3-1.1-.1-1.5z" })
                        )
                    )
                )
            )
        );
    }
}

"use strict";

class Utils {
    static sceneData() {
        return [{
            sceneID: 41560148,
            sceneImage: "./images/41560148/41560148.jpg",
            sceneComposition: {
                "GOLV2110": {
                    sku: "GOLV2110",
                    productManu: "George Oliver",
                    productRating: "5",
                    productReviews: 5,
                    productPrice: "234.99",
                    productName: "Brasher Side Chair",
                    pdpLink: "https://www.wayfair.com/furniture/pdp/george-oliver-brasher-side-chair-golv2110.html?rtype=8&redir=GOLV2110",
                    productDescription: "<p>From providing sensible seating arrangements in smaller spaces to rounding out interior designs, accent chairs make all-star additions to any home decor arsenal. Sporting button tufts and birch wood legs, this low-profile chair brings mid-century vibes home. Even better, its polyester blend upholstery wipes clean with a cloth and some mild soap. Crafted of solid and manufactured wood, this chair measures 32.25'' H x 27.25'' W x 29'' D and features a removable cushion. Minimal assembly is required.</p><strong>Features:</strong><ul><li>Design: Side Chair</li><li>Upholstered: Yes<ul><li>Upholstery Material: Polyester Blend</li><li>Upholstery Material Details: 100% Polyester</li><li>Genuine Leather Type: </li><li>Faux Leather Type: </li><li>Seat Fill Material: </li><li>Seat Fill Material Details: </li><li>Upholstery Color: Muted Purple</li><li>Upholstery Grade: </li><li>Pattern: Solid Color</li><li>Legal Documentation: No</li></ul></li><li>Frame Material: Solid + Manufactured Wood<ul><li>Wood Construction Details: </li><li>Frame Material Details: Birch</li></ul></li><li>Frame Color: Natural</li><li>Wood Species: </li><li>Arms Included: No<ul><li>Arm Type: </li><li>Arm Material: </li><li>Arm Material Details: </li></ul></li><li>Ottoman Included: No<ul><li>Ottoman Height - Top to Bottom: </li><li>Ottoman Width - Side to Side: </li><li>Ottoman Depth - Front to Back: </li></ul></li><li>Tufted Cushions: Yes</li><li>Wood Finish: </li><li>Swivel: No</li><li>Seating Firmness: Soft</li><li>Removable Cushions: Yes<ul><li>Removable Cushion Location: Seat</li><li>Reversible Cushions: </li><li>Removable Cushion Cover: </li></ul></li><li>Toss Pillows Included: No<ul><li>Number of Toss Pillows: </li><li>Toss Pillow Upholstery Material: </li><li>Toss Pillow Fill Material: </li></ul></li><li>Style: Modern & Contemporary</li><li>Slipcovered: No</li><li>Nailhead Trim: No</li><li>Distressed: No</li><li>Recycled Content: No<ul><li>Total Recycled Content (Percentage): </li><li>Post-Consumer Content (Percentage): </li><li>Remanufactured/Refurbished: </li></ul></li><li>Contains Flame Retardant Materials: No</li><li>Country of Manufacture: China</li><li>Product Care: Wipe with cloth and mild soap</li></ul><strong>Spefications:</strong><ul><li>Commercial ONLY Certifications: No<ul><li>ANSI/BIFMA e3 Furniture Sustainability Standard: </li><li>ANSI/BIFMA M7.1 Standard Test Method for Determining VOC Emissions: </li><li>ANSI/BIFMA X5.1 Office Seating: </li><li>ANSI/BIFMA X7.1 Standard for Formaldehyde & TVOC Emissions: </li><li>ANSI/BIFMA X5.4 Lounge & Public Seating: </li><li>BHFTI Upholstered Furniture Flammability Compliant: </li><li>CALGreen Compliant: </li><li>Energy Policy Act 1992 Compliant: </li><li>GreenSpec: </li><li>GREENGUARD Certified: </li><li>FIRA Certified: </li><li>GSA Approved: </li><li>ITTO Compliant: </li><li>ISO 9001 Certified: </li><li>ISO 14001 Certified: </li><li>ISO 14000 Certified: </li><li>ISO 9000 Certified: </li><li>PEFC Certified: </li><li>OEKO-TEX Standard 100 Certified: </li><li>NFPA Compliant: </li><li>SCS Certified: </li></ul></li><li>Commercial OR Residential Certifications: Yes<ul><li>CE Certified: No</li><li>CPG Compliant: Yes</li><li>Fire Rated: No</li><li>TAA Compliant: Yes</li><li>FSC Certified: No</li><li>CAL TB 133 Compliant: No</li><li>CAL TB 117-2013 Compliant: No</li></ul></li><li>California Proposition 65 Warning Required: Yes</li><li>AZO free: No</li><li>ISTA 1A Certified: </li><li>ISTA 3A or 6A Certified: </li><li>Composite Wood Product (CWP): Yes<ul><li>CARB Phase II Compliant (formaldehyde emissions): </li><li>TSCA Title VI Compliant (formaldehyde emissions): </li></ul></li></ul><strong>Dimensions:</strong><ul><li>Overall Product Weight: 35</li><li>Overall Height - Top to Bottom: 32.25</li><li>Overall Width - Side to Side: 27.25</li><li>Overall Depth - Front to Back: 29</li><li>Seat Height - Top to Bottom: 18.5</li><li>Seat Width - Side to Side: 19.75</li><li>Seat Depth - Front to Back: 20</li><li>Arm Height - Top to Bottom: </li></ul><strong>Assembly:</strong><ul><li>Assembly Required: Yes</li></ul><strong>Warranty:</strong><ul><li>Product Warranty: 90 Days</li></ul>",
                    modelURL: "./models/GOLV2110.fbx",
                    skuImageURL: "./images/41560148/GOLV2110.jpg",
                    spawnRotation: "0 0.3926990817 0",
                    dimX: 27.25,
                    dimY: 32.25,
                    dimZ: 29,
                    //image map coordinates...
                    mappingCoordinates: "1001,518,984,518,941,518,239,564,203,585,198,612,226,965,237,1018,226,1037,253,1307,274,1339,339,1405,324,1622,369,1630,403,1454,595,1632,624,1638,631,1929,682,1929,699,1629,1310,1514,1365,1779,1409,1775,1379,1509,1444,1489,1473,1449,1483,1166,1480,1149,1100,965,1074,796,1021,529"
                }
            }
        }, {
            sceneID: 40207502,
            sceneImage: "./images/40207502/40207502.jpg",
            sceneComposition: {
                "WRLO1870": {
                    sku: "WRLO1870",
                    productName: "Aubine Armchair",
                    productManu: "Willa Arlo Interiors",
                    productRating: "4.8",
                    productReviews: 92,
                    productPrice: "215.99",
                    pdpLink: "https://www.wayfair.com/furniture/pdp/willa-arlo-interiors-aubine-armchair-wrlo1870.html?rtype=8&redir=WRLO1870&piid=22459233",
                    productDescription: "<p>If you're searching for a seat, just set your sights on this alluring arm chair! Taking on a traditional silhouette, it gets a twist of today thanks to a few nods to contemporary design. Founded atop four tapered feet, its clean-lined birch wood frame features curved arms on either side for a streamlined look. While its foam padding and polyester blend upholstery in a solid hue gives it timeless elegance, it might just stand out with its polished nailhead trim. Simply pull it up beside a Chesterfield sofa for a luxe living room look, then take your aesthetic to the floors with a fringe-trimmed rug laying out. Though we think this charming chair is stunning sitting solo, you can always make it a little more marvelous by piling on a pair of plush patterned pillows.</p><strong>Features:</strong><ul><li>Premium subtle textured weave solid fabric</li><li>Double nailhead rows along arms and back</li><li>Black finish wood legs</li><li>Add a decor-friendly accent to any room in the home</li><li>Bedroom, living room, family room, home office</li><li>Nailhead finish: Chrome</li><li>Self-welt seat cushion</li><li>Design: Armchair</li><li>Upholstered: Yes<ul><li>Upholstery Material: Polyester Blend</li><li>Upholstery Material Details: Polyester</li><li>Genuine Leather Type: </li><li>Faux Leather Type: </li><li>Seat Fill Material: Foam</li><li>Seat Fill Material Details: </li><li>Upholstery Color: </li><li>Upholstery Grade: </li><li>Pattern: Solid Color</li><li>Legal Documentation: No</li></ul></li><li>Weight Capacity: 250</li><li>Frame Material: Wood<ul><li>Wood Construction Details: </li><li>Frame Material Details: Birch wood construction</li></ul></li><li>Frame Color: Birch wood construction</li><li>Wood Species: Birch</li><li>Arms Included: Yes<ul><li>Arm Type: Square arms</li><li>Arm Material: Fabric</li><li>Arm Material Details: </li></ul></li><li>Ottoman Included: No<ul><li>Ottoman Height - Top to Bottom: </li><li>Ottoman Width - Side to Side: </li><li>Ottoman Depth - Front to Back: </li></ul></li><li>Tufted Cushions: No</li><li>Wood Finish: Birch</li><li>Swivel: No</li><li>Seating Firmness: Medium-Firm</li><li>Seat Construction: Web Suspension;Sinuous Springs</li><li>Removable Cushions: <ul><li>Removable Cushion Location: </li><li>Reversible Cushions: </li><li>Removable Cushion Cover: </li></ul></li><li>Toss Pillows Included: No<ul><li>Number of Toss Pillows: </li><li>Toss Pillow Upholstery Material: </li><li>Toss Pillow Fill Material: </li></ul></li><li>Style: Modern & Contemporary</li><li>Slipcovered: No</li><li>Nailhead Trim: Yes</li><li>Distressed: No</li><li>Recycled Content: No<ul><li>Total Recycled Content (Percentage): </li><li>Post-Consumer Content (Percentage): </li><li>Remanufactured/Refurbished: </li></ul></li><li>Contains Flame Retardant Materials: No</li><li>Fire Resistant: Yes</li><li>Country of Manufacture: China</li><li>Product Care: Spot clean</li><li>Supplier Intended & Approved Use: Residential Use</li></ul><strong>Spefications:</strong><ul><li>Commercial ONLY Certifications: No<ul><li>ANSI/BIFMA e3 Furniture Sustainability Standard: </li><li>ANSI/BIFMA M7.1 Standard Test Method for Determining VOC Emissions: </li><li>ANSI/BIFMA X5.1 Office Seating: </li><li>ANSI/BIFMA X7.1 Standard for Formaldehyde & TVOC Emissions: </li><li>ANSI/BIFMA X5.4 Lounge & Public Seating: </li><li>BHFTI Upholstered Furniture Flammability Compliant: </li><li>CALGreen Compliant: </li><li>Energy Policy Act 1992 Compliant: </li><li>GreenSpec: </li><li>GREENGUARD Certified: </li><li>FIRA Certified: </li><li>GSA Approved: </li><li>ITTO Compliant: </li><li>ISO 9001 Certified: </li><li>ISO 14001 Certified: </li><li>ISO 14000 Certified: </li><li>ISO 9000 Certified: </li><li>PEFC Certified: </li><li>OEKO-TEX Standard 100 Certified: </li><li>NFPA Compliant: </li><li>SCS Certified: </li></ul></li><li>Commercial OR Residential Certifications: No<ul><li>CE Certified: </li><li>CPG Compliant: </li><li>Fire Rated: </li><li>TAA Compliant: </li><li>FSC Certified: </li><li>TB 133 Compliant: </li><li>TB 117-2013 Compliant: </li></ul></li><li>California Proposition 65 Warning Required: Yes</li><li>AZO free: No</li><li>ISTA 1A Certified: </li><li>ISTA 3A or 6A Certified: </li><li>Composite Wood Product (CWP): Yes<ul><li>CARB Phase II Compliant (formaldehyde emissions): </li><li>TSCA Title VI Compliant (formaldehyde emissions): </li></ul></li></ul><strong>Dimensions:</strong><ul><li>Overall Product Weight: 39.8</li><li>Overall Height - Top to Bottom: 36.25</li><li>Overall Width - Side to Side: 28.75</li><li>Overall Depth - Front to Back: 32</li><li>Seat Height - Top to Bottom: 18</li><li>Seat Width - Side to Side: </li><li>Seat Depth - Front to Back: 22</li><li>Back Height - Top to Bottom: 20</li><li>Leg Height - Top to Bottom: 5.5</li></ul><strong>Assembly:</strong><ul><li>Assembly Required: Yes</li></ul><strong>Warranty:</strong><ul><li>Product Warranty: 180 Days</li></ul>",
                    modelURL: "./models/WRLO1870.fbx",
                    skuImageURL: "./images/40207502/WRLO1870.jpg",
                    spawnRotation: "0 0.3926990817 0",
                    dimX: 28.75,
                    dimY: 36.25,
                    dimZ: 32,
                    //image map coordinates...
                    mappingCoordinates: "444,490,1241,510,1257,548,1271,603,1293,663,1319,720,1339,767,1374,806,1395,829,1464,834,1556,838,1633,848,1646,873,1649,1064,1649,1530,1630,1548,1594,1696,1547,1698,1526,1687,1503,1549,830,1600,800,1759,731,1759,703,1585,578,1519,562,1618,505,1616,496,1484,481,1454,466,961,516,953,518,903,468,898"
                }
            }
        }, {
            sceneID: 40265885,
            sceneImage: "./images/40265885/40265885.jpg",
            sceneComposition: {
                "LTDR2907": {
                    sku: "LTDR2907",
                    productManu: "Three Posts",
                    productRating: "4.5",
                    productReviews: 11,
                    productPrice: "339.99",
                    productName: "Fredia Club Manual Recliner",
                    pdpLink: "https://www.wayfair.com/furniture/pdp/latitude-run-fredia-club-manual-recliner-ltdr2907.html?rtype=8&redir=LTDR2907",
                    productDescription: "<p></p><strong>Features:</strong><ul><li>High durability</li><li>Upholstery Material: Faux leather<ul><li>Upholstery Material Details: </li><li>Genuine Leather Type: </li><li>Faux Leather Type: Bonded Leather</li></ul></li><li>Upholstery Color: </li><li>Reclining Type: Manual<ul><li>Reclining Type Details: Manual - Push Back</li></ul></li><li>Position Type: 2-Position<ul><li>Position Lock: </li></ul></li><li>Recline Angle: 45</li><li>Removable Cushions: Yes<ul><li>Removable Cushion Cover: </li><li>Reversible Cushions: </li><li>Removable Cushion Location: Back</li></ul></li><li>Design: Standard Recliner;Ergonomic Recliner;Club Recliner</li><li>Frame Material: <ul><li>Frame Material Details: </li><li>Wood Construction Details: </li></ul></li><li>Wood Species: Eucalyptus</li><li>Wood Finish: Natural/Unfinished</li><li>Frame Color: Mahogany</li><li>Leg Material: Wood<ul><li>Leg Material Details: </li></ul></li><li>Seat Construction: Coil Spring</li><li>Seat Fill Material: Foam<ul><li>Seat Fill Material Details: </li></ul></li><li>Seating Comfort: Medium</li><li>Ottoman Included: No</li><li>Heating: No</li><li>Nailhead Trim: No</li><li>Storage Included: No<ul><li>Storage Location: </li></ul></li><li>Required Back Clearance to Recline: 25</li><li>Print: Solid</li><li>Toss Pillows Included: No<ul><li>Number of Toss Pillows: </li><li>Toss Pillow Fill Material: </li><li>Toss Pillow Upholstery Material: </li></ul></li><li>Durability: Water Resistant</li><li>Contains Flame Retardant Materials: Yes</li><li>Weight Capacity: 250</li><li>Recycled Content: No<ul><li>Total Recycled Content (Percentage): </li><li>Post-Consumer Content (Percentage): </li><li>Remanufactured/Refurbished: </li></ul></li><li>Country of Manufacture: China</li><li>Style: Modern & Contemporary</li></ul><strong>Spefications:</strong><ul><li>Commercial OR Residential Certifications: Yes<ul><li>CPG Compliant: </li><li>Fire Rated: </li><li>CE Certified: </li><li>TAA Compliant: </li><li>SFI Certified: </li><li>TB 117-2013 Compliant: Yes</li><li>FSC Certified: </li><li>TB 133 Compliant: </li></ul></li><li>Commercial ONLY Certifications: No<ul><li>ANSI/BIFMA e3 Furniture Sustainability Standard: </li><li>ANSI/BIFMA M7.1 Standard Test Method for Determining VOC Emissions: </li><li>ANSI/BIFMA X7.1 Standard for Formaldehyde & TVOC Emissions: </li><li>CALGreen Compliant: </li><li>Energy Policy Act 1992 Compliant: </li><li>FIRA Certified: </li><li>GreenSpec: </li><li>ISO 14001 Certified: </li><li>ISO 9001 Certified: </li><li>ITTO Compliant: </li><li>GREENGUARD Certified: </li><li>SCS Certified: </li><li>PEFC Certified: </li><li>ISO 14000 Certified: </li><li>ISO 9000 Certified: </li><li>ANSI/BIFMA X5.4 Lounge & Public Seating: </li><li>BHFTI Upholstered Furniture Flammability Compliant: </li><li>GSA Approved: </li><li>NFPA Compliant: </li></ul></li><li>California Proposition 65 Warning Required: No</li><li>ISTA 3A or 6A Certified: </li><li>ISTA 1A Certified: </li><li>BS 5852 Certified: </li></ul><strong>Dimensions:</strong><ul><li>Overall Height - Top to Bottom: 42</li><li>Overall Width - Side to Side: 30</li><li>Overall Depth - Front to Back: 32.5</li><li>Seat Height - Top to Bottom: 19</li><li>Seat Width - Side to Side: 20</li><li>Seat Depth - Front to Back: 21</li><li>Clearance from Floor to Bottom of Recliner: 4</li><li>Fully Reclined Height - Top to Bottom: 31.5</li><li>Fully Reclined Depth - Front to Back: 61</li><li>Legs: Yes<ul><li>Leg Height - Top to Bottom: 4</li></ul></li><li>Ottoman: No<ul><li>Ottoman Height - Top to Bottom: </li><li>Ottoman Width - Side to Side: </li><li>Ottoman Depth - Front to Back: </li></ul></li><li>Storage Space: No<ul><li>Storage Space Height - Top to Bottom: </li><li>Storage Space Width - Side to Side: </li><li>Storage Space Depth - Front to Back: </li></ul></li><li>Overall Product Weight: 75</li><li>Arm Height - Top to Bottom: 25</li></ul><strong>Assembly:</strong><ul><li>No tools required, easy 2 step assembly</li><li>Assembly Required: Yes</li></ul><strong>Warranty:</strong><ul><li>Product Warranty: 1 Year</li></ul>",
                    modelURL: "./models/LTDR2907.fbx",
                    skuImageURL: "./images/40265885/LTDR2907.jpg",
                    spawnRotation: "0 0.3926990817 0",
                    dimX: 30,
                    dimY: 42,
                    dimZ: 32.5,
                    //image map coordinates...
                    mappingCoordinates: "1035,473,747,465,569,466,537,480,519,516,557,982,477,991,452,1014,458,1109,474,1243,486,1607,541,1616,509,1737,571,1748,611,1667,615,1637,1008,1726,1007,1887,1038,1903,1074,1893,1104,1727,1559,1658,1619,1788,1674,1785,1651,1688,1651,1661,1651,1647,1704,1637,1715,1312,1729,1127,1736,1024,1718,1001,1487,976,1121,962,1098,902,1072,655,1061,512"
                }
            }
        }, {
            sceneID: 32920228,
            sceneImage: "./images/32920228/32920228.jpg",
            sceneComposition: {
                "thps1002": {
                    sku: "THPS1002",
                    productName: "Back East Cocktail Ottoman",
                    productManu: "Three Posts",
                    productRating: "4.5",
                    productReviews: 27,
                    productOrigPrice: 579,
                    productPrice: "459.99",
                    pdpLink: "https://www.wayfair.com/furniture/pdp/three-posts-back-east-cocktail-ottoman-thps1005.html?piid=19515631",
                    productDescription: "<p></p><strong>Features:</strong><ul><li>Materials: Rubberwood, pine wood, foam and linen</li><li>Design: Cocktail</li><li>Includes a drawer for extra storage</li><li>Type: Cocktail</li><li>Shape: Square</li><li>Upholstery Color: </li><li>Upholstery Material: Other<ul><li>Upholstery Material Details: Linen</li><li>Genuine Leather Type: </li><li>Faux Leather Type: </li><li>Upholstery Grade: </li></ul></li><li>Pattern: Solid Color</li><li>Storage Mechanism: </li><li>Style (Old): Traditional</li><li>Frame Material: Solid Wood<ul><li>Frame Material Details: </li><li>Wood Construction Details: </li><li>Wood Species: </li></ul></li><li>Upholstered: Yes<ul><li>Legal Documentation: </li></ul></li><li>Distressed: No</li><li>Style: Traditional</li><li>Removable Cushion Cover: No</li><li>Tufted Cushions: Yes</li><li>Casters: No</li><li>Nailhead Trim: No</li><li>Tray Top: No</li><li>Convertible: No</li><li>Wood Finish: Natural/Unfinished</li><li>Contains Flame Retardant Materials: No</li><li>Life Stage: Adult</li><li>Recycled Content: No<ul><li>Total Recycled Content (Percentage): </li><li>Post-Consumer Content (Percentage): </li><li>Remanufactured/Refurbished: </li></ul></li><li>Product Care: Vacuum regularly and to remove stains wipe with a cotton cloth with mild soap and water solution</li><li>Country of Manufacture: China</li><li>Weight Capacity: 250</li><li>Purposeful Distressing Type: </li></ul><strong>Spefications:</strong><ul><li>Commercial ONLY Certifications: No<ul><li>Blauer Engel: </li><li>ANSI/BIFMA X7.1 Standard for Formaldehyde & TVOC Emissions: </li><li>ANSI/BIFMA M7.1 Standard Test Method for Determining VOC Emissions: </li><li>ANSI/BIFMA e3 Furniture Sustainability Standard: </li><li>BHFTI Upholstered Furniture Flammability Compliant: </li><li>FIRA Certified: </li><li>Energy Policy Act 1992 Compliant: </li><li>CALGreen Compliant: </li><li>GSA Approved: </li><li>GreenSpec: </li><li>GREENGUARD Certified: </li><li>ISO 14001 Certified: </li><li>ISO 14000 Certified: </li><li>ISO 9001 Certified: </li><li>ISO 9000 Certified: </li><li>PEFC Certified: </li><li>NFPA Compliant: </li><li>ITTO Compliant: </li><li>SCS Certified: </li><li>Stiftung Warentest Note: </li><li>TÜV Rheinland zertifiziert: </li></ul></li><li>Commercial OR Residential Certifications: No<ul><li>TB 117-2013 Compliant: </li><li>TB 133 Compliant: </li><li>TAA Compliant: </li><li>FSC Certified: </li><li>Fire Rated: </li><li>CE Certified: </li><li>CPG Compliant: </li></ul></li><li>SATRA Approved: No</li><li>FISP Certified: No</li><li>California Proposition 65 Warning Required: Yes</li><li>IP Rating: </li><li>ISTA 3A or 6A Certified: </li><li>ISTA 1A Certified: </li><li>Composite Wood Product (CWP): No<ul><li>CARB Phase II Compliant (formaldehyde emissions): </li><li>TSCA Title VI Compliant (formaldehyde emissions): </li></ul></li></ul><strong>Dimensions:</strong><ul><li>Drawer Interior: 2\" H x 21.8\" W x 9.17\" D</li><li>Thickness of the upholstered top: 4\"</li><li>Overall Height - Top to Bottom: 19</li><li>Overall Width - Side to Side: 38</li><li>Overall Depth - Front to Back: 38</li><li>Storage Included: No<ul><li>Storage Space Height - Top to Bottom: </li><li>Storage Space Width - Side to Side: </li><li>Storage Space Depth - Front to Back: </li></ul></li><li>Overall Product Weight: 80</li></ul><strong>Assembly:</strong><ul><li>Assembly Required: Yes</li></ul><strong>Warranty:</strong><ul><li>Product Warranty: 90 Day manufacturer's warranty</li></ul>",
                    modelURL: "./models/KMDS3246.fbx",
                    skuImageURL: "./images/32920228/KMDS3246.jpg",
                    spawnRotation: "0 0.3926990817 0",
                    //in inches
                    dimX: 38,
                    dimY: 19,
                    dimZ: 38,
                    //image map coordinates...
                    mappingCoordinates: "74,728,78,788,92,822,92,898,122,931,115,942,124,947,129,970,118,993,129,1012,115,1025,110,1053,113,1080,124,1115,138,1136,133,1157,133,1186,111,1205,108,1283,168,1311,228,1300,839,1519,841,1557,938,1588,1042,1562,1044,1527,1772,1318,1841,1334,1913,1313,1912,1230,1887,1212,1867,1193,1889,1180,1876,1159,1894,1125,1899,1108,1903,1078,1899,1048,1890,1032,1898,1012,1887,996,1887,973,1905,961,1903,943,1924,924,1929,818,1940,814,1935,728,1871,684,1795,677,1560,636,1435,618,1405,611,1339,677,535,657,535,624,428,625,313,648,175,657,106,682"
                }
            }
        }, {
            sceneID: 123456,
            sceneImage: "./images/123456/123456.jpg",
            sceneComposition: {
                "BNGL9373": {
                    sku: "BNGL9373",
                    productManu: "Bungalow Rose",
                    productRating: "4.5",
                    productReviews: 97,
                    productPrice: "358.99",
                    pdpLink: "https://www.wayfair.com/furniture/pdp/bungalow-rose-cope-6-drawer-double-dresser-bngl9373.html",
                    productName: "Cope 6 Drawer Double Dresser",
                    productDescription: "<p></p><strong>Features:</strong><ul><li>Dark and highly distressed finish</li><li>Metal base</li><li>Rustic Industrial design</li><li>6 Drawers for storage</li><li>Product Type: Standard Dresser/Chest;Double dresser</li><li>Orientation: Horizontal</li><li>Material: <ul><li>Material Details: </li><li>Wood Construction Details: </li><li>Wood Species: </li></ul></li><li>Wood Construction Type: Solid and manufactured wood</li><li>Wood Tone: Medium Brown Wood</li><li>Color: Dark Brown/Dark Gray</li><li>Mirrored Finish: No</li><li>Distressed: Yes</li><li>Drawers Included: Yes<ul><li>Number of Drawers: 6</li><li>Drawer Glide Mechanism: </li><li>Drawer Glide Material: </li><li>Soft Close or Self Close Drawers: </li><li>Felt Lined Drawers: </li></ul></li><li>Mirror Included: No</li><li>Media Compartments: No</li><li>Finished Back: No</li><li>Style: Traditional;Eclectic</li><li>Style (Old): Modern</li><li>Country of Manufacture: Viet Nam</li><li>Plug-In: No<ul><li>Plug Type: </li><li>Adapter Type: </li></ul></li><li>Supplier Intended & Approved Use: Residential Use</li></ul><strong>Spefications:</strong><ul><li>Commercial ONLY Certifications: <ul><li>FIRA Certified: </li><li>Energy Policy Act 1992 Compliant: </li><li>GREENGUARD Certified: </li><li>ISO 14000 Certified: </li><li>ISO 9001 Certified: </li><li>ISO 14001 Certified: </li><li>ISO 9000 Certified: </li><li>PEFC Certified: </li><li>ITTO Compliant: </li></ul></li><li>Commercial OR Residential Certifications: Yes<ul><li>CE Certified: </li><li>CPG Compliant: </li><li>CPSIA Compliant: </li><li>FSC Certified: Yes</li><li>EPP Compliant: </li><li>TB 133 Compliant: </li><li>JPMA Certified: </li><li>TB 117-2013 Compliant: Yes</li></ul></li><li>California Proposition 65 Warning Required: No</li><li>General Certificate of Conformity (GCC): No</li><li>ISTA 1A Certified: </li><li>ISTA 3A or 6A Certified: Yes</li><li>Composite Wood Product (CWP): Yes<ul><li>CARB Phase II Compliant (formaldehyde emissions): </li><li>TSCA Title VI Compliant (formaldehyde emissions): </li></ul></li></ul><strong>Dimensions:</strong><ul><li>Overall drawer dimensions: 8\" H x 22.06\" W x 13.66\" D</li><li>Drawers extension: 0.75</li><li>Overall Height - Top to Bottom: 35.7</li><li>Overall Height - Top to Bottom: 27.48</li><li>Overall Width - Side to Side: 48</li><li>Overall Depth - Front to Back: 16</li><li>Drawers: Yes<ul><li>Drawer Interior Height - Top to Bottom: 5.75</li><li>Drawer Interior Width - Side to Side: 20.75</li><li>Drawer Interior Depth - Front to Back: 12.62</li><li>Drawer Weight Capacity: </li></ul></li><li>Shelves: No<ul><li>Shelf Height - Top to Bottom: </li><li>Shelf Width - Side to Side: </li><li>Shelf Depth - Front to Back: </li><li>Shelf Weight Capacity: </li></ul></li><li>Mirror: No<ul><li>Mirror Height - Top to Bottom: </li><li>Mirror Width - Side to Side: </li><li>Mirror Depth - Front to Back: </li></ul></li><li>Overall Product Weight: 132.28</li></ul><strong>Assembly:</strong><ul><li>Level of Assembly: Partial Assembly</li><li>Assembly Required: Yes<ul><li>Suggested # of People: 1</li><li>Estimated Time to Assemble: 15</li><li>Additional Tools Required: </li><li>Avoid Power Tools: Yes</li><li># of Pieces to be Assembled: </li><li># of Hardware Pieces Included: </li><li># of Steps Required: </li></ul></li></ul><strong>Warranty:</strong><ul><li>Product Warranty: 30 Days</li></ul>",
                    modelURL: "./models/BNGL9373.fbx",
                    skuImageURL: "./images/123456/BNGL9373-pdp.jpg",
                    spawnRotation: "0 0.3926990817 0",
                    dimX: 48,
                    dimY: 27.48,
                    dimZ: 16,
                    //image map coordinates...
                    mappingCoordinates: "1752,692,1697,680,1656,694,1577,673,1501,669,1381,666,1229,662,1088,657,955,660,816,660,671,664,557,680,507,784,419,863,253,922,226,934,207,1031,189,1137,165,1224,165,1393,196,1405,223,1504,276,1520,311,1416,1429,1490,1451,1612,1515,1617,1538,1490,1633,1439,1644,1494,1702,1485,1722,1381,1757,1363"
                }
            }
        }, {
            sceneID: 39611130,
            sceneImage: "./images/39611130/39611130.jpg",
            sceneComposition: {
                "CSTD1069": {
                    sku: "CSTD1069",
                    productName: "Curtis Coffee Table",
                    productManu: "Corrigan Studio",
                    productRating: "4.5",
                    productReviews: 240,
                    productOrigPrice: "369.99",
                    productPrice: "194.99",
                    pdpLink: "https://www.wayfair.com/furniture/pdp/corrigan-studio-curtis-coffee-table-cstd1069.html",
                    productDescription: "<p>Featuring an openwork design, splayed legs, and a rich walnut finish, this eye-catching console table anchors your den or living room ensemble in contemporary style. Top it with your favorite art books to complete the loft-worthy look, then set down a boldly pattern rug underneath for a pop of contrast.</p><strong>Features:</strong><ul><li>Contemporary style</li><li>Rich walnut finish</li><li>Product Type: Coffee Table</li><li>Top Shape: Rectangular</li><li>Style: Modern & Contemporary</li><li>Top Color: Rich Walnut</li><li>Base Color: Rich Walnut</li><li>Distressed: No</li><li>Gloss Finish: Yes</li><li>Wrought Iron: No</li><li>Top Material: Solid + Manufactured Wood<ul><li>Top Material Details: Solid hardwood and Zebra veneer RTA</li><li>Top Wood Construction Details: Solid Wood Veneers</li><li>Wood Species: Walnut</li></ul></li><li>Base Material: Solid + Manufactured Wood<ul><li>Base Material Details: Solid hardwood and Zebra veneer RTA</li><li>Base Wood Construction Details: Solid Wood Veneers</li></ul></li><li>Reclaimed Wood: No</li><li>Wood Finish: Walnut</li><li>Mirrored: No</li><li>Base Type: 4 Legs</li><li>Hidden Storage Compartment: No</li><li>Folding: No</li><li>Built-In Lighting: No</li><li>Stools Included: No</li><li>Wheels: No</li><li>Shelves Included: Yes<ul><li>Number of Shelves: 1</li></ul></li><li>Cabinets Included: No<ul><li>Number of Cabinets: </li></ul></li><li>Drawers Included: No<ul><li>Number of Drawers: </li><li>Drawer Glide Material: </li><li>Soft Close of Self Close Drawers: </li></ul></li><li>Upholstered: No<ul><li>Upholstery Material: </li><li>Legal Documentation: </li></ul></li><li>Weight Capacity: 150</li><li>Recycled Content: No<ul><li>Total Recycled Content (Percentage): </li><li>Post-Consumer Content (Percentage): </li><li>Remanufactured/Refurbished: </li></ul></li><li>Country of Manufacture: Malaysia</li><li>EU Energy Efficiency Class: </li><li>Style (Old): Mid-Century;Modern</li></ul><strong>Spefications:</strong><ul><li>Commercial ONLY Certifications: Yes<ul><li>SCS Certified: </li><li>Stiftung Warentest Note: </li><li>Blauer Engel: </li><li>GREENGUARD Certified: </li><li>PEFC Certified: </li><li>ISO 9001 Certified: </li><li>ISO 14001 Certified: </li><li>FIRA Certified: </li><li>ITTO Compliant: </li><li>ISO 9000 Certified: </li><li>ISO 14000 Certified: </li><li>HFES 100 Certified Ergonomic: </li><li>GSA Approved: </li><li>GreenSpec: </li><li>Energy Policy Act 1992 Compliant: </li><li>CALGreen Compliant: </li><li>ANSI/BIFMA X7.1 Standard for Formaldehyde & TVOC Emissions: </li><li>ANSI/BIFMA X5.9 Storage: </li><li>ANSI/BIFMA M7.1 Standard Test Method for Determining VOC Emissions: </li><li>ANSI/BIFMA e3 Furniture Sustainability Standard: </li><li>TÜV Rheinland zertifiziert: </li></ul></li><li>Commercial OR Residential Certifications: No<ul><li>TB 133 Compliant: </li><li>EPP Compliant: </li><li>FSC Certified: </li><li>CAL TB 117-2013 Compliant: </li><li>TAA Compliant: </li><li>Fire Rated: </li><li>Energy Star Compliant: </li><li>CPG Compliant: </li><li>CE Certified: </li><li>ADA Compliant: </li></ul></li><li>ISTA 3A or 6A Certified: Yes</li><li>Composite Wood Product (CWP): Yes<ul><li>CARB Phase II Compliant (formaldehyde emissions): </li><li>TSCA Title VI Compliant (formaldehyde emissions): </li></ul></li></ul><strong>Dimensions:</strong><ul><li>Overall Height - Top to Bottom: 19</li><li>Overall Length - End to End: 47</li><li>Overall Width - Front to Back: 24</li><li>Extendable: No<ul><li>Length When Fully Extended: </li></ul></li><li>Table Top Thickness: 0.75</li><li>Drawers: No<ul><li>Drawer Interior Height - Top to Bottom: </li><li>Drawer Interior Width - Side to Side: </li><li>Drawer Interior Depth - Front to Back: </li></ul></li><li>Shelving: Yes<ul><li>Shelf Height - Top to Bottom: 5.875</li></ul></li><li>Cabinets: No<ul><li>Cabinet Interior Height - Top to Bottom: </li><li>Cabinet Interior Width - Side to Side: </li><li>Cabinet Interior Depth - Front to Back: </li></ul></li><li>Lift Top: No<ul><li>Lift Top Height - Top to Bottom: </li></ul></li><li>Overall Product Weight: 57</li><li>Small Table: No<ul><li>Small Table Height - Top to Bottom: </li><li>Small Table Length - End to End: </li><li>Small Table Width - Front to Back: </li></ul></li><li>Stool: No<ul><li>Stool Height - Top to Bottom: </li><li>Stool Width - Side to Side: </li><li>Stool Depth - Front to Back: </li></ul></li></ul><strong>Assembly:</strong><ul><li>Assembly Required: Yes<ul><li>Suggested # of People: </li><li>Estimated Time to Assemble: </li><li>Estimated Time to Assemble [Internal]: </li><li>Additional Tools Required: </li><li>Avoid Power Tools: </li><li># of Pieces to be Assembled: </li><li># of Hardware Pieces Included: </li><li># of Steps Required: </li></ul></li></ul><strong>Warranty:</strong><ul><li>90 Day manufacturer warranty</li><li>Product Warranty: 90 Day limited</li></ul>",
                    modelURL: "./models/CSTD1069.fbx",
                    skuImageURL: "./images/39611130/CSTD1069.jpg",
                    spawnRotation: "0 0.3926990817 0",
                    dimX: 47.48,
                    dimY: 19.0,
                    dimZ: 23.97,
                    //image map coordinates...
                    mappingCoordinates: "783,371,465,382,438,400,417,421,419,433,458,441,461,1041,476,1055,483,1069,474,1106,479,1148,476,1178,493,1452,481,1471,488,1483,474,1510,474,1526,463,1531,461,1630,472,1639,476,1651,481,1672,477,1692,484,1730,495,1766,530,1768,539,1723,551,1663,557,1630,571,1617,1106,1753,1109,1792,1125,1806,1129,1831,1125,1861,1134,1893,1139,1939,1182,1946,1203,1861,1203,1833,1212,1794,1224,1741,1445,1642,1455,1663,1455,1699,1461,1738,1468,1773,1510,1780,1524,1699,1526,1658,1536,1646,1540,1542,1521,1499,1524,1173,1528,1130,1526,1070,1545,1049,1540,445,1579,438,1581,417,1535,388"
                }
            }
        }];
    }
}

// {
//     sceneID: 45284028,
//     sceneImage: "./images/45284028/45284028.jpg",
//     sceneComposition: {
//         "KLF6346": {
//             sku: "KLF6346", 
//             productManu: "Darby Home Co",
//             productRating: "4",
//             productReviews: 1,
//             productPrice: "1249.99",
//             pdpLink:"https://www.wayfair.com/furniture/pdp/darby-home-co-kashvi-leather-loveseat-drbh4571.html?rtype=8&redir=DRBH4571&piid=25729234",
//             productName: "Kashvi Leather Loveseat",
//             productDescription: "<p>Sophisticated and well-tailored, this Kashvi Leather Loveseat makes a splash with its tight, button tufted back that cascades down shaped arms. The banded front border is paired well with the 2 bordered and welted seat cushions. Tapered wooden legs support the regal collection.</p><strong>Features:</strong><ul><li>Product Type: Loveseat</li><li>Design: Loveseat<ul><li>Reclining Type: </li><li>Sleeper Size: </li></ul></li><li>Seating Capacity: 2</li><li>Upholstery Material: Genuine Leather<ul><li>Upholstery Material Details: 100% Cowhide</li><li>Genuine Leather Type: Top Grain Leather</li><li>Faux Leather Type: </li></ul></li><li>Upholstery Color: </li><li>Leg Color: Brown</li><li>Pattern: Solid</li><li>Frame Material: Wood<ul><li>Frame Material Details: </li><li>Wood Construction Details: </li></ul></li><li>Seat Fill Material: Foam<ul><li>Seat Fill Material Details: 100% Foam</li></ul></li><li>Back Fill Material: Foam<ul><li>Back Fill Material Details: 100% Foam</li></ul></li><li>Seat Construction: Sinuous Springs</li><li>Seating Firmness: Medium</li><li>Removable Cushions: Yes<ul><li>Removable Cushion Location: Seat</li><li>Removable Cushion Cover: Yes</li><li>Reversible Cushions: No</li></ul></li><li>Storage Included: No<ul><li>Storage Location: </li></ul></li><li>Arm Type: Recessed arms;Square arms</li><li>Seat Style: Multiple cushion seat</li><li>Back Type: Tufted back</li><li>Nailhead Trim: No</li><li>Skirted: No<ul><li>Skirt Style: </li></ul></li><li>Toss Pillows Included: No<ul><li>Number of Toss Pillows: </li><li>Toss Pillow Upholstery Material: </li><li>Toss Pillow Fill Material: </li></ul></li><li>Country of Manufacture: United States</li><li>Style: Traditional</li><li>Slipcovered: No</li><li>Contains Flame Retardent Materials: </li><li>Supplier Intended & Approved Use: Residential Use</li></ul><strong>Spefications:</strong><ul><li>Commercial ONLY Certifications: No<ul><li>ANSI/BIFMA e3 Furniture Sustainability Standard: </li><li>ANSI/BIFMA M7.1 Standard Test Method for Determining VOC Emissions: </li><li>ANSI/BIFMA X5.11 Large Occupant Office Seating: </li><li>ANSI/BIFMA X7.1 Standard for Formaldehyde & TVOC Emissions: </li><li>Blauer Engel: </li><li>BHFTI Upholstered Furniture Flammability Compliant: </li><li>ANSI/BIFMA X5.4 Lounge & Public Seating: </li><li>CALGreen Compliant: </li><li>Energy Policy Act 1992 Compliant: </li><li>ITTO Compliant: </li><li>GSA Approved: </li><li>GreenSpec: </li><li>GREENGUARD Certified: </li><li>FIRA certified: </li><li>ISO 14000 Certified: </li><li>ISO 14001 Certified: </li><li>ISO 9000 Certified: </li><li>ISO 9001 Certified: </li><li>TÜV Rheinland zertifiziert: </li><li>PEFC certified: </li><li>NFPA Compliant: </li><li>SCS Certified: </li></ul></li><li>Commercial OR Residential Certifications: No<ul><li>CE Certified: </li><li>CPG Compliant: </li><li>Fire Rated: </li><li>Lacey Act Compliant: </li><li>FSC Certified: </li><li>SFI Certified: </li><li>TAA Compliant: </li><li>TB 117-2013 Compliant: </li><li>TB 133 Compliant: </li></ul></li><li>California Proposition 65 Warning Required: Yes</li><li>ISTA 3A or 6A Certified: </li><li>ISTA 1A Certified: </li><li>BS 5852 Certified: </li><li>Composite Wood Product (CWP): Yes<ul><li>CARB Phase II Compliant (formaldehyde emissions): </li><li>TSCA Title VI Compliant (formaldehyde emissions): </li></ul></li></ul><strong>Dimensions:</strong><ul><li>Overall Height - Top to Bottom: 37</li><li>Overall Width - Side to Side: 61</li><li>Overall Depth - Front to Back: 36</li><li>Seat Depth - Front to Back: 22</li><li>Seat Height - Top to Bottom: 22</li><li>Seat Width - Side to Side: 53</li><li>Clearance from Floor to Bottom of Sofa: 5.5</li><li>Sleeper Sofa: No<ul><li>Sleeper Sofa Mattress Thickness - Top to Bottom: </li><li>Sleeper Area Width: </li><li>Sleeper Area Length: </li></ul></li><li>Storage Space: No<ul><li>Storage Space Height - Top to Bottom: </li><li>Storage Space Width - Side to Side: </li><li>Storage Space Depth - Front to Back: </li></ul></li><li>Overall Product Weight: 107</li><li>Required Back Clearance to Recline: </li><li>Leg Height - Top to Bottom: 5.5</li><li>Back Height - Top to Bottom: 15</li><li>Minimum Door Width - Side to Side: 38</li></ul><strong>Assembly:</strong><ul><li>Assembly Required: No</li></ul><strong>Warranty:</strong><ul><li>Product Warranty: Limited lifetime</li></ul>",
//             modelURL: "./models/KLF6346.fbx",
//             skuImageURL : "./images/45284028/KLF6346.jpg",
//             spawnRotation: "0 -0.3926990817 0",
//             dimX: 29,
//             dimY: 34,
//             dimZ: 31,
//             //image map coordinates...
//             mappingCoordinates: "1752,692,1697,680,1656,694,1577,673,1501,669,1381,666,1229,662,1088,657,955,660,816,660,671,664,557,680,507,784,419,863,253,922,226,934,207,1031,189,1137,165,1224,165,1393,196,1405,223,1504,276,1520,311,1416,1429,1490,1451,1612,1515,1617,1538,1490,1633,1439,1644,1494,1702,1485,1722,1381,1757,1363"
//         }
//    } 

// "TRPT1311": { 
//         sku: "TRPT1311",
//         modelURL: "./models/TRPT1311.fbx",
//         mappingCoordinates: "4,901,55,896,64,1000,94,1002,106,929,81,896,83,827,69,792,67,733,95,686,141,661,290,647,518,611,436,449,452,419,449,399,428,371,385,355,242,348,177,2,2,0"
//     },
// "TRPT1276": {
//         sku: "TRPT1276", 
//         modelURL: "./models/TRPT1276.fbx",
//         mappingCoordinates: "991,220,968,238,950,287,966,351,1008,388,1033,418,1118,425,1137,437,1153,459,1143,476,1157,494,1272,510,1273,542,1349,558,1385,531,1395,536,1402,549,1404,603,1830,674,1924,718,1936,770,1936,831,1929,909,1909,950,1897,974,1899,1003,1987,1020,1994,174,1432,183,1159,188,1037,204"
//     },
// "THRE6707": { 
//         sku: "THRE6707",
//         modelURL: "./models/THRE6707.fbx",
//         mappingCoordinates: "7,913,44,910,60,1004,97,1004,104,1080,125,1150,111,1186,101,1286,166,1322,226,1306,832,1525,836,1549,931,1595,1046,1571,1051,1532,1772,1325,1830,1339,1915,1314,1917,1233,1880,1196,1892,1164,1894,1147,1912,1081,1901,1027,1910,1009,1995,1028,1995,1996,2,1998"
//     },
// "THRE3389": { 
//         sku: "THRE3389",
//         modelURL: "./models/THRE3389.fbx",
//         mappingCoordinates: "705,527,758,532,809,534,816,551,816,587,857,595,839,608,758,608,673,608,657,606,670,535"
//     }, 
// "THRE3389_1": { 
//         sku: "THRE3389",
//         modelURL: "./models/THRE3389.fbx",
//         mappingCoordinates: "1014,435,1000,443,1002,468,993,488,972,509,1060,523,1163,502,1141,479,1150,461,1140,442,1111,426,1037,426"
//     }

