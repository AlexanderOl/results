function disableLoginListener() {
    var formElement = document.getElementById('kc-form-login');
    var buttonElement = document.getElementById('kc-login');
    function disableLoginButton() {
        buttonElement.setAttribute('disabled', 'disabled');
    }
    formElement.addEventListener('submit', disableLoginButton);
}

window.onload = disableLoginListener;
