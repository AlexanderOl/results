﻿/// <summary>
/// The WebTicketManager will automatically get all server supported authentication
/// types through the mex endpoint. The supported auth types will be returned back
/// to the application when EndInitialize is called.
/// </summary>
var AuthenticationType = new Object();
AuthenticationType.Start = 0;
AuthenticationType.None = 0;
AuthenticationType.IWA = 1;
AuthenticationType.Forms = 2;
AuthenticationType.BasicAnon = 3;
AuthenticationType.WsFedPassive = 4;
AuthenticationType.End = 4;

var MsDiagnosticErrorId = new Object();
MsDiagnosticErrorId.UserIsNotSipEnabled = "28000";
MsDiagnosticErrorId.UserNamePasswordIncorrect = "28020";
MsDiagnosticErrorId.TicketExpired = "28033";
MsDiagnosticErrorId.UserPasswordExpired = "28046";
MsDiagnosticErrorId.UserAccountDisabled = "28047";
MsDiagnosticErrorId.WsFedPassiveNotSignedIn = "28048";
MsDiagnosticErrorId.WsFedPassiveMaybeState = "28049";
MsDiagnosticErrorId.WsFedPassiveTicketExpired = "28050";
MsDiagnosticErrorId.WsFedPassiveTicketInvalid = "28051";

MinTicketValidityDuration = 15;


/// <summary>
/// Define the exception types that could be thrown by WTM.
/// </summary>
function Exception(message, innerException) {
    this.name = "Exception";
    this.message = message;
    this.innerException = innerException;
}

Exception.prototype.Name = function () {
    return this.name;
}

Exception.prototype.Message = function (message) {
    if (message != undefined) {
        this.message = message;
    }
    return this.message;
}

Exception.prototype.toString = function() {
    var result = this.name + ": " + this.message;
    if (this.innerException && this.innerException != null) {
        if (this.innerException instanceof Exception) {
            result += "\n InnerException: \n " + this.innerException.toString();
        }
        else {
            result += "\n InnerException: \n ";
            result += "Exception name: " + this.innerException.name + "\n";
            result += "Exception message: " + this.innerException.message + "\n";
        }
    }
    return result;
}

function ConnectionException(message, innerException) {
    Exception.call(this, message, innerException);
    this.name = "ConnectionException";
}

ConnectionException.prototype = new Exception();

function ArgumentException(message, innerException) {
    Exception.call(this, message, innerException);
    this.name = "ArgumentException";
}

ArgumentException.prototype = new Exception();

function ArgumentNullException(message, innerException) {
    Exception.call(this, message, innerException);
    this.name = "ArgumentNullException";
}

ArgumentNullException.prototype = new Exception();

function InvalidOperationException(message, innerException) {
    Exception.call(this, message, innerException);
    this.name = "InvalidOperationException";
}

InvalidOperationException.prototype = new Exception();

function ServerErrorException(message, innerException) {
    Exception.call(this, message, innerException);
    this.name = "ServerErrorException";
}

ServerErrorException.prototype = new Exception();

ServerErrorException.prototype.ErrorCode = function (code) {
    if (code != undefined) {
        this._errorCode = code;
    }

    return this._errorCode;
}

function AuthenticationException(message, innerException) {
    Exception.call(this, message, innerException);
    this.name = "AuthenticationException";
}

AuthenticationException.prototype = new Exception();

AuthenticationException.prototype.ErrorId = function (code) {
    if (code != undefined) {
        this._errorId = code;
    }

    return this._errorId;
}

AuthenticationException.prototype.DisplayName = function (displayName) {
    if (displayName != undefined) {
        this._displayName = displayName;
    }

    return this._displayName;
}

AuthenticationException.prototype.MemberName = function (memberName) {
    if (memberName != undefined) {
        this._memberName = memberName;
    }

    return this._memberName;
}

function ObjectDisposedException(message, innerException) {
    Exception.call(this, message, innerException);
    this.name = "ObjectDisposedException";
}

ObjectDisposedException.prototype = new Exception();

/// <summary>
/// Specify what type of web ticket the application wants.
/// Authenticated web ticket is for authenticated endpoint.
/// Anonymous web ticket is for anonymous endpoint doing conf join
/// </summary>
var WebTicketType = new Object();
WebTicketType.Authenticated = 0;
WebTicketType.Anonymous = 1;

function UserCredential(userName, password) {
    if (!userName || userName == null || userName.length == 0) {
        var exception = new ArgumentNullException("userName");
        throw exception;
    }

    // TODO: will we support empty password?
    if (!password || password == null || password.length == 0) {
        var exception = new ArgumentNullException("password");
        throw exception;
    }

    if (userName.indexOf("@") == -1 && userName.indexOf("\\") == -1) {
        var exception = new ArgumentException("userName format is incorrect");
        throw exception;
    }

    // encode with base64 format
    var convert = new Convert();
    var utf8Encoding = new UTF8Encoding();
    this._userName = convert.ToBase64String(utf8Encoding.GetBytes(userName));
    this._password = convert.ToBase64String(utf8Encoding.GetBytes(password));
}

UserCredential.prototype.UserName = function() {
    return this._userName;
}

UserCredential.prototype.Password = function() {
    return this._password;
}

/// <summary>
/// WebTicketManager use this class to return back the aqcuired web ticket 
/// information to the application.
/// for anonymous web ticket, the user name will be empty string.
/// </summary>
function WebTicketInfo(ticket, sipUri, userName) {
    this._ticket = ticket;
    this._sipUri = sipUri;
    this._userName = userName;
    this._isInternal = false;
    this._isSipEnabled = false;
    this._expiryTime = null;
    this._creationTime = null;
    this._isRemoteDeployment = false;
}

WebTicketInfo.prototype.WebTicket = function (ticket) {
    if (ticket != undefined) {
        // set ticket
        if (ticket == null || ticket.length == 0) {
            throw new ArgumentNullException("ticket");
        }
        this._ticket = ticket;
    }
    return this._ticket;
}

WebTicketInfo.prototype.SipUri = function(sipUri) {
    if (sipUri != undefined) {
        // set SipUri
        if (sipUri == null || sipUri.length == 0) {
            throw new ArgumentNullException("sipUri");
        }
        this._sipUri = sipUri;
    }
    return this._sipUri;
}

WebTicketInfo.prototype.UserName = function(userName) {
    if (userName != undefined) {
        // set UserName
        if (userName == null || userName.length == 0) {
            throw new ArgumentNullException("userName");
        }
        this._userName = userName;
    }
    return this._userName;
}

WebTicketInfo.prototype.IsInternal = function (isInternal) {
    if (isInternal != undefined) {
        this._isInternal = isInternal;
    }
    return this._isInternal;
}

WebTicketInfo.prototype.IsSipEnabled = function (isSipEnabled) {
    if (isSipEnabled != undefined) {
        this._isSipEnabled = isSipEnabled;
    }
    return this._isSipEnabled;
}

WebTicketInfo.prototype.ExpiryTime = function(expiryTime) {
    if (expiryTime != undefined) {
        // set expiryTime
        if (expiryTime == null) {
            throw new ArgumentNullException("expiryTime");
        }
        this._expiryTime = expiryTime;
    }
    return this._expiryTime;
}

WebTicketInfo.prototype.CreationTime = function (creationTime) {
    if (creationTime != undefined) {
        // set creationTime
        if (creationTime == null) {
            throw new ArgumentNullException("creationTime");
        }
        this._creationTime = creationTime;
    }
    return this._creationTime;
}

WebTicketInfo.prototype.IsRemoteDeployment = function (isRemoteDeployment) {
    if (isRemoteDeployment != undefined) {
        this._isRemoteDeployment = isRemoteDeployment;
    }
    return this._isRemoteDeployment;
}

WebTicketInfo.prototype.toString = function () {
    var message = "";
    message = message + "UserName: " + this._userName + "\n";
    message = message + "SipUri: " + this._sipUri + "\n";
    message = message + "IsInternal: " + this._isInternal.toString() + "\n";
    message = message + "IsSipEnabled: " + this._isSipEnabled.toString() + "\n";
    message = message + "IsRemoteDeployment: " + this._isRemoteDeployment.toString() + "\n";
    message = message + "WebTicket: " + this._ticket + "\n";

    return message;
}

WebTicketManager.State = new Object();
WebTicketManager.State.None = 0;
WebTicketManager.State.Initializing = 1;
WebTicketManager.State.Initialized = 2;
WebTicketManager.State.Acquiring = 3;
WebTicketManager.State.Acquired = 4;
WebTicketManager.State.Disposed = 5;

var UTCTimeTemplate = "%0-%1-%2T%3:%4:%5Z";

var MeetingTicketClaimTemplate = ["<Claims Dialect=\"urn:component:Microsoft.Rtc.WebAuthentication.2010:authclaims\">",
                                    "<ClaimType Uri=\"http://schemas.microsoft.com/ws/2005/05/identity/claims/conferenceuri\" Optional=\"false\" xmlns=\"http://schemas.xmlsoap.org/ws/2006/12/authorization\">",
                                       "<Value>%0</Value>",
                                    "</ClaimType>",
                                  "</Claims>"].join("");

var RenewTargetTemplate = ["<RenewTarget>",
                             "<UserToken xmlns=\"urn:component:Microsoft.Rtc.WebAuthentication.2010\">",
                             "%0",
                             "</UserToken>",
                           "</RenewTarget>"].join("");

var IWARequestTemplate = ["<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">",
                            "<s:Body>",
                                "<RequestSecurityToken xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" Context=\"%0\" xmlns=\"http://docs.oasis-open.org/ws-sx/ws-trust/200512\">",
                                    "<TokenType>urn:component:Microsoft.Rtc.WebAuthentication.2010:user-cwt-1</TokenType>",
                                    "<RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</RequestType>",
                                    "<AppliesTo xmlns=\"http://schemas.xmlsoap.org/ws/2004/09/policy\">",
                                        "<EndpointReference xmlns=\"http://www.w3.org/2005/08/addressing\">",
                                            "<Address>%1</Address>",
                                        "</EndpointReference>",
                                    "</AppliesTo>",
                                    "%2",
                                    "<Lifetime>",
                                        "<Created xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">",
                                        "%3",
                                        "</Created>",
                                        "<Expires xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">",
                                        "%4",
                                        "</Expires>",
                                    "</Lifetime>",
                                    "%5",
                                "</RequestSecurityToken>",
                            "</s:Body>",
                        "</s:Envelope>"].join("");
var FormsAnonRequestTemplate = ["<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">",
                                    "<s:Header>",
                                        "<Security s:mustUnderstand=\"1\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\" xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">",
                                            "<UsernameToken>",
                                                "<Username>%0</Username>",
                                                "<Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">%1</Password>",
                                            "</UsernameToken>",
                                        "</Security>",
                                    "</s:Header>",
                                    "<s:Body>",
                                        "<RequestSecurityToken xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" Context=\"%2\" xmlns=\"http://docs.oasis-open.org/ws-sx/ws-trust/200512\">",
                                            "<TokenType>urn:component:Microsoft.Rtc.WebAuthentication.2010:user-cwt-1</TokenType>",
                                            "<RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</RequestType>",
                                            "<AppliesTo xmlns=\"http://schemas.xmlsoap.org/ws/2004/09/policy\">",
                                                "<EndpointReference xmlns=\"http://www.w3.org/2005/08/addressing\">",
                                                    "<Address>%3</Address>",
                                                "</EndpointReference>",
                                            "</AppliesTo>",
                                            "%4",
                                            "<Lifetime>",
                                                "<Created xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">",
                                                "%5",
                                                "</Created>",
                                                "<Expires xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">",
                                                "%6",
                                                "</Expires>",
                                            "</Lifetime>",
                                            "<KeyType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/SymmetricKey</KeyType>",
                                            "%7",
                                        "</RequestSecurityToken>",
                                    "</s:Body>",
                                "</s:Envelope>"].join("");
var GetUserDetailsRequestTemplate = ["<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">",
                                        "<s:Header>",
                                            "<Security xmlns=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">%0</Security>",
                                            "<To xmlns=\"http://www.w3.org/2005/08/addressing\">%1</To>",
                                            "<Action xmlns=\"http://www.w3.org/2005/08/addressing\">http://tempuri.org/ISessionManager/GetUserDetails</Action>",
                                        "</s:Header>",
                                        "<s:Body>",
                                            "<GetUserDetails xmlns=\"http://tempuri.org/\" />",
                                        "</s:Body>",
                                    "</s:Envelope>"].join("");
var GetMexDocumentRequestTemplate = ["<soap12:Envelope xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">",
                                                            "<soap12:Header>",
                                                                "<wsa:Action soap12:mustUnderstand=\"1\">",
                                                                    "http://schemas.xmlsoap.org/ws/2004/09/transfer/Get",
                                                                "</wsa:Action>",
                                                                "<wsa:ReplyTo>",
                                                                    "<wsa:Address>",
                                                                        "http://www.w3.org/2005/08/addressing/anonymous",
                                                                    "</wsa:Address>",
                                                                "</wsa:ReplyTo>",
                                                                "<wsa:To soap12:mustUnderstand=\"1\">",
                                                                    "%0",
                                                                "</wsa:To>",
                                                            "</soap12:Header>",
                                                            "<soap12:Body/>",
                                                        "</soap12:Envelope>"].join("");

function WebTicketManager() {
    this._state = WebTicketManager.State.None;
    this._supportedAuthTypes = new Array();
    this._connection = new WebTicketConnection();
    this.OnlineAuthPage = null;
    this._connection.Initialize(this);
    this._connection._requestHeaders.Add("Content-Type", "text/xml; charset=utf-8");
    this._urlDictionary = new Map();
    this._callback = null;
    this.WSFedBearerPresent = false;
}

WebTicketManager.prototype.Dispose = function () {
    this._state = WebTicketManager.State.Disposed;
    delete this._supportedAuthTypes;
    delete this._connection;
    this._urlDictionary.ClearAll();
    delete this._urlDictionary;
}

/// <summary>
/// This method will provide the application the ability to set the uri of the
/// WebTicketService. This should be the svc's uri.
/// </summary>
WebTicketManager.prototype.WebTicketServiceUri = function(uri) {
    if (uri != undefined) {
        if (!uri || uri == null || uri.length == 0) {
            var exception = new ArgumentNullException("uri");
            throw exception;
        }
        var colonCharPos = uri.indexOf(':');
        if (colonCharPos == -1) {
            // can not find the ':' char to figure out the uri scheme
            var exception = new ArgumentException("uri:" + uri.toString());
            throw exception;
        }
        var scheme = uri.substring(0, colonCharPos);
        scheme = scheme.toLowerCase();
        if (scheme != "http" && scheme != "https") {
            // only http and https uri scheme supported
            var exception = new ArgumentException("uri:" + uri.toString());
            throw exception;
        }

        this._webTicketServiceUri = uri;
    }

    return this._webTicketServiceUri;
}

/// <summary>
/// Initialize the WebTicket manager to get back the WebTicket web service 
/// supported authentication types.
/// Currently we don't support re-initialization, it will just simply finish
/// this call synchronizely.
/// </summary>
/// <returns>
/// The server supported authenticaiton types stored in an array will be passed to
/// the callback call.
/// </returns>
WebTicketManager.prototype.Initialize = function (callback) {
    if (this._state != WebTicketManager.State.None) {
        var exception = new InvalidOperationException("WebTicketManager.Initialize: WrongState -- " + this._state.toString());
        throw exception;
    }

    if (!callback || callback == null) {
        var exception = new ArgumentNullException("callback");
        throw exception;
    }

    this._state = WebTicketManager.State.Initializing;
    this._callback = callback;

    try {
        if (!this._webTicketServiceUri || this._webTicketServiceUri.length <= 0) {
            var exception = new InvalidOperationException("WebTicketManager.Initialize: need to set _webTicketServiceUri before call Initialize");
            throw exception;
        }
        var url = this._webTicketServiceUri + "/mex";
       
        this._connection._requestHeaders.Remove("Content-Type");
        window.setTimeout(TimerHandler(this._connection, this._connection.SendHttpRequest, "GET", url, null), 0);
    }
    catch (e) {
        // revert the state back to None if not success
        this._state = WebTicketManager.State.None;
        throw e;
    }
}

/// <summary>
/// Get URL for given auth type.
/// </summary>
/// <param name="authTypeToUse"></param>
/// <returns> Server URL for given auth type </returns>
WebTicketManager.prototype.GetUrl = function(authTypeToUse) {
    if (this._state != WebTicketManager.State.Initialized && this._state != WebTicketManager.State.Acquired) {
        var exception = new InvalidOperationException("WebTicketManager.AcquireTicket: WrongState to call GetUrl: " + this._state.toString());
        throw exception;
    }
    var url = this._urlDictionary.Get(authTypeToUse);
    if (!url || url == null || url.length == 0) {
        var exception = new ArgumentException("the specified authentication type: " + authTypeToUse.toString() + " is not supported by server");
        throw exception;
    }

    return url;
}

/// <summary>
/// Acquire a new ticket.
/// If this is not the first time to call this, the old ticket will be thrown away.
/// </summary>
/// <param name="authTypeToUse"></param>
/// <param name="credential"></param>
/// <param name="renewTarget">Compact Web Ticket to renew. Use when renewing anonymous user web tickets.</param>
/// <returns> the WebTicketInfo will be passed through the callback </returns>
WebTicketManager.prototype.AcquireTicket = function (authTypeToUse, credential, callback, renewTarget) {
    return this.AcquireTicketForDuration(authTypeToUse, credential, MinTicketValidityDuration, callback, null, renewTarget);

 }

 /// <summary>
 /// Acquire a new ticket.
 /// If this is not the first time to call this, the old ticket will be thrown away.
 /// </summary>
 /// <param name="authTypeToUse"></param>
 /// <param name="credential"></param>
 /// <param name="conferenceUri">If ticket if for a UCWA based meeting, provide the SIP conference URI</param>
 /// <returns> the WebTicketInfo will be passed through the callback </returns>
 WebTicketManager.prototype.AcquireMeetingTicket = function (authTypeToUse, credential, conferenceUri, callback) {

     if (!conferenceUri || conferenceUri == null) {
         var exception = new ArgumentNullException("conferenceUri");
         throw exception;
     }

     return this.AcquireTicketForDuration(authTypeToUse, credential, MinTicketValidityDuration, callback, conferenceUri, null);

 }

/// <summary>
/// Acquire a new ticket.
/// If this is not the first time to call this, the old ticket will be thrown away.
/// </summary>
/// <param name="authTypeToUse"></param>
/// <param name="credential"></param>
/// <param name="desiredDuration">Desired duration in minutes for ticket validity.</param>
/// <param name="conferenceUri">If ticket if for a UCWA based meeting, provide the SIP conference URI</param>
/// <param name="renewTarget">Compact Web Ticket to renew.</param>
/// <returns> the WebTicketInfo will be passed through the callback </returns>
 WebTicketManager.prototype.AcquireTicketForDuration = function (authTypeToUse, credential, desiredDuration, callback, conferenceUri, renewTarget) {

     if (this._state != WebTicketManager.State.Initialized && this._state != WebTicketManager.State.Acquired) {
         var exception = new InvalidOperationException("WebTicketManager.AcquireTicket: WrongState to call AcquireTicket: " + this._state.toString());
         throw exception;
     }

     if (!callback || callback == null) {
         var exception = new ArgumentNullException("callback");
         throw exception;
     }

     if ((authTypeToUse == AuthenticationType.IWA || authTypeToUse == AuthenticationType.WsFedPassive) &&
        credential != null) {
         var exception = new ArgumentException("WebTicketManager.AcquireTicket: ArgumentException, credential should be null for IWA or WsFedPassive auth");
         throw exception;
     }

     if (authTypeToUse == AuthenticationType.Forms && credential == null) {
         var exception = new ArgumentException("WebTicketManager.AcquireTicket: ArgumentException, credential should not be null for forms auth");
         throw exception;
     }

     var ticketDuration = desiredDuration;

     //Let server dictate max.
     if (ticketDuration < MinTicketValidityDuration) {
         ticketDuration = MinTicketValidityDuration;
     }

     var conferenceClaim = "";

     if (conferenceUri != null && conferenceUri != "") {
         conferenceClaim = StringFormat(MeetingTicketClaimTemplate, conferenceUri);
     }

     var renewTargetElement = "";

     if (renewTarget != null && renewTarget != "") {
         if (authTypeToUse != AuthenticationType.BasicAnon) {
             var exception = new ArgumentException("WebTicketManager.AcquireTicket: ArgumentException, Renewal is only allowed for anonymous tickets");
             throw exception;
         }

         renewTargetElement = StringFormat(RenewTargetTemplate, renewTarget);
     }


     var originalState = this._state;
     this._state = WebTicketManager.State.Acquiring;
     this._callback = callback;

     var webTicket;

     try {
         var context = guid();

         this._authTypeToUse = authTypeToUse;
         var url = this._urlDictionary.Get(authTypeToUse);
         if (!url || url == null || url.length == 0) {
             var exception = new ArgumentException("the specified authentication type: " + authTypeToUse.toString() + " is not supported by server");
             throw exception;
         }

         var created = new Date();
         var createdTimeString = this._GetUTCTimeString(created);
         var expires = new Date(created.toUTCString());
         expires.setMinutes(created.getMinutes() + ticketDuration);
         var expiresTimeString = this._GetUTCTimeString(expires);
         var requestData;
         if (authTypeToUse == AuthenticationType.IWA || authTypeToUse == AuthenticationType.WsFedPassive) {
             requestData = StringFormat(IWARequestTemplate, context, url, conferenceClaim, createdTimeString, expiresTimeString, renewTargetElement);
         }
         else {
             requestData = StringFormat(FormsAnonRequestTemplate, credential.UserName(), credential.Password(), context, url, conferenceClaim, 
                                        createdTimeString, expiresTimeString, renewTargetElement);
         }

         this._connection._requestHeaders.Remove("Content-Type");
         this._connection._requestHeaders.Remove("SOAPAction");
         this._connection._requestHeaders.Add("Content-Type", "text/xml");
         this._connection._requestHeaders.Add("SOAPAction", "http://docs.oasis-open.org/ws-sx/ws-trust/200512/RST/Issue");
         window.setTimeout(TimerHandler(this._connection, this._connection.SendHttpRequest, "POST", url, requestData), 0);
     }
     catch (e) {
         // restore the state if not success
         this._state = originalState;
         throw e;
     }

     return webTicket;
 }

WebTicketManager.prototype._PadString = function (content, len) {
    val = String(content);
    while (val.length < len) val = "0" + val;
    return val;
}

WebTicketManager.prototype._GetUTCTimeString = function (dateTime) {
    return StringFormat(
        UTCTimeTemplate,
        this._PadString(dateTime.getUTCFullYear(), 4),
        this._PadString(dateTime.getUTCMonth()+1, 2),
        this._PadString(dateTime.getUTCDate(), 2),
        this._PadString(dateTime.getUTCHours(), 2),
        this._PadString(dateTime.getUTCMinutes(), 2),
        this._PadString(dateTime.getUTCSeconds(), 2));
}

WebTicketManager.prototype._OnSuccess = function() {
    var result = null;
    var exception = null;

    if (this._state == WebTicketManager.State.Disposed) {
        // log the info trace: object has been disposed, the result ignored
        exception = new ObjectDisposedException("WebTicketManager");
    }
    else if (this._state == WebTicketManager.State.Initializing) {
        // this should be the get mex document call result
        try {
            result = this._InitializationCallback();
        }
        catch (e) {
            this._state = WebTicketManager.State.None;
            exception = e;
        }
    }
    else if (this._state == WebTicketManager.State.Acquiring) {
        // this should be the acquireWebTicket WCF call result
        try {
            this._AcquireTicketCallback();
            // after successfully acquire ticket, need to get user details before
            // call the callbck, so just return
            result = this._GetUserDetailsCallback();
        }
        catch (e) {
            this._state = WebTicketManager.State.Initialized;
            exception = e;
        }
    }
//    else if (this._state == WebTicketManager.State.Acquired) {
//        // this should be the GetUserDetails WCF call result
//        try {
//            result = this._GetUserDetailsCallback();
//        }
//        catch (e) {
//            this._state = WebTicketManager.State.Initialized;
//            exception = e;
//        }
//    }
    else {
        exception = new Exception("WebTicketManager._OnSuccess: wrong state to continue processing, " + this._state.toString());
    }

    if (result != null || exception != null) {
        this._callback(result, exception);
    }
    else {
        // should not be here
        ShowException("WebTicketManager._OnSuccess: ERROR!!!");
    }
}

WebTicketManager.prototype._OnError = function (errorCode, innerException) {
    var exception = null;
    var XMLHTTPREQUEST_CHALLENGE = 401;

    if (this._state == WebTicketManager.State.Disposed) {
        // log the info trace: object has been disposed, the error ignored.
        exception = new ObjectDisposedException("WebTicketManager");
    }
    else {
        if (this._state == WebTicketManager.State.Initializing) {
            this._state = WebTicketManager.State.None;
            exception = new Exception("WebTicketManager._OnError: Initialize failed with errorCode: " + errorCode.toString(), innerException);
        }
        else {
            var originalState = this._state;
            this._state = WebTicketManager.State.Initialized;
            if (originalState == WebTicketManager.State.Acquiring) {
                // the webticket acquiring failed
                if (this._authTypeToUse == AuthenticationType.Forms) {
                    var errorId = this._ProcessFaultMessage();
                    if (errorId) {
                        exception = new AuthenticationException("authentication failed, refer to the error id", null);
                        exception.ErrorId = errorId;
                    }
                    else {
                        exception = new Exception("WebTicketManager._OnError: AcquireTicket failed with errorCode: " + errorCode.toString(), innerException);
                    }
                }
                else if (this._authTypeToUse == AuthenticationType.IWA) {
                    if (errorCode == XMLHTTPREQUEST_CHALLENGE) {
                        // IWA auth get 401 response means that the IWA failed with the provided user credential
                        exception = new AuthenticationException("authentication failed, refer to the error id", null);
                        exception.ErrorId = MsDiagnosticErrorId.UserNamePasswordIncorrect;
                    }
                    else {
                        var msDiagHeader = this._connection.GetResponseHeader("X-Ms-diagnostics");
                        if (msDiagHeader) {
                            var msDiag = new MsDiagHeader();
                            msDiag.parse(msDiagHeader);

                            exception = new AuthenticationException("authentication failed, refer to the error id", null);
                            exception.ErrorId = msDiag.ErrorId;
                            exception.DisplayName = msDiag.DisplayName;
                            exception.MemberName = msDiag.MemberName;

                            // 
                        }
                        else {
                            exception = new Exception("WebTicketManager._OnError: AcquireTicket failed with errorCode: " + errorCode.toString(), innerException);
                        }
                    }
                }
                else if (this._authTypeToUse == AuthenticationType.WsFedPassive) {
                    if (errorCode == XMLHTTPREQUEST_CHALLENGE) {
                        // WsFedPassive auth get 401 response means that the it failed with the provided user credential
                        exception = new AuthenticationException("authentication failed, refer to the error id", null);
                        exception.ErrorId = MsDiagnosticErrorId.WsFedPassiveNotSignedIn;
                    }
                    else {
                        var msDiagHeader = this._connection.GetResponseHeader("X-Ms-diagnostics");
                        if (msDiagHeader) {
                            // get the error id from the header
                            var msDiag = new MsDiagHeader();
                            msDiag.parse(msDiagHeader);

                            exception = new AuthenticationException("authentication failed, refer to the error id", null);
                            exception.ErrorId = msDiag.ErrorId;
                            exception.DisplayName = msDiag.DisplayName;
                            exception.MemberName = msDiag.MemberName;
                        }
                        else {
                            exception = new Exception("WebTicketManager._OnError: AcquireTicket failed with errorCode: " + errorCode.toString(), innerException);
                        }
                    }
                }
                else {
                    exception = new Exception("WebTicketManager._OnError: AcquireTicket failed with errorCode: " + errorCode.toString(), innerException);
                }
            }
            else if (originalState == WebTicketManager.State.Acquired) {
                // the getuserdetails failed
                exception = new Exception("WebTicketManager._OnError: GetUserDetails failed with errorCode: " + errorCode.toString(), innerException);
            }
            else {
                exception = new Exception("WebTicketManager._OnError: wrong state to continue processing, " + this._state.toString(), innerException);
            }
        }
    }

    this._callback(null, exception);
}

WebTicketManager.prototype._ProcessFaultMessage = function () {
    var responseXml = this._connection.GetResponseXML();
    if (!responseXml || responseXml.length == 0) {
        return null;
    }

    var msDiagnosticsFaultXmlNodes = this._getElementsByTagName("Ms-Diagnostics-Fault", "urn:component:Microsoft.Rtc.WebAuthentication.2010", null, responseXml);
    if (!msDiagnosticsFaultXmlNodes || msDiagnosticsFaultXmlNodes.length == 0) {
        return null;
    }

    var errorIdXmlNodes = this._getElementsByTagName("ErrorId", "urn:component:Microsoft.Rtc.WebAuthentication.2010", null, msDiagnosticsFaultXmlNodes[0]);
    if (!errorIdXmlNodes || errorIdXmlNodes.length == 0) {
        return null;
    }

    var errorId = XMLGetInnerXMLString(errorIdXmlNodes[0]);
    return errorId;
}

WebTicketManager.prototype._InitializationCallback = function() {
    // extract the auth types and url for each auth type from returned mex document
    var responseXml = this._connection.GetResponseXML();
    if (!responseXml || responseXml.length == 0) {
        var exception = new ServerErrorException("WebTicketManager.Initialize: fail to get back mex document");
        throw exception;
    }

    var serviceXmlNodes = this._getElementsByTagName("service", "http://schemas.xmlsoap.org/wsdl/", "wsdl", responseXml);
    if (!serviceXmlNodes || serviceXmlNodes.length == 0) {
        var exception = new ServerErrorException("WebTicketManager.Initialize: can not find wsdl:service node from the mex document, response is: " + XMLGetXMLString(responseXml));
        throw exception;
    }

    var webTicketServiceNode = serviceXmlNodes[0];
    var serviceName = this._getAttributeByName("name", null, null, webTicketServiceNode);
    if (!serviceName || serviceName != "WebTicketService") {
        var exception = new ServerErrorException("WebTicketManager.Initialize: can not find wsdl:service node with name WebTicketService from the mex document, response is: " + XMLGetXMLString(responseXml));
        throw exception;
    }

    var portNodes = this._getElementsByTagName("port", "http://schemas.xmlsoap.org/wsdl/", "wsdl", webTicketServiceNode);
    if (!portNodes || portNodes.length == 0) {
        var exception = new ServerErrorException("WebTicketManager.Initialize: can not find wsdl:port node from the mex document, response is: " + XMLGetXMLString(responseXml));
        throw exception;
    }

    var mapServices = new Map();
    for (var index = 0; index < portNodes.length; index++) {
        var portNode = portNodes[index];
        var binding = this._getAttributeByName("binding", null, null, portNode);
        if (binding && binding.length > 0) {
            // strip the namespace part if any
            var colonCharPos = binding.indexOf(':');
            if (colonCharPos != -1) {
                binding = binding.substr(colonCharPos + 1);
            }
            var addressNodes = this._getElementsByTagName("address", "http://schemas.xmlsoap.org/wsdl/soap/", "soap", portNode);
            if (addressNodes && addressNodes.length > 0) {
                var addressNode = addressNodes[0];
                var location = this._getAttributeByName("location", null, null, addressNode);
                if (location && location.length > 0) {
                    mapServices.Add(binding, location);
                }
                else {
                    // log this with warning: "can not find location attribute for binding " + binding + " from the mex document";
                }
            }
            else {
                // log this with warning: "can not find soap:address node for binding " + binding + " from the mex document";
            }
        }
        else {
            // log this with warning: "can not find binding attribute from the port node: " + XMLGetXMLString(portNode);
        }
    }

    var bindingXmlNodes = this._getElementsByTagName("binding", "http://schemas.xmlsoap.org/wsdl/", "wsdl", responseXml);
    if (!bindingXmlNodes || bindingXmlNodes.length == 0) {
        var exception = new ServerErrorException("WebTicketManager.Initialize: can not find wsdl:binding node from the mex document, response is: " + XMLGetXMLString(responseXml));
        throw exception;
    }

    var mapBindings = new Map();
    for (var index = 0; index < bindingXmlNodes.length; index++) {
        var bindingNode = bindingXmlNodes[index];
        var bindingName = this._getAttributeByName("name", null, null, bindingNode);
        if (bindingName && bindingName.length > 0) {
            var policyReferenceNodes = this._getElementsByTagName("PolicyReference", "http://schemas.xmlsoap.org/ws/2004/09/policy", "wsp", bindingNode);
            if (policyReferenceNodes && policyReferenceNodes.length > 0) {
                var policyReferenceNode = policyReferenceNodes[0];
                var uri = this._getAttributeByName("URI", null, null, policyReferenceNode);
                if (uri && uri.length > 0) {
                    // remove the prefix '#' if any
                    if (uri.charAt(0) == '#') {
                        uri = uri.substr(1);
                    }
                    mapBindings.Add(uri, bindingName);
                }
                else {
                    // log this with warning: "can not find URI attribute from the PolicyReference node:" + XMLGetXMLString(policyReferenceNode)
                }
            }
            else {
                // log this with warning: "can not find PolicyReference node from the mex document for binding: " + bindingName
            }
        }
        else {
            // log this with warning: "can not find name attribute from the binding node: " + XMLGetXMLString(bindingNode)
        }
    }

    var policyXmlNodes = this._getElementsByTagName("Policy", "http://schemas.xmlsoap.org/ws/2004/09/policy", "wsp", responseXml);
    if (!policyXmlNodes || policyXmlNodes.length == 0) {
        var exception = new ServerErrorException("WebTicketManager.Initialize: can not find wsdl:binding node from the mex document, response is: " + XMLGetXMLString(responseXml));
        throw exception;
    }

    var mapPolicies = new Map();
    for (var index = 0; index < policyXmlNodes.length; index++) {
        var policyXmlNode = policyXmlNodes[index];
        var id = this._getAttributeByName("Id", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd", "wsu", policyXmlNode);
        if (id && id.length > 0) {
            if(id=="WsFedBearer_policy") {
                this.WSFedBearerPresent = true;
            }
            var wspAllNodes = this._getElementsByTagName("All", "http://schemas.xmlsoap.org/ws/2004/09/policy", "wsp", policyXmlNode);
            if (wspAllNodes && wspAllNodes.length > 0) {
                var wspAllNode = wspAllNodes[0];
                for (var i = 0; i < wspAllNode.childNodes.length; i++) {
                    var child = wspAllNode.childNodes[i];
                    var authTypeName = child.nodeName;
                    // strip the namespace part if any
                    var colonCharPos = authTypeName.indexOf(':');
                    if (colonCharPos != -1) {
                        authTypeName = authTypeName.substr(colonCharPos + 1);
                    }
                    var authType = AuthenticationType.None;
                    switch (authTypeName) {
                        case "NegotiateAuthentication":
                        case "NtlmAuthentication":
                            authType = AuthenticationType.IWA;
                            break;
                        case "FormsAuthentication":
                            authType = AuthenticationType.Forms;
                            break;
                        case "AnonAuthentication":
                            authType = AuthenticationType.BasicAnon;
                            break;
                        case "WsFederationPassive":
                            this.OnlineAuthPage = this._getAttributeByName("passiveauthpage", "urn:component:Microsoft.Rtc.WebAuthentication.2010", "af", child);
                            authType = AuthenticationType.WsFedPassive;
                            break;
                    }
                    if (authType != AuthenticationType.None) {
                        // log this with info: server support authType.toString()
                        mapPolicies.Add(authType, id);
                    }
                }
            }
            else {
                // log this with warning: "can not find All node from the policy node: " + XMLGetXMLString(policyXmlNode)
            }
        }
        else {
            // log this with warning: "can not find Id attribute from the policy node: " + XMLGetXMLString(policyXmlNode)
        }
    }

    for (var key = AuthenticationType.Start; key <= AuthenticationType.End; key++) {
        var value = mapPolicies.Get(key);
        if (value) {
            var binding = mapBindings.Get(value);
            if (binding) {
                var url = mapServices.Get(binding);
                if (url) {
                    this._supportedAuthTypes.push(key);
                    this._urlDictionary.Add(key, url);
                }
            }
        }
    }

    // pass the supported auth types to the app through callback
    var supportedAuthTypes = new Map();
    // initialize the map
    supportedAuthTypes.Add(AuthenticationType.IWA, false);
    supportedAuthTypes.Add(AuthenticationType.Forms, false);
    supportedAuthTypes.Add(AuthenticationType.BasicAnon, false);
    supportedAuthTypes.Add(AuthenticationType.WsFedPassive, false);
    for (var index = 0; index < this._supportedAuthTypes.length; index++) {
        supportedAuthTypes.Add(this._supportedAuthTypes[index], true);
    }

    this._state = WebTicketManager.State.Initialized;

    return supportedAuthTypes;
}

WebTicketManager.prototype.ParseExpirationTime = function(responseXml) {

var expires= this._getElementsByTagName("Expires", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd", "", responseXml)[0];

var expiryTimeValue = XMLGetInnerXMLString(expires);

//Parsing fails for IE
var parsedTime = new Date(expiryTimeValue);

if(isNaN(parsedTime))
{
    var dateArray = expiryTimeValue.split(new RegExp("[-T:.]{1}"));

    parsedTime  = new Date(Date.UTC(dateArray[0],dateArray[1]-1,dateArray[2],dateArray[3],dateArray[4],dateArray[5]));
}

return parsedTime;
}

WebTicketManager.prototype.ParseCreationTime = function (responseXml) {

    var created = this._getElementsByTagName("Created", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd", "", responseXml)[0];

    var creationTimeValue = XMLGetInnerXMLString(created);

    //Parsing fails for IE
    var parsedTime = new Date(creationTimeValue);

    if (isNaN(parsedTime)) {
        var dateArray = creationTimeValue.split(new RegExp("[-T:.]{1}"));

        parsedTime = new Date(Date.UTC(dateArray[0], dateArray[1] - 1, dateArray[2], dateArray[3], dateArray[4], dateArray[5]));
    }

    return parsedTime;
}

WebTicketManager.prototype._AcquireTicketCallback = function () {


    // extract the webticket out from the response
    var responseXml = this._connection.GetResponseXML();
    if (!responseXml || responseXml.length == 0) {
        var exception = new ServerErrorException("WebTicketManager._AcquireTicketCallback: fail to acquire web ticket");
        throw exception;
    }

    var responseNodes = this._getElementsByTagName("RequestSecurityTokenResponse", "http://docs.oasis-open.org/ws-sx/ws-trust/200512", "", responseXml);
    if (!responseNodes || responseNodes == null || responseNodes.Length == 0) {
        var exception = new ServerErrorException("WebTicketManager._AcquireTicketCallback: response is: " + XMLGetXMLString(responseXml));
        throw exception;
    }

    var userIsInRemoteDeployment = false;
    var remoteDeployment = this._getAttributeByName("RemoteDeployment", "urn:component:Microsoft.Rtc.WebAuthentication.2010", "a", responseNodes[0]);
    if (remoteDeployment && remoteDeployment == "True") {
        userIsInRemoteDeployment = true;
    }


    var webticket = this._getElementsByTagName("UserToken", "urn:component:Microsoft.Rtc.WebAuthentication.2010", "a", responseXml)[0];
    if (!webticket || webticket == null || webticket.length == 0) {
        var exception = new ServerErrorException("WebTicketManager._AcquireTicketCallback: fail to acquire web ticket, response is: " + XMLGetXMLString(responseXml));
        throw exception;
    }


    var webticketString = XMLGetInnerXMLString(webticket);
    this._webTicketInfo = new WebTicketInfo(webticketString);
    this._webTicketInfo.ExpiryTime = this.ParseExpirationTime(responseXml);
    this._webTicketInfo.CreationTime = this.ParseCreationTime(responseXml);
    this._webTicketInfo.IsRemoteDeployment = userIsInRemoteDeployment;

    this._state = WebTicketManager.State.Acquired;

    //    // after the ticket is acquired, we need to pull the user details by making the WCF call to SessionManager service
    //    // get the base uri from the webticket url
    //    var url = this._urlDictionary.Get(this._authTypeToUse);
    //    var colonCharPos = url.indexOf(':');
    //    var baseUri = url.substring(0, colonCharPos + 3);
    //    var restStr = url.substr(colonCharPos + 3);
    //    var slashCharPos = restStr.indexOf('/');
    //    baseUri = baseUri + restStr.substring(0, slashCharPos + 1);

    //    url = baseUri + "reachweb/Sip.svc/SessionManager";
    //    requestData = StringFormat(GetUserDetailsRequestTemplate, webticketString, url);

    //    this._connection._requestHeaders.Remove("SOAPAction");
    //    this._connection._requestHeaders.Add("SOAPAction", "http://tempuri.org/ISessionManager/GetUserDetails");
    //    window.setTimeout(TimerHandler(this._connection, this._connection.SendHttpRequest, "POST", url, requestData), 0);
}

WebTicketManager.prototype._GetUserDetailsCallback = function() {
//    responseXml = this._connection.GetResponseXML();
//    if (!responseXml || responseXml.length == 0) {
//        var exception = new ServerErrorException("WebTicketManager._GetUserDetailsCallback: fail to acquire web ticket");
//        throw exception;
//    }

//    // extract the user details out from response xml
//    var getUserDetailsResponse = this._getElementsByTagName("GetUserDetailsResponse", null, null, responseXml)[0];
//    if (getUserDetailsResponse) {
//        var getUserDetailsResult = this._getElementsByTagName("GetUserDetailsResult", null, null, getUserDetailsResponse)[0];
//        if (getUserDetailsResult) {
//            var displayNameNode = this._getElementsByTagName("DisplayName", "http://schemas.datacontract.org/2004/07/Microsoft.Rtc.Internal.WebRelay.Sip", "b", getUserDetailsResult)[0];
//            if (displayNameNode) {
//                var displayNameNode = XMLGetNodeValue(displayNameNode);
//                this._webTicketInfo.UserName(displayNameNode);
//            }
//            else {
//                var exception = new ServerErrorException("WebTicketManager._GetUserDetailsCallback: can not find the DisplayName node from the response:" + XMLGetXMLString(responseXml));
//                throw exception;
//            }
//            var isExternalNode = this._getElementsByTagName("IsExternal", "http://schemas.datacontract.org/2004/07/Microsoft.Rtc.Internal.WebRelay.Sip", "b", getUserDetailsResult)[0];
//            if (isExternalNode) {
//                var isExternal = XMLGetNodeValue(isExternalNode).toLowerCase();
//                if (isExternal == "true") {
//                    this._webTicketInfo.IsInternal(false);
//                }
//                else {
//                    this._webTicketInfo.IsInternal(true);
//                }
//            }
//            else {
//                var exception = new ServerErrorException("WebTicketManager._GetUserDetailsCallback: can not find the IsInternal node from the response:" + XMLGetXMLString(responseXml));
//                throw exception;
//            }
//            var isSipEnabledNode = this._getElementsByTagName("IsSipEnabled", "http://schemas.datacontract.org/2004/07/Microsoft.Rtc.Internal.WebRelay.Sip", "b", getUserDetailsResult)[0];
//            if (isSipEnabledNode) {
//                var isSipEnabled = XMLGetNodeValue(isSipEnabledNode).toLowerCase();
//                if (isSipEnabled == "true") {
//                    this._webTicketInfo.IsSipEnabled(true);
//                }
//                else {
//                    this._webTicketInfo.IsSipEnabled(false);
//                }
//            }
//            else {
//                var exception = new ServerErrorException("WebTicketManager._GetUserDetailsCallback: can not find the IsSipEnabled node from the response:" + XMLGetXMLString(responseXml));
//                throw exception;
//            }
//            var sipUriNode = this._getElementsByTagName("SipUri", "http://schemas.datacontract.org/2004/07/Microsoft.Rtc.Internal.WebRelay.Sip", "b", getUserDetailsResult)[0];
//            if (sipUriNode) {
//                this._webTicketInfo.SipUri(XMLGetNodeValue(sipUriNode));
//            }
//            else {
//                var exception = new ServerErrorException("WebTicketManager._GetUserDetailsCallback: can not find the SipUri node from the response:" + XMLGetXMLString(responseXml));
//                throw exception;
//            }
//        }
//        else {
//            var exception = new ServerErrorException("WebTicketManager._GetUserDetailsCallback: can not find the GetUserDetailsResult node from the response:" + XMLGetXMLString(responseXml));
//            throw exception;
//        }
//    }
//    else {
//        var exception = new ServerErrorException("WebTicketManager._GetUserDetailsCallback: can not find the GetUserDetailsResponse node from the response:" + XMLGetXMLString(responseXml));
//        throw exception;
//    }

    // make a copy of the WebTicketInfo and pass the copy to the app through callback
    var webTicketInfo = new WebTicketInfo();
    webTicketInfo._ticket = this._webTicketInfo._ticket;
    webTicketInfo.ExpiryTime = this._webTicketInfo.ExpiryTime;
    webTicketInfo.CreationTime = this._webTicketInfo.CreationTime;
    webTicketInfo.IsRemoteDeployment = this._webTicketInfo.IsRemoteDeployment;
//    webTicketInfo._sipUri = this._webTicketInfo._sipUri;
//    webTicketInfo._userName = this._webTicketInfo._userName;
//    webTicketInfo._isInternal = this._webTicketInfo._isInternal;
//    webTicketInfo._isSipEnabled = this._webTicketInfo._isSipEnabled;

    return webTicketInfo;
}

WebTicketManager.prototype._getElementsByTagName = function(tagName, ns, prefix, scope) {
    if (!tagName || tagName == null || tagName.length == 0) {
        var exception = new ArgumentNullException("tagName");
        throw exception;
    }
    if (!scope || scope == null) {
        var exception = new ArgumentNullException("scope");
        throw exception;
    }
    var elementListForReturn;
    if ((!ns || ns == null || ns.length == 0) && (!prefix || prefix == null || prefix.length == 0)) {
        try {
            elementListForReturn = scope.getElementsByTagName(tagName);
        }
        catch (e) {
            // best effort to get the elements, if fail, just return undefined elementListForReturn,
            // the caller will check it. same for the below.
        }
        return elementListForReturn;
    }
    if (prefix && prefix != null && prefix.length > 0) {
        try {
            elementListForReturn = scope.getElementsByTagName(prefix + ":" + tagName);
        }
        catch (e) {
        }
    }
    if ((ns && ns != null && ns.length > 0) && (!elementListForReturn || elementListForReturn.length == 0)) {
        try {
            elementListForReturn = scope.getElementsByTagName(ns + ":" + tagName);
        }
        catch (e) {
        }
        if (!elementListForReturn || elementListForReturn.length == 0) {
            elementListForReturn = scope.getElementsByTagName(tagName);
            if (!elementListForReturn || elementListForReturn.length == 0 && scope.getElementsByTagNameNS) {
                try {
                    elementListForReturn = scope.getElementsByTagNameNS(ns, tagName);
                }
                catch (e) {
                }
            }
        }
    }

    return elementListForReturn;
}

WebTicketManager.prototype._getAttributeByName = function(name, ns, prefix, scope) {
    if (!name || name == null || name.length == 0) {
        var exception = new ArgumentNullException("name");
        throw exception;
    }
    if (!scope || scope == null) {
        var exception = new ArgumentNullException("scope");
        throw exception;
    }

    var attributeForReturn;
    if ((!ns || ns == null || ns.length == 0) && (!prefix || prefix == null || prefix.length == 0)) {
        try {
            attributeForReturn = scope.getAttribute(name);
        }
        catch (e) {
            // best effort to get the attribute, if fail, just return undefined attributeForReturn,
            // the caller will check it. same for the below.
        }
        return attributeForReturn;
    }
    if (prefix && prefix != null && prefix.length > 0) {
        try {
            attributeForReturn = scope.getAttribute(prefix + ":" + name);
        }
        catch (e) {
        }
    }
    if ((ns && ns != null && ns.length > 0) && (!attributeForReturn || attributeForReturn.length == 0)) {
        try {
            attributeForReturn = scope.getAttribute(ns + ":" + name);
        }
        catch (e) {
        }
        if (!attributeForReturn || attributeForReturn.length == 0) {
            attributeForReturn = scope.getAttribute(name);
        }
    }

    return attributeForReturn;
}

//---------------------------------------------------
// Map
// the javascript is instrinsically a map,
// but it can not offer the count of property within the map
// so, this is class is a light encapsulation to offer 
// the count property
//----------------------------------------------------
function Map() {
    this._map = new Object();
    this._count = 0;
}

// return true or flase
Map.prototype.Add = function (key, value) {
    if (!this._map[key]) {
        this._count++;

        this._map[key] = value;
        return true;
    }
    else {
        return false;
    }
}

// Update
// return true or false
Map.prototype.Update = function (key, value) {
    if (this._map[key]) {
        this._map[key] = value;
        return true;
    }
    else {
        return false;
    }
}

// return true or false
Map.prototype.Remove = function (key) {
    if (this._map[key] && (delete this._map[key] == true)) {
        this._count--;
        return true;
    }
    else {
        return false;
    }
}

Map.prototype.Get = function (key) {
    return this._map[key];
}

Map.prototype.GetMap = function () {
    return this._map;
}

Map.prototype.GetCount = function () {
    return this._count;
}

Map.prototype.ClearAll = function () {
    delete this._map;
    this._map = new Object();
    this._count = 0;
}

// XmlHelp function : returns the xml strings
function XMLGetXMLString(xmlNode) {
    if (!xmlNode) {
        throw new ArgumentNullException("xmlNode");
    }

    var str = "";
    // for IE    
    if (xmlNode.xml) {
        str = xmlNode.xml;
    }
    else {
        // For safari, we encapsulate the xmlNode
        if (xmlNode.xmlRootNode != null) {
            str = new XMLSerializer().serializeToString(xmlNode.xmlRootNode);

            // safari can only parse xmldoc and can not parse xmlnode
            if (str == null) {
                str = XMLGetElementString(xmlNode.xmlRootNode);
            }
        }
        else {
            str = new XMLSerializer().serializeToString(xmlNode);
        }
    }

    return str;
}

// XmlHelp function : returns the xml element inner strings
function XMLGetInnerXMLString(node) {
    var _result = "";

    if (node == null) { return _result; }

    for (var i = 0; i < node.childNodes.length; i++) {
        var thisNode = node.childNodes[i];
        switch (thisNode.nodeType) {
            case 1: // ELEMENT_NODE
            case 5: // ENTITY_REFERENCE_NODE
                _result += XMLGetElementString(thisNode);
                break;
            case 3: // TEXT_NODE
            case 2: // ATTRIBUTE_NODE
            case 4: // CDATA_SECTION_NODE
                _result += EscapeXmlSensitveChar(thisNode.nodeValue);
                break;
            default:
                break;
        }
    }
    return _result;
}


// XmlHelp function : returns the xml strings
// This function has the same functionality of XMLGetXMLSting, but has worser performance
// We only use it when necessary, such as safari can only parse xmldoc with XMLSerializer instead of xmlnode
function XMLGetElementString(thisNode) {
    if (thisNode == null) {
        throw new ArgumentNullException("thisNode");
    }

    var _result = "";

    // start tag
    _result += '<' + thisNode.nodeName;

    // add attributes
    if (thisNode.attributes && thisNode.attributes.length > 0) {
        for (var i = 0; i < thisNode.attributes.length; i++) {
            _result += " " + thisNode.attributes[i].name
			    + "=\"" + EscapeXmlSensitveChar(thisNode.attributes[i].value) + "\"";
        }
    }

    // close start tag
    _result += '>';

    // content of tag
    _result += XMLGetInnerXMLString(thisNode);

    // end tag
    _result += '</' + thisNode.nodeName + '>';

    return _result;
}


// XmlHelp function
function XMLGetNodeValue(xmlNode) {
    if (!xmlNode) {
        throw new ArgumentNullException("xmlNode");
    }

    var textNode = xmlNode.firstChild;
    if (textNode && textNode.nodeValue) {
        return textNode.nodeValue;
    }
    else {
        return "";
    }
}

function Convert() {
	// private property
	this._keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
}

// input is byte array
Convert.prototype.ToBase64String = function (input) {
    var output = "";
    var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
    var i = 0;

    while (i < input.length) {
        chr1 = input[i++];
        chr2 = input[i++];
        chr3 = input[i++]; 

        enc1 = chr1 >> 2;
        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        enc4 = chr3 & 63;

        if (isNaN(chr2)) {
            enc3 = enc4 = 64;
        }
        else if (isNaN(chr3)) {
            enc4 = 64;
        }

        output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
    }

    return output;
}

function UTF8Encoding() {
}

// input is unicode string, output is the utf-8 encoded byte array
UTF8Encoding.prototype.GetBytes = function (string) {
    var output = new Array();

    for (var n = 0; n < string.length; n++) {

        var c = string.charCodeAt(n);

        if (c < 128) {
            output.push(c);
        }
        else if ((c > 127) && (c < 2048)) {
            output.push((c >> 6) | 192);
            output.push((c & 63) | 128);
        }
        else if ((c > 2047) && (c < 65536)) {
            output.push((c >> 12) | 224);
            output.push(((c >> 6) & 63) | 128);
            output.push((c & 63) | 128);
        }
        else if ((c > 65535) && (c < 1114112)) {
            output.push((c >> 18) | 240);
            output.push(((c >> 12) & 63) | 128);
            output.push(((c >> 6) & 63) | 128);
            output.push((c & 63) | 128);
        }
    }

    return output;
}

function S4() {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}
function guid() {
    return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

function WebTicketConnection() {
    this._httpRequest = this._CreateXMLHttpRequestObject();
    this._requestHeaders = new Map();
    this._isInUse = false;
    // on IE5.5, the ready status sequence could be 1, 4, 4, 4 or have multiple 4, which means 
    // the completed status could be fired more than event, so we need this 
    // variable to protect this
    this._lastReadyStatus = 0;
    this._timerid = 0;
    this._timeout = 30000;
    this._isTimerRunning = false;
}

WebTicketConnection.prototype.OnTimeout = function () {
    this.StopTimer();
    if (this._isInUse) {
        this._isInUse = false;
        this._SendFailed(999);
    }
}

WebTicketConnection.prototype.StartTimer = function () {
    if (!this._isTimerRunning) {
        this._timerid = window.setInterval(Delegate(this, this.OnTimeout), this._timeout);
        this._isTimerRunning = true;
    }
}

WebTicketConnection.prototype.StopTimer = function () {
    if (this._isTimerRunning) {
        window.clearInterval(this._timerid);
        this._timerid = 0;
        this._isTimerRunning = false;
    }
}

WebTicketConnection.prototype.Initialize = function (owner) {
    this._requestOwner = owner;
}

//Return the response text of request
WebTicketConnection.prototype.GetResponseXML = function () {
    if (this._httpRequest != null) {
        var text = RemoveC0Chars(this._httpRequest.responseText);

        var xml = null;

        if (window.DOMParser) {
            xml = new DOMParser().parseFromString(text, "application/xml");
        }
        else {
            xml = this._httpRequest.responseXML;

            // Means IE can not parse this xml, we should remove the C0 Chars
            if (xml.childNodes.length == 0 && window.ActiveXObject) {
                try {
                    xml = new ActiveXObject("Microsoft.XMLDOM");
                    xml.loadXML(text);
                }
                catch (e) {
                    ShowException("WebTicketConnection.GetResponseXML:" + e.toString());
                }

            }
        }

        return xml;
    }
    else {
        return null;
    }
}

WebTicketConnection.prototype.GetResponseHeader = function (headerName) {
    try {
        if (this._httpRequest != null) {
            return this._httpRequest.getResponseHeader(headerName);
        }
    } catch (e) { 
    }
    return null;
}

WebTicketConnection.prototype.SendHttpRequest = function (type, url, data) {
    if (this._isInUse == true) {
        var exception = new InvalidOperationException("Connection is in use");
        throw exception;
    }

    this._isInUse = true;

    // the passing in url must be full url including scheme and FQDN
    // and only https is supported.
    try {
        this._httpRequest.open(type, url, true);

        this._httpRequest.onreadystatechange = Delegate(this, this._ReadyStateChanged);

        if (type == "POST") {
            var headers = this._requestHeaders.GetMap();
            for (var it in headers) {
                this._httpRequest.setRequestHeader(it, headers[it]);
            }
        }

        this.StartTimer();

        this._httpRequest.send(data);
    }
    catch (e) {
        this._isInUse = false;
        this._SendFailed(2000, e);
    }
}

// _ReadyStateChanged(): it would be invoked when the states of the XmlHttpRequest object is changed
WebTicketConnection.prototype._ReadyStateChanged = function () {
    var XMLHTTPREQUEST_COMPLETE = 4;
    var XMLHTTPREQUEST_OK = 200;

    // Note: 
    // 1. We get this parameter at the very first stage because of a Firefox bug.
    //    If we get this value at later stage, we will hit exception.
    // 2. In IE, we can only get this value when the readyState is 4. 
    var currentState = null;
    var httpCode = null;

    // We ignore any readyStateChange notification if the current connection is no longer in use
    // This can happen incase the timer has already timed out.
    if (!this._isInUse) {
        return;
    }

    try {
        currentState = this._httpRequest.readyState;
    }
    catch (e) {
        this._SendFailed(2002, e);
        return;
    }

    try {
        // For Safari 10.1.3 the end status is 0
        if ((currentState == 0 || currentState == XMLHTTPREQUEST_COMPLETE) && this._lastReadyStatus != XMLHTTPREQUEST_COMPLETE) {
            try {
                httpCode = this._httpRequest.status;
            }
            catch (e) {
                //Trace(TraceType.Server, "http status error");
                httpCode = 377;
            }

            this._lastReadyStatus = currentState;

            if (httpCode == XMLHTTPREQUEST_OK) {
                this._SendSuccess();
            }
            else if (currentState != 0) {
                //Safari cannot get httpcode if network is down.
                if (!httpCode) {
                    httpCode = 404;
                }
                this._SendFailed(httpCode);
            }
        }
        else {
            this._lastReadyStatus = currentState;
        }
    }
    catch (e) {
        this._SendFailed(2001, e);
    }
}

WebTicketConnection.prototype._SendFailed = function (errorCode, exception) {
    this._isInUse = false;
    this.StopTimer();
    try {
        this._requestOwner._OnError(errorCode, exception);
    }
    catch (e) {
        ShowException("WebTicketConnection._SendFailed:" + e.toString());
    }
}

WebTicketConnection.prototype._SendSuccess = function () {
    this._isInUse = false;
    this.StopTimer();
    try {
        this._requestOwner._OnSuccess();
    }
    catch (e) {
        ShowException("WebTicketConnection._SendSuccess:" + e.toString());
    }
}

//Create xmlhttprequest object 
WebTicketConnection.prototype._CreateXMLHttpRequestObject = function () {
    try {
        var httpRequest = null;

        if (window.XMLHttpRequest) // for none IE browsers
        {
            httpRequest = new XMLHttpRequest();
        }
        else if (window.ActiveXObject) // for IE
        {
            var MSXML_XMLHTTP_PROGIDS = new Array(
                            'Microsoft.XMLHTTP',
                            'MSXML2.XMLHTTP.5.0',
                            'MSXML2.XMLHTTP.4.0',
                            'MSXML2.XMLHTTP.3.0',
                            'MSXML2.XMLHTTP'
                            );

            for (var i = 0; i < MSXML_XMLHTTP_PROGIDS.length; i++) {
                httpRequest = new ActiveXObject(MSXML_XMLHTTP_PROGIDS[i]);

                if (httpRequest != null) {
                    break;
                }
            }
        }

        if (!httpRequest) {
            //TODO: Add Error treat here
            throw new ConnectionException("Can not create a XmlHttpRequest Object!");
        }

        return httpRequest;
    }
    catch (e) {
        throw new ConnectionException("Can not create a XmlHttpRequest Object: " + e.toString());
    }
}

////////////////////////////////////////////////////////////////////////////////
// MsDiagHeader

function MsDiagHeader() {
}

MsDiagHeader.prototype.ErrorId = function (code) {
    if (code != undefined) {
        this._errorId = code;
    }

    return this._errorId;
}

MsDiagHeader.prototype.DisplayName = function (displayName) {
    if (displayName != undefined) {
        this._displayName = displayName;
    }

    return this._displayName;
}

MsDiagHeader.prototype.MemberName = function (memberName) {
    if (memberName != undefined) {
        this._memberName = memberName;
    }

    return this._memberName;
}


MsDiagHeader.prototype.parse = function (headerValue) {
    /// <param name="headerValue" type="String"/>
    /// <returns type="MsDiagHeader"/>
    var DisplayNameLabel = 'displayName=';
    var MemberNameLabel = 'memberName=';

    this.DisplayName = null;
    this.MemberName = null;
    this.ErrorId = "0";

    var errorCodeFound = false;
    var parts = this._splitParams(headerValue);
    for (var i = 0; i < parts.length; i++) {
        var part = parts[i];
        if (!errorCodeFound) {
            this.ErrorId = part;
            errorCodeFound = true;
        }
        else {
            var subStr = part.substring(0, DisplayNameLabel.length);
            if (subStr == DisplayNameLabel) {
                this.DisplayName = this._dequote(part, DisplayNameLabel.length, part.length - DisplayNameLabel.length);
            }
            else {
                subStr = part.substring(0, MemberNameLabel.length);
                if (subStr == MemberNameLabel) {
                    this.MemberName = this._dequote(part, MemberNameLabel.length, part.length - MemberNameLabel.length);
                }
            }
        }
    }
}

MsDiagHeader.prototype._splitParams = function (value) {
    /// <summary>
    /// Multiple headers parameters are semicolon separated.  This method
    /// returns a list of parameters, taking into consideration quoted strings.
    /// </summary>
    var headerList = [];
    var next = 0;
    while (next < value.length) {
        var semi = this._findUnquoted(value, next, ';');
        if (semi > next) {
            var token = value.substr(next, semi - next);
            headerList.push(token);
        }
        else {
            token = value.substr(next);
            headerList.push(token);
            break;
        }
        next = semi + 1;
    }
    return headerList;
}

MsDiagHeader.prototype._findUnquoted = function (str, start, delim) {
    /// <summary>
    /// Returns the location of delim, accounting for quoted strings.
    /// </summary>
    var index = start;
    var endQuote = ' ';
    var prev = ' ';
    while (index < str.length) {
        var ch = str.charAt(index);
        if (endQuote === ' ') {
            if (prev !== '\\') {
                if (ch === delim) {
                    return index;
                }
                else {
                    switch (ch) {
                        case '"':
                            endQuote = '"';
                            break;
                        case '<':
                            endQuote = '>';
                            break;
                    }
                }
            }
            else {
                ch = ' ';
            }
        }
        else if (prev !== '\\') {
            if (endQuote === ch) {
                endQuote = ' ';
            }
        }
        prev = ch;
        index++;
    }
    return -1;
}

MsDiagHeader.prototype._dequote = function (quotedString, offset, length) {
    /// <summary>
    /// This method converts a supplied quoted string to a non-quoted string. This
    /// process removes the leading and trailing DQUOTE (") and removes \ from \\ and \"
    /// sequences.
    /// </summary>
    if (quotedString == null) {
        return '';
    }
    var friendlyValue = '';
    var prevWasBackslash = false;
    var end = (length + offset) - 1;
    for (var i = offset; i <= end; i++) {
        var nextChar = quotedString.charAt(i);
        if (prevWasBackslash) {
            friendlyValue += nextChar;
            prevWasBackslash = false;
        }
        else if (nextChar === '\\') {
            prevWasBackslash = true;
        }
        else {
            if ((i === offset) || (i === end)) {
                if (nextChar !== '"') {
                    friendlyValue += nextChar;
                }
            }
            else {
                friendlyValue += nextChar;
            }
        }
    }
    return friendlyValue;
}

// EOF
