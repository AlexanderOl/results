//------------------------------------------------------------------------------
// PinForm page related Javascript code
//
//------------------------------------------------------------------------------

var nTimeout = 15 * 60000; //15 minutes
var nMaxPinLength = 24; // Maximum allowed length for user Pin

var ClientStatus = new Object( );
ClientStatus.Anonymous = 1;
ClientStatus.LoggedIn = 2; //Normal form after login
ClientStatus.IwaOrWsFedLogin = 3;
ClientStatus.FormLogin = 4;
ClientStatus.ChangePin = 5;
ClientStatus.ResetConf = 6;
ClientStatus.PhoneNotConfig = 7;
ClientStatus.PinNotConfigured = 8;

var authToUse = AuthenticationType.None;
var originalAuthToUse = AuthenticationType.None;

var ResponseStatus = new Object( );
ResponseStatus.Empty = 0;
ResponseStatus.Exception = 1;
ResponseStatus.PinEnabled = 2;
ResponseStatus.PinNotAvailble = 3;
ResponseStatus.PinLocked = 4;
ResponseStatus.PinExpired = 5;

ResponseStatus.PinDisabled = 6;
ResponseStatus.UserDoesNotExist = 7;
ResponseStatus.RequestMalformed = 8;
ResponseStatus.UnAuthorized = 9;
ResponseStatus.OtherFailure = 10;

ResponseStatus.CertificateNotAvailable = 11;
ResponseStatus.InvalidePin = 12;
ResponseStatus.PinChanged = 13;

ResponseStatus.PinUnlocked = 14;

ResponseStatus.ConferenceInfoAvailable = 15;
ResponseStatus.Wave13User = 16;

ResponseStatus.PhoneNotConfig = 17;
ResponseStatus.BadPin = 18;

ResponseStatus.InvalidPinNumericOnly = 19;
ResponseStatus.InvalidPinConsecutiveDigits = 20;
ResponseStatus.InvalidPinRepeatingDigit = 21;
ResponseStatus.InvalidPinMinimumLength = 22;
ResponseStatus.InvalidPinMaximumLength = 23;
ResponseStatus.InvalidPinHistory = 24;
ResponseStatus.InvalidPinPhone = 25;

ResponseStatus.PublicMeetingNotAllowed = 26;
ResponseStatus.AccountGloballyLockedOut = 27;

ResponseStatus.Wave12User = 28;

var ResponseSubStatus = new Object( );
ResponseSubStatus.Empty = 0;
ResponseSubStatus.UsePhoneExtension = 1;
ResponseSubStatus.UsePhone = 2;
ResponseSubStatus.OtherFailure = 3;

var _DialHandlerUrl = "/dialin/pin/DialinHandler.ashx";
var _ResourceUrl = "/dialin/client/DialinResource.aspx?ResourceLang=";
var _requestsHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
var _requestsShell = "<cwaRequests xmlns=\"http://schemas.microsoft.com/2006/09/rtc/cwa\">%0\n\r</cwaRequests>";
var _GetConfInfoCommand = "<DialinCommand Type=\"GetConferenceInformation\" />";
var _GetUserPinInfoCommand = "<DialinCommand Type=\"GetUserPinInformation\" LogonData=\"%0\" />";
var _ResetUserPinInfoCommand = "<DialinCommand Type=\"ResetUserPinInformation\" Pin=\"%0\" />";
var _UnlockUserPinInfoCommand = "<DialinCommand Type=\"UnlockUserPinInformation\" />";
var _ResetConfInfoCommand = "<DialinCommand Type=\"ResetConferenceInformation\" />";

var ActiveObjectEnum = new Object( );
ActiveObjectEnum.UserPin = 0;
ActiveObjectEnum.Conference = 1;

var UserPinPanelEnum = new Object( );
UserPinPanelEnum.Normal = 0;
UserPinPanelEnum.Expired = 1;
UserPinPanelEnum.Locked = 2;
UserPinPanelEnum.PhoneNotConfigured = 3;

var RequestInProgress = new Object( );
RequestInProgress.None = 0;
RequestInProgress.UnlockPin = 1;
RequestInProgress.UpdateResource = 2;
RequestInProgress.SendResetConf = 3;
RequestInProgress.SendNewPin = 4;
RequestInProgress.GetUserPinInfo = 5;
RequestInProgress.GetConferenceInfo = 6;

var availableAuthTypes = Object();

function UserData()
{
    this.Uri = null;
    this.UserName = null;
    this.SignInAs = null;
    this.Language = null;
    this.WebTicket = null;
    
    this.Status = ClientStatus.Anonymous;
    this.ActiveObject = ActiveObjectEnum.UserPin;
    this.UserPinPanel = UserPinPanelEnum.Normal;
}

function MainForm()
{
    this.connection = null;
    this.dataUser = null;
    this.nTimeoutID = 0;
    this.webTicketManager = null;
    this.RequestInProgress = RequestInProgress.None;
}

MainForm.prototype.ResetTimer = function( )
{
    if(this.nTimeoutID != 0)
    {
        window.clearTimeout(this.nTimeoutID);
        this.nTimeoutID = 0;
    }
        
    this.nTimeoutID = window.setTimeout(this.SignOut, nTimeout);    
}

MainForm.prototype.InitForm = function(data) {
    // Javascript is enabled,
    // un-hide the outerDiv
    // so all content will be shown.
    document.getElementById("outerDiv").style.display = "block";
    
    // Hide the Sign-in button on the initial page
    // until we hear back from the WebTicketManager
    // about the authentication methods supported
    // by the Server and can decide whether to show
    // the user IWA or Forms sign-in page.
    this.btnSignIn = document.getElementById("btnSignIn");    
    this.btnSignIn.style.display = "none";
    
    // Initialize the WebTicketManager.
    this.webTicketManager = new WebTicketManager();
    var server = document.location.host;
    if (document.location.protocol == "http" && document.location.port != 80) {
        server += ":" + document.location.port;
    }
    else if (document.location.protocol == "https" && document.location.port != 443) {
        server += ":" + document.location.port;       
    }
    this.webTicketManager.WebTicketServiceUri("https://" + server + "/webticket/webticketservice.svc");

    try {
        this.webTicketManager.Initialize(Delegate(this, this.AuthTypesReceived));
    }
    catch (e) {
        this.ShowErrorMessage(msgOperationFailed);
    }

    this.pinForm = document.getElementById("pinForm");
    this.confForm = document.getElementById("confForm");
    this.phoneForm = document.getElementById("phoneForm");
    this.dtmfCommandsForm = document.getElementById("dtmfCommandsForm");

    this.pinBasicForm = document.getElementById("pinBasicForm");
    this.pinInfoForm = document.getElementById("pinInfoForm");
    this.pinLockForm = document.getElementById("pinLockForm");
    this.pinExpForm = document.getElementById("pinExpForm");

    this.signinForm = document.getElementById("signinForm");
    this.txtSignInDiff = document.getElementById("txtSignInDiff");
    this.usrInfoPanel = document.getElementById("usrInfoPanel");
    this.submitButtonPanel = document.getElementById("submitButtonPanel");
    this.signInDiffAccountPanel = document.getElementById("signInDiffAccountPanel");
    this.thirdColumnHeader = document.getElementById("thirdColumnHeader");
    this.txtDTMFCommandDescription = document.getElementById("txtDTMFCommandDescription");        
    this.signIwaOrWsFedForm = document.getElementById("signIwaOrWsFedForm");
    this.newPinForm = document.getElementById("newPinForm");
    this.resetConfirmForm = document.getElementById("resetConfirmForm");

    this.fldUserName = document.getElementById("fldUserName");
    this.fldPassword = document.getElementById("fldPassword");
    this.trPassword = document.getElementById("trPassword");

    //This will cause exception in firefox
    //this.fldPassword.size = fldUserName.size; //fldPassword may have different size in IE6

    this.sltLang = document.getElementById("sltLang");
    this.sltLangIWA = document.getElementById("sltLangIWA");

    this.basicError = document.getElementById("basicError");
    this.spanUserID = document.getElementById("spanUserID");
    this.iwaError = document.getElementById("iwaError");
    this.formError = document.getElementById("formError");
    this.pinError = document.getElementById("pinError");
    this.spnExpiredInDays = document.getElementById("spnExpiredInDays");
    this.spnPinDays = document.getElementById("txtPINDays");
    this.spnPhoneCleanNumber = document.getElementById("spnPhoneCleanNumber");
    this.spnPhoneExtensionNumber = document.getElementById("spnPhoneExtensionNumber");
    this.fldPin = document.getElementById("fldPin"); ;
    this.fldPin2 = document.getElementById("fldPin2"); ;
    this.confMessage = document.getElementById("confMessage");
    this.txtConfNotes = document.getElementById("txtConfNotes");
    this.txtNewPINDesc = document.getElementById("txtNewPINDesc");
    this.pinMessage = document.getElementById("pinMessage");
    this.pinPhoneOrExtensionMessage = document.getElementById("pinPhoneOrExtensionMessage");
    this.tdPhoneConferenceID = document.getElementById("tdPhoneConferenceID");
    this.tdMeetingURL = document.getElementById("tdMeetingURL");
    this.txtBasicFormHeader = document.getElementById("txtBasicFormHeader");
    this.imgLogo = document.getElementById("imgLogo");
    this.pnlChangePin = document.getElementById("pnlChangePin");
    this.pnlResetConf = document.getElementById("pnlResetConf");
    this.txtPhoneConferenceIDDesc = document.getElementById("txtPhoneConferenceIDDesc");
    this.txtMeetingURL = document.getElementById("txtMeetingURL");
    this.txtConfResetButton = document.getElementById("txtConfResetButton");
    this.txtConfDesc = document.getElementById("txtConfDesc");
    this.txtResetConfDesc = document.getElementById("txtResetConfDesc");

    this.rowDTMFCommandMuteUnmuteSelf = document.getElementById("rowDTMFCommandMuteUnmuteSelf");
    this.tdDTMFCommandMuteUnmuteSelf = document.getElementById("tdDTMFCommandMuteUnmuteSelf");
    this.txtDTMFCommandMuteUnmuteSelf = document.getElementById("txtDTMFCommandMuteUnmuteSelf");

    this.rowDTMFCommandMuteUnmuteAll = document.getElementById("rowDTMFCommandMuteUnmuteAll");
    this.tdDTMFCommandMuteUnmuteAll = document.getElementById("tdDTMFCommandMuteUnmuteAll");
    this.txtDTMFCommandMuteUnmuteAll = document.getElementById("txtDTMFCommandMuteUnmuteAll");

    this.rowDTMFCommandLockUnlockConference = document.getElementById("rowDTMFCommandLockUnlockConference");
    this.tdDTMFCommandLockUnlockConference = document.getElementById("tdDTMFCommandLockUnlockConference");
    this.txtDTMFCommandLockUnlockConference = document.getElementById("txtDTMFCommandLockUnlockConference");

    this.rowDTMFCommandEnableDisableAnnouncements = document.getElementById("rowDTMFCommandEnableDisableAnnouncements");
    this.tdDTMFCommandEnableDisableAnnouncements = document.getElementById("tdDTMFCommandEnableDisableAnnouncements");
    this.txtDTMFCommandEnableDisableAnnouncements = document.getElementById("txtDTMFCommandEnableDisableAnnouncements");

    this.rowDTMFCommandRollCall = document.getElementById("rowDTMFCommandRollCall");
    this.tdDTMFCommandRollCall = document.getElementById("tdDTMFCommandRollCall");
    this.txtDTMFCommandRollCall = document.getElementById("txtDTMFCommandRollCall");

    this.rowDTMFCommandHelp = document.getElementById("rowDTMFCommandHelp");
    this.tdDTMFCommandHelp = document.getElementById("tdDTMFCommandHelp");
    this.txtDTMFCommandHelp = document.getElementById("txtDTMFCommandHelp");

    this.rowDTMFCommandAdmitAll = document.getElementById("rowDTMFCommandAdmitAll");
    this.tdDTMFCommandAdmitAll = document.getElementById("tdDTMFCommandAdmitAll");
    this.txtDTMFCommandAdmitAll = document.getElementById("txtDTMFCommandAdmitAll");

    this.txtDTMFNote = document.getElementById("txtDTMFNote");
    
    this.unlockPinButton = document.getElementById("unlockPinButton");
    this.txtNewPinCancelButton = document.getElementById("txtNewPinCancelButton");

    this.dataUser = data;

    this.connection = new Connection();
    this.connection.Initialize(this);
    this.spanUserID.innerHTML = "";
    this.tdPhoneConferenceID.innerHTML = "";
    this.tdMeetingURL.innerHTML = "";
    this.ClearAllMessage();
    this.SetSelectedLanguage(this.sltLang, sCurrentLang);
    this.SetSelectedLanguage(this.sltLangIWA, sCurrentLang);
    this.UpdateResource(sCurrentLang);
    this.userNameTips = ""; //set default value
}

/// <summary>
/// Retrieve the parameter value from the URL
/// Used to retrieve Rps Cookie Name value
/// </summary>
function GetParamValue(name) {
    var paramValue = "";
    try {
        var qString = window.location.search;
        if (qString.length > 1 && qString.charAt(0) == '?') {
            qString = qString.substr(1);
            qStringList = qString.split('&');
            var queryParam = "";
            for (i = 0; i < qStringList.length; i++) {
                if (qStringList[i].search(name) >= 0) {
                    queryParam = qStringList[i];
                    break;
                }
            }
            if (queryParam.length > 0) {
                paramValue = queryParam.split('=')[1];
            }
        }
    }
    catch (e) {
        // unexpected exception; would never happen
    }

    return paramValue;
}

MainForm.prototype.AuthTypesReceived = function (authTypes, exception) {

    availableAuthTypes = authTypes;

    if (availableAuthTypes == null && exception != null) {
        // Failed to get server supported auth types
        this.ShowErrorMessage(msgOperationFailed);
        return;
    }
    else if (availableAuthTypes != null && exception == null) {

        // If both Server and Client support IWA
        // and this is the Internal website, use IWA.
        if (availableAuthTypes.Get(AuthenticationType.IWA) == true && sIsExternal.toLowerCase() == "false") {
            if (this.isBrowserIWACapable()) {
                authToUse = AuthenticationType.IWA;
            }
        }
        // If server supports WsFed - Passive Auth
        else if (availableAuthTypes.Get(AuthenticationType.WsFedPassive) == true) {
            var cookieName = GetParamValue("AuthCookieName");

            // We know about RPS cookie
            if (cookieName.length > 0) {
                this.AuthTypeUsed = AuthenticationType.WsFedPassive;
                this.webTicketManager.AcquireTicketForDuration(AuthenticationType.WsFedPassive, null, nTimeout, Delegate(this, this.AcquireTicketCallback));
            }
            
            authToUse = AuthenticationType.WsFedPassive;
        }
        // If Server supports Forms auth, and nothing else use that
        else if (availableAuthTypes.Get(AuthenticationType.Forms) == true) {
            authToUse = AuthenticationType.Forms;
        }
    }
    else {
        this.ShowErrorMessage(msgOperationFailed);
        return;
    }

    if (authToUse == AuthenticationType.IWA ||
        authToUse == AuthenticationType.WsFedPassive) {

        this.trPassword.style.display = "none"; //don't show password for IWA
        this.userNameTips = msgIWAUserNameTips;
        
        // Un-hide the Sign-in button on the initial page
        // now that we know which authentication method to
        // give this user.
        this.btnSignIn.style.display = "";

        var altAuthMethodEnabled = false;

        if (authToUse == AuthenticationType.IWA && 
            (availableAuthTypes.Get(AuthenticationType.Forms) == true
            || availableAuthTypes.Get(AuthenticationType.WsFedPassive) == true)) {
            altAuthMethodEnabled = true;
        }

        // If Forms or WsFed authentication is available, enable the
        // "Sign-in as a different user" prompt, otherwise
        // remove it to not confuse the user
        if (!altAuthMethodEnabled) {
            txtSignInDiff.style.display = "none";
        }
        else {
            txtSignInDiff.style.display = "";
        }
    }
    else if (authToUse == AuthenticationType.Forms) {
        this.userNameTips = msgFormUserNameTips;
        
        // Un-hide the Sign-in button on the initial page
        // now that we know which authentication method to
        // give this user.
        this.btnSignIn.style.display = "";
    }
    else // AuthenticationType.None
    {
        this.btnSignIn.style.display = "none";
        this.txtBasicFormHeader.style.display = "none";
        this.ShowErrorMessage(msgAuthNotSupport);
    }

    this.fldUserName.title = this.userNameTips;
    this.fldUserName.value = this.userNameTips;

    this.DisplayForm();
}

MainForm.prototype.isBrowserIWACapable = function () {
    /* Browser Related Constants */
    var INTERNET_EXPLORER = "Microsoft Internet Explorer";
    var INTERNET_EXPLORER_11 = "Microsoft Internet Explorer 11+";
    var FIREFOX = "FireFox";
    var SAFARI = "Safari";
    var CHROME = "Chrome";

    /* OS Related Constants */
    var WINDOWS = "Windows";
    var MAC = "Mac";
    var LINUX = "Linux";
        
    var browserName="";           // Browser Name INTERNET_EXPLORER, FIREFOX, SAFARI
    var browserVersion = 0.0;     // Broswer Version x.x
    var osName="";                // Operating System Name WINDOWS, MAC, LINUX
    var osVersion = 0.0;          // Operating System Version x.x

    /* Browser Detection */
    if (/Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
        browserName = FIREFOX;
        browserVersion = RegExp.$1;
    } else if (/MSIE (\d+\.\d+)/.test(navigator.userAgent)) { //IE 10.0 and below
        browserName = INTERNET_EXPLORER;
        browserVersion = RegExp.$1;
    } else if (/Mozilla\/(\d+\.\d+)/.test(navigator.userAgent)) { //IE 11 and above
        browserName = INTERNET_EXPLORER_11;
        browserVersion = RegExp.$1;
    } else if (/Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent)) {
        browserName = SAFARI;
        if (/Version[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
            browserVersion = RegExp.$1;
        }
    }
      else if(/Chrome[\/\s](\d+\.\d+)/.test(navigator.userAgent)) {
        browserName = CHROME;
        browserVersion = RegExp.$1;
    }

    /* OS Detection */
    if (/Windows NT (\d+\.\d+)/.test(navigator.userAgent)) {
        osName = WINDOWS;
        osVersion = RegExp.$1;
    } else if (/Intel Mac OS X/.test(navigator.userAgent)) {
        osName = MAC;
        if(/Intel Mac OS X (\d+\.\d+)/.test(navigator.userAgent)){
            osVersion = RegExp.$1;
            if(/Intel Mac OS X (\d+\.\d+\.\d+)/.test(navigator.userAgent)){
                osVersion = RegExp.$1;
            }
        } else if(/Intel Mac OS X (\d+\_\d+)/.test(navigator.userAgent)){
            osVersion = (RegExp.$1).replace('_', '.');
            if(/Intel Mac OS X (\d+\_\d+\_\d+)/.test(navigator.userAgent)) {
                osVersion = RegExp.$1.replace('_', '.');
            }
        }
    } else if (navigator.userAgent.indexOf('Linux') >= 0) {
        osName = LINUX;
        //TODO: version
    }
    
    if ((osName == WINDOWS) &&
        ((browserName == INTERNET_EXPLORER_11 && browserVersion >= 5.0) ||
        (browserName == INTERNET_EXPLORER && browserVersion >= 6.0) ||
        (browserName == FIREFOX && browserVersion >= 3.5)) ||
        (browserName == CHROME && browserVersion >= 8.0))
    {
        // This browser can do IWA auth.
        return true;
    }
    
    // All other browsers can NOT do IWA auth.
    return false;    
}

MainForm.prototype.DisplayForm = function () {
    // if pin auth is disabled in DialinConferencingConfiguration
    // we will show phone numbers and dtmf commands only
    var isPinAuthEnabled = sIsPinAuthEnabled.toLowerCase();
    if (isPinAuthEnabled == "false") {
        ShowForm(this.pinForm, false);
        ShowForm(this.confForm, false);
        ShowForm(this.phoneForm, true);

        this.SetDTMFCommandsInfo();
        ShowForm(this.dtmfCommandsForm, true);

        ShowForm(this.pinBasicForm, false);
        ShowForm(this.pinInfoForm, false);
        ShowForm(this.pinLockForm, false);
        ShowForm(this.pinExpForm, false);

        ShowForm(this.signinForm, false);
        ShowForm(this.usrInfoPanel, false);
        ShowForm(this.signIwaOrWsFedForm, false);
        ShowForm(this.newPinForm, false);
        ShowForm(this.resetConfirmForm, false);
        return;
    }

    switch (this.dataUser.Status) {
        case ClientStatus.Anonymous:
            ShowForm(this.pinForm, true);
            ShowForm(this.confForm, false);
            ShowForm(this.phoneForm, true);

            this.SetDTMFCommandsInfo();
            ShowForm(this.dtmfCommandsForm, true);

            ShowForm(this.pinBasicForm, true);
            ShowForm(this.pinInfoForm, false);
            ShowForm(this.pinLockForm, false);
            ShowForm(this.pinExpForm, false);

            ShowForm(this.signinForm, false);
            ShowForm(this.usrInfoPanel, false);
            ShowForm(this.signIwaOrWsFedForm, false);
            ShowForm(this.newPinForm, false);
            ShowForm(this.resetConfirmForm, false);
            break;
        case ClientStatus.IwaOrWsFedLogin:
            ShowForm(this.pinForm, false);
            ShowForm(this.confForm, false);
            ShowForm(this.phoneForm, false);
            ShowForm(this.dtmfCommandsForm, false);

            ShowForm(this.pinBasicForm, false);
            ShowForm(this.pinInfoForm, false);
            ShowForm(this.pinLockForm, false);

            ShowForm(this.signinForm, false);
            ShowForm(this.usrInfoPanel, false);
            ShowForm(this.signIwaOrWsFedForm, true);
            ShowForm(this.newPinForm, false);
            ShowForm(this.resetConfirmForm, false);
            break;
        case ClientStatus.FormLogin:
            ShowForm(this.pinForm, false);
            ShowForm(this.confForm, false);
            ShowForm(this.phoneForm, false);
            ShowForm(this.dtmfCommandsForm, false);

            ShowForm(this.pinBasicForm, false);
            ShowForm(this.pinInfoForm, false);
            ShowForm(this.pinLockForm, false);

            ShowForm(this.signinForm, true);
            ShowForm(this.usrInfoPanel, false);
            ShowForm(this.signIwaOrWsFedForm, false);
            ShowForm(this.newPinForm, false);
            ShowForm(this.resetConfirmForm, false);
            break;
        case ClientStatus.LoggedIn:
            ShowForm(this.pinForm, true);
            ShowForm(this.confForm, true);
            ShowForm(this.phoneForm, true);

            this.SetDTMFCommandsInfo();
            ShowForm(this.dtmfCommandsForm, true);

            ShowForm(this.pinBasicForm, false);
            switch (this.dataUser.UserPinPanel) {
                case UserPinPanelEnum.Expired:
                    ShowForm(this.pinInfoForm, false);
                    ShowForm(this.pinLockForm, false);
                    ShowForm(this.pinExpForm, true);
                    break;
                case UserPinPanelEnum.Locked:
                    ShowForm(this.pinInfoForm, false);
                    ShowForm(this.pinLockForm, true);
                    ShowForm(this.pinExpForm, false);
                    break;
                case UserPinPanelEnum.PhoneNotConfigured:
                    ShowForm(this.pinInfoForm, false);
                    ShowForm(this.pinLockForm, false);
                    ShowForm(this.pinExpForm, false);
                    break;
                default:
                    ShowForm(this.pinInfoForm, true);
                    ShowForm(this.pinLockForm, false);
                    ShowForm(this.pinExpForm, false);
                    break;
            }

            ShowForm(this.signinForm, false);
            ShowForm(this.usrInfoPanel, true);
            ShowForm(this.signIwaOrWsFedForm, false);
            ShowForm(this.newPinForm, false);
            ShowForm(this.resetConfirmForm, false);
            break;
        case ClientStatus.ChangePin:
        case ClientStatus.PinNotConfigured:
            ShowForm(this.pinForm, false);
            ShowForm(this.confForm, false);
            ShowForm(this.phoneForm, false);
            ShowForm(this.dtmfCommandsForm, false);

            ShowForm(this.pinBasicForm, false);
            ShowForm(this.pinInfoForm, false);
            ShowForm(this.pinLockForm, false);

            ShowForm(this.signinForm, false);
            ShowForm(this.usrInfoPanel, true);
            ShowForm(this.signIwaOrWsFedForm, false);
            ShowForm(this.newPinForm, true);
            ShowForm(this.resetConfirmForm, false);
            break;
        case ClientStatus.ResetConf:
            ShowForm(this.pinForm, false);
            ShowForm(this.confForm, false);
            ShowForm(this.phoneForm, false);
            ShowForm(this.dtmfCommandsForm, false);

            ShowForm(this.pinBasicForm, false);
            ShowForm(this.pinInfoForm, false);
            ShowForm(this.pinLockForm, false);

            ShowForm(this.signinForm, false);
            ShowForm(this.usrInfoPanel, true);
            ShowForm(this.signIwaOrWsFedForm, false);
            ShowForm(this.newPinForm, false);
            ShowForm(this.resetConfirmForm, true);
            break;
    }
}

MainForm.prototype.ChangePin = function( )
{
    this.ResetTimer( );
    this.dataUser.Status = ClientStatus.ChangePin;
    this.fldPin.value = "";
    this.fldPin2.value = "";
    this.ClearMessage(); //for the change pin form
    this.DisplayForm( );
}

MainForm.prototype.UnlockPin = function( )
{
    this.dataUser.Status = ClientStatus.LoggedIn;
    this.dataUser.UserPinPanel = UserPinPanelEnum.Locked;
    this.dataUser.ActiveObject = ActiveObjectEnum.UserPin;     
    this.ClearAllMessage( );
    this.ResetTimer( );

    if (this.dataUser.WebTicket == null)
    {
        this.ShowErrorMessage(msgSessionTimout);
        return;
    }
    
    var reqUserCmd = _requestsHeader + StringFormat(_requestsShell, _UnlockUserPinInfoCommand);
    
    if (this.RequestInProgress != RequestInProgress.None)
    {
        this.ShowErrorMessage(msgRequestInProgress);
        return;
    }
    this.RequestInProgress = RequestInProgress.UnlockPin;
    window.setTimeout(TimerHandler(this.connection, this.connection.SendHttpRequest, "POST", _DialHandlerUrl, reqUserCmd, this.dataUser.WebTicket), 0);
}

MainForm.prototype.OnUnlockPinCallback = function( )
{
    var oResult = this.connection.ProcessUnlockUserPinResponse( );
    var sExpiredDays = oResult.ExpiredInDays;
    this.ClearMessage( );
    
    switch(this.connection.ResponseStatus)
    {
        case ResponseStatus.AccountGloballyLockedOut: // Force user to reset PIN
        case ResponseStatus.PinNotAvailble:
            this.dataUser.Status = ClientStatus.PinNotConfigured;
            this.fldPin.value = "";
            this.fldPin2.value = "";
            this.ClearMessage( ); //for the change pin form
            break;
        case ResponseStatus.PinUnlocked:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.ClearMessage( ); 
            if(sExpiredDays == "0")
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Expired;
            }
            else if(sExpiredDays == "-1")
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Normal;
                this.spnExpiredInDays.innerHTML = msgPinNeverExpired + " ";
                this.spnPinDays.innerHTML = "";
            }
            else
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Normal;
                this.spnExpiredInDays.innerHTML = sExpiredDays + " ";
                if(sExpiredDays == "1")
                {
                    this.spnPinDays.innerHTML = txtPINDay_res;
                }
                else
                {
                    this.spnPinDays.innerHTML = txtPINDays_res;
                }
            }
                
            this.ShowSuccessMessage(msgPinUnlockSucess);
            break;
        case ResponseStatus.PinLocked:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.dataUser.UserPinPanel = UserPinPanelEnum.Locked;
            this.ClearMessage( );
            break;
        case ResponseStatus.PinExpired:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.dataUser.UserPinPanel = UserPinPanelEnum.Expired;
            this.ClearMessage( );

            this.ShowSuccessMessage(msgPinUnlockSucess);
            break;
        default:
            // ResponseStatus.Exception will end up here.
            this.ShowErrorMessage(msgOperationFailed);
            break;
    }
}

MainForm.prototype.ResetConference = function( )
{
    this.ResetTimer( );
    this.dataUser.Status = ClientStatus.ResetConf;
    this.DisplayForm( );
}

MainForm.prototype.SignIn = function( )
{
    if (authToUse == AuthenticationType.IWA ||
        authToUse == AuthenticationType.WsFedPassive)
    {
        this.dataUser.Status = ClientStatus.IwaOrWsFedLogin;
    }
    else 
    {
        this.dataUser.Status = ClientStatus.FormLogin;
    }
    this.DisplayForm( );
}

MainForm.prototype.SignOut = function() {
    if (mainWnd.nTimeoutID != 0) {
        window.clearTimeout(mainWnd.nTimeoutID);
        mainWnd.nTimeoutID = 0;
    }

    this.RequestInProgress = RequestInProgress.None;
    
    mainWnd.dataUser.Status = ClientStatus.Anonymous;
    mainWnd.dataUser.WebTicket = null;
    mainWnd.ClearAllMessage();
    mainWnd.spanUserID.innerHTML = "";
    mainWnd.fldPassword.value = "";
    mainWnd.fldPin.value = "";
    mainWnd.fldPin2.value = "";
    mainWnd.spnExpiredInDays.innerHTML = "";
    mainWnd.spnPinDays.innerHTML = "";
    mainWnd.spnPhoneCleanNumber.innerHTML = "";
    mainWnd.spnPhoneExtensionNumber.innerHTML = "";
    mainWnd.tdPhoneConferenceID.innerHTML = "";
    mainWnd.tdMeetingURL.innerHTML = "";
    mainWnd.pinPhoneOrExtensionMessage.innerHTML = "";
    mainWnd.ClearPinPhoneOrExtentionMessage();
    mainWnd.DisplayForm();

    if (authToUse == AuthenticationType.WsFedPassive)
    {
        var cookieName = GetParamValue("AuthCookieName");

        // We know about RPS cookie if AuthCookieName is still present; invalidate the cookie
        if (cookieName.length > 0) {
            parent.window.location = this.webTicketManager.OnlineAuthPage + "?logout=1&lc=" + LcId + "&redirectUrl=" + DialInEncodedUrl;
        }
    }
    
    this.RevertToDefaultSignInMethod();

    mainWnd.EnableSignInButtons();
}

MainForm.prototype.RevertToDefaultSignInMethod = function () {
    if (originalAuthToUse == AuthenticationType.IWA &&
        (authToUse == AuthenticationType.Forms ||
         authToUse == AuthenticationType.WsFedPassive)) {
        // switch back from Forms or WsFed to IWA in case user wants to sign in again; because "Sign in as another user" was used
        authToUse = AuthenticationType.IWA;
        this.trPassword.style.display = "none";
        txtSignInDiff.style.display = "";
    }
}

MainForm.prototype.UpdateUI = function( )
{
    document.getElementById("txtDialinPageTitle").innerHTML = txtDialinPageTitle_res;
    document.getElementById("txtSignOut").innerHTML = txtSignOut_res;
    document.getElementById("txtPINTitle").innerHTML = txtPINTitle_res;
    document.getElementById("txtBasicFormHeader").innerHTML = txtBasicFormHeader_res;
    document.getElementById("txtSignIn").innerHTML = txtSignIn_res;
    document.getElementById("txtPinInfoHeader").innerHTML = txtPinInfoHeader_res;
    document.getElementById("txtPINExpiredHeader").innerHTML = txtPINExpiredHeader_res;
    document.getElementById("txtChangePIN").innerHTML = txtChangePIN_res;
    document.getElementById("txtForgotYourPin").innerHTML = txtForgotYourPin_res;
    document.getElementById("txtPINDays").innerHTML = txtPINDays_res;
    document.getElementById("txtPhoneNumber").innerHTML = txtPhoneNumber_res;
    document.getElementById("txtPhoneExtension").innerHTML = txtPhoneExtension_res;
    document.getElementById("txtPINExpireFordHeader").innerHTML = txtPINExpireFordHeader_res;
    document.getElementById("txtChangeExpiredPIN").innerHTML = txtChangeExpiredPIN_res;
    document.getElementById("txtPINUnlockedHeader").innerHTML = txtPINUnlockedHeader_res;
    document.getElementById("txtUnlockPIN").innerHTML = txtUnlockPIN_res;
    document.getElementById("txtSignInFormHeader").innerHTML = txtSignInFormHeader_res;
    document.getElementById("txtSigninDesc").innerHTML = txtSigninDesc_res;
    document.getElementById("txtLanguage").innerHTML = txtLanguage_res;
    document.getElementById("txtUserName").innerHTML = txtUserName_res;
    document.getElementById("txtPassword").innerHTML = txtPassword_res;
    document.getElementById("txtSignInButton").innerHTML = txtSignInButton_res;
    document.getElementById("txtCancelSignInButton").innerHTML = txtCancelSignInButton_res;
    document.getElementById("txtIWATitle").innerHTML = txtIWATitle_res;
    document.getElementById("txtIWAHeader").innerHTML = txtIWAHeader_res;
    document.getElementById("txtIWALanguage").innerHTML = txtIWALanguage_res;
    document.getElementById("txtIWASigninButton").innerHTML = txtIWASigninButton_res;
    document.getElementById("txtSignInDiff").innerHTML = txtSignInDiff_res;
    document.getElementById("txtBackToMainpage").innerHTML = txtBackToMainpage_res;
    document.getElementById("txtNewPINTitle").innerHTML = txtNewPINTitle_res;
    document.getElementById("imgPinExpForm").title = tooltipWarning;
    document.getElementById("imgPinLockForm").title = tooltipWarning;
    
    var pinRequirementsGeneric = txtPinRequirementsGeneric_res.replace(/%0/g, nMaxPinLength);
    document.getElementById("txtNewPINDesc").innerHTML = pinRequirementsGeneric;
    
    document.getElementById("txtNewPINLabel").innerHTML = txtNewPINLabel_res;
    document.getElementById("txtNewPINConfirm").innerHTML = txtNewPINConfirm_res;
    document.getElementById("txtNewPinSaveButton").innerHTML = txtNewPinSaveButton_res;
    document.getElementById("txtNewPinCancelButton").innerHTML = txtNewPinCancelButton_res;
    document.getElementById("txtResetConfTitle").innerHTML = txtResetConfTitle_res;
    document.getElementById("txtResetConfDesc").innerHTML = txtResetConfDesc_res;
    document.getElementById("txtResetConfPrompt").innerHTML = txtResetConfPrompt_res;
    document.getElementById("txtResetConfYesButton").innerHTML = txtResetConfYesButton_res;
    document.getElementById("txtResetConfNoButton").innerHTML = txtResetConfNoButton_res;
    document.getElementById("txtConfTitle").innerHTML = txtConfTitle_res;
    document.getElementById("txtConfDesc").innerHTML = txtConfDesc_res;
    document.getElementById("txtConfNotes").innerHTML = txtConfNotes_res;
    document.getElementById("txtPhoneConferenceIDDesc").innerHTML = txtPhoneConferenceIDDesc_res;
    document.getElementById("txtMeetingURL").innerHTML = txtMeetingURL_res;
    document.getElementById("txtConfResetButton").innerHTML = txtConfResetButton_res;
    document.getElementById("txtPhoneFormTitle").innerHTML = txtPhoneFormTitle_res;
    document.getElementById("txtPhoneFormRegion").innerHTML = txtPhoneFormRegion_res;
    document.getElementById("txtPhoneFormNumber").innerHTML = txtPhoneFormNumber_res;
    document.getElementById("txtPhoneFormLangs").innerHTML = txtPhoneFormLangs_res;
    document.getElementById("txtDTMFCommandsFormTitle").innerHTML = txtDTMFCommandsFormTitle_res;
    document.getElementById("txtDTMFCommandName").innerHTML = txtDTMFCommandName_res;
    document.getElementById("txtDTMFCommandDescription").innerHTML = txtDTMFCommandDescription_res;
    document.getElementById("txtDTMFCommandMuteUnmuteSelf").innerHTML = txtDTMFCommandMuteUnmuteSelf_res;
    document.getElementById("txtDTMFCommandMuteUnmuteAll").innerHTML = txtDTMFCommandMuteUnmuteAll_res;
    document.getElementById("txtDTMFCommandLockUnlockConference").innerHTML = txtDTMFCommandLockUnlockConference_res;
    document.getElementById("txtDTMFCommandEnableDisableAnnouncements").innerHTML = txtDTMFCommandEnableDisableAnnouncements_res;
    document.getElementById("txtDTMFCommandRollCall").innerHTML = txtDTMFCommandRollCall_res;
    document.getElementById("txtDTMFCommandHelp").innerHTML = txtDTMFCommandHelp_res;
    document.getElementById("txtDTMFCommandAdmitAll").innerHTML = txtDTMFCommandAdmitAll_res;
    document.getElementById("txtDTMFNote").innerHTML = txtDTMFNote_res;
    
    if (authToUse == AuthenticationType.IWA) {
        this.userNameTips = msgIWAUserNameTips;
    }
    else // AuthenticationType.Forms or AuthenticationType.None
    {
        // Default to Forms auth text, if we have not yet
        // determined the type of auth to use.
        this.userNameTips = msgFormUserNameTips;
    }
    this.fldUserName.title = this.userNameTips;
    this.fldUserName.value = this.userNameTips;
    
    if (textDirection)
    {
        window.document.dir = textDirection;
        this.sltLang.dir = textDirection;
        this.sltLangIWA.dir = textDirection;
        
        // Fix alignment of various items on the Page
        // based on the language chosen.
        if (textDirection.toLowerCase() == "ltr")
        {
            this.usrInfoPanel.style.textAlign="right";
            this.submitButtonPanel.style.textAlign="right";
            this.signInDiffAccountPanel.style.textAlign="right";
            this.thirdColumnHeader.style.textAlign="right";
            this.txtDTMFCommandDescription.style.textAlign="left";
        }
        else if (textDirection.toLowerCase() == "rtl")
        {
            this.usrInfoPanel.style.textAlign="left";
            this.submitButtonPanel.style.textAlign="left";
            this.signInDiffAccountPanel.style.textAlign="left";
            this.thirdColumnHeader.style.textAlign="left";
            this.txtDTMFCommandDescription.style.textAlign="right";
        }
    }
    
    if (widthInputTextFieldUsername)
    {
        this.fldUserName.style.width = widthInputTextFieldUsername;
    }
    
    // When the user chooses a different language from the dropdown
    // and we update the language of the Page, clear any error messages
    // that might have been displayed as a result of a previous action
    // by the user.  If the user were to repeat that same action now,
    // the error message will be shown in the new language chosen by the
    // user.  This is necessary since we do not keep any state of what
    // error message is displayed on the page and therefore cannot
    // automatically update it to be shown in the new language in the
    // case when the user chooses a different language and we update
    // the rest of the page to reflect this.
    this.ClearAllMessage();
}

MainForm.prototype.SetDTMFCommandsInfo = function()
{
    if (IsStringNullOrEmpty(sDTMFCmdStrMuteUnmuteSelf) == true)
    {
        // Hide the Mute/Unmute self row
        this.rowDTMFCommandMuteUnmuteSelf.style.display = "none";
    }
    else
    {
        // Un-hide the Mute/Unmute self row
        this.rowDTMFCommandMuteUnmuteSelf.style.display = "";
        
        this.tdDTMFCommandMuteUnmuteSelf.innerHTML = sDTMFCmdStrMuteUnmuteSelf;
    }
    
    if (IsStringNullOrEmpty(sDTMFCmdStrMuteUnmuteAll) == true)
    {
        // Hide the Mute/Unmute all row
        this.rowDTMFCommandMuteUnmuteAll.style.display = "none";
    }
    else
    {
        // Un-hide the Mute/Unmute all row
        this.rowDTMFCommandMuteUnmuteAll.style.display = "";
        
        this.tdDTMFCommandMuteUnmuteAll.innerHTML = sDTMFCmdStrMuteUnmuteAll;
    }
    
    if (IsStringNullOrEmpty(sDTMFCmdStrLockUnlockConference) == true)
    {
        // Hide the Lock/unlock conference row
        this.rowDTMFCommandLockUnlockConference.style.display = "none";
    }
    else
    {
        // Un-hide the Lock/unlock conference row
        this.rowDTMFCommandLockUnlockConference.style.display = "";
        
        this.tdDTMFCommandLockUnlockConference.innerHTML = sDTMFCmdStrLockUnlockConference;
    }
    
    if (IsStringNullOrEmpty(sDTMFCmdStrEnableDisableAnnouncements) == true)
    {
        // Hide the Enable/disable announcements row
        this.rowDTMFCommandEnableDisableAnnouncements.style.display = "none";
    }
    else
    {
        // Un-hide the Enable/disable announcements row
        this.rowDTMFCommandEnableDisableAnnouncements.style.display = "";
        
        this.tdDTMFCommandEnableDisableAnnouncements.innerHTML = sDTMFCmdStrEnableDisableAnnouncements;
    }
    
    if (IsStringNullOrEmpty(sDTMFCmdStrRollCall) == true)
    {
        // Hide the Roll call row
        this.rowDTMFCommandRollCall.style.display = "none";
    }
    else
    {
        // Un-hide the Roll call row
        this.rowDTMFCommandRollCall.style.display = "";
        
        this.tdDTMFCommandRollCall.innerHTML = sDTMFCmdStrRollCall;
    }
    
    if (IsStringNullOrEmpty(sDTMFCmdStrHelp) == true)
    {
        // Hide the Help row
        this.rowDTMFCommandHelp.style.display = "none";
    }
    else
    {
        // Un-hide the Help row
        this.rowDTMFCommandHelp.style.display = "";
        
        this.tdDTMFCommandHelp.innerHTML = sDTMFCmdStrHelp;
    }
    
    if (IsStringNullOrEmpty(sDTMFCmdStrAdmitAll) == true)
    {
        // Hide the Admit All row
        this.rowDTMFCommandAdmitAll.style.display = "none";
    }
    else
    {
        // Un-hide the Admit All row
        this.rowDTMFCommandAdmitAll.style.display = "";
        
        this.tdDTMFCommandAdmitAll.innerHTML = sDTMFCmdStrAdmitAll;
    }
}

MainForm.prototype.SetPublicMeetingNotAllowedInfo = function()
{
    // Hide both the Phone Conference ID and the Meeting URL.
    var sPhoneConferenceID = "";
    var sMeetingURL = "";
    
    this.SetPublicMeetingInfo(sPhoneConferenceID, sMeetingURL);
    
    // Hide the Public Meeting reset link.
    this.txtConfResetButton.style.display = "none";
}

MainForm.prototype.SetPublicMeetingInfo = function(sPhoneConferenceID, sMeetingURL)
{
    if (IsStringNullOrEmpty(sPhoneConferenceID) == true)
    {
        // Hide the Phone Conference ID.
        this.txtPhoneConferenceIDDesc.style.display = "none";
        this.tdPhoneConferenceID.style.display = "none";
        
        // Update the various text to NOT talk about
        // the Phone Conference.
        this.txtConfDesc.innerHTML = txtConfDescPSTNDisabled_res;
        this.txtResetConfDesc.innerHTML = txtResetConfDescPSTNDisabled_res;

        // Hide the Notes text at the bottom
        // since it is applicable only to Phone
        // conferences.
        this.txtConfNotes.style.display = "none";
    }
    else
    {
    	// Un-hide the Phone Conference ID.
    	this.txtPhoneConferenceIDDesc.style.display = "";
        this.tdPhoneConferenceID.style.display = "";
        
        this.tdPhoneConferenceID.innerHTML = sPhoneConferenceID;
        
        // Update the various text to talk about
        // the Phone Conference.
        this.txtConfDesc.innerHTML = txtConfDesc_res;
        this.txtResetConfDesc.innerHTML = txtResetConfDesc_res;
        
        // Un-hide the Notes text at the bottom.
        this.txtConfNotes.style.display = "";
    }
    
    if (IsStringNullOrEmpty(sMeetingURL) == true)
    {
        // Hide the Meeting URL.
        this.txtMeetingURL.style.display = "none";
        this.tdMeetingURL.style.display = "none";
    }
    else
    {
    	// Un-hide the Meeting URL.
        this.txtMeetingURL.style.display = "";
        this.tdMeetingURL.style.display = "";
        
        this.tdMeetingURL.innerHTML = sMeetingURL;
    }
    
    // Make sure we un-hide the Public Meeting reset link.
    this.txtConfResetButton.style.display = "";
}

MainForm.prototype.HidePublicMeetingDetails = function()
{
    // Hide the Phone Conference ID.
    this.txtPhoneConferenceIDDesc.style.display = "none";
    this.tdPhoneConferenceID.style.display = "none";
        
    // Hide the Meeting URL.
    this.txtMeetingURL.style.display = "none";
    this.tdMeetingURL.style.display = "none";
}
                
MainForm.prototype.SetPinComplexityRequirementsText = function(sMinPinLength, sAllowCommonPatterns, sHistoryCount)
{
    var complexityText = "";
    
    var lenText = txtPinRequirementsLen_res.replace(/%0/g, sMinPinLength);
    lenText = lenText.replace(/%1/g, nMaxPinLength);
    
    complexityText = txtPinRequirementsBegin_res
                        + "<br>&nbsp; &nbsp; &nbsp; &nbsp;" + lenText
                        + "<br>&nbsp; &nbsp; &nbsp; &nbsp;" + txtPinRequirementsAllowedCharacters_res;
      
    if (sAllowCommonPatterns.toLowerCase() != "true") 
    {
        complexityText = complexityText
                            + "<br>&nbsp; &nbsp; &nbsp; &nbsp;" + txtPinRequirementsCommonPatterns_res;
    }
    if (sHistoryCount > 0)
    {
        var historyText = txtPinRequirementsHistory_res.replace(/%0/g, sHistoryCount);
        
        complexityText = complexityText
                            + "<br>&nbsp; &nbsp; &nbsp; &nbsp;" + historyText;
    }
    complexityText = complexityText
                            + "<br>" + txtPinRequirementsEnd_res;
    
    this.txtNewPINDesc.innerHTML = complexityText;
}

MainForm.prototype.UpdateResource = function(sLang)
{
    if (this.RequestInProgress != RequestInProgress.None)
    {
        this.ShowErrorMessage(msgRequestInProgress);
        return;
    }
    sCurrentLang = sLang;
    this.RequestInProgress = RequestInProgress.UpdateResource;
    window.setTimeout(TimerHandler(this.connection, this.connection.SendHttpRequest, "GET", _ResourceUrl + sLang, "", null), 0);
}

MainForm.prototype.OnUpdateResourceCallback = function()
{
    var text = this.connection.httpRequest.responseText;
    eval(text);
    this.UpdateUI();
}

MainForm.prototype.SetSelectedLanguage = function(sltLanguage, sLang)
{
    var nIndex = -1;
    for (i = 0; i< sltLanguage.options.length; i++)
    {
        if (sltLanguage.options[i].value.toLowerCase() == sLang.toLowerCase())
        {
		    nIndex = i;
		    break;
		}
    }

    sltLanguage.selectedIndex = nIndex;
}

MainForm.prototype.FormsLanguageSelectionChanged = function()
{
    var languageSelector = this.sltLang;
    
    if (languageSelector.selectedIndex != -1)
    {
        var sLang = languageSelector.options[languageSelector.selectedIndex].value;
        if (sLang.toLowerCase() != sCurrentLang.toLowerCase())
        {
            this.SetSelectedLanguage(this.sltLangIWA, sLang);
            this.UpdateResource(sLang);
            
            // Disable languageSelector & Sign-in buttons here.
            // We will reenable them once the call to fetch
            // language resources is complete.
            this.DisableFormsLanguageSelector();
            this.DisableFormsSignInButton();
            
            sCurrentLang = sLang;
        }
    }
}

MainForm.prototype.SendDiffAccountSignIn = function() {
    var sUserName = this.fldUserName.value;
    if (sUserName == this.userNameTips) {
        sUserName = "";
    }

    // Make this work with IWA auth?
    // WebTicketManager requires credential
    // to be null in that case, so can't specify username.
    if (authToUse == AuthenticationType.Forms) {
        var sPassword = this.fldPassword.value;
        try {
            var credential = new UserCredential(sUserName, sPassword);
        }
        catch (e) {
            if (e.name == "ArgumentNullException" || e.name == "ArgumentException") {
                this.ShowErrorMessage(msgUserNamePasswordIncorrect);
                return;
            }
        }
    }

    try {
        this.webTicketManager.AcquireTicket(authToUse, credential, Delegate(this, this.AcquireTicketCallback));

        // Disable the Sign-in button, so the user cannot sign-in again
        // until we receive the response to acquire ticket.
        this.DisableFormsSignInButton();
    }
    catch (e) {
        this.ShowErrorMessage(msgOperationFailed);
    }
}

MainForm.prototype.AcquireTicketCallback = function (webTicketInfo, exception) {
    if (webTicketInfo == null && exception != null) {
        this.EnableSignInButtons();
        if (exception.name == "AuthenticationException") {
            var errorMsg = "";
            switch (exception.ErrorId) {
                case MsDiagnosticErrorId.UserIsNotSipEnabled:
                    errorMsg = msgUserIsNotSipEnabled;
                    break;
                case MsDiagnosticErrorId.UserNamePasswordIncorrect:
                    errorMsg = msgUserNamePasswordIncorrect;
                    break;
                case MsDiagnosticErrorId.UserPasswordExpired:
                    errorMsg = msgUserPasswordExpired;
                    break;
                case MsDiagnosticErrorId.UserAccountDisabled:
                    errorMsg = msgUserAccountDisabled;
                    break;
                case MsDiagnosticErrorId.WsFedPassiveNotSignedIn:
                case MsDiagnosticErrorId.WsFedPassiveMaybeState:
                case MsDiagnosticErrorId.WsFedPassiveTicketExpired:
                case MsDiagnosticErrorId.WsFedPassiveTicketInvalid:
                    parent.window.location = this.webTicketManager.OnlineAuthPage + "?lc=" + LcId + "&redirectUrl=" + DialInEncodedUrl;
                    return; //handled sucessfully
                default:
                    errorMsg = msgOperationFailed;
                    break;
            }
            this.ShowErrorMessage(errorMsg);
        }
        else {
            this.ShowErrorMessage(msgOperationFailed);
        }
        return;
    } else if (webTicketInfo != null && exception == null) {
        this.dataUser.Status = ClientStatus.LoggedIn;
        this.ResetTimer();

        // We successfully acquired the web-ticket,
        // stash it away.
        if (webTicketInfo.WebTicket() != null) {
            this.dataUser.WebTicket = webTicketInfo.WebTicket();
        }

        // Get Pin info here
        this.GetUserPinInfo();
    }
    else {
        this.EnableSignInButtons();
        this.ShowErrorMessage(msgOperationFailed);
        return;
    }
}

MainForm.prototype.EnableSignInButtons = function () {
    // Enable the Sign-in buttons again:
    // we enable both Sign-in button on Forms auth page
    // and the Sign-in button on IWA auth page.
    
    var signInButtonIWA = document.getElementById("txtIWASigninButton");
    signInButtonIWA.disabled = false;
    
    var signInButtonForms = document.getElementById("txtSignInButton");
    signInButtonForms.disabled = false;
}

MainForm.prototype.DisableFormsSignInButton = function () {
    var signInButtonForms = document.getElementById("txtSignInButton");
    signInButtonForms.disabled = true;
}

MainForm.prototype.DisableIWASignInButton = function () {
    var signInButtonIWA = document.getElementById("txtIWASigninButton");
    signInButtonIWA.disabled = true;
}

MainForm.prototype.EnableLanguageSelectors = function () {
    this.sltLang.disabled = false;
    this.sltLangIWA.disabled = false;
}

MainForm.prototype.DisableFormsLanguageSelector = function () {
    this.sltLang.disabled = true;
}

MainForm.prototype.DisableIWALanguageSelector = function () {
    this.sltLangIWA.disabled = true;
}

MainForm.prototype.CancelFormSignIn = function() {
    this.dataUser.Status = ClientStatus.Anonymous;
    this.ClearAllMessage();

    if (originalAuthToUse == AuthenticationType.IWA) 
    {
        // switch back from Forms to IWA
        authToUse = AuthenticationType.IWA;
        this.trPassword.style.display = "none";
        txtSignInDiff.style.display = "";
    }
    this.DisplayForm();
}

MainForm.prototype.FormSignIn = function () {

    // Remove the "sign in with a different account"
    // and clear all messages
    txtSignInDiff.style.display = "none";
    this.ClearAllMessage();

    if (authToUse == AuthenticationType.IWA) {
        // we are switching from IWA to other, set flag to reset
        // sign-in method to default after sign-out
        originalAuthToUse = AuthenticationType.IWA;

        if (availableAuthTypes.Get(AuthenticationType.WsFedPassive) == true) { // If WsFed is available use that over Forms
            authToUse = AuthenticationType.WsFedPassive;
        }
        else { // this button would have been disabled if Forms was not available

            // we are switching from IWA to Forms sign-in, must set the auth type
            // correct. Also the password field has to be present again. It used
            // to be set to not diaplayed for IWA.
            authToUse = AuthenticationType.Forms;
            // Display the password field
            this.trPassword.style.display = "";

            this.dataUser.Status = ClientStatus.FormLogin;
        }
    }

    this.DisplayForm();
}

//<summary>
// Cancel IWA, Forms or WsFed sign-in attempt
// </summary>
MainForm.prototype.CancelIWALogin = function( )
{
    this.dataUser.Status = ClientStatus.Anonymous;
    this.ClearAllMessage( );
    this.DisplayForm();
    this.RevertToDefaultSignInMethod();
}

MainForm.prototype.IWALanguageSelectionChanged = function()
{
    var languageSelector = this.sltLangIWA;
    
    if (languageSelector.selectedIndex != -1)
    {
        var sLang = languageSelector.options[languageSelector.selectedIndex].value;
        if (sLang.toLowerCase() != sCurrentLang.toLowerCase())
        {
            this.SetSelectedLanguage(this.sltLang, sLang);
            this.UpdateResource(sLang);
            
            // Disable languageSelector & Sign-in buttons here.
            // We will reenable them once the call to fetch
            // language resources is complete.
            this.DisableIWALanguageSelector();
            this.DisableIWASignInButton();
            
            sCurrentLang = sLang;
        }
    }
}

MainForm.prototype.SendIwaOrWsFedSignIn = function () {

    try {

        if (authToUse == AuthenticationType.WsFedPassive) {
            // Simulate a 401 error to send Dial In Page to Passive Auth component. On return, it will have the cookie name
            var exception = new Exception();
            exception.name = "AuthenticationException";
            exception.ErrorId = MsDiagnosticErrorId.WsFedPassiveNotSignedIn;
            this.AcquireTicketCallback(null, exception);
            return;
        }
        else {
            var credential = null; // Required for IWA.

            this.webTicketManager.AcquireTicket(authToUse, credential, Delegate(this, this.AcquireTicketCallback));
        }

        // Disable the Sign-in button, so the user cannot sign-in again
        // until we receive the response to acquire ticket.
        this.DisableIWASignInButton();
    }
    catch (e)
    {
        this.ShowErrorMessage(msgOperationFailed);
    }
}

MainForm.prototype.RedirectTo = function(sURL)
{
    if (IsStringNullOrEmpty(sURL) == true)
    {
        // No URL was specified for the redirect, just return.
        return;
    }
    
    window.location = sURL;
}

MainForm.prototype.SendResetConf = function( )
{
    this.ResetTimer( );

    this.dataUser.Status = ClientStatus.LoggedIn;
    this.dataUser.ActiveObject = ActiveObjectEnum.Conference;
    this.ClearAllMessage( );
    
    if (this.dataUser.WebTicket == null)
    {
        this.ShowErrorMessage(msgSessionTimout);
        return;
    }

    var reqConfCmd = _requestsHeader + StringFormat(_requestsShell, _ResetConfInfoCommand);
    
    if (this.RequestInProgress != RequestInProgress.None)
    {
        this.ShowErrorMessage(msgRequestInProgress);
        return;
    }
    this.RequestInProgress = RequestInProgress.SendResetConf;
    window.setTimeout(TimerHandler(this.connection, this.connection.SendHttpRequest, "POST", _DialHandlerUrl, reqConfCmd, this.dataUser.WebTicket), 0);
}

MainForm.prototype.OnSendResetConfCallback = function()
{
    var oResult = this.connection.ProcessGetConferenceResponse( );
    var sPhoneConferenceID = oResult.PhoneConferenceID;
    var sMeetingURL = oResult.MeetingURL;
    this.ClearMessage( );
    
    switch(this.connection.ResponseStatus)
    {
        case ResponseStatus.ConferenceInfoAvailable:
            this.SetPublicMeetingInfo(sPhoneConferenceID, sMeetingURL);
            this.ShowSuccessMessage(msgResetConfSuccess);
            break;
        case ResponseStatus.PublicMeetingNotAllowed:
            this.SetPublicMeetingNotAllowedInfo();
            this.ShowErrorMessage(msgPublicMeetingNotAllowed);
            break;
        default:
            // ResponseStatus.Exception will end up here.
            this.SendResetConfFailed();
            break;
    }
}

MainForm.prototype.SendResetConfFailed = function()
{
    this.HidePublicMeetingDetails();
    this.ShowErrorMessage(msgOperationFailed);
}

MainForm.prototype.CancelResetConf = function( )
{
    this.ResetTimer( );
    this.dataUser.Status = ClientStatus.LoggedIn;
    this.ClearAllMessage( );
    this.DisplayForm( );
}

MainForm.prototype.CancelNewPin = function( )
{
    if (this.dataUser.Status == ClientStatus.PinNotConfigured)
    {
        this.SignOut( );
    }
    else
    {
        this.dataUser.Status = ClientStatus.LoggedIn;
        this.ClearAllMessage();
        this.DisplayForm();
    }
}

MainForm.prototype.SendNewPin = function( )
{
    this.ResetTimer( );
    this.dataUser.ActiveObject = ActiveObjectEnum.UserPin;     
    this.ClearAllMessage( );
    
    if ((IsStringNullOrEmpty(this.fldPin.value) == true) && (IsStringNullOrEmpty(this.fldPin2.value) == true))
    {
        this.ShowErrorMessage(msgPinBlank);
        return;
    }
    else if(this.fldPin.value != this.fldPin2.value)
    {
        this.ShowErrorMessage(msgPinNoMatch);
        return;
    }
    
    var sPin = EscapeXmlSensitveChar(this.fldPin.value);
    
    if (this.dataUser.WebTicket == null)
    {
        this.ShowErrorMessage(msgSessionTimout);
        return;
    }

    var sResetReq = StringFormat(_ResetUserPinInfoCommand, sPin);
    var reqSetUserInfo = _requestsHeader + StringFormat(_requestsShell, sResetReq);

    if (this.RequestInProgress != RequestInProgress.None)
    {
        this.ShowErrorMessage(msgRequestInProgress);
        return;
    }
    this.RequestInProgress = RequestInProgress.SendNewPin;
    window.setTimeout(TimerHandler(this.connection, this.connection.SendHttpRequest, "POST", _DialHandlerUrl, reqSetUserInfo, this.dataUser.WebTicket), 0);
}

MainForm.prototype.OnSendNewPinCallback = function()
{
    var oResult = this.connection.ProcessResetUserPinResponse( );
    var sExpiredDays = oResult.ExpiredInDays;
    this.ClearMessage( );
    
    switch(this.connection.ResponseStatus)
    {
        case ResponseStatus.PinChanged:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.ClearMessage( ); 
            if(sExpiredDays == "0")
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Expired;
            }
            else if(sExpiredDays == "-1")
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Normal;
                this.spnExpiredInDays.innerHTML = msgPinNeverExpired + " ";
                this.spnPinDays.innerHTML = "";
            }
            else
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Normal;
                this.spnExpiredInDays.innerHTML = sExpiredDays + " ";
                if(sExpiredDays == "1")
                {
                    this.spnPinDays.innerHTML = txtPINDay_res;
                }
                else
                {
                    this.spnPinDays.innerHTML = txtPINDays_res;
                }
            }
            this.ShowSuccessMessage(msgPinChangeSucess);
            break;
        case ResponseStatus.PinLocked:
            this.ShowErrorMessage(msgPinLockedWhenReset);
            break;
        case ResponseStatus.CertificateNotAvailable:
           this.ShowErrorMessage(msgNoServerCert);
           break;
        case ResponseStatus.InvalidePin:
            this.ShowErrorMessage(msgInvalidPinGeneric);
            break;
        case ResponseStatus.InvalidPinNumericOnly:
            this.ShowErrorMessage(msgInvalidPinNumericOnly);
            break;
        case ResponseStatus.InvalidPinConsecutiveDigits:
            this.ShowErrorMessage(msgInvalidPinConsecutiveDigits);
            break;
        case ResponseStatus.InvalidPinRepeatingDigit:
            this.ShowErrorMessage(msgInvalidPinRepeatingDigit);
            break;
        case ResponseStatus.InvalidPinMinimumLength:
            var pinLengthError = msgInvalidPinMinimumLength.replace(/%0/g, oResult.MinPinLength);
            this.ShowErrorMessage(pinLengthError);
            break;
        case ResponseStatus.InvalidPinMaximumLength:
           var pinLengthError = msgInvalidPinMaximumLength.replace(/%0/g, nMaxPinLength);
           this.ShowErrorMessage(pinLengthError);
           break;
        case ResponseStatus.InvalidPinHistory:
            this.ShowErrorMessage(msgInvalidPinHistory);
            break;
        case ResponseStatus.InvalidPinPhone:
            this.ShowErrorMessage(msgInvalidPinPhone);
            break;
        case ResponseStatus.PinExpired:
            this.ShowErrorMessage(msgInvalidPinExpired);
            break;
        case ResponseStatus.PhoneNotConfig:
            this.ClearMessage();
            this.ShowErrorMessage(msgPhoneNotConfig);
            break;
        case ResponseStatus.BadPin:
            this.ClearMessage();
            this.ShowErrorMessage(msgBadPin);
            break;
        default:
            // ResponseStatus.Exception will end up here.
            this.ShowErrorMessage(msgOperationFailed);
            break;
    }
}

MainForm.prototype.GetUserPinInfo = function() {
    this.dataUser.ActiveObject = ActiveObjectEnum.UserPin;
    
    if (this.dataUser.WebTicket == null)
    {
        this.ShowErrorMessage(msgSessionTimout);
        return;
    }
    
    var reqUserInfo = _requestsHeader + StringFormat(_requestsShell, _GetUserPinInfoCommand);

    if (this.RequestInProgress != RequestInProgress.None)
    {
        this.ShowErrorMessage(msgRequestInProgress);
        return;
    }
    this.RequestInProgress = RequestInProgress.GetUserPinInfo;
    window.setTimeout(TimerHandler(this.connection, this.connection.SendHttpRequest, "POST", _DialHandlerUrl, reqUserInfo, this.dataUser.WebTicket), 0);
}

MainForm.prototype.OnGetUserPinInfoCallback = function()
{
    var oResult = this.connection.ProcessGetUserPinResponse();
    var sExpiredDays = oResult.ExpiredInDays;
    this.ClearMessage();
    this.spanUserID.innerHTML = oResult.DisplayName;
    
    // GetUserPinInfo is the first call to the Server after
    // the user logs in.  Set the text for the Pin Complexity
    // requirements based on what was in our response.
    // This will ensure that we are able to display these
    // requirements to the user whenever he/she goes to
    // change his/her PIN.
    var sMinPinLength = oResult.MinPinLength;
    var sAllowCommonPatterns = oResult.AllowCommonPatterns;
    var sHistoryCount = oResult.HistoryCount;
    this.SetPinComplexityRequirementsText(sMinPinLength, sAllowCommonPatterns, sHistoryCount);

    switch (this.connection.ResponseStatus) {
        case ResponseStatus.PinNotAvailble:
            this.dataUser.Status = ClientStatus.PinNotConfigured;
            this.fldPin.value = "";
            this.fldPin2.value = "";
            this.ClearMessage(); //for the change pin form
            break;
        case ResponseStatus.PinEnabled:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.ClearMessage( ); 
            if(sExpiredDays == "0")
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Expired;
            }
            else if(sExpiredDays == "-1")
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Normal;
                this.spnExpiredInDays.innerHTML = msgPinNeverExpired + " ";
                this.spnPinDays.innerHTML = "";
            }
            else
            {
                this.dataUser.UserPinPanel = UserPinPanelEnum.Normal;
                this.spnExpiredInDays.innerHTML = sExpiredDays + " ";
                if(sExpiredDays == "1")
                {
                    this.spnPinDays.innerHTML = txtPINDay_res;
                }
                else
                {
                    this.spnPinDays.innerHTML = txtPINDays_res;
                }
            }
            break;
        case ResponseStatus.PinLocked:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.dataUser.UserPinPanel = UserPinPanelEnum.Locked;
            this.ClearMessage();
            break;
        case ResponseStatus.PinExpired:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.dataUser.UserPinPanel = UserPinPanelEnum.Expired;
            this.ClearMessage();
            break;
        case ResponseStatus.Wave13User:
            // GetUserPinInfo is the first call to server after login:
            // check if the logged-in user is a Wave 13 user.  If yes,
            // sign them out and redirect them to the CWA 13 Dialin Page.
            this.dataUser.Status = ClientStatus.Anonymous;
            this.ClearMessage();
            this.SignOut();
            this.RedirectTo(sWave13DialinURL);
            return;
        case ResponseStatus.Wave12User:
            // GetUserPinInfo is the first call to server after login:
            // check if the logged-in user is a Wave 12 user.  If yes,
            // sign them out and give them an appropriate error message
            // since there was no CAA/Dialin Page in Wave 12.
            this.dataUser.Status = ClientStatus.Anonymous;
            this.ClearMessage();
            this.SignOut();
            this.ShowErrorMessage(msgW12User);
            return;
        case ResponseStatus.PhoneNotConfig:
            this.dataUser.Status = ClientStatus.LoggedIn;
            this.dataUser.UserPinPanel = UserPinPanelEnum.PhoneNotConfigured;
            this.ClearMessage();
            this.ShowErrorMessage(msgPhoneNotConfig);
            return;
        default:
            // ResponseStatus.Exception will end up here.
            // In case of an error, hide the user's
            // Phone/Extension/Pin info.
            this.GetUserPinInfoFailed();
            break;
    }

    this.spnPhoneCleanNumber.innerHTML = oResult.PhoneNumber;
    this.spnPhoneExtensionNumber.innerHTML = oResult.PhoneExtension;
    if(this.connection.ResponseSubStatus == ResponseSubStatus.UsePhone)
    {
        if(oResult.PhoneExtension == "")
        {
            this.ShowPinPhoneOrExtentionMessage(msgPhoneExtNotConfig);
        }
        else
        {
            this.ShowPinPhoneOrExtentionMessage(msgPhoneExtDup);
        }
    }
    else
    {
        this.ClearPinPhoneOrExtentionMessage( );
    }
}

MainForm.prototype.GetUserPinInfoFailed = function()
{
    this.dataUser.UserPinPanel = UserPinPanelEnum.PhoneNotConfigured;
    this.ShowErrorMessage(msgOperationFailed);
}

MainForm.prototype.GetConferenceInfo = function( )
{
    this.dataUser.ActiveObject = ActiveObjectEnum.Conference;
    
    if (this.dataUser.WebTicket == null)
    {
        this.ShowErrorMessage(msgSessionTimout);
        return;
    }
    
    var reqConfInfo = _requestsHeader + StringFormat(_requestsShell, _GetConfInfoCommand);
    
    if (this.RequestInProgress != RequestInProgress.None)
    {
        this.ShowErrorMessage(msgRequestInProgress);
        return;
    }
    this.RequestInProgress = RequestInProgress.GetConferenceInfo;
    window.setTimeout(TimerHandler(this.connection, this.connection.SendHttpRequest, "POST", _DialHandlerUrl, reqConfInfo, this.dataUser.WebTicket), 0);    
}

MainForm.prototype.OnGetConferenceInfoCallback = function()
{
    var oResult = this.connection.ProcessGetConferenceResponse( );
    var sPhoneConferenceID = oResult.PhoneConferenceID;
    var sMeetingURL = oResult.MeetingURL;
    this.ClearMessage( );
    
    switch(this.connection.ResponseStatus)
    {
        case ResponseStatus.ConferenceInfoAvailable:
            this.SetPublicMeetingInfo(sPhoneConferenceID, sMeetingURL);
            break;
        case ResponseStatus.PublicMeetingNotAllowed:
            this.SetPublicMeetingNotAllowedInfo();
            this.ShowErrorMessage(msgPublicMeetingNotAllowed);
            break;
        default:
            // ResponseStatus.Exception will end up here.
            // In case of an error, hide the Public Meeting details.
            this.GetConferenceInfoFailed();
            break;
    }
}

MainForm.prototype.GetConferenceInfoFailed = function()
{
    this.SetPublicMeetingNotAllowedInfo();
    this.ShowErrorMessage(msgOperationFailed);
}

MainForm.prototype.OnError = function(errorCode, exception) 
{
    // Note: We have the exception if needed.
    
    // First check to see if the request failed with 401/Unauthorized
    // and if it did, check if its due to the web-ticket having expired.
    // If it is, we need to force the user to sign back in.
    if (errorCode == 401)
    {
        var msDiagHeader = this.connection.GetResponseHeader("X-Ms-diagnostics");
        if (msDiagHeader)
        {
            // Get the error ID from the MS-Diag header.
            var indexOfComma = msDiagHeader.indexOf(";");
            var errorId = msDiagHeader.slice(0, indexOfComma);
            
            if (errorId == MsDiagnosticErrorId.TicketExpired)
            {
                this.dataUser.Status = ClientStatus.Anonymous;
                this.ClearMessage();
                this.SignOut();
                this.ShowErrorMessage(msgSessionTimout);
                return;
            }
        }
    }
    
    switch (this.RequestInProgress) {
        case RequestInProgress.UnlockPin:
            this.ShowErrorMessage(msgOperationFailed);
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.UpdateResource:
            this.ShowErrorMessage(msgOperationFailed);
            this.RequestInProgress = RequestInProgress.None;
            this.EnableLanguageSelectors();
            this.EnableSignInButtons();
            break;
        case RequestInProgress.SendResetConf:
            this.SendResetConfFailed();
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.SendNewPin:
            this.ShowErrorMessage(msgOperationFailed);
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.GetUserPinInfo:
            this.GetUserPinInfoFailed();
            this.RequestInProgress = RequestInProgress.None;
            
            // Initiate the GetConference call.
            this.GetConferenceInfo();
            break;
        case RequestInProgress.GetConferenceInfo:
            this.GetConferenceInfoFailed();
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.None:
        default:
            // This should never happen.
            this.ShowErrorMessage(msgOperationFailed);
            this.RequestInProgress = RequestInProgress.None;
            break;
    }
    
    this.DisplayForm();
}

MainForm.prototype.OnSuccess = function() 
{
    // Note: When we initiate a request e.g. UnlockPin,
    // we set some state which is later used to display
    // the response in the appropriate section of the page
    // (both in success and error cases) at the time of
    // request completion i.e. in the error/success callbacks.
    // So make sure the calls/callbacks are matched and no other
    // request can come inbetween and modify this state.
    switch (this.RequestInProgress) {
        case RequestInProgress.UnlockPin:
            this.OnUnlockPinCallback();
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.UpdateResource:
            this.OnUpdateResourceCallback();
            this.RequestInProgress = RequestInProgress.None;
            this.EnableLanguageSelectors();
            this.EnableSignInButtons();
            break;
        case RequestInProgress.SendResetConf:
            this.OnSendResetConfCallback();
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.SendNewPin:
            this.OnSendNewPinCallback();
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.GetUserPinInfo:
            this.OnGetUserPinInfoCallback();
            this.RequestInProgress = RequestInProgress.None;
            
            if (this.dataUser.Status != ClientStatus.Anonymous)
            {
                // If the user is still signed in after
                // GetUserPinInfo(), then this is not a
                // W12 or W13 user:
                // initiate the GetConferenceInfo call.
                this.GetConferenceInfo();
            }
            break;
        case RequestInProgress.GetConferenceInfo:
            this.OnGetConferenceInfoCallback();
            this.RequestInProgress = RequestInProgress.None;
            break;
        case RequestInProgress.None:
        default:
            // This should never happen.
            this.ShowErrorMessage(msgOperationFailed);
            this.RequestInProgress = RequestInProgress.None;
            break;
    }
    
    this.DisplayForm();
}

MainForm.prototype.ShowPinPhoneOrExtentionMessage = function(sMessage) 
{
	this.pinPhoneOrExtensionMessage.className = "errorMessage";
	this.pinPhoneOrExtensionMessage.innerHTML = '<img src="/dialin/client/warningIcon.gif" title="' + tooltipWarning + '" class="warningIcon"/>' + sMessage;
}

MainForm.prototype.ClearPinPhoneOrExtentionMessage = function( ) 
{
	this.pinPhoneOrExtensionMessage.innerHTML = "";
}

MainForm.prototype.ShowErrorMessage = function(sMessage) {
    switch (this.dataUser.Status) {
        case ClientStatus.IwaOrWsFedLogin:
            this.iwaError.className = "errorMessage";
            this.iwaError.innerHTML = '<img src="/dialin/client/MSOL_NotificationError_16.png" title="' + tooltipError + '" class="warningIcon"/>' + sMessage;
            break;
        case ClientStatus.FormLogin:
            this.formError.className = "errorMessage";
            this.formError.innerHTML = '<img src="/dialin/client/MSOL_NotificationError_16.png" title="' + tooltipError + '" class="warningIcon"/>' + sMessage;
            break;
        case ClientStatus.LoggedIn:
            if (this.dataUser.ActiveObject == ActiveObjectEnum.UserPin) {
                this.pinMessage.className = "errorMessage";
                this.pinMessage.innerHTML = '<img src="/dialin/client/MSOL_NotificationError_16.png" title="' + tooltipError + '" class="warningIcon"/>' + sMessage;
            }
            else {
                this.confMessage.className = "errorMessage";
                this.confMessage.innerHTML = '<img src="/dialin/client/MSOL_NotificationError_16.png" title="' + tooltipError + '" class="warningIcon"/>' + sMessage;
            }
            break;
        case ClientStatus.ChangePin:
        case ClientStatus.PinNotConfigured:
            this.pinError.className = "errorMessage";
            this.pinError.innerHTML = '<img src="/dialin/client/MSOL_NotificationError_16.png" title="' + tooltipError + '" class="warningIcon"/>' + sMessage;
            break;
        case ClientStatus.Anonymous:
            this.basicError.className = "errorMessage";
            this.basicError.innerHTML = '<img src="/dialin/client/MSOL_NotificationError_16.png" title="' + tooltipError + '" class="warningIcon"/>' + sMessage;
            break;
    }
}

MainForm.prototype.ShowSuccessMessage = function(sMessage) 
{
    switch(this.dataUser.Status)
    {
        case ClientStatus.IwaOrWsFedLogin:
            this.iwaError.className = "successMessage";
            this.iwaError.innerHTML = sMessage;
            break;
        case ClientStatus.FormLogin:
            this.formError.className = "successMessage";
            this.formError.innerHTML = sMessage;
            break;
        case ClientStatus.LoggedIn:
            if(this.dataUser.ActiveObject == ActiveObjectEnum.UserPin)
            {
                this.pinMessage.className = "successMessage";
                this.pinMessage.innerHTML = sMessage;
            }
            else
            {
                this.confMessage.className = "successMessage";
                this.confMessage.innerHTML = sMessage;
            }
            break;
        case ClientStatus.ChangePin:
        case ClientStatus.PinNotConfigured:
            this.pinError.className = "successMessage";
            this.pinError.innerHTML = sMessage;
            break;
    }
}

MainForm.prototype.ClearMessage = function( ) 
{
    switch(this.dataUser.Status)
    {
        case ClientStatus.Anonymous:
            this.spanUserID.innerHTML = "";
            break;
        case ClientStatus.IwaOrWsFedLogin:
            this.iwaError.innerHTML = "";
            break;
        case ClientStatus.FormLogin:
            this.formError.innerHTML = "";
            break;
        case ClientStatus.LoggedIn:
            if(this.dataUser.ActiveObject == ActiveObjectEnum.UserPin)
                this.pinMessage.innerHTML = "";
            else
                this.confMessage.innerHTML = "";
            break;
        case ClientStatus.ChangePin:
        case ClientStatus.PinNotConfigured:
            this.pinError.innerHTML = "";
            break;
    }
}

MainForm.prototype.ClearAllMessage = function() 
{
    this.basicError.innerHTML = "";
    this.iwaError.innerHTML = "";
    this.formError.innerHTML = "";
    this.pinMessage.innerHTML = "";
    this.confMessage.innerHTML = "";
    this.pinError.innerHTML = "";
}

MainForm.prototype.OnURIOnFocus = function() 
{
    if (this.fldUserName.value == this.userNameTips) 
    {
        this.fldUserName.select();
        this.fldUserName.focus();
    }
}

MainForm.prototype.OnURIOnClick = function() 
{
    if (this.fldUserName.value == this.userNameTips) 
    {
        this.fldUserName.value = "";
        this.fldUserName.focus();
    }
}

MainForm.prototype.OnURIOnBlur = function() 
{
    if (this.fldUserName.value == "") 
    {
        this.fldUserName.value = this.userNameTips;
    }
}


function Connection( )
{
    this.httpRequest = this._CreateXMLHttpRequestObject( );
    this.ResponseStatus = ResponseStatus.Empty;
    this.ResponseSubStatus = ResponseSubStatus.Empty;
}

Connection.prototype.Initialize = function (owner) {
    this.requestOwner = owner;
}

//Return the response text of request
Connection.prototype.GetResponseXML = function()
{
    if (this.httpRequest != null)
    {
        var text = RemoveC0Chars(this.httpRequest.responseText);
        
        var xml = null;
        
        if (window.DOMParser)
        {        
            xml = new DOMParser().parseFromString(text, "application/xml");                                                           
        }
        else
        {            
            xml = this.httpRequest.responseXML;
            
            // Means IE can not parse this xml, we should remove the C0 Chars
            if (xml.childNodes.length == 0 && window.ActiveXObject)
            {
                try
                {
                    xml = new ActiveXObject("Microsoft.XMLDOM");
                    xml.loadXML(text);                                    
                }
                catch(e)
                {
                    //ShowException(e);
                }
                
            }
        } 
        
        return xml;
     }
     else
     {
        return null;
     }    
}

Connection.prototype.ProcessGetUserPinResponse = function() {
    var oRet = new Object();
    oRet.ExpiredInDate = null;
    oRet.DisplayName = null;
    oRet.PhoneNumber = "";
    oRet.PhoneExtension = "";
    oRet.MinPinLength = null;
    oRet.AllowCommonPatterns = null;
    oRet.HistoryCount = null;
    oRet.ErrorMsg = null;
    
    var xml = this.GetResponseXML();
    if (xml == null)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "NullXML";
        return oRet;
    }

    var xmlItem = xml.getElementsByTagName("cwaResponses");
    var xmlItems = xmlItem[0].childNodes;
    var xmlItem = null;
    
    try {
        //Find the first childnodes which != "#text"
        for (var i = 0; i < xmlItems.length; i++) {
            if (xmlItems[i].nodeName.toLowerCase() == "response") {
                xmlItem = xmlItems[i];
                break;
            }
        }

        var sStatus = xmlItem.getAttribute("status");
        var sSubStatus = xmlItem.getAttribute("substatus");	
        oRet.ExpiredInDays = xmlItem.getAttribute("expiredindays");
        oRet.DisplayName = xmlItem.getAttribute("displayname");
        oRet.PhoneNumber = xmlItem.getAttribute("phone");
        oRet.PhoneExtension = xmlItem.getAttribute("phoneext");
        oRet.MinPinLength = xmlItem.getAttribute("minpinlength");
        oRet.AllowCommonPatterns = xmlItem.getAttribute("allowcommonpatterns");
        oRet.HistoryCount = xmlItem.getAttribute("historycount");
        eval("this.ResponseStatus = ResponseStatus." + sStatus);
        eval("this.ResponseSubStatus = ResponseSubStatus." + sSubStatus);
    }
    catch (e)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "Error parsing XML: " + e.toString( );
    }

    return oRet;
}

Connection.prototype.ProcessResetUserPinResponse = function( )
{
    var oRet = new Object( );
    oRet.ExpiredInDate = null;
    oRet.MinPinLength = null;
    oRet.ErrorMsg = null;
    
    var xml = this.GetResponseXML();
    if (xml == null)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "NullXML";
        return oRet;
    }
        
    var xmlItem = xml.getElementsByTagName("cwaResponses");		 
    var xmlItems = xmlItem[0].childNodes;
    var xmlItem = null;
    
    try
    {              
        //Find the first childnodes which != "#text"
        for (var i = 0; i < xmlItems.length; i++)
        {
            if (xmlItems[i].nodeName.toLowerCase()== "response")
            {
                xmlItem = xmlItems[i];
                break;
            }
        }

        var sStatus = xmlItem.getAttribute("status");
        var sSubStatus = xmlItem.getAttribute("substatus");	
        oRet.ExpiredInDays = xmlItem.getAttribute("expiredindays");
        oRet.MinPinLength = xmlItem.getAttribute("minpinlength");
        eval("this.ResponseStatus = ResponseStatus." + sStatus);
        eval("this.ResponseSubStatus = ResponseSubStatus." + sSubStatus);
    }
    catch(e)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "Error parsing XML: " + e.toString( );
    }
    
    return oRet;
}

Connection.prototype.ProcessUnlockUserPinResponse = function( )
{
    var oRet = new Object( );
    oRet.ExpiredInDate = null;
    oRet.DisplayName = null;
    oRet.ErrorMsg = null;
    
    var xml = this.GetResponseXML();
    if (xml == null)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "NullXML";
        return oRet;
    }
        
    var xmlItem = xml.getElementsByTagName("cwaResponses");		 
    var xmlItems = xmlItem[0].childNodes;
    var xmlItem = null;
    
    try
    {              
        //Find the first childnodes which != "#text"
        for (var i = 0; i < xmlItems.length; i++)
        {
            if (xmlItems[i].nodeName.toLowerCase()== "response")
            {
                xmlItem = xmlItems[i];
                break;
            }
        }

        var sStatus = xmlItem.getAttribute("status");
        oRet.ExpiredInDays = xmlItem.getAttribute("expiredindays");
        eval("this.ResponseStatus = ResponseStatus." + sStatus);
    }
    catch(e)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "Error parsing XML: " + e.toString( );
    }
    
    return oRet;
}

Connection.prototype.ProcessGetConferenceResponse = function( )
{
    var oRet = new Object( );
    oRet.PhoneConferenceID = null;
    oRet.MeetingURL = null;
    oRet.ErrorMsg = null;
    
    var xml = this.GetResponseXML();
    if (xml == null)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "NullXML";
        return oRet;
    }
        
    var xmlItem = xml.getElementsByTagName("cwaResponses");		 
    var xmlItems = xmlItem[0].childNodes;
    var xmlItem = null;
    
    try
    {              
        //Find the first childnodes which != "#text"
        for (var i = 0; i < xmlItems.length; i++)
        {
            if (xmlItems[i].nodeName.toLowerCase()== "response")
            {
                xmlItem = xmlItems[i];
                break;
            }
        }

        var sStatus = xmlItem.getAttribute("status");
        oRet.PhoneConferenceID = xmlItem.getAttribute("phoneconferenceid");
        oRet.MeetingURL = xmlItem.getAttribute("meetingurl");
        eval("this.ResponseStatus = ResponseStatus." + sStatus);
    }
    catch(e)
    {
        this.ResponseStatus = ResponseStatus.Exception;
        oRet.ErrorMsg = "Error parsing XML: " + e.toString( );
    }
    
    return oRet;
}

Connection.prototype.GetResponseHeader = function(headerName)
{
    try
    {
        if (this.httpRequest != null && this.httpRequest.getResponseHeader(headerName))
        {
            return this.httpRequest.getResponseHeader(headerName);
        }
        else 
        {
            return null;
        }
    }
    catch(e)    
    {
        return null;        
    }
}

Connection.prototype.SendHttpRequest = function(type, url, data, ticket) {
    try {
        // Set up a new request to the Server.
        // Request is async.
        this.httpRequest.open(type, url, true);
        
        this.httpRequest.onreadystatechange = Delegate(this, this.OnReadyStateChanged);
        
        if (type == "POST") {
            this.httpRequest.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        }

        if (ticket != null) {
            // Pass the web-ticket as a request header.
            // See "Web Ticket Authentication for Web Components.docx" for web ticket header format            
            this.httpRequest.setRequestHeader("X-MS-WebTicket", ticket);
        }
        
        // Send the request to the Server
        // alongwith the data.
        this.httpRequest.send(data);
    } catch (e) {
        this.HttpRequestFailed(0, e);
    }
}

// Invoked when the state of the XmlHttpRequest object changes
Connection.prototype.OnReadyStateChanged = function () {
    var XMLHTTPREQUEST_COMPLETE = 4;
    var XMLHTTPREQUEST_OK = 200;

    // Note: 
    // 1. We get this parameter at the very first stage because of a Firefox bug.
    //    If we get this value at later stage, we will hit exception.
    // 2. In IE, we can only get this value when the readyState is 4. 
    var currentState = null;
    var httpCode = null;

    try {
        currentState = this.httpRequest.readyState;
    }
    catch (e) {
        this.HttpRequestFailed(0, e);
        return;
    }

    try {
        // For Safari 10.1.3 the end status is 0
        if (currentState == 0 || currentState == XMLHTTPREQUEST_COMPLETE) {
            try {
                httpCode = this.httpRequest.status;
            }
            catch (e) {
                //Trace(TraceType.Server, "http status error");
                httpCode = 377;
            }

            if (httpCode == XMLHTTPREQUEST_OK) {
                this.HttpRequestSucceeded();
            }
            else if (currentState != 0) {
                //Safari cannot get httpcode if network is down.
                if (!httpCode) {
                    httpCode = 404;
                }
                this.HttpRequestFailed(httpCode);
            }
        }
    }
    catch (e) {
        this.HttpRequestFailed(0, e);
    }
}

Connection.prototype.HttpRequestFailed = function (errorCode, exception)
{
    this.requestOwner.OnError(errorCode, exception);
}

Connection.prototype.HttpRequestSucceeded = function ()
{
    this.requestOwner.OnSuccess();
}

//Create xmlhttprequest object 
Connection.prototype._CreateXMLHttpRequestObject = function()
{
    try
    {
        var httpRequest = null;
        
        if( window.XMLHttpRequest ) // for none IE browsers
        {
            httpRequest = new XMLHttpRequest();
        }
        else if( window.ActiveXObject ) // for IE
        {
            var MSXML_XMLHTTP_PROGIDS = new Array(
                            'Microsoft.XMLHTTP',
                            'MSXML2.XMLHTTP.5.0',
                            'MSXML2.XMLHTTP.4.0',
                            'MSXML2.XMLHTTP.3.0',
                            'MSXML2.XMLHTTP'
                            );
        
            for (var i=0; i < MSXML_XMLHTTP_PROGIDS.length; i++)
            {
                httpRequest = new ActiveXObject(MSXML_XMLHTTP_PROGIDS[i]);
                
                if( httpRequest != null )
                {
                    break;
                }
            }
        }

        if(!httpRequest)
        {
            //TODO: Add Error treat here
            throw new CWA__Exception("Fatal", "Can not create a XmlHttpRequest Object!");
        }  
        
        return httpRequest;
    }
    catch(e)
    {
        this.ShowErrorMessage(msgBrowserNotSupported);
    }
}

function ShowForm(oForm, bShow)
{
    var sDisplay = bShow ? "" : "none";
    if(oForm.id == "usrInfoPanel")
    {
        if(bShow)
            sDisplay = "visible";
        else
            sDisplay = "hidden";
            
        if(oForm.style.visibility != sDisplay)
            oForm.style.visibility = sDisplay;
    }
    else if(oForm.style.display != sDisplay)
        oForm.style.display = sDisplay;
}

/**
 * EscapeXmlSensitveChar is a function used to 
 * convert '<' -> '&lt;' '>' -> '&gt;' '&' -> '&amp;' ''' -> '&apos;' '"' -> '&quot;'
 * for text data in XML format
 */
function EscapeXmlSensitveChar(str)
{
    var str = str + "";
	
    if(!str)
    {
        return "";
    }
    
    str = str.replace(/&/ig, "&amp;");
    str = str.replace(/</ig, "&lt;");
    str = str.replace(/>/ig, "&gt;");
    str = str.replace(/\'/ig, "&apos;");
    str = str.replace(/\"/ig, "&quot;");

    return EncodeC0Chars(str);
}

function IsStringNullOrEmpty(str)
{
    if (str == null || str.length == 0)
    {
        return true;
    }
    
    return false;
}

function StringFormat()
{
    var newString = arguments[0];
    
    for( var i = 0; i < arguments.length - 1; i++ )   
    {
        newString = newString.replace( "%" + i, arguments[i + 1] );
    }

    return newString;    
}

function ShowException(e) {
    var errorMessage;
    
    if (e instanceof Exception) {
        errorMessage = e.toString();
    }
    else {
        errorMessage = e.name + ":\n" + e.message + "\n";
    }
    
    mainWnd.ShowErrorMessage(errorMessage);
}

// Generate a regular expression to remove all C0 control chars
// This string will be &#(1|2|3....|1a); to pare the c0 chars

var C0PatternString = "&#(";

for (var i = 0; i < 32; i++)
{
    // /r/n is valid char, we just ignore this
    if (i == 10 || i == 13)
    {
        continue;
    }
    var str = "x" + i.toString(16) + "|" + i;
    if (i == 0)
    {
        C0PatternString = C0PatternString + str;
    }
    else
    {
        C0PatternString = C0PatternString + "|" + str;
    }    
}

C0PatternString = C0PatternString + ");";

var C0RegExp = new RegExp(C0PatternString, "ig");

/**
*  As browser's XML Dom parser can not parse C0 control chars, so we must remove this chars before we parse it
*/
function RemoveC0Chars(str)
{
    // We replace C0 control chars as a " "
    
    var str = str.replace(C0RegExp, " ");
    return str;    
}

/**
 * This function used to remove the leading and ending spaces for given string.
 */
function Trim(string)
{
    if (string == null) return "";

    // initiliaze regular expression to be used at first time
    if (Trim.SpaceRegExp == null)
    {
        // 12288 is the unicode of full shape space char
        // 160 is no-break space
        var spaceRegExp = "\\s|" + String.fromCharCode(12288) + "|" + String.fromCharCode(160);
        Trim.SpaceRegExp = 
            new RegExp("(^(" + spaceRegExp + ")*)|((" + spaceRegExp + ")*$)", "g");
    }

    return string.toString().replace(Trim.SpaceRegExp, "");
}

/**
*  Encode C0 Chars in a valid xml document
*/
function EncodeC0Chars(str)
{
    var str = str + "";
    
    if(!str)
    {
        return "";
    }
    else
	{
        // NOTE: String.fromCharCode(0) is the end of string. There is a bug in safari that will 
        // regard all "" as charcode(0). Such as string "cwa" in safari will be replaced as "&#x0c&#x0w&#x0a".
        for(var i = 1; i < 32; i++)
        {
            //eg. replace String.fromCharCode(0xB) with "&#xB;"
            str = str.replace(EncodeC0Chars._stringFromCharCode[i], "&#x" + EncodeC0Chars._hex[i] + ";");
        }
        
        return str; 
    }
}

(function()
{
    EncodeC0Chars._stringFromCharCode = [];
    EncodeC0Chars._hex =[];

    for(var i = 1; i < 32; ++i)
    {
        EncodeC0Chars._stringFromCharCode[i] = new RegExp(String.fromCharCode(i), "g");
        EncodeC0Chars._hex[i] = i.toString(16).toUpperCase();
    }
})();

function stringToBytes(str) {
    var ch, st, re = [];
    for (var i = 0; i < str.length; i++) {
        ch = str.charCodeAt(i);  // get char 
        st = [];                 // set up "stack"
        do {
            st.push(ch & 0xFF);  // push byte to stack
            ch = ch >> 8;          // shift value down by 1 byte
        }
        while (ch);
        // add stack contents to result
        // done because chars have "wrong" endianness
        re = re.concat(st.reverse());
    }
    // return an array of bytes
    return re;
}

// input is unicode string, output is the utf-8 encoded byte array
function unicodeStringToUTF8Bytes (string) {
    var output = new Array();

    for (var n = 0; n < string.length; n++) {

        var c = string.charCodeAt(n);

        if (c < 128) {
            output.push(c);
        }
        else if ((c > 127) && (c < 2048)) {
            output.push((c >> 6) | 192);
            output.push((c & 63) | 128);
        }
        else if ((c > 2047) && (c < 65536)) {
            output.push((c >> 12) | 224);
            output.push(((c >> 6) & 63) | 128);
            output.push((c & 63) | 128);
        }
        else if ((c > 65535) && (c < 1114112)) {
            output.push((c >> 18) | 240);
            output.push(((c >> 12) & 63) | 128);
            output.push(((c >> 6) & 63) | 128);
            output.push((c & 63) | 128);
        }
    }

    return output;
}

