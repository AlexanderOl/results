function setFloorplanFields(target) {
  const selection = target.options[target.selectedIndex];
  const homeId = target.dataset.homeId
  const bedroomsInput = document.querySelectorAll(`[data-disable-id='${homeId}'][data-attribute='bedrooms']`)[0];
  const bathsInput = document.querySelectorAll(`[data-disable-id='${homeId}'][data-attribute='baths']`)[0];
  const squareFootageInput = document.querySelectorAll(`[data-disable-id='${homeId}'][data-attribute='squareFootage']`)[0];
  const issueBtn = document.querySelectorAll(`[data-home-id='${homeId}'][data-target='#newTicketForm']`)[0];

  if (selection.text !== '--None--') {
    bedroomsInput.disabled = true;
    bedroomsInput.value = selection.dataset.bedCount;

    bathsInput.disabled = true;
    bathsInput.value = selection.dataset.bathCount;

    squareFootageInput.value = selection.dataset.squareFootage;
    squareFootageInput.setAttribute('min', selection.dataset.minSquareFootage);
    squareFootageInput.setAttribute('max', selection.dataset.maxSquareFootage);

    if (issueBtn) {
      issueBtn.dataset.floorplanid = selection.value;
    }
  } else {
    bedroomsInput.disabled = false;
    bathsInput.disabled = false;
    squareFootageInput.setAttribute('min', 200);
    squareFootageInput.setAttribute('max', 3500);

    if (issueBtn) {
      issueBtn.dataset.floorplanid = '';
    }
  }
}

function sleep(time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

window.addEventListener('load', () => {
  const formSubmits = document.querySelectorAll('button[type="submit"]')

  formSubmits.forEach((element) => {
    element.addEventListener('click', (event) => {
      event.preventDefault()

      const form = document.querySelector(`#${event.target.dataset.formId}`)

      event.target.disabled = true
      form.submit()

      sleep(3000).then(() => {
        event.target.disabled = false
      })
    })
  })

  const searchSubmit = document.getElementById('search-submit')

  if (searchSubmit !== null) {
    searchSubmit.addEventListener('click', () => {
      const searchQuery = document.getElementById('search-query')

      if (searchQuery !== null && searchQuery.value !== '') {
        const baseUrl = window.location.href.split('?')[0]
        const query = searchQuery.value
        window.location.href = `${baseUrl}?unit_number=${query}`
      }
    })
  }

  const floorplanSelections = document.querySelectorAll("[data-attribute='floorplan']")

  if (floorplanSelections.length > 0) {
    floorplanSelections.forEach((selection) => {
      selection.addEventListener('change',function(event){
        setFloorplanFields(event.target)
      })

      setFloorplanFields(selection)
    })
  }

  const issueBtns = document.querySelectorAll("[data-target='#newTicketForm']")

  issueBtns.forEach((btn) => {
    btn.addEventListener('click', function(event) {
      document.getElementById('home_id').value = event.target.dataset.homeId
      document.getElementById('floorplan_id').value = event.target.dataset.floorplanId
    })
  })

  const typeSelect = document.querySelector('#type-select')
  const issueOptions = {
    'Ticket::Property::MissingUrl': `This property is missing a link for the "pricing website" button`,
    'Ticket::Property::DuplicateHome': 'There are multiple homes with near-identical unit numbers at this property',
    'Ticket::Home::PricingIssue': 'This home is not allowing the rent cost to be set correctly',
    'Ticket::Floorplan::InvalidData': 'The bedroom count, bathroom count, or the square footage range of this floorplan is incorrect'
  }

  if (typeSelect != null) {
    typeSelect.addEventListener('change', (event) => {
      const issueDescription = document.querySelector('#issue-description')

      issueDescription.innerHTML = issueOptions[event.target.value]
    })
  }

  const issueSelect = document.getElementById('type-select')
  const issueDescription = document.querySelector('#issue-description')

  if (issueSelect != null && issueDescription != null) {
    issueDescription.innerHTML = issueOptions[issueSelect.value]
  }
})